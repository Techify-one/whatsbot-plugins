"""Pure OAuth helpers shared by routes and tests."""

from __future__ import annotations

import base64
import hashlib
import re
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


SUPPORTED_SCOPES = ("whatsbot:read", "whatsbot:write")
DEFAULT_SCOPE = " ".join(SUPPORTED_SCOPES)
_PKCE_VALUE_RE = re.compile(r"^[A-Za-z0-9._~-]{43,128}$")
_PKCE_CHALLENGE_RE = re.compile(r"^[A-Za-z0-9_-]{43,128}$")


def base64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def pkce_s256(verifier: str) -> str:
    return base64url(hashlib.sha256(verifier.encode("ascii")).digest())


def valid_pkce_verifier(verifier: str) -> bool:
    return bool(_PKCE_VALUE_RE.fullmatch(verifier))


def valid_pkce_challenge(challenge: str) -> bool:
    return bool(_PKCE_CHALLENGE_RE.fullmatch(challenge))


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def normalize_scope(raw_scope: str) -> str:
    requested = [part for part in (raw_scope or DEFAULT_SCOPE).split() if part]
    if any(scope not in SUPPORTED_SCOPES for scope in requested):
        raise ValueError("unsupported_scope")
    if "whatsbot:write" in requested and "whatsbot:read" not in requested:
        requested.insert(0, "whatsbot:read")
    ordered = [scope for scope in SUPPORTED_SCOPES if scope in requested]
    return " ".join(ordered or ["whatsbot:read"])


def valid_oauth_redirect(uri: str) -> bool:
    """Accept secure web callbacks and native-client loopback callbacks.

    Public MCP clients commonly use HTTPS callbacks (cloud clients) or an
    ephemeral localhost port (CLI/desktop clients).  Authorization codes are
    still bound to the exact registered URI and protected by mandatory PKCE.
    """
    if not isinstance(uri, str) or not uri or len(uri) > 2048:
        return False
    if any(ord(char) < 32 or ord(char) == 127 for char in uri):
        return False
    try:
        parsed = urlsplit(uri)
        port = parsed.port
    except (TypeError, ValueError):
        return False
    if (
        not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or bool(parsed.fragment)
    ):
        return False
    if parsed.scheme == "https":
        return True
    if parsed.scheme != "http":
        return False
    return parsed.hostname.lower() in {"127.0.0.1", "localhost", "::1"} and port is not None


def append_query(uri: str, **values: str) -> str:
    parsed = urlsplit(uri)
    query = parse_qsl(parsed.query, keep_blank_values=True)
    query.extend((key, value) for key, value in values.items() if value != "")
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(query), parsed.fragment))
