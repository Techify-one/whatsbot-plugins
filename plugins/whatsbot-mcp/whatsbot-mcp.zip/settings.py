"""Owner-configurable limits for the MCP surface."""

from pydantic import BaseModel, Field


class Settings(BaseModel):
    public_base_url: str = Field(
        default="https://seu-dominio.com.br",
        min_length=8,
        max_length=300,
        description=(
            "URL HTTPS pública usada no OAuth e no endpoint /mcp, sem barra final."
        ),
    )
    allow_write_tools: bool = Field(
        default=True,
        description=(
            "Permite ferramentas que enviam mensagens ou alteram contatos. "
            "Cada chamada ainda exige confirm=true e idempotency_key."
        ),
    )
    max_contacts: int = Field(
        default=25,
        ge=1,
        le=100,
        description="Máximo de contatos devolvidos por pesquisa.",
    )
    max_messages: int = Field(
        default=50,
        ge=1,
        le=200,
        description="Máximo de mensagens devolvidas por conversa.",
    )
    max_text_chars: int = Field(
        default=4000,
        ge=100,
        le=12000,
        description="Limite de caracteres para mensagens e notas criadas pelo MCP.",
    )
