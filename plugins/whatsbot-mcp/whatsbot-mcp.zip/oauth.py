"""OAuth 2.1 authorization server and public MCP resource.

The implementation supports standards-based public MCP clients: authorization
code flow, mandatory PKCE S256, dynamic client registration, rotating refresh
tokens, HTTPS callbacks, and native-client loopback callbacks. OAuth and
owner-managed MCP tokens authorize only root ``/mcp`` and are never accepted
by the core WhatsBot middleware.
"""

from __future__ import annotations

from collections import deque
import hmac
import html
import json
import secrets
import time
from typing import Any
from urllib.parse import urlsplit

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from sqlalchemy import text

from plugins.context import make_plugin_db
from server.auth import generate_token, hash_password

from .access_tokens import validate_access_token as validate_managed_access_token
from .oauth_core import (
    DEFAULT_SCOPE,
    SUPPORTED_SCOPES,
    append_query,
    normalize_scope,
    pkce_s256,
    token_hash,
    valid_oauth_redirect,
    valid_pkce_challenge,
    valid_pkce_verifier,
)
from .protocol import error
from .routes import handle_mcp_request, mcp_get_response


OAUTH_PREFIX = "/api/auth/whatsbot-mcp/oauth"
AUTHORIZE_PATH = OAUTH_PREFIX + "/authorize"
TOKEN_PATH = OAUTH_PREFIX + "/token"
REGISTER_PATH = OAUTH_PREFIX + "/register"
ACCESS_TOKEN_TTL = 60 * 60
REFRESH_TOKEN_TTL = 30 * 24 * 60 * 60
AUTH_CODE_TTL = 5 * 60
_CONFIG_PREFIX = "plugin.whatsbot_mcp."

_runtime_settings: Any | None = None
_oauth_attempts: dict[str, deque[float]] = {}
_registration_attempts: dict[str, deque[float]] = {}


class OAuthError(ValueError):
    def __init__(self, code: str, description: str, status: int = 400):
        super().__init__(description)
        self.code = code
        self.description = description
        self.status = status


def _now() -> int:
    return int(time.time())


def _setting(name: str, default: Any) -> Any:
    from db.repositories import config_repo

    return config_repo.get(_CONFIG_PREFIX + name, default)


def _base_url(request: Request) -> str:
    configured = str(
        _setting("public_base_url", "https://seu-dominio.com.br") or ""
    ).strip().rstrip("/")
    try:
        parsed = urlsplit(configured)
        if parsed.scheme == "https" and parsed.netloc and not parsed.query and not parsed.fragment:
            return configured
    except ValueError:
        pass
    forwarded_proto = request.headers.get("x-forwarded-proto", "").split(",")[0].strip()
    scheme = forwarded_proto if forwarded_proto in ("http", "https") else request.url.scheme
    host = request.headers.get("x-forwarded-host", "").split(",")[0].strip()
    host = host or request.headers.get("host", "")
    return f"{scheme}://{host}".rstrip("/")


def _resource(request: Request) -> str:
    return _base_url(request) + "/mcp"


def core_bearer_token() -> str:
    """Return the core panel token for server-internal API calls only."""
    settings = _runtime_settings
    if settings is None:
        return ""
    password_hash = settings.get("web_password_hash", "")
    salt = settings.get("web_password_salt", "")
    if not password_hash or not salt:
        return ""
    return generate_token(password_hash, salt)


def _json_no_store(payload: dict[str, Any], status: int = 200) -> JSONResponse:
    return JSONResponse(
        payload,
        status_code=status,
        headers={"Cache-Control": "no-store", "Pragma": "no-cache"},
    )


def _oauth_error(exc: OAuthError) -> JSONResponse:
    return _json_no_store(
        {"error": exc.code, "error_description": exc.description},
        status=exc.status,
    )


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for", "")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def _password_attempt_allowed(ip: str) -> bool:
    now = time.time()
    attempts = _oauth_attempts.setdefault(ip, deque(maxlen=10))
    while attempts and now - attempts[0] > 15 * 60:
        attempts.popleft()
    return len(attempts) < 5


def _record_password_failure(ip: str) -> None:
    _oauth_attempts.setdefault(ip, deque(maxlen=10)).append(time.time())


def _registration_allowed(ip: str) -> bool:
    now = time.time()
    attempts = _registration_attempts.setdefault(ip, deque(maxlen=40))
    while attempts and now - attempts[0] > 60 * 60:
        attempts.popleft()
    if len(attempts) >= 20:
        return False
    attempts.append(now)
    return True


def _verify_owner_password(password: str) -> bool:
    settings = _runtime_settings
    if settings is None or not password:
        return False
    salt = settings.get("web_password_salt", "")
    expected = settings.get("web_password_hash", "")
    if not salt or not expected:
        return False
    return hmac.compare_digest(hash_password(password, salt), expected)


def _cleanup_oauth_rows(conn, now: int) -> None:
    conn.execute(
        text("DELETE FROM plugin_whatsbot_mcp_oauth_codes WHERE expires_at < :now"),
        {"now": now},
    )
    conn.execute(
        text(
            "DELETE FROM plugin_whatsbot_mcp_oauth_tokens "
            "WHERE refresh_expires_at < :now"
        ),
        {"now": now},
    )


def _register_client(client_name: str, redirect_uris: list[str]) -> dict[str, Any]:
    now = _now()
    client_id = "wbot_" + secrets.token_urlsafe(24)
    with make_plugin_db() as conn:
        _cleanup_oauth_rows(conn, now)
        count = conn.execute(
            text("SELECT COUNT(*) FROM plugin_whatsbot_mcp_oauth_clients")
        ).scalar_one()
        if int(count or 0) >= 1000:
            raise OAuthError("invalid_client_metadata", "Limite de clientes atingido.", 429)
        conn.execute(
            text(
                "INSERT INTO plugin_whatsbot_mcp_oauth_clients "
                "(client_id, client_name, redirect_uris_json, created_at) "
                "VALUES (:client_id, :client_name, :redirects, :created_at)"
            ),
            {
                "client_id": client_id,
                "client_name": client_name,
                "redirects": json.dumps(redirect_uris, ensure_ascii=False),
                "created_at": now,
            },
        )
    return {
        "client_id": client_id,
        "client_id_issued_at": now,
        "client_name": client_name,
        "redirect_uris": redirect_uris,
        "grant_types": ["authorization_code", "refresh_token"],
        "response_types": ["code"],
        "token_endpoint_auth_method": "none",
    }


def _get_client(client_id: str) -> dict[str, Any] | None:
    if not client_id or len(client_id) > 200:
        return None
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT client_id, client_name, redirect_uris_json "
                "FROM plugin_whatsbot_mcp_oauth_clients WHERE client_id = :client_id"
            ),
            {"client_id": client_id},
        ).mappings().first()
    if not row:
        return None
    try:
        redirects = json.loads(row["redirect_uris_json"])
    except (TypeError, json.JSONDecodeError):
        return None
    return {**dict(row), "redirect_uris": redirects}


def _save_code(
    code: str,
    client_id: str,
    redirect_uri: str,
    code_challenge: str,
    scope: str,
    resource: str,
) -> None:
    with make_plugin_db() as conn:
        _cleanup_oauth_rows(conn, _now())
        conn.execute(
            text(
                "INSERT INTO plugin_whatsbot_mcp_oauth_codes "
                "(code_hash, client_id, redirect_uri, code_challenge, scope, resource, expires_at) "
                "VALUES (:code_hash, :client_id, :redirect_uri, :challenge, :scope, :resource, :expires_at)"
            ),
            {
                "code_hash": token_hash(code),
                "client_id": client_id,
                "redirect_uri": redirect_uri,
                "challenge": code_challenge,
                "scope": scope,
                "resource": resource,
                "expires_at": _now() + AUTH_CODE_TTL,
            },
        )


def _get_code(code: str) -> dict[str, Any] | None:
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT client_id, redirect_uri, code_challenge, scope, resource "
                "FROM plugin_whatsbot_mcp_oauth_codes "
                "WHERE code_hash = :code_hash AND expires_at >= :now "
            ),
            {"code_hash": token_hash(code), "now": _now()},
        ).mappings().first()
    return dict(row) if row else None


def _consume_code(code: str, client_id: str) -> bool:
    with make_plugin_db() as conn:
        result = conn.execute(
            text(
                "DELETE FROM plugin_whatsbot_mcp_oauth_codes "
                "WHERE code_hash = :code_hash AND client_id = :client_id "
                "AND expires_at >= :now"
            ),
            {
                "code_hash": token_hash(code),
                "client_id": client_id,
                "now": _now(),
            },
        )
    return result.rowcount == 1


def _issue_tokens(client_id: str, scope: str, resource: str) -> dict[str, Any]:
    access_token = secrets.token_urlsafe(32)
    refresh_token = secrets.token_urlsafe(40)
    now = _now()
    with make_plugin_db() as conn:
        _cleanup_oauth_rows(conn, now)
        conn.execute(
            text(
                "INSERT INTO plugin_whatsbot_mcp_oauth_tokens "
                "(access_hash, refresh_hash, client_id, scope, resource, "
                "access_expires_at, refresh_expires_at, created_at) "
                "VALUES (:access_hash, :refresh_hash, :client_id, :scope, :resource, "
                ":access_expires_at, :refresh_expires_at, :created_at)"
            ),
            {
                "access_hash": token_hash(access_token),
                "refresh_hash": token_hash(refresh_token),
                "client_id": client_id,
                "scope": scope,
                "resource": resource,
                "access_expires_at": now + ACCESS_TOKEN_TTL,
                "refresh_expires_at": now + REFRESH_TOKEN_TTL,
                "created_at": now,
            },
        )
    return {
        "access_token": access_token,
        "token_type": "Bearer",
        "expires_in": ACCESS_TOKEN_TTL,
        "refresh_token": refresh_token,
        "scope": scope,
    }


def _get_refresh(refresh_token: str, client_id: str) -> dict[str, Any] | None:
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT client_id, scope, resource "
                "FROM plugin_whatsbot_mcp_oauth_tokens "
                "WHERE refresh_hash = :refresh_hash AND client_id = :client_id "
                "AND refresh_expires_at >= :now "
            ),
            {
                "refresh_hash": token_hash(refresh_token),
                "client_id": client_id,
                "now": _now(),
            },
        ).mappings().first()
    return dict(row) if row else None


def _consume_refresh(refresh_token: str, client_id: str) -> bool:
    with make_plugin_db() as conn:
        result = conn.execute(
            text(
                "DELETE FROM plugin_whatsbot_mcp_oauth_tokens "
                "WHERE refresh_hash = :refresh_hash AND client_id = :client_id "
                "AND refresh_expires_at >= :now"
            ),
            {
                "refresh_hash": token_hash(refresh_token),
                "client_id": client_id,
                "now": _now(),
            },
        )
    return result.rowcount == 1


def validate_oauth_access_token(access_token: str, expected_resource: str) -> set[str] | None:
    if not access_token or len(access_token) > 512:
        return None
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT scope, resource FROM plugin_whatsbot_mcp_oauth_tokens "
                "WHERE access_hash = :access_hash AND access_expires_at >= :now"
            ),
            {"access_hash": token_hash(access_token), "now": _now()},
        ).mappings().first()
    if not row or row["resource"] != expected_resource:
        return None
    return set(str(row["scope"] or "").split())


def _validate_authorization(params: dict[str, str], request: Request) -> tuple[dict[str, Any], str, str]:
    if params.get("response_type") != "code":
        raise OAuthError("unsupported_response_type", "Apenas response_type=code é aceito.")
    client = _get_client(params.get("client_id", ""))
    if not client:
        raise OAuthError("invalid_request", "Cliente OAuth desconhecido.")
    redirect_uri = params.get("redirect_uri", "")
    if redirect_uri not in client["redirect_uris"]:
        raise OAuthError("invalid_request", "redirect_uri não registrado.")
    challenge = params.get("code_challenge", "")
    if params.get("code_challenge_method") != "S256" or not valid_pkce_challenge(challenge):
        raise OAuthError("invalid_request", "PKCE S256 é obrigatório.")
    if len(params.get("state", "")) > 2048:
        raise OAuthError("invalid_request", "state grande demais.")
    try:
        scope = normalize_scope(params.get("scope", ""))
    except ValueError as exc:
        raise OAuthError("invalid_scope", "Escopo não suportado.") from exc
    expected_resource = _resource(request)
    resource = params.get("resource", "") or expected_resource
    if resource != expected_resource:
        raise OAuthError("invalid_target", "Resource OAuth incorreto.")
    return client, scope, resource


def _authorize_form(params: dict[str, str], client_name: str, scope: str) -> str:
    hidden = "".join(
        f'<input type="hidden" name="{html.escape(key)}" value="{html.escape(value, quote=True)}">'
        for key, value in params.items()
    )
    scope_labels = {
        "whatsbot:read": "Ler status, contatos e conversas",
        "whatsbot:write": "Enviar mensagens e alterar contatos (com confirmação)",
    }
    permissions = "".join(
        f"<li>{html.escape(scope_labels[item])}</li>" for item in scope.split()
    )
    redirect_uri = html.escape(params.get("redirect_uri", ""), quote=True)
    return f"""<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Autorizar WhatsBot MCP</title>
<style>body{{font-family:system-ui;background:#f4f6f8;margin:0;padding:24px;color:#17202a}}main{{max-width:460px;margin:7vh auto;background:white;padding:28px;border-radius:16px;box-shadow:0 10px 35px #0002}}h1{{font-size:23px;margin-top:0}}p,li{{line-height:1.45}}code{{display:block;overflow-wrap:anywhere;background:#eef2f5;padding:8px;border-radius:6px;margin-top:6px}}.warning{{color:#8a4b08}}label{{display:block;font-weight:600;margin:20px 0 7px}}input[type=password]{{box-sizing:border-box;width:100%;padding:12px;border:1px solid #aab4be;border-radius:8px;font-size:16px}}button{{width:100%;padding:12px;margin-top:18px;background:#087f5b;color:white;border:0;border-radius:8px;font-size:16px;font-weight:700}}small{{display:block;color:#5f6b76;margin-top:15px}}</style></head>
<body><main><h1>Autorizar WhatsBot</h1><p><strong>{html.escape(client_name)}</strong> solicita acesso ao seu WhatsBot:</p><ul>{permissions}</ul>
<p class="warning"><strong>Confirme o destino antes de continuar:</strong><code>{redirect_uri}</code></p>
<form method="post" action="{AUTHORIZE_PATH}">{hidden}<label for="password">Senha do painel WhatsBot</label><input id="password" name="password" type="password" autocomplete="current-password" required autofocus><button type="submit">Autorizar aplicativo</button></form>
<small>A senha é validada no seu próprio servidor e não é enviada ao aplicativo MCP.</small></main></body></html>"""


async def protected_resource_metadata(request: Request):
    base = _base_url(request)
    return {
        "resource": base + "/mcp",
        "authorization_servers": [base],
        "scopes_supported": list(SUPPORTED_SCOPES),
        "bearer_methods_supported": ["header"],
        "resource_name": "WhatsBot MCP",
    }


async def authorization_server_metadata(request: Request):
    base = _base_url(request)
    return {
        "issuer": base,
        "authorization_endpoint": base + AUTHORIZE_PATH,
        "token_endpoint": base + TOKEN_PATH,
        "registration_endpoint": base + REGISTER_PATH,
        "response_types_supported": ["code"],
        "response_modes_supported": ["query"],
        "grant_types_supported": ["authorization_code", "refresh_token"],
        "token_endpoint_auth_methods_supported": ["none"],
        "code_challenge_methods_supported": ["S256"],
        "scopes_supported": list(SUPPORTED_SCOPES),
    }


async def dynamic_client_registration(request: Request):
    if not _registration_allowed(_client_ip(request)):
        return _oauth_error(
            OAuthError("temporarily_unavailable", "Muitas tentativas de cadastro.", 429)
        )
    try:
        content_length = int(request.headers.get("content-length", "0") or 0)
    except ValueError:
        content_length = 0
    if content_length > 16 * 1024:
        return _oauth_error(
            OAuthError("invalid_client_metadata", "Cadastro grande demais.", 413)
        )
    try:
        body = await request.json()
    except Exception:
        return _oauth_error(OAuthError("invalid_client_metadata", "JSON inválido."))
    redirect_uris = body.get("redirect_uris") if isinstance(body, dict) else None
    if (
        not isinstance(redirect_uris, list)
        or not redirect_uris
        or len(redirect_uris) > 10
        or not all(isinstance(uri, str) and valid_oauth_redirect(uri) for uri in redirect_uris)
    ):
        return _oauth_error(
            OAuthError(
                "invalid_redirect_uri",
                "Use callback HTTPS ou loopback HTTP em localhost/127.0.0.1/[::1] com porta.",
            )
        )
    method = body.get("token_endpoint_auth_method", "none")
    if method != "none":
        return _oauth_error(
            OAuthError("invalid_client_metadata", "Somente clientes públicos com PKCE são aceitos.")
        )
    grant_types = body.get("grant_types", ["authorization_code", "refresh_token"])
    if (
        not isinstance(grant_types, list)
        or not grant_types
        or any(item not in {"authorization_code", "refresh_token"} for item in grant_types)
        or "authorization_code" not in grant_types
    ):
        return _oauth_error(
            OAuthError("invalid_client_metadata", "grant_types não suportado.")
        )
    response_types = body.get("response_types", ["code"])
    if not isinstance(response_types, list) or response_types != ["code"]:
        return _oauth_error(
            OAuthError("invalid_client_metadata", "Somente response_types=[\"code\"] é aceito.")
        )
    client_name = str(body.get("client_name") or "Cliente MCP").strip()[:120] or "Cliente MCP"
    try:
        result = _register_client(client_name, list(dict.fromkeys(redirect_uris)))
    except OAuthError as exc:
        return _oauth_error(exc)
    return _json_no_store(result, status=201)


async def authorize_get(request: Request):
    params = {key: request.query_params.get(key, "") for key in (
        "response_type", "client_id", "redirect_uri", "code_challenge",
        "code_challenge_method", "state", "scope", "resource",
    )}
    try:
        client, scope, resource = _validate_authorization(params, request)
    except OAuthError as exc:
        return HTMLResponse(
            f"<h1>Solicitação OAuth inválida</h1><p>{html.escape(exc.description)}</p>",
            status_code=exc.status,
        )
    params["scope"] = scope
    params["resource"] = resource
    return HTMLResponse(_authorize_form(params, client["client_name"], scope))


async def authorize_post(request: Request):
    try:
        form = await request.form()
    except Exception:
        return HTMLResponse(
            "<h1>Solicitação OAuth inválida</h1><p>Formulário inválido.</p>",
            status_code=400,
        )
    params = {key: str(form.get(key) or "") for key in (
        "response_type", "client_id", "redirect_uri", "code_challenge",
        "code_challenge_method", "state", "scope", "resource",
    )}
    try:
        client, scope, resource = _validate_authorization(params, request)
    except OAuthError as exc:
        return HTMLResponse(
            f"<h1>Solicitação OAuth inválida</h1><p>{html.escape(exc.description)}</p>",
            status_code=exc.status,
        )
    ip = _client_ip(request)
    if not _password_attempt_allowed(ip):
        return HTMLResponse("<h1>Muitas tentativas</h1><p>Tente novamente mais tarde.</p>", status_code=429)
    password = str(form.get("password") or "")
    if len(password) > 1024:
        _record_password_failure(ip)
        return HTMLResponse(
            "<h1>Solicitação OAuth inválida</h1><p>Senha inválida.</p>",
            status_code=400,
        )
    if not _verify_owner_password(password):
        _record_password_failure(ip)
        params["scope"] = scope
        params["resource"] = resource
        page = _authorize_form(params, client["client_name"], scope).replace(
            "<form method=", '<p style="color:#b42318"><strong>Senha incorreta.</strong></p><form method=', 1
        )
        return HTMLResponse(page, status_code=401)
    _oauth_attempts.pop(ip, None)
    code = secrets.token_urlsafe(32)
    _save_code(
        code,
        params["client_id"],
        params["redirect_uri"],
        params["code_challenge"],
        scope,
        resource,
    )
    location = append_query(params["redirect_uri"], code=code, state=params.get("state", ""))
    return RedirectResponse(location, status_code=303, headers={"Cache-Control": "no-store"})


async def token_endpoint(request: Request):
    try:
        form = await request.form()
        grant_type = str(form.get("grant_type") or "")
        client_id = str(form.get("client_id") or "")
        if not _get_client(client_id):
            raise OAuthError("invalid_client", "Cliente desconhecido.", 401)

        if grant_type == "authorization_code":
            code = str(form.get("code") or "")
            if not code or len(code) > 512:
                raise OAuthError("invalid_grant", "Código inválido ou expirado.")
            row = _get_code(code)
            if not row or row["client_id"] != client_id:
                raise OAuthError("invalid_grant", "Código inválido ou expirado.")
            if str(form.get("redirect_uri") or "") != row["redirect_uri"]:
                raise OAuthError("invalid_grant", "redirect_uri não confere.")
            verifier = str(form.get("code_verifier") or "")
            if not valid_pkce_verifier(verifier):
                raise OAuthError("invalid_grant", "code_verifier inválido.")
            try:
                calculated = pkce_s256(verifier)
            except (UnicodeEncodeError, ValueError) as exc:
                raise OAuthError("invalid_grant", "code_verifier inválido.") from exc
            if not hmac.compare_digest(calculated, row["code_challenge"]):
                raise OAuthError("invalid_grant", "Falha na verificação PKCE.")
            requested_resource = str(form.get("resource") or row["resource"])
            if requested_resource != row["resource"]:
                raise OAuthError("invalid_target", "Resource incorreto.")
            if not _consume_code(code, client_id):
                raise OAuthError("invalid_grant", "Código já utilizado.")
            return _json_no_store(_issue_tokens(client_id, row["scope"], row["resource"]))

        if grant_type == "refresh_token":
            refresh_token = str(form.get("refresh_token") or "")
            if not refresh_token or len(refresh_token) > 512:
                raise OAuthError("invalid_grant", "Refresh token inválido ou expirado.")
            row = _get_refresh(refresh_token, client_id)
            if not row:
                raise OAuthError("invalid_grant", "Refresh token inválido ou expirado.")
            requested_scope = str(form.get("scope") or row["scope"])
            scope = normalize_scope(requested_scope)
            if not set(scope.split()).issubset(set(str(row["scope"]).split())):
                raise OAuthError("invalid_scope", "O refresh não pode ampliar escopos.")
            if not _consume_refresh(refresh_token, client_id):
                raise OAuthError("invalid_grant", "Refresh token já utilizado.")
            return _json_no_store(_issue_tokens(client_id, scope, row["resource"]))

        raise OAuthError("unsupported_grant_type", "Grant type não suportado.")
    except OAuthError as exc:
        return _oauth_error(exc)
    except Exception:
        return _oauth_error(OAuthError("invalid_request", "Requisição OAuth inválida."))


def _challenge(request: Request) -> JSONResponse:
    metadata = _base_url(request) + "/.well-known/oauth-protected-resource/mcp"
    return JSONResponse(
        error(None, -32001, "OAuth authorization required"),
        status_code=401,
        headers={
            "Cache-Control": "no-store",
            "WWW-Authenticate": (
                f'Bearer resource_metadata="{metadata}", scope="{DEFAULT_SCOPE}"'
            ),
        },
    )


def _authorize_mcp_request(request: Request) -> set[str] | None:
    header = request.headers.get("authorization", "")
    if not header.startswith("Bearer "):
        return None
    raw_token = header[7:].strip()
    return (
        validate_oauth_access_token(raw_token, _resource(request))
        or validate_managed_access_token(raw_token)
    )


async def public_mcp_post(request: Request):
    scopes = _authorize_mcp_request(request)
    if not scopes:
        return _challenge(request)
    request.state.whatsbot_mcp_scopes = scopes
    return await handle_mcp_request(request, authorization_checked=True)


async def public_mcp_get(request: Request):
    scopes = _authorize_mcp_request(request)
    if not scopes:
        return _challenge(request)
    request.state.whatsbot_mcp_scopes = scopes
    return mcp_get_response()


def register_public_routes(app, deps) -> None:
    global _runtime_settings
    _runtime_settings = deps.settings
    marker = "whatsbot_mcp_public_routes_registered"
    if getattr(app.state, marker, False):
        return
    setattr(app.state, marker, True)
    app.add_api_route(
        "/.well-known/oauth-protected-resource",
        protected_resource_metadata,
        methods=["GET"],
        name="whatsbot_mcp_oauth_resource_metadata",
    )
    app.add_api_route(
        "/.well-known/oauth-protected-resource/mcp",
        protected_resource_metadata,
        methods=["GET"],
        name="whatsbot_mcp_oauth_resource_metadata_path",
    )
    app.add_api_route(
        "/.well-known/oauth-authorization-server",
        authorization_server_metadata,
        methods=["GET"],
        name="whatsbot_mcp_oauth_server_metadata",
    )
    app.add_api_route(REGISTER_PATH, dynamic_client_registration, methods=["POST"], name="whatsbot_mcp_oauth_register")
    app.add_api_route(AUTHORIZE_PATH, authorize_get, methods=["GET"], name="whatsbot_mcp_oauth_authorize_get")
    app.add_api_route(AUTHORIZE_PATH, authorize_post, methods=["POST"], name="whatsbot_mcp_oauth_authorize_post")
    app.add_api_route(TOKEN_PATH, token_endpoint, methods=["POST"], name="whatsbot_mcp_oauth_token")
    app.add_api_route("/mcp", public_mcp_get, methods=["GET"], name="whatsbot_mcp_public_get")
    app.add_api_route("/mcp", public_mcp_post, methods=["POST"], name="whatsbot_mcp_public_post")
