"""FastAPI routes mounted by WhatsBot at /api/plugins/whatsbot_mcp."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, Response

from .access_tokens import (
    AccessTokenError,
    create_access_token,
    list_access_tokens,
    revoke_access_token,
)
from .protocol import (
    LATEST_PROTOCOL_VERSION,
    SERVER_NAME,
    SERVER_VERSION,
    SUPPORTED_PROTOCOL_VERSIONS,
    dispatch,
    error,
)
from .service import ToolFailure, execute, mcp_tool_result


router = APIRouter()


def _ok(data: dict[str, Any], status_code: int = 200) -> JSONResponse:
    return JSONResponse(
        {"ok": True, "data": data},
        status_code=status_code,
        headers={"Cache-Control": "no-store"},
    )


def _bad_request(message: str, status_code: int = 400) -> JSONResponse:
    return JSONResponse(
        {"ok": False, "error": message},
        status_code=status_code,
        headers={"Cache-Control": "no-store"},
    )


def _headers() -> dict[str, str]:
    return {
        "Cache-Control": "no-store",
        "MCP-Protocol-Version": LATEST_PROTOCOL_VERSION,
    }


@router.get("/health")
async def health(request: Request):
    return {
        "ok": True,
        "data": {
            "name": SERVER_NAME,
            "version": SERVER_VERSION,
            "transport": "streamable-http-json",
            "protocol_versions": list(SUPPORTED_PROTOCOL_VERSIONS),
            "endpoint": str(request.url).rsplit("/health", 1)[0] + "/mcp",
        },
    }


@router.get("/tokens")
async def get_tokens():
    return _ok({"tokens": list_access_tokens()})


@router.post("/tokens")
async def post_token(request: Request):
    try:
        body = await request.json()
    except Exception:
        return _bad_request("JSON inválido.")
    if not isinstance(body, dict):
        return _bad_request("Corpo inválido.")
    try:
        created = create_access_token(
            name=body.get("name", ""),
            raw_scope=body.get("scope", "whatsbot:read"),
            valid_days=body.get("valid_days", 90),
            never_expires=body.get("never_expires", False),
        )
    except AccessTokenError as exc:
        return _bad_request(str(exc))
    return _ok(created, status_code=201)


@router.delete("/tokens/{token_id}")
async def delete_token(token_id: str):
    if not revoke_access_token(token_id):
        return _bad_request("Token não encontrado ou já revogado.", 404)
    return _ok({"token_id": token_id, "revoked": True})


def mcp_get_response():
    return JSONResponse(
        {"ok": False, "error": "Este servidor MCP usa POST com JSON-RPC."},
        status_code=405,
        headers={**_headers(), "Allow": "POST"},
    )


@router.get("/mcp")
async def mcp_get():
    return mcp_get_response()


async def handle_mcp_request(request: Request, *, authorization_checked: bool = False):
    authorization = request.headers.get("authorization", "")
    if (
        not authorization_checked
        and (not authorization.startswith("Bearer ") or not authorization[7:].strip())
    ):
        return JSONResponse(
            error(None, -32001, "Unauthorized"),
            status_code=401,
            headers={**_headers(), "WWW-Authenticate": 'Bearer realm="WhatsBot MCP"'},
        )

    content_type = request.headers.get("content-type", "")
    if "application/json" not in content_type.lower():
        return JSONResponse(
            error(None, -32600, "Content-Type must be application/json"),
            status_code=415,
            headers=_headers(),
        )
    accept = request.headers.get("accept", "*/*").lower()
    if not any(media in accept for media in ("application/json", "*/*")):
        return JSONResponse(
            error(None, -32600, "This endpoint returns application/json"),
            status_code=406,
            headers=_headers(),
        )

    try:
        payload: Any = await request.json()
    except Exception:
        return JSONResponse(error(None, -32700, "Parse error"), status_code=400, headers=_headers())

    if isinstance(payload, list):
        return JSONResponse(
            error(None, -32600, "JSON-RPC batches are not supported"),
            status_code=400,
            headers=_headers(),
        )

    async def run_tool(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        try:
            result = await execute(name, arguments, request)
            return mcp_tool_result(result)
        except ToolFailure as exc:
            return mcp_tool_result({"ok": False, "error": str(exc)}, is_error=True)
        except Exception:
            return mcp_tool_result(
                {"ok": False, "error": "Falha interna ao executar a ferramenta."},
                is_error=True,
            )

    response = await dispatch(payload, run_tool)
    if response is None:
        return Response(status_code=202, headers=_headers())
    return JSONResponse(response, status_code=200, headers=_headers())


@router.post("/mcp")
async def mcp_post(request: Request):
    return await handle_mcp_request(request)
