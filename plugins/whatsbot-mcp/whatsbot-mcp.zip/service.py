"""Curated WhatsBot operations exposed as MCP tools."""

from __future__ import annotations

import asyncio
import json
import re
import time
from typing import Any
from urllib.parse import quote

import httpx
from sqlalchemy import text

from db.repositories import config_repo, contact_repo, message_repo
from plugins.context import make_plugin_db

from .protocol import TOOLS


_PHONE_RE = re.compile(r"^[0-9]{8,24}(?:@(g\.us|s\.whatsapp\.net))?$")
_IDEMPOTENCY_RE = re.compile(r"^[A-Za-z0-9._:-]{8,128}$")
_TOOL_NAMES = {tool["name"] for tool in TOOLS}
_CONFIG_PREFIX = "plugin.whatsbot_mcp."


class ToolFailure(Exception):
    """A safe, user-facing tool error."""


def _setting(name: str, default: Any) -> Any:
    return config_repo.get(_CONFIG_PREFIX + name, default)


def _required_text(arguments: dict[str, Any], key: str, max_length: int) -> str:
    value = arguments.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ToolFailure(f"'{key}' é obrigatório.")
    value = value.strip()
    if len(value) > max_length:
        raise ToolFailure(f"'{key}' excede o limite de {max_length} caracteres.")
    return value


def _phone(arguments: dict[str, Any]) -> str:
    value = _required_text(arguments, "phone", 64)
    if not _PHONE_RE.fullmatch(value):
        raise ToolFailure("Telefone/JID inválido; use o valor exato retornado pela pesquisa.")
    return value


def _limit(arguments: dict[str, Any], key: str, default: int, configured: int) -> int:
    value = arguments.get(key, default)
    if isinstance(value, bool) or not isinstance(value, int):
        raise ToolFailure(f"'{key}' deve ser um número inteiro.")
    return max(1, min(value, configured))


def _safe_text(value: Any, limit: int = 4000) -> str:
    if value is None:
        return ""
    if not isinstance(value, str):
        value = json.dumps(value, ensure_ascii=False, default=str)
    return value if len(value) <= limit else value[:limit] + "…"


def _safe_contact(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "phone": row.get("phone"),
        "name": row.get("name") or row.get("group_name") or "",
        "is_group": bool(row.get("is_group")),
        "ai_enabled": bool(row.get("ai_enabled")),
        "tags": list(row.get("tags") or []),
        "unread_count": int(row.get("unread_count") or 0),
        "unread_ai_count": int(row.get("unread_ai_count") or 0),
        "last_message": _safe_text(row.get("last_message") or "", 500),
        "last_ts": row.get("last_ts") or row.get("updated_at"),
        "archived": bool(row.get("is_archived") or row.get("archived")),
        "pinned": bool(row.get("pinned")),
    }


def _safe_message(row: dict[str, Any]) -> dict[str, Any]:
    result = {
        "id": row.get("_id") or row.get("id"),
        "msg_id": row.get("msg_id"),
        "role": row.get("role"),
        "content": _safe_text(row.get("content"), 4000),
        "ts": row.get("ts"),
        "status": row.get("status"),
        "media_type": row.get("media_type"),
        "reply_to_msg_id": row.get("reply_to_msg_id"),
        "revoked": bool(row.get("revoked")),
    }
    if row.get("sender_name"):
        result["sender_name"] = _safe_text(row.get("sender_name"), 200)
    if row.get("sender_phone"):
        result["sender_phone"] = _safe_text(row.get("sender_phone"), 64)
    return result


async def _call_core_api(
    request: Any,
    method: str,
    path: str,
    *,
    json_body: dict[str, Any] | None = None,
) -> Any:
    authorization = request.headers.get("authorization", "")
    # Calls arriving through public /mcp carry a scoped OAuth or managed MCP
    # token that the core middleware must not accept. Exchange it server-side
    # for the deterministic panel token without exposing that token to clients.
    try:
        from .oauth import core_bearer_token

        internal_token = core_bearer_token()
        if internal_token:
            authorization = f"Bearer {internal_token}"
    except Exception:
        pass
    transport = httpx.ASGITransport(app=request.app)
    async with httpx.AsyncClient(
        transport=transport,
        base_url="http://whatsbot.internal",
        timeout=30.0,
    ) as client:
        response = await client.request(
            method,
            path,
            headers={"Authorization": authorization, "Accept": "application/json"},
            json=json_body,
        )
    try:
        payload = response.json()
    except ValueError as exc:
        raise ToolFailure(f"O WhatsBot respondeu HTTP {response.status_code} sem JSON válido.") from exc
    if not response.is_success or not payload.get("ok"):
        message = payload.get("error") or f"HTTP {response.status_code}"
        raise ToolFailure(str(message))
    return payload.get("data")


def _claim_request(key: str, tool: str, phone: str) -> tuple[str, dict[str, Any] | None]:
    now = int(time.time())
    with make_plugin_db() as conn:
        conn.execute(
            text("DELETE FROM plugin_whatsbot_mcp_requests WHERE created_at < :cutoff"),
            {"cutoff": now - (30 * 24 * 60 * 60)},
        )
        inserted = conn.execute(
            text(
                "INSERT INTO plugin_whatsbot_mcp_requests "
                "(idempotency_key, tool, phone, status, result_json, created_at) "
                "VALUES (:key, :tool, :phone, 'processing', NULL, :created_at) "
                "ON CONFLICT (idempotency_key) DO NOTHING "
                "RETURNING idempotency_key"
            ),
            {"key": key, "tool": tool, "phone": phone, "created_at": now},
        ).scalar_one_or_none()
        if inserted:
            return "new", None
        row = conn.execute(
            text(
                "SELECT tool, phone, status, result_json "
                "FROM plugin_whatsbot_mcp_requests WHERE idempotency_key = :key"
            ),
            {"key": key},
        ).mappings().first()

    if not row:
        return "processing", None
    if row["tool"] != tool or row["phone"] != phone:
        raise ToolFailure("A idempotency_key já foi usada em outra operação.")
    if row["status"] == "completed" and row["result_json"]:
        try:
            return "completed", json.loads(row["result_json"])
        except (TypeError, json.JSONDecodeError):
            return "completed", {"ok": True}
    return "processing", None


def _complete_request(key: str, result: dict[str, Any]) -> None:
    with make_plugin_db() as conn:
        conn.execute(
            text(
                "UPDATE plugin_whatsbot_mcp_requests "
                "SET status = 'completed', result_json = :result "
                "WHERE idempotency_key = :key"
            ),
            {"key": key, "result": json.dumps(result, ensure_ascii=False, default=str)},
        )


def _release_request(key: str) -> None:
    with make_plugin_db() as conn:
        conn.execute(
            text(
                "DELETE FROM plugin_whatsbot_mcp_requests "
                "WHERE idempotency_key = :key AND status = 'processing'"
            ),
            {"key": key},
        )


async def _write(
    tool: str,
    phone: str,
    arguments: dict[str, Any],
    operation: Any,
) -> dict[str, Any]:
    if not bool(_setting("allow_write_tools", True)):
        raise ToolFailure("Ferramentas de escrita estão desativadas nas configurações do plugin.")
    if arguments.get("confirm") is not True:
        raise ToolFailure("Confirmação explícita necessária: defina confirm=true após o usuário aprovar.")
    key = _required_text(arguments, "idempotency_key", 128)
    if not _IDEMPOTENCY_RE.fullmatch(key):
        raise ToolFailure("idempotency_key inválida; use 8–128 caracteres alfanuméricos, . _ : ou -.")

    state, previous = await asyncio.to_thread(_claim_request, key, tool, phone)
    if state == "completed":
        replay = dict(previous or {})
        replay["idempotent_replay"] = True
        return replay
    if state == "processing":
        raise ToolFailure("Uma chamada com esta idempotency_key já está em andamento.")

    try:
        result = await operation()
        if not isinstance(result, dict):
            result = {"result": result}
        await asyncio.to_thread(_complete_request, key, result)
        return result
    except Exception:
        await asyncio.to_thread(_release_request, key)
        raise


async def execute(name: str, arguments: dict[str, Any], request: Any) -> dict[str, Any]:
    if name not in _TOOL_NAMES:
        raise ToolFailure(f"Ferramenta desconhecida: {name}")

    if name == "whatsbot_get_status":
        data = await _call_core_api(request, "GET", "/api/status")
        return {"ok": True, "status": data}

    if name == "whatsbot_search_contacts":
        query = arguments.get("query", "")
        if not isinstance(query, str) or len(query) > 120:
            raise ToolFailure("'query' deve ser texto com até 120 caracteres.")
        archived = arguments.get("archived", False)
        if not isinstance(archived, bool):
            raise ToolFailure("'archived' deve ser booleano.")
        configured = max(1, min(int(_setting("max_contacts", 25)), 100))
        limit = _limit(arguments, "limit", 25, configured)
        rows = await asyncio.to_thread(contact_repo.list_contacts, query.strip(), archived)
        contacts = [_safe_contact(dict(row)) for row in rows[:limit]]
        return {"ok": True, "count": len(contacts), "contacts": contacts}

    if name == "whatsbot_get_conversation":
        phone = _phone(arguments)
        include_private = arguments.get("include_private_notes", False)
        if not isinstance(include_private, bool):
            raise ToolFailure("'include_private_notes' deve ser booleano.")
        configured = max(1, min(int(_setting("max_messages", 50)), 200))
        limit = _limit(arguments, "limit", 50, configured)

        def load_conversation() -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
            contact = contact_repo.get_full_contact(phone)
            if not contact:
                return None, []
            messages = [dict(row) for row in message_repo.get_all(contact["id"])]
            return dict(contact), messages

        contact, messages = await asyncio.to_thread(load_conversation)
        if not contact:
            raise ToolFailure("Contato não encontrado.")
        if not include_private:
            messages = [row for row in messages if row.get("role") != "private_note"]
        selected = messages[-limit:]
        return {
            "ok": True,
            "contact": _safe_contact(contact),
            "message_count": len(selected),
            "messages": [_safe_message(row) for row in selected],
        }

    phone = _phone(arguments)
    encoded_phone = quote(phone, safe="@")

    oauth_scopes = getattr(request.state, "whatsbot_mcp_scopes", None)
    if oauth_scopes is not None and "whatsbot:write" not in oauth_scopes:
        raise ToolFailure("O token MCP não possui o escopo whatsbot:write.")

    if name == "whatsbot_send_message":
        max_chars = max(100, min(int(_setting("max_text_chars", 4000)), 12000))
        message = _required_text(arguments, "message", max_chars)
        reply_to = arguments.get("reply_to")
        if reply_to is not None and (not isinstance(reply_to, str) or len(reply_to) > 256):
            raise ToolFailure("'reply_to' inválido.")

        async def send() -> dict[str, Any]:
            body: dict[str, Any] = {"message": message}
            if reply_to:
                body["reply_to"] = reply_to.strip()
            data = await _call_core_api(
                request, "POST", f"/api/contacts/{encoded_phone}/send", json_body=body
            )
            return {"ok": True, "phone": phone, "sent": True, **(data or {})}

        return await _write(name, phone, arguments, send)

    if name == "whatsbot_add_private_note":
        max_chars = max(100, min(int(_setting("max_text_chars", 4000)), 12000))
        note = _required_text(arguments, "text", max_chars)

        async def add_note() -> dict[str, Any]:
            data = await _call_core_api(
                request,
                "POST",
                f"/api/contacts/{encoded_phone}/private-message",
                json_body={"text": note, "ai_read": False, "ai_reply": False},
            )
            return {"ok": True, "phone": phone, "saved": True, "note": data}

        return await _write(name, phone, arguments, add_note)

    if name == "whatsbot_set_ai_enabled":
        enabled = arguments.get("enabled")
        if not isinstance(enabled, bool):
            raise ToolFailure("'enabled' deve ser booleano.")

        async def set_ai() -> dict[str, Any]:
            data = await _call_core_api(
                request,
                "POST",
                f"/api/contacts/{encoded_phone}/toggle-ai",
                json_body={"enabled": enabled},
            )
            return {"ok": True, "phone": phone, **(data or {})}

        return await _write(name, phone, arguments, set_ai)

    if name == "whatsbot_set_contact_tags":
        tags = arguments.get("tags")
        if not isinstance(tags, list) or len(tags) > 20:
            raise ToolFailure("'tags' deve ser uma lista com no máximo 20 itens.")
        clean_tags: list[str] = []
        for tag in tags:
            if not isinstance(tag, str) or not tag.strip() or len(tag.strip()) > 30:
                raise ToolFailure("Cada tag deve ter entre 1 e 30 caracteres.")
            if tag.strip() not in clean_tags:
                clean_tags.append(tag.strip())

        async def set_tags() -> dict[str, Any]:
            data = await _call_core_api(
                request,
                "PUT",
                f"/api/contacts/{encoded_phone}/tags",
                json_body={"tags": clean_tags},
            )
            return {"ok": True, "phone": phone, **(data or {})}

        return await _write(name, phone, arguments, set_tags)

    raise ToolFailure(f"Ferramenta desconhecida: {name}")


def mcp_tool_result(data: dict[str, Any], *, is_error: bool = False) -> dict[str, Any]:
    return {
        "content": [
            {
                "type": "text",
                "text": json.dumps(data, ensure_ascii=False, default=str),
            }
        ],
        "structuredContent": data,
        "isError": is_error,
    }
