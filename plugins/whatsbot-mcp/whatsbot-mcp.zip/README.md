# WhatsBot MCP

Plugin para WhatsBot que oferece um endpoint MCP Streamable HTTP JSON-RPC
compatível com clientes MCP remotos:

`https://SEU-DOMINIO/mcp`

## Ferramentas

- `whatsbot_get_status`
- `whatsbot_search_contacts`
- `whatsbot_get_conversation`
- `whatsbot_send_message`
- `whatsbot_add_private_note`
- `whatsbot_set_ai_enabled`
- `whatsbot_set_contact_tags`

As leituras devolvem campos selecionados e nunca expõem chaves, caminhos locais de mídia
ou configurações internas. Notas privadas ficam ocultas por padrão. Toda escrita exige
`confirm=true` e uma `idempotency_key` única; o servidor guarda o resultado por 30 dias
para impedir repetições acidentais.

## Instalação

1. Importe o `.zip` na tela **Plugins** do WhatsBot.
2. Ative **WhatsBot MCP** e aguarde o reinício.
3. Abra **Configurar** para copiar o endpoint, ajustar limites, administrar
   tokens e consultar os exemplos de conexão.

O `.zip` deve conter `plugin.yaml` na raiz, como o pacote distribuído.

## Autenticação

O endpoint público aceita duas formas de autenticação:

- **OAuth 2.1**, recomendado: descoberta automática, Dynamic Client
  Registration, Authorization Code com PKCE S256, access token curto e refresh
  token rotativo. Aceita callbacks HTTPS e callbacks loopback de clientes
  nativos em `localhost`, `127.0.0.1` ou `[::1]`.
- **Token MCP**, alternativa: criado e revogado em **Configurar**, com escopos
  próprios e validade em dias ou sem expiração. Tokens sem expiração continuam
  válidos até serem revogados. Use-os como `Authorization: Bearer <TOKEN_MCP>`.

Ambos ficam limitados ao endpoint `/mcp` e aos escopos `whatsbot:read` e
`whatsbot:write`; nenhum deles autoriza rotas administrativas do WhatsBot.

## Clientes

A tela **Configurar** contém um accordion com exemplos atualizados para:

- ChatGPT
- Gemini CLI
- Claude web/Desktop/mobile
- Claude Code
- Hermes Agent
- OpenClaw

Em todos eles, use `https://SEU-DOMINIO/mcp`. Prefira OAuth e use um token
MCP apenas quando o cliente não implementar a descoberta OAuth. Nunca use a
senha do painel ou o token administrativo como Bearer do MCP.

A rota antiga `https://SEU-DOMINIO/api/plugins/whatsbot_mcp/mcp` permanece
disponível apenas para compatibilidade administrativa; integrações externas
devem usar a rota pública `/mcp`.
