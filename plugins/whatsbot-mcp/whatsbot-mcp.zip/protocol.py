"""Small, stateless MCP Streamable HTTP JSON-RPC core.

WhatsBot's plugin API mounts FastAPI ``APIRouter`` objects but does not merge
third-party ASGI lifespans.  This module therefore implements the small MCP
surface needed by the plugin without creating another server process.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any


SERVER_NAME = "whatsbot-mcp"
SERVER_VERSION = "1.2.1"
LATEST_PROTOCOL_VERSION = "2025-06-18"
SUPPORTED_PROTOCOL_VERSIONS = (
    LATEST_PROTOCOL_VERSION,
    "2025-03-26",
)


READ_ONLY = {
    "readOnlyHint": True,
    "destructiveHint": False,
    "idempotentHint": True,
    "openWorldHint": False,
}


TOOLS: list[dict[str, Any]] = [
    {
        "name": "whatsbot_get_status",
        "title": "Consultar status do WhatsBot",
        "description": "Consulta conexão, contador de mensagens e estado da resposta automática.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
        "annotations": READ_ONLY,
    },
    {
        "name": "whatsbot_search_contacts",
        "title": "Pesquisar contatos",
        "description": "Pesquisa contatos por nome, telefone, tag ou conteúdo indexado.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "maxLength": 120, "description": "Busca opcional."},
                "archived": {"type": "boolean", "default": False},
                "limit": {"type": "integer", "minimum": 1, "maximum": 100, "default": 25},
            },
            "additionalProperties": False,
        },
        "annotations": READ_ONLY,
    },
    {
        "name": "whatsbot_get_conversation",
        "title": "Ler conversa",
        "description": (
            "Lê as mensagens mais recentes sem marcar a conversa como lida. "
            "Notas privadas só aparecem quando include_private_notes=true."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "phone": {"type": "string", "description": "Telefone/JID retornado pela pesquisa."},
                "limit": {"type": "integer", "minimum": 1, "maximum": 200, "default": 50},
                "include_private_notes": {"type": "boolean", "default": False},
            },
            "required": ["phone"],
            "additionalProperties": False,
        },
        "annotations": READ_ONLY,
    },
    {
        "name": "whatsbot_send_message",
        "title": "Enviar mensagem no WhatsApp",
        "description": (
            "Envia uma mensagem real ao contato. Exige confirmação explícita e uma "
            "idempotency_key única para impedir envio duplicado."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "phone": {"type": "string", "description": "Telefone/JID exato do destinatário."},
                "message": {"type": "string", "minLength": 1},
                "reply_to": {"type": "string", "description": "ID opcional da mensagem citada."},
                "idempotency_key": {"type": "string", "minLength": 8, "maxLength": 128},
                "confirm": {"type": "boolean", "description": "Deve ser true após confirmação do usuário."},
            },
            "required": ["phone", "message", "idempotency_key", "confirm"],
            "additionalProperties": False,
        },
        "annotations": {
            "readOnlyHint": False,
            "destructiveHint": True,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    },
    {
        "name": "whatsbot_add_private_note",
        "title": "Adicionar nota privada",
        "description": "Salva uma nota apenas no painel; ela não é enviada ao contato.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "phone": {"type": "string"},
                "text": {"type": "string", "minLength": 1},
                "idempotency_key": {"type": "string", "minLength": 8, "maxLength": 128},
                "confirm": {"type": "boolean"},
            },
            "required": ["phone", "text", "idempotency_key", "confirm"],
            "additionalProperties": False,
        },
        "annotations": {
            "readOnlyHint": False,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    },
    {
        "name": "whatsbot_set_ai_enabled",
        "title": "Alterar IA automática do contato",
        "description": "Ativa ou desativa a resposta automática de IA para um contato.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "phone": {"type": "string"},
                "enabled": {"type": "boolean"},
                "idempotency_key": {"type": "string", "minLength": 8, "maxLength": 128},
                "confirm": {"type": "boolean"},
            },
            "required": ["phone", "enabled", "idempotency_key", "confirm"],
            "additionalProperties": False,
        },
        "annotations": {
            "readOnlyHint": False,
            "destructiveHint": True,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    },
    {
        "name": "whatsbot_set_contact_tags",
        "title": "Definir tags do contato",
        "description": "Substitui a lista de tags de um contato por tags já cadastradas no WhatsBot.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "phone": {"type": "string"},
                "tags": {
                    "type": "array",
                    "items": {"type": "string", "minLength": 1, "maxLength": 30},
                    "maxItems": 20,
                },
                "idempotency_key": {"type": "string", "minLength": 8, "maxLength": 128},
                "confirm": {"type": "boolean"},
            },
            "required": ["phone", "tags", "idempotency_key", "confirm"],
            "additionalProperties": False,
        },
        "annotations": {
            "readOnlyHint": False,
            "destructiveHint": True,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    },
]


ToolRunner = Callable[[str, dict[str, Any]], Awaitable[dict[str, Any]]]


def success(request_id: Any, result: dict[str, Any]) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": request_id, "result": result}


def error(request_id: Any, code: int, message: str) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {"code": code, "message": message},
    }


async def dispatch(payload: Any, run_tool: ToolRunner) -> dict[str, Any] | None:
    """Dispatch one JSON-RPC request. JSON-RPC batches are intentionally unsupported."""
    if not isinstance(payload, dict):
        return error(None, -32600, "Invalid Request")

    request_id = payload.get("id")
    method = payload.get("method")
    if payload.get("jsonrpc") != "2.0" or not isinstance(method, str):
        return error(request_id, -32600, "Invalid Request")

    # MCP notifications never execute tools and do not receive a response.
    if "id" not in payload:
        return None

    params = payload.get("params") or {}
    if not isinstance(params, dict):
        return error(request_id, -32602, "Invalid params")

    if method == "initialize":
        requested = params.get("protocolVersion")
        selected = (
            requested
            if requested in SUPPORTED_PROTOCOL_VERSIONS
            else LATEST_PROTOCOL_VERSION
        )
        return success(
            request_id,
            {
                "protocolVersion": selected,
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
                "instructions": (
                    "Use ferramentas de leitura para localizar o contato antes de escrever. "
                    "Operações de escrita exigem confirmação explícita e idempotency_key única."
                ),
            },
        )

    if method == "ping":
        return success(request_id, {})
    if method == "tools/list":
        return success(request_id, {"tools": TOOLS})
    if method == "resources/list":
        return success(request_id, {"resources": []})
    if method == "prompts/list":
        return success(request_id, {"prompts": []})
    if method == "tools/call":
        name = params.get("name")
        arguments = params.get("arguments") or {}
        if not isinstance(name, str) or not isinstance(arguments, dict):
            return error(request_id, -32602, "Invalid params")
        return success(request_id, await run_tool(name, arguments))

    return error(request_id, -32601, "Method not found")
