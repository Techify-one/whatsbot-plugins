"""Owner-managed bearer tokens for MCP clients without OAuth support."""

from __future__ import annotations

import secrets
import time
from typing import Any

from sqlalchemy import text

from plugins.context import make_plugin_db

from .oauth_core import normalize_scope, token_hash


TOKEN_PREFIX = "wbmcp_"
MAX_ACTIVE_TOKENS = 50
MIN_VALID_DAYS = 1
MAX_VALID_DAYS = 365


class AccessTokenError(ValueError):
    pass


def _now() -> int:
    return int(time.time())


def create_access_token(
    name: str,
    raw_scope: str = "whatsbot:read",
    valid_days: int = 90,
    *,
    never_expires: bool = False,
) -> dict[str, Any]:
    clean_name = str(name or "").strip()
    if not clean_name or len(clean_name) > 80:
        raise AccessTokenError("Informe um nome com até 80 caracteres.")
    if not isinstance(never_expires, bool):
        raise AccessTokenError("'never_expires' deve ser verdadeiro ou falso.")
    days = 0
    if not never_expires:
        try:
            days = int(valid_days)
        except (TypeError, ValueError) as exc:
            raise AccessTokenError("A validade deve ser um número inteiro de dias.") from exc
        if not MIN_VALID_DAYS <= days <= MAX_VALID_DAYS:
            raise AccessTokenError(
                f"A validade deve ficar entre {MIN_VALID_DAYS} e {MAX_VALID_DAYS} dias."
            )
    try:
        scope = normalize_scope(raw_scope or "whatsbot:read")
    except ValueError as exc:
        raise AccessTokenError("Escopo MCP inválido.") from exc

    now = _now()
    token_id = secrets.token_urlsafe(9)
    raw_token = f"{TOKEN_PREFIX}{token_id}_{secrets.token_urlsafe(32)}"
    expires_at = 0 if never_expires else now + days * 24 * 60 * 60
    with make_plugin_db() as conn:
        active_count = conn.execute(
            text(
                "SELECT COUNT(*) FROM plugin_whatsbot_mcp_access_tokens "
                "WHERE revoked_at IS NULL "
                "AND (expires_at = 0 OR expires_at >= :now)"
            ),
            {"now": now},
        ).scalar_one()
        if int(active_count or 0) >= MAX_ACTIVE_TOKENS:
            raise AccessTokenError("Limite de tokens ativos atingido.")
        conn.execute(
            text(
                "INSERT INTO plugin_whatsbot_mcp_access_tokens "
                "(token_hash, token_id, name, scope, expires_at, created_at) "
                "VALUES (:token_hash, :token_id, :name, :scope, :expires_at, :created_at)"
            ),
            {
                "token_hash": token_hash(raw_token),
                "token_id": token_id,
                "name": clean_name,
                "scope": scope,
                "expires_at": expires_at,
                "created_at": now,
            },
        )
    return {
        "token": raw_token,
        "token_id": token_id,
        "name": clean_name,
        "scope": scope,
        "expires_at": expires_at,
        "never_expires": never_expires,
        "created_at": now,
    }


def list_access_tokens() -> list[dict[str, Any]]:
    now = _now()
    with make_plugin_db() as conn:
        rows = conn.execute(
            text(
                "SELECT token_id, name, scope, expires_at, created_at, "
                "last_used_at, revoked_at "
                "FROM plugin_whatsbot_mcp_access_tokens "
                "ORDER BY created_at DESC LIMIT 100"
            )
        ).mappings().all()
    result = []
    for row in rows:
        item = dict(row)
        item["never_expires"] = int(item["expires_at"]) == 0
        item["status"] = (
            "revoked"
            if item["revoked_at"] is not None
            else "expired"
            if int(item["expires_at"]) != 0 and int(item["expires_at"]) < now
            else "active"
        )
        result.append(item)
    return result


def revoke_access_token(token_id: str) -> bool:
    if not token_id or len(token_id) > 64:
        return False
    with make_plugin_db() as conn:
        result = conn.execute(
            text(
                "UPDATE plugin_whatsbot_mcp_access_tokens "
                "SET revoked_at = :now "
                "WHERE token_id = :token_id AND revoked_at IS NULL"
            ),
            {"now": _now(), "token_id": token_id},
        )
    return result.rowcount == 1


def validate_access_token(raw_token: str) -> set[str] | None:
    if (
        not raw_token
        or not raw_token.startswith(TOKEN_PREFIX)
        or len(raw_token) > 512
    ):
        return None
    now = _now()
    hashed = token_hash(raw_token)
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT scope FROM plugin_whatsbot_mcp_access_tokens "
                "WHERE token_hash = :token_hash AND revoked_at IS NULL "
                "AND (expires_at = 0 OR expires_at >= :now)"
            ),
            {"token_hash": hashed, "now": now},
        ).mappings().first()
        if row:
            conn.execute(
                text(
                    "UPDATE plugin_whatsbot_mcp_access_tokens "
                    "SET last_used_at = :now WHERE token_hash = :token_hash"
                ),
                {"now": now, "token_hash": hashed},
            )
    if not row:
        return None
    return set(str(row["scope"] or "").split())
