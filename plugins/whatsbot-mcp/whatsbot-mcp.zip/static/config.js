import { h } from 'preact';
import { useEffect, useState } from 'preact/hooks';
import htm from 'htm';

const html = htm.bind(h);

const DOCS = {
  chatgpt: 'https://developers.openai.com/apps-sdk/deploy/connect-chatgpt',
  gemini: 'https://google-gemini.github.io/gemini-cli/docs/tools/mcp-server.html',
  claude: 'https://support.claude.com/en/articles/11175166-get-started-with-custom-connectors-using-remote-mcp',
  claudeCode: 'https://code.claude.com/docs/en/mcp',
  hermes: 'https://hermes-agent.nousresearch.com/docs/user-guide/features/mcp',
  openclaw: 'https://docs.openclaw.ai/gateway/configuration-reference#mcp',
};

function authHeaders(extra = {}) {
  const token = localStorage.getItem('whatsbot_token') || '';
  return token ? { ...extra, Authorization: `Bearer ${token}` } : { ...extra };
}

function formatDate(timestamp) {
  if (!timestamp) return 'Nunca';
  return new Date(Number(timestamp) * 1000).toLocaleString('pt-BR');
}

function formatExpiry(timestamp) {
  return Number(timestamp) === 0 ? 'Sem expiração' : formatDate(timestamp);
}

function Code({ children }) {
  return html`
    <pre class="mt-2 overflow-x-auto rounded bg-slate-950 p-3 text-[11px] leading-relaxed text-slate-100"><code>${children}</code></pre>
  `;
}

function Guide({ id, title, openGuide, setOpenGuide, children, docs }) {
  const open = openGuide === id;
  return html`
    <div class="border border-wa-border rounded-lg overflow-hidden">
      <button type="button"
              class="w-full flex items-center justify-between gap-3 px-3 py-3 text-left bg-wa-panel"
              aria-expanded=${open}
              onClick=${() => setOpenGuide(open ? '' : id)}>
        <span class="text-sm font-medium">${title}</span>
        <span class="text-wa-secondary">${open ? '−' : '+'}</span>
      </button>
      ${open && html`
        <div class="border-t border-wa-border p-3 text-xs leading-relaxed space-y-2">
          ${children}
          <a class="inline-block text-wa-teal underline"
             href=${docs} target="_blank" rel="noopener noreferrer">Documentação oficial</a>
        </div>
      `}
    </div>
  `;
}

export default function WhatsBotMcpConfig({ apiBase = '/api/plugins/whatsbot_mcp' } = {}) {
  const [values, setValues] = useState({
    public_base_url: location.origin,
    allow_write_tools: true,
    max_contacts: 25,
    max_messages: 50,
    max_text_chars: 4000,
  });
  const [tokens, setTokens] = useState([]);
  const [tokenName, setTokenName] = useState('');
  const [tokenScope, setTokenScope] = useState('whatsbot:read');
  const [tokenDays, setTokenDays] = useState(90);
  const [neverExpires, setNeverExpires] = useState(false);
  const [tokenStatus, setTokenStatus] = useState('');
  const [newToken, setNewToken] = useState(null);
  const [showNewToken, setShowNewToken] = useState(false);
  const [openGuide, setOpenGuide] = useState('chatgpt');
  const [status, setStatus] = useState('Carregando…');
  const [saving, setSaving] = useState(false);
  const [creatingToken, setCreatingToken] = useState(false);
  const endpoint = `${String(values.public_base_url || location.origin).replace(/\/$/, '')}/mcp`;
  const tokenExample = '<TOKEN_MCP>';

  async function load() {
    try {
      const [settingsResponse, healthResponse, tokensResponse] = await Promise.all([
        fetch(`${apiBase}/settings`, { headers: authHeaders() }),
        fetch(`${apiBase}/health`, { headers: authHeaders() }),
        fetch(`${apiBase}/tokens`, { headers: authHeaders() }),
      ]);
      const settingsData = await settingsResponse.json();
      const healthData = await healthResponse.json();
      const tokensData = await tokensResponse.json();
      if (settingsData.ok && settingsData.data && settingsData.data.values) {
        setValues(settingsData.data.values);
      }
      if (tokensData.ok && tokensData.data) {
        setTokens(tokensData.data.tokens || []);
      }
      setStatus(healthData.ok ? `Online · v${healthData.data.version}` : 'Indisponível');
    } catch (error) {
      setStatus(`Erro: ${error.message || error}`);
    }
  }

  async function save() {
    setSaving(true);
    try {
      const response = await fetch(`${apiBase}/settings`, {
        method: 'PUT',
        headers: authHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(values),
      });
      const data = await response.json();
      if (!data.ok) throw new Error(data.error || 'Falha ao salvar');
      setValues(data.data.values);
      setStatus('Configurações salvas');
    } catch (error) {
      setStatus(`Erro: ${error.message || error}`);
    } finally {
      setSaving(false);
    }
  }

  async function createToken() {
    const days = Number(tokenDays);
    if (
      !neverExpires
      && (!Number.isInteger(days) || days < 1 || days > 365)
    ) {
      setTokenStatus('Informe uma validade entre 1 e 365 dias ou marque Sem expiração.');
      return;
    }
    setTokenStatus('');
    setCreatingToken(true);
    try {
      const response = await fetch(`${apiBase}/tokens`, {
        method: 'POST',
        headers: authHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          name: tokenName,
          scope: tokenScope,
          valid_days: days,
          never_expires: neverExpires,
        }),
      });
      const data = await response.json();
      if (!data.ok) throw new Error(data.error || 'Falha ao gerar token');
      setNewToken(data.data);
      setShowNewToken(false);
      setTokenName('');
      setTokenStatus(
        data.data.never_expires
          ? 'Token sem expiração criado; copie-o agora.'
          : 'Token criado; copie-o agora.'
      );
      setStatus('Token criado; copie-o agora');
      const listResponse = await fetch(`${apiBase}/tokens`, { headers: authHeaders() });
      const listData = await listResponse.json();
      if (listData.ok) setTokens(listData.data.tokens || []);
    } catch (error) {
      setTokenStatus(`Erro: ${error.message || error}`);
      setStatus(`Erro: ${error.message || error}`);
    } finally {
      setCreatingToken(false);
    }
  }

  async function revokeToken(tokenId) {
    if (!window.confirm('Revogar este token? Os clientes que o usam perderão acesso.')) return;
    try {
      const response = await fetch(`${apiBase}/tokens/${encodeURIComponent(tokenId)}`, {
        method: 'DELETE',
        headers: authHeaders(),
      });
      const data = await response.json();
      if (!data.ok) throw new Error(data.error || 'Falha ao revogar');
      setTokens(tokens.map(item => (
        item.token_id === tokenId
          ? { ...item, status: 'revoked', revoked_at: Math.floor(Date.now() / 1000) }
          : item
      )));
      setTokenStatus('Token revogado');
      setStatus('Token revogado');
    } catch (error) {
      setTokenStatus(`Erro: ${error.message || error}`);
      setStatus(`Erro: ${error.message || error}`);
    }
  }

  async function copy(value, message) {
    try {
      await navigator.clipboard.writeText(value);
      setStatus(message);
    } catch (error) {
      setStatus(`Não foi possível copiar: ${error.message || error}`);
    }
  }

  useEffect(() => { load(); }, []);

  return html`
    <div class="space-y-6">
      <section class="space-y-3">
        <div>
          <label class="block text-sm font-medium mb-1">URL pública HTTPS</label>
          <input class="w-full border border-wa-border bg-wa-panel rounded px-3 py-2 text-xs"
                 value=${values.public_base_url || ''}
                 onInput=${event => setValues({ ...values, public_base_url: event.target.value })} />
        </div>
        <div>
          <div class="text-sm font-medium mb-1">Endpoint MCP universal</div>
          <div class="flex gap-2">
            <input class="flex-1 border border-wa-border bg-wa-panel rounded px-3 py-2 text-xs"
                   readOnly value=${endpoint} />
            <button type="button" class="px-3 py-2 rounded bg-wa-teal text-white text-sm"
                    onClick=${() => copy(endpoint, 'Endpoint copiado')}>Copiar</button>
          </div>
          <div class="text-xs text-wa-secondary mt-2">${status}</div>
        </div>

        <label class="flex items-start gap-3 border border-wa-border rounded p-3">
          <input type="checkbox" class="mt-1"
                 checked=${values.allow_write_tools}
                 onChange=${event => setValues({ ...values, allow_write_tools: event.target.checked })} />
          <span>
            <span class="block text-sm font-medium">Permitir ferramentas de escrita</span>
            <span class="block text-xs text-wa-secondary">
              Envios e alterações ainda exigem confirm=true e uma chave de idempotência única.
            </span>
          </span>
        </label>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
          ${[
            ['max_contacts', 'Contatos', 1, 100],
            ['max_messages', 'Mensagens', 1, 200],
            ['max_text_chars', 'Caracteres', 100, 12000],
          ].map(([key, label, min, max]) => html`
            <label class="text-xs">
              <span class="block mb-1 text-wa-secondary">${label}</span>
              <input type="number" min=${min} max=${max}
                     class="w-full border border-wa-border bg-wa-panel rounded px-3 py-2"
                     value=${values[key]}
                     onInput=${event => setValues({ ...values, [key]: Number(event.target.value) })} />
            </label>
          `)}
        </div>

        <button type="button" disabled=${saving}
                class="px-4 py-2 rounded bg-wa-teal text-white text-sm disabled:opacity-50"
                onClick=${save}>${saving ? 'Salvando…' : 'Salvar configurações'}</button>
      </section>

      <section class="border-t border-wa-border pt-5 space-y-3">
        <div>
          <h3 class="text-base font-semibold">Tokens MCP</h3>
          <p class="text-xs text-wa-secondary mt-1">
            Alternativa ao OAuth para qualquer cliente que aceite o header Authorization.
            O token funciona somente em ${endpoint}, nunca na administração do WhatsBot.
          </p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <label class="text-xs sm:col-span-1">
            <span class="block mb-1 text-wa-secondary">Nome do cliente</span>
            <input class="w-full border border-wa-border bg-wa-panel rounded px-3 py-2"
                   maxlength="80" placeholder="Ex.: automação local"
                   value=${tokenName}
                   onInput=${event => setTokenName(event.target.value)} />
          </label>
          <label class="text-xs">
            <span class="block mb-1 text-wa-secondary">Permissões</span>
            <select class="w-full border border-wa-border bg-wa-panel rounded px-3 py-2"
                    value=${tokenScope}
                    onChange=${event => setTokenScope(event.target.value)}>
              <option value="whatsbot:read">Somente leitura</option>
              <option value="whatsbot:read whatsbot:write">Leitura e escrita</option>
            </select>
          </label>
          <label class="text-xs">
            <span class="block mb-1 text-wa-secondary">Validade em dias</span>
            <input type="number" min="1" max="365"
                   disabled=${neverExpires}
                   class="w-full border border-wa-border bg-wa-panel rounded px-3 py-2 disabled:opacity-50"
                   value=${tokenDays}
                   onInput=${event => setTokenDays(Number(event.target.value))} />
          </label>
        </div>
        <label class="flex items-start gap-3 border border-wa-border rounded p-3">
          <input type="checkbox" class="mt-1"
                 checked=${neverExpires}
                 onChange=${event => {
                   setNeverExpires(event.target.checked);
                   setTokenStatus('');
                 }} />
          <span>
            <span class="block text-sm font-medium">Sem expiração</span>
            <span class="block text-xs text-wa-secondary">
              O token continuará válido até ser revogado manualmente.
            </span>
          </span>
        </label>
        <button type="button" disabled=${creatingToken || !tokenName.trim()}
                class="px-4 py-2 rounded bg-wa-teal text-white text-sm disabled:opacity-50"
                onClick=${createToken}>${creatingToken ? 'Gerando…' : 'Gerar novo token'}</button>
        ${tokenStatus && html`
          <div class=${`text-xs ${
            tokenStatus.startsWith('Erro:') || tokenStatus.startsWith('Informe')
              ? 'text-red-700'
              : 'text-wa-secondary'
          }`}>
            ${tokenStatus}
          </div>
        `}

        ${newToken && html`
          <div class="rounded border border-amber-300 bg-amber-50 text-amber-950 p-3 space-y-2">
            <div class="text-sm font-semibold">Copie agora: o valor completo só aparece nesta tela.</div>
            <div class="text-xs">
              Validade: ${newToken.never_expires ? 'Sem expiração — válido até revogação' : formatExpiry(newToken.expires_at)}
            </div>
            <div class="flex flex-wrap gap-2">
              <input class="min-w-0 flex-1 border border-amber-300 bg-white rounded px-3 py-2 text-xs font-mono"
                     type=${showNewToken ? 'text' : 'password'} readOnly value=${newToken.token} />
              <button type="button" class="px-3 py-2 rounded border border-amber-400 text-xs"
                      onClick=${() => setShowNewToken(!showNewToken)}>
                ${showNewToken ? 'Ocultar' : 'Mostrar'}
              </button>
              <button type="button" class="px-3 py-2 rounded bg-amber-700 text-white text-xs"
                      onClick=${() => copy(newToken.token, 'Token copiado')}>
                Copiar token
              </button>
            </div>
          </div>
        `}

        <div class="space-y-2">
          ${tokens.length === 0 && html`
            <p class="text-xs text-wa-secondary">Nenhum token criado.</p>
          `}
          ${tokens.map(item => html`
            <div class="flex flex-wrap items-center justify-between gap-3 border border-wa-border rounded p-3">
              <div class="min-w-0">
                <div class="text-sm font-medium">${item.name}</div>
                <div class="text-[11px] text-wa-secondary break-all">
                  ${item.token_id} · ${item.scope} · ${formatExpiry(item.expires_at)}
                </div>
                <div class="text-[11px] text-wa-secondary">
                  Último uso: ${formatDate(item.last_used_at)} · ${item.status}
                </div>
              </div>
              ${item.status === 'active' && html`
                <button type="button" class="px-3 py-1.5 rounded border border-red-300 text-red-700 text-xs"
                        onClick=${() => revokeToken(item.token_id)}>Revogar</button>
              `}
            </div>
          `)}
        </div>
      </section>

      <section class="border-t border-wa-border pt-5 space-y-3">
        <div>
          <h3 class="text-base font-semibold">Como conectar</h3>
          <p class="text-xs text-wa-secondary mt-1">
            Prefira OAuth. Use um token MCP apenas quando o cliente não fizer descoberta OAuth.
          </p>
        </div>

        <${Guide} id="chatgpt" title="ChatGPT" openGuide=${openGuide}
          setOpenGuide=${setOpenGuide} docs=${DOCS.chatgpt}>
          <ol class="list-decimal pl-5 space-y-1">
            <li>Abra Configurações → Plugins e crie um novo plugin.</li>
            <li>Nome: WhatsBot. URL do servidor: <strong>${endpoint}</strong>.</li>
            <li>Em Autenticação selecione <strong>OAuth</strong>, aceite o aviso e clique em Criar.</li>
            <li>Na autorização, informe a senha do painel WhatsBot e permita o acesso.</li>
          </ol>
        <//>

        <${Guide} id="gemini" title="Gemini CLI" openGuide=${openGuide}
          setOpenGuide=${setOpenGuide} docs=${DOCS.gemini}>
          <p>Adicione o servidor HTTP e, dentro do Gemini CLI, execute o comando de autenticação:</p>
          <${Code}>${`gemini mcp add --transport http whatsbot ${endpoint}\n/mcp auth whatsbot`}<//>
          <p>Alternativa com token:</p>
          <${Code}>${`gemini mcp add --transport http whatsbot ${endpoint} --header "Authorization: Bearer ${tokenExample}"`}<//>
        <//>

        <${Guide} id="claude" title="Claude (web, Desktop e mobile)" openGuide=${openGuide}
          setOpenGuide=${setOpenGuide} docs=${DOCS.claude}>
          <ol class="list-decimal pl-5 space-y-1">
            <li>Abra Customize → Connectors → + → Add custom connector.</li>
            <li>Cole <strong>${endpoint}</strong> como URL do servidor remoto.</li>
            <li>Deixe Client ID e Client Secret vazios para usar o cadastro automático.</li>
            <li>Clique em Add, depois Connect, e conclua a autorização OAuth.</li>
          </ol>
        <//>

        <${Guide} id="claude-code" title="Claude Code" openGuide=${openGuide}
          setOpenGuide=${setOpenGuide} docs=${DOCS.claudeCode}>
          <p>OAuth automático, salvo no escopo do usuário:</p>
          <${Code}>${`claude mcp add --transport http --scope user whatsbot ${endpoint}\nclaude mcp login whatsbot`}<//>
          <p>Alternativa com token:</p>
          <${Code}>${`claude mcp add --transport http --scope user whatsbot ${endpoint} \\\n  --header "Authorization: Bearer ${tokenExample}"`}<//>
        <//>

        <${Guide} id="hermes" title="Hermes Agent" openGuide=${openGuide}
          setOpenGuide=${setOpenGuide} docs=${DOCS.hermes}>
          <p>Em <code>~/.hermes/config.yaml</code>:</p>
          <${Code}>${`mcp_servers:\n  whatsbot:\n    url: "${endpoint}"\n    auth: oauth`}<//>
          <${Code}>${`hermes mcp login whatsbot`}<//>
          <p>Alternativa: remova <code>auth: oauth</code> e configure o header:</p>
          <${Code}>${`    headers:\n      Authorization: "Bearer ${tokenExample}"`}<//>
        <//>

        <${Guide} id="openclaw" title="OpenClaw" openGuide=${openGuide}
          setOpenGuide=${setOpenGuide} docs=${DOCS.openclaw}>
          <p>Adicione ao arquivo de configuração:</p>
          <${Code}>${`{\n  mcp: {\n    servers: {\n      whatsbot: {\n        url: "${endpoint}",\n        transport: "streamable-http",\n        auth: "oauth"\n      }\n    }\n  }\n}`}<//>
          <${Code}>${`openclaw mcp login whatsbot`}<//>
          <p>Alternativa: remova <code>auth</code> e use:</p>
          <${Code}>${`headers: { Authorization: "Bearer ${tokenExample}" }`}<//>
        <//>
      </section>

      <div class="rounded border border-yellow-200 bg-yellow-50 text-yellow-900 p-3 text-xs leading-relaxed">
        OAuth exige a senha apenas na página deste servidor. Tokens MCP são segredos:
        não publique, não envie em mensagens e revogue imediatamente se houver exposição.
      </div>
    </div>
  `;
}
