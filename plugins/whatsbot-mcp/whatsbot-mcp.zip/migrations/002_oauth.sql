CREATE TABLE IF NOT EXISTS plugin_whatsbot_mcp_oauth_clients (
    client_id          TEXT PRIMARY KEY,
    client_name        TEXT NOT NULL,
    redirect_uris_json TEXT NOT NULL,
    created_at         BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS plugin_whatsbot_mcp_oauth_codes (
    code_hash      TEXT PRIMARY KEY,
    client_id      TEXT NOT NULL,
    redirect_uri   TEXT NOT NULL,
    code_challenge TEXT NOT NULL,
    scope          TEXT NOT NULL,
    resource       TEXT NOT NULL,
    expires_at     BIGINT NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_whatsbot_mcp_oauth_codes_expires_at
    ON plugin_whatsbot_mcp_oauth_codes(expires_at);

CREATE TABLE IF NOT EXISTS plugin_whatsbot_mcp_oauth_tokens (
    access_hash        TEXT PRIMARY KEY,
    refresh_hash       TEXT NOT NULL UNIQUE,
    client_id          TEXT NOT NULL,
    scope              TEXT NOT NULL,
    resource           TEXT NOT NULL,
    access_expires_at  BIGINT NOT NULL,
    refresh_expires_at BIGINT NOT NULL,
    created_at         BIGINT NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_whatsbot_mcp_oauth_tokens_refresh_expires_at
    ON plugin_whatsbot_mcp_oauth_tokens(refresh_expires_at);

