CREATE TABLE IF NOT EXISTS plugin_whatsbot_mcp_access_tokens (
    token_hash   TEXT PRIMARY KEY,
    token_id     TEXT NOT NULL UNIQUE,
    name         TEXT NOT NULL,
    scope        TEXT NOT NULL,
    expires_at   BIGINT NOT NULL,
    created_at   BIGINT NOT NULL,
    last_used_at BIGINT,
    revoked_at   BIGINT
);

CREATE INDEX IF NOT EXISTS plugin_whatsbot_mcp_access_tokens_expires_at
    ON plugin_whatsbot_mcp_access_tokens(expires_at);

CREATE INDEX IF NOT EXISTS plugin_whatsbot_mcp_access_tokens_token_id
    ON plugin_whatsbot_mcp_access_tokens(token_id);
