CREATE TABLE IF NOT EXISTS plugin_whatsbot_mcp_requests (
    idempotency_key TEXT PRIMARY KEY,
    tool            TEXT NOT NULL,
    phone           TEXT NOT NULL DEFAULT '',
    status          TEXT NOT NULL,
    result_json     TEXT,
    created_at      BIGINT NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_whatsbot_mcp_requests_created_at
    ON plugin_whatsbot_mcp_requests(created_at);

