"""WhatsBot MCP plugin.

The WhatsBot loader can only mount plugin routers below ``/api/plugins/<id>``.
MCP OAuth discovery and resource endpoints must be public, while the rest of
WhatsBot's ``/api`` remains protected. During plugin discovery (which runs
before core route registration), this module adds one narrow hook around the
core auth route registrar. The hook only registers this plugin's OAuth and
root ``/mcp`` routes; it does not disable or replace WhatsBot authentication.
"""

__version__ = "1.2.1"


def _install_public_routes_hook() -> None:
    from server.routes import auth as core_auth

    marker = "_whatsbot_mcp_public_routes_hooked"
    if getattr(core_auth, marker, False):
        return

    original_register_routes = core_auth.register_routes

    def register_routes_with_mcp_oauth(app, deps):
        original_register_routes(app, deps)
        from .oauth import register_public_routes

        register_public_routes(app, deps)

    core_auth.register_routes = register_routes_with_mcp_oauth
    setattr(core_auth, marker, True)


_install_public_routes_hook()
