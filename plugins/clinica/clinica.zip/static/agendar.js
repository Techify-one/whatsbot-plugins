// Página pública de agendamento da Clínica Vida Leve (Etapa 6 — UX revista).
//
// Layout consumer-facing inspirado em Calendly/Fresha:
//   1) Serviço     → cards com nome/duração/preço
//   2) Profissional → cards horizontais com "Qualquer disponível" no topo
//   3) Data         → calendário do mês com dias sem vaga acinzentados +
//                     atalhos "Hoje / Amanhã / Próxima semana"
//   4) Horário      → chips dos slots do dia escolhido
//   5) Dados        → nome + WhatsApp
//   6) Confirmação  → resumo da reserva + protocolo
//
// Endpoints consumidos (todos públicos):
//   GET  /info
//   GET  /servicos
//   GET  /servicos/{id}/profissionais
//   GET  /servicos/{id}/disponibilidade?mes=YYYY-MM[&profissional_id=N]
//   GET  /servicos/{id}/slots?data=YYYY-MM-DD[&profissional_id=N]
//   POST /agendamentos
//   GET  /agendamentos/{id}
//
// IMPORTANTE: este arquivo NÃO depende do token de auth — usa fetch puro.
// Mantemos compatibilidade caso o admin acesse: a página funciona com ou
// sem token. Endpoints chamados são todos públicos.

import { h } from 'preact';
import { useEffect, useState, useMemo, useCallback, useRef } from 'preact/hooks';
import htm from 'htm';

const html = htm.bind(h);

// ── fetch helpers (sem auth) ───────────────────────────────────────────
async function apiJson(url, init = {}) {
  const headers = { ...(init.headers || {}) };
  if (init.body) headers['Content-Type'] = headers['Content-Type'] || 'application/json';
  const res = await fetch(url, { ...init, headers });
  const raw = await res.text();
  let data;
  try { data = raw ? JSON.parse(raw) : {}; }
  catch { throw new Error(`Erro ${res.status}: ${raw.slice(0, 200) || res.statusText}`); }
  if (!res.ok || !data.ok) {
    throw new Error(data.error || data.detail || `Erro ${res.status}`);
  }
  return data.data;
}

// ── formatadores ───────────────────────────────────────────────────────
const formatBRL = (centavos) =>
  (centavos / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const formatDuracao = (min) => {
  if (min < 60) return `${min} min`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m ? `${h}h${m.toString().padStart(2, '0')}` : `${h}h`;
};

const DIAS_SEMANA_ABREV = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
const DIAS_SEMANA = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];
const MESES = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro',
];

const pad2 = (n) => n.toString().padStart(2, '0');
const toISO = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const hojeLocal = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
const isoToDate = (iso) => {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d);
};
const formatDataLonga = (iso) => {
  const d = isoToDate(iso);
  return `${DIAS_SEMANA[(d.getDay() + 6) % 7]}, ${d.getDate()} de ${MESES[d.getMonth()]}`;
};

// WhatsApp: aceita só dígitos; máscara visual (XX) XXXXX-XXXX para celular BR.
// Estado guarda apenas dígitos (`telefone`); o input exibe o formato.
const onlyDigits = (s) => (s || '').replace(/\D+/g, '');
const formatWhatsAppMask = (digits) => {
  const d = onlyDigits(digits).slice(0, 11);
  if (d.length <= 2) return d;
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
};
// Brasil: 10 dígitos (fixo) ou 11 (celular com 9 inicial). DDI 55 é adicionado no backend.
const isWhatsAppValido = (digits) => /^\d{10,11}$/.test(onlyDigits(digits));

// ══════════════════════════════════════════════════════════════════════
// Componente raiz
// ══════════════════════════════════════════════════════════════════════

export default function AgendarScreen({ apiBase }) {
  const [info, setInfo] = useState(null);
  const [servicos, setServicos] = useState([]);
  const [servico, setServico] = useState(null);
  const [profissionais, setProfissionais] = useState([]);
  // null = "qualquer disponível"; objeto = profissional escolhido
  const [profissional, setProfissional] = useState(undefined); // undefined = ainda não escolheu
  const [dataIso, setDataIso] = useState(null);
  const [slot, setSlot] = useState(null);
  const [cliente, setCliente] = useState({ nome: '', telefone: '' });
  const [confirmado, setConfirmado] = useState(null);
  const [carregando, setCarregando] = useState(true);
  const [erroGeral, setErroGeral] = useState('');
  // Etapa 12.5 — token de convite vindo de ?c=TOKEN (gerado pela tool
  // enviar_link_agendamento). Quando válido, pré-preenche o WhatsApp e é
  // reenviado no POST /agendamentos para marcar `used_at` (métrica).
  const [conviteToken, setConviteToken] = useState(null);
  const [conviteAplicado, setConviteAplicado] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [i, s] = await Promise.all([
          apiJson(`${apiBase}/info`),
          apiJson(`${apiBase}/servicos`),
        ]);
        setInfo(i);
        setServicos(s);
      } catch (e) {
        setErroGeral(e.message);
      } finally {
        setCarregando(false);
      }
    })();
  }, [apiBase]);

  // Lê ?c=TOKEN do URL e pré-preenche o telefone. Roda uma vez no boot.
  // Falha (token inválido/expirado) é silenciosa: a página segue funcionando
  // como se não houvesse convite — o cliente digita o WhatsApp normalmente.
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const tk = (params.get('c') || '').trim();
      if (!tk) return;
      setConviteToken(tk);
      (async () => {
        try {
          const data = await apiJson(`${apiBase}/convites/${encodeURIComponent(tk)}`);
          const tel = onlyDigits(data?.telefone || '');
          if (tel) {
            setCliente((c) => ({ ...c, telefone: tel }));
            setConviteAplicado(true);
          }
        } catch (_) {
          // Token expirado/inexistente — segue o jogo sem pré-preencher.
        }
      })();
    } catch (_) {
      // window/URLSearchParams indisponível (SSR-like) — ignora.
    }
  }, [apiBase]);

  // Quando muda o serviço, recarrega lista de profissionais aptos.
  useEffect(() => {
    if (!servico) {
      setProfissionais([]);
      setProfissional(undefined);
      setDataIso(null);
      setSlot(null);
      return;
    }
    setProfissional(undefined);
    setDataIso(null);
    setSlot(null);
    (async () => {
      try {
        const p = await apiJson(`${apiBase}/servicos/${servico.id}/profissionais`);
        setProfissionais(p);
      } catch (e) {
        setErroGeral(e.message);
      }
    })();
  }, [apiBase, servico]);

  const resetTudo = () => {
    setServico(null);
    setProfissional(undefined);
    setDataIso(null);
    setSlot(null);
    setCliente({ nome: '', telefone: '' });
    setConfirmado(null);
    setErroGeral('');
  };

  if (carregando) {
    return html`<div class="min-h-screen flex items-center justify-center text-gray-500">Carregando...</div>`;
  }

  if (confirmado) {
    return html`<${PaginaConfirmacao} ag=${confirmado} info=${info} apiBase=${apiBase} onNovo=${resetTudo} />`;
  }

  return html`
    <div class="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <!-- Header da clínica -->
      <header class="bg-white border-b border-gray-200">
        <div class="max-w-4xl mx-auto px-4 py-5">
          <h1 class="text-2xl md:text-3xl font-bold text-gray-900">${info?.nome || 'Agendar'}</h1>
          ${info?.slogan && html`<p class="text-sm text-gray-500 mt-1">${info.slogan}</p>`}
          <div class="text-xs text-gray-500 mt-2 flex flex-wrap gap-x-4 gap-y-1">
            ${info?.telefone && html`<span>📞 ${info.telefone}</span>`}
            ${info?.endereco && html`<span>📍 ${info.endereco}</span>`}
          </div>
        </div>
      </header>

      <main class="max-w-4xl mx-auto px-4 py-6 space-y-6">
        ${erroGeral && html`
          <div class="bg-red-50 border border-red-200 text-red-700 rounded-lg p-3 text-sm">
            ${erroGeral}
          </div>
        `}

        <!-- 1. Serviço -->
        <${Passo} numero="1" titulo="Escolha o serviço" ativo=${true}>
          <${ServicoCards}
            servicos=${servicos}
            selecionado=${servico}
            onSelect=${setServico}
          />
        </${Passo}>

        <!-- 2. Profissional -->
        ${servico && html`
          <${Passo} numero="2" titulo="Escolha o profissional" ativo=${true}>
            <${ProfissionalCards}
              profissionais=${profissionais}
              selecionado=${profissional}
              onSelect=${setProfissional}
            />
          </${Passo}>
        `}

        <!-- 3. Data -->
        ${servico && profissional !== undefined && html`
          <${Passo} numero="3" titulo="Escolha o dia e horário" ativo=${true}>
            <${SeletorDataHora}
              key=${`${servico.id}-${profissional?.id ?? 'any'}`}
              apiBase=${apiBase}
              servico=${servico}
              profissionalId=${profissional?.id || null}
              dataIso=${dataIso}
              slot=${slot}
              onDataChange=${(d) => { setDataIso(d); setSlot(null); }}
              onSlotChange=${setSlot}
            />
          </${Passo}>
        `}

        <!-- 4. Dados do cliente -->
        ${servico && profissional !== undefined && dataIso && slot && html`
          <${Passo} numero="4" titulo="Seus dados" ativo=${true}>
            <${FormCliente}
              apiBase=${apiBase}
              servico=${servico}
              profissional=${profissional}
              profissionais=${profissionais}
              dataIso=${dataIso}
              slot=${slot}
              cliente=${cliente}
              onClienteChange=${setCliente}
              onConfirmado=${setConfirmado}
              conviteToken=${conviteToken}
              conviteAplicado=${conviteAplicado}
            />
          </${Passo}>
        `}
      </main>

      <footer class="text-center text-xs text-gray-400 py-6">
        Clínica Vida Leve · Sistema didático WhatsBot
      </footer>
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// Wrapper de passo numerado (estilo timeline vertical)
// ══════════════════════════════════════════════════════════════════════

function Passo({ numero, titulo, children }) {
  return html`
    <section class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div class="px-5 py-4 border-b border-gray-100 flex items-center gap-3">
        <span class="w-7 h-7 rounded-full bg-blue-600 text-white text-sm font-semibold flex items-center justify-center">${numero}</span>
        <h2 class="font-semibold text-gray-900">${titulo}</h2>
      </div>
      <div class="p-5">
        ${children}
      </div>
    </section>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// 1. Serviços (cards grid)
// ══════════════════════════════════════════════════════════════════════

function ServicoCards({ servicos, selecionado, onSelect }) {
  if (servicos.length === 0) {
    return html`<div class="text-sm text-gray-500">Nenhum serviço disponível no momento.</div>`;
  }
  return html`
    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
      ${servicos.map(s => {
        const ativo = selecionado?.id === s.id;
        // Faixa de preço entre os profissionais do serviço (cai no base se vier null).
        const precoMin = s.preco_min_centavos ?? s.valor_centavos;
        const precoMax = s.preco_max_centavos ?? s.valor_centavos;
        const varia = precoMin !== precoMax;
        return html`
          <button
            key=${s.id}
            type="button"
            onClick=${() => onSelect(s)}
            class=${`text-left border rounded-lg p-4 transition-all ${
              ativo
                ? 'border-blue-600 bg-blue-50 ring-2 ring-blue-200'
                : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-sm'
            }`}
          >
            <div class="flex items-start justify-between gap-3 mb-1">
              <div class="font-semibold text-gray-900">${s.nome}</div>
              <div class="text-right whitespace-nowrap">
                ${varia && html`<div class="text-[10px] text-gray-400 leading-none mb-0.5">a partir de</div>`}
                <div class="font-semibold text-blue-700">${formatBRL(precoMin)}</div>
              </div>
            </div>
            ${s.descricao && html`<div class="text-xs text-gray-600 mb-2">${s.descricao}</div>`}
            <div class="text-xs text-gray-500">⏱ ${formatDuracao(s.duracao_min)}</div>
          </button>
        `;
      })}
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// 2. Profissionais (com "Qualquer disponível" no topo)
// ══════════════════════════════════════════════════════════════════════

function ProfissionalCards({ profissionais, selecionado, onSelect }) {
  if (profissionais.length === 0) {
    return html`
      <div class="text-sm text-gray-500">
        Nenhum profissional disponível para esse serviço no momento.
      </div>
    `;
  }
  const qualquerAtivo = selecionado === null;
  // Menor preço entre os profissionais — anunciado no card "Qualquer disponível"
  // (o backend escolhe o mais barato entre os livres na hora de reservar).
  const precos = profissionais.map(p => p.valor_centavos).filter(v => v != null);
  const precoMin = precos.length ? Math.min(...precos) : null;
  const precoMax = precos.length ? Math.max(...precos) : null;
  const variaPreco = precoMin != null && precoMin !== precoMax;
  return html`
    <div class="space-y-2">
      <button
        type="button"
        onClick=${() => onSelect(null)}
        class=${`w-full text-left border rounded-lg p-3 transition-all ${
          qualquerAtivo
            ? 'border-blue-600 bg-blue-50 ring-2 ring-blue-200'
            : 'border-gray-200 bg-white hover:border-gray-300'
        }`}
      >
        <div class="flex items-center gap-3">
          <span class="w-10 h-10 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-lg">✨</span>
          <div class="flex-1">
            <div class="font-semibold text-gray-900">Qualquer profissional disponível</div>
            <div class="text-xs text-gray-500">Mostramos mais horários — escolhemos automaticamente.</div>
          </div>
          ${precoMin != null && html`
            <div class="text-right whitespace-nowrap">
              ${variaPreco && html`<div class="text-[10px] text-gray-400 leading-none mb-0.5">a partir de</div>`}
              <div class="font-semibold text-blue-700 text-sm">${formatBRL(precoMin)}</div>
            </div>
          `}
        </div>
      </button>
      ${profissionais.map(p => {
        const ativo = selecionado?.id === p.id;
        const iniciais = p.nome.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
        return html`
          <button
            key=${p.id}
            type="button"
            onClick=${() => onSelect(p)}
            class=${`w-full text-left border rounded-lg p-3 transition-all ${
              ativo
                ? 'border-blue-600 bg-blue-50 ring-2 ring-blue-200'
                : 'border-gray-200 bg-white hover:border-gray-300'
            }`}
          >
            <div class="flex items-center gap-3">
              <span class="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-semibold text-sm">${iniciais}</span>
              <div class="flex-1">
                <div class="font-semibold text-gray-900">${p.nome}</div>
                ${p.especialidade && html`<div class="text-xs text-gray-500">${p.especialidade}</div>`}
              </div>
              ${p.valor_centavos != null && html`
                <div class="font-semibold text-blue-700 text-sm whitespace-nowrap">${formatBRL(p.valor_centavos)}</div>
              `}
            </div>
          </button>
        `;
      })}
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// 3. Calendário + slots
// ══════════════════════════════════════════════════════════════════════

function SeletorDataHora({ apiBase, servico, profissionalId, dataIso, slot, onDataChange, onSlotChange }) {
  // Mês exibido no calendário (Date apontando pro dia 1).
  const [mesRef, setMesRef] = useState(() => { const d = hojeLocal(); d.setDate(1); return d; });
  const [disponibilidade, setDisponibilidade] = useState({}); // { iso: count }
  const [carregandoMes, setCarregandoMes] = useState(false);
  const [slots, setSlots] = useState([]);
  const [carregandoSlots, setCarregandoSlots] = useState(false);
  const [erro, setErro] = useState('');

  const mesIso = `${mesRef.getFullYear()}-${pad2(mesRef.getMonth() + 1)}`;

  // Carrega disponibilidade do mês.
  useEffect(() => {
    let cancel = false;
    (async () => {
      setCarregandoMes(true);
      setErro('');
      try {
        const q = new URLSearchParams({ mes: mesIso });
        if (profissionalId) q.set('profissional_id', profissionalId);
        const r = await apiJson(`${apiBase}/servicos/${servico.id}/disponibilidade?${q}`);
        if (!cancel) setDisponibilidade(r.dias || {});
      } catch (e) {
        if (!cancel) setErro(e.message);
      } finally {
        if (!cancel) setCarregandoMes(false);
      }
    })();
    return () => { cancel = true; };
  }, [apiBase, servico.id, profissionalId, mesIso]);

  // Carrega slots do dia escolhido.
  useEffect(() => {
    if (!dataIso) { setSlots([]); return; }
    let cancel = false;
    (async () => {
      setCarregandoSlots(true);
      setErro('');
      try {
        const q = new URLSearchParams({ data: dataIso });
        if (profissionalId) q.set('profissional_id', profissionalId);
        const r = await apiJson(`${apiBase}/servicos/${servico.id}/slots?${q}`);
        if (cancel) return;
        // Unifica todos os slots de todos os profs (dedup) em ordem.
        const set = new Set();
        for (const p of (r.profissionais || [])) {
          for (const s of p.slots) set.add(s);
        }
        setSlots([...set].sort());
      } catch (e) {
        if (!cancel) setErro(e.message);
      } finally {
        if (!cancel) setCarregandoSlots(false);
      }
    })();
    return () => { cancel = true; };
  }, [apiBase, servico.id, profissionalId, dataIso]);

  // Atalhos rápidos
  const irPara = (offsetDias) => {
    const d = hojeLocal();
    d.setDate(d.getDate() + offsetDias);
    const iso = toISO(d);
    // Se o dia cair em outro mês, avança a referência.
    setMesRef(new Date(d.getFullYear(), d.getMonth(), 1));
    onDataChange(iso);
  };

  return html`
    <div class="space-y-4">
      <!-- Atalhos -->
      <div class="flex flex-wrap gap-2">
        <button type="button" onClick=${() => irPara(0)}
          class="px-3 py-1.5 text-xs font-medium border border-gray-300 rounded-full hover:bg-gray-50">
          Hoje
        </button>
        <button type="button" onClick=${() => irPara(1)}
          class="px-3 py-1.5 text-xs font-medium border border-gray-300 rounded-full hover:bg-gray-50">
          Amanhã
        </button>
        <button type="button" onClick=${() => irPara(7)}
          class="px-3 py-1.5 text-xs font-medium border border-gray-300 rounded-full hover:bg-gray-50">
          Próxima semana
        </button>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Calendário -->
        <${CalendarioMes}
          mesRef=${mesRef}
          onMudarMes=${setMesRef}
          disponibilidade=${disponibilidade}
          carregando=${carregandoMes}
          dataSelecionada=${dataIso}
          onSelect=${onDataChange}
        />

        <!-- Slots -->
        <div>
          ${!dataIso
            ? html`
              <div class="border border-dashed border-gray-200 rounded-lg p-6 text-center text-sm text-gray-400">
                Escolha uma data no calendário para ver os horários.
              </div>
            `
            : carregandoSlots
              ? html`<div class="text-sm text-gray-500">Buscando horários...</div>`
              : html`
                <div>
                  <div class="text-sm font-medium text-gray-800 mb-2">
                    ${formatDataLonga(dataIso)}
                  </div>
                  ${slots.length === 0
                    ? html`<div class="text-sm text-gray-500">Sem horários neste dia.</div>`
                    : html`
                      <div class="grid grid-cols-3 sm:grid-cols-4 gap-2">
                        ${slots.map(s => {
                          const ativo = slot === s;
                          return html`
                            <button
                              key=${s}
                              type="button"
                              onClick=${() => onSlotChange(s)}
                              class=${`px-2 py-2 rounded font-mono text-sm border transition-colors ${
                                ativo
                                  ? 'bg-blue-600 border-blue-600 text-white'
                                  : 'bg-white border-blue-200 text-blue-800 hover:bg-blue-50'
                              }`}
                            >${s}</button>
                          `;
                        })}
                      </div>
                    `}
                </div>
              `}
        </div>
      </div>

      ${erro && html`<div class="text-sm text-red-600">${erro}</div>`}
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// Calendário de mês (Calendly-style: dias sem vaga acinzentados)
// ══════════════════════════════════════════════════════════════════════

function CalendarioMes({ mesRef, onMudarMes, disponibilidade, carregando, dataSelecionada, onSelect }) {
  const hoje = hojeLocal();
  const ano = mesRef.getFullYear();
  const mes = mesRef.getMonth();
  const primeiroDia = new Date(ano, mes, 1);
  const ultimoDia = new Date(ano, mes + 1, 0);
  // Semana começa na segunda (0=seg ... 6=dom)
  const offsetInicio = (primeiroDia.getDay() + 6) % 7;
  const totalCelulas = Math.ceil((offsetInicio + ultimoDia.getDate()) / 7) * 7;

  // Limita navegação a no máx 6 meses no futuro (didático — produção poderia variar).
  const mesMin = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
  const mesMax = new Date(hoje.getFullYear(), hoje.getMonth() + 6, 1);

  const prevMes = () => {
    const novo = new Date(ano, mes - 1, 1);
    if (novo >= mesMin) onMudarMes(novo);
  };
  const nextMes = () => {
    const novo = new Date(ano, mes + 1, 1);
    if (novo <= mesMax) onMudarMes(novo);
  };

  const celulas = useMemo(() => {
    const arr = [];
    for (let i = 0; i < totalCelulas; i++) {
      const diaNum = i - offsetInicio + 1;
      if (diaNum < 1 || diaNum > ultimoDia.getDate()) {
        arr.push(null);
      } else {
        const d = new Date(ano, mes, diaNum);
        arr.push(d);
      }
    }
    return arr;
  }, [ano, mes, offsetInicio, totalCelulas, ultimoDia]);

  return html`
    <div>
      <div class="flex items-center justify-between mb-3">
        <button type="button" onClick=${prevMes}
          disabled=${new Date(ano, mes - 1, 1) < mesMin}
          class="w-8 h-8 rounded hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed text-gray-700">‹</button>
        <div class="font-semibold text-gray-900">
          ${MESES[mes]} ${ano}
        </div>
        <button type="button" onClick=${nextMes}
          disabled=${new Date(ano, mes + 1, 1) > mesMax}
          class="w-8 h-8 rounded hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed text-gray-700">›</button>
      </div>

      <div class="grid grid-cols-7 gap-1 text-center text-xs text-gray-500 mb-1">
        ${DIAS_SEMANA_ABREV.map(d => html`<div key=${d}>${d}</div>`)}
      </div>

      <div class=${`grid grid-cols-7 gap-1 ${carregando ? 'opacity-50' : ''}`}>
        ${celulas.map((d, i) => {
          if (!d) return html`<div key=${`e${i}`}></div>`;
          const iso = toISO(d);
          const isPassado = d < hoje;
          const count = disponibilidade[iso] || 0;
          const temVaga = count > 0;
          const selecionado = iso === dataSelecionada;
          const isHoje = +d === +hoje;
          const desabilitado = isPassado || !temVaga;
          return html`
            <button
              key=${iso}
              type="button"
              disabled=${desabilitado}
              onClick=${() => onSelect(iso)}
              title=${temVaga ? `${count} horário${count !== 1 ? 's' : ''} disponível${count !== 1 ? 'eis' : ''}` : 'Sem vagas'}
              class=${`relative aspect-square rounded-lg flex flex-col items-center justify-center text-sm transition-all ${
                selecionado
                  ? 'bg-blue-600 text-white font-semibold'
                  : desabilitado
                    ? 'text-gray-300 cursor-not-allowed'
                    : isHoje
                      ? 'bg-blue-50 text-blue-800 font-semibold border border-blue-200 hover:bg-blue-100'
                      : 'text-gray-800 hover:bg-blue-50 border border-transparent hover:border-blue-200'
              }`}
            >
              <span>${d.getDate()}</span>
              ${temVaga && !selecionado && html`
                <span class="absolute bottom-1 w-1 h-1 rounded-full bg-blue-500"></span>
              `}
            </button>
          `;
        })}
      </div>

      <div class="mt-3 flex items-center gap-4 text-xs text-gray-500">
        <span class="flex items-center gap-1">
          <span class="w-1.5 h-1.5 rounded-full bg-blue-500"></span> Com vagas
        </span>
        <span class="flex items-center gap-1">
          <span class="text-gray-300">—</span> Sem vagas
        </span>
      </div>
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// 4. Form do cliente + envio
// ══════════════════════════════════════════════════════════════════════

function FormCliente({ apiBase, servico, profissional, profissionais, dataIso, slot, cliente, onClienteChange, onConfirmado, conviteToken, conviteAplicado }) {
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState('');

  // Preço do resumo: do profissional escolhido, ou "a partir de" o menor preço
  // quando o cliente deixou em "Qualquer disponível" (o backend escolhe o mais barato).
  const precosLista = (profissionais || []).map(p => p.valor_centavos).filter(v => v != null);
  const precoMinLista = precosLista.length ? Math.min(...precosLista) : servico.valor_centavos;
  const precoResumo = profissional
    ? (profissional.valor_centavos ?? servico.valor_centavos)
    : precoMinLista;
  const precoResumoLabel = profissional
    ? formatBRL(precoResumo)
    : `a partir de ${formatBRL(precoResumo)}`;

  const submit = async (e) => {
    e.preventDefault();
    const nome = cliente.nome.trim();
    const telDigits = onlyDigits(cliente.telefone);
    if (!nome) {
      setErro('Preencha o nome completo.');
      return;
    }
    if (!isWhatsAppValido(telDigits)) {
      setErro('WhatsApp inválido. Use DDD + número (ex: 11 99999-0000).');
      return;
    }
    setEnviando(true);
    setErro('');
    try {
      const ag = await apiJson(`${apiBase}/agendamentos`, {
        method: 'POST',
        body: JSON.stringify({
          servico_id: servico.id,
          profissional_id: profissional ? profissional.id : null,
          data: dataIso,
          hora_inicio: slot,
          cliente_nome: nome,
          cliente_telefone: telDigits,
          // Etapa 12.5 — só vai se o cliente abriu /clinica/agendar?c=TOKEN
          // e o token resolveu para o telefone. Backend marca used_at.
          convite_token: conviteToken || undefined,
        }),
      });
      const detalhado = await apiJson(`${apiBase}/agendamentos/${ag.id}`);
      onConfirmado(detalhado);
    } catch (e) {
      setErro(e.message);
    } finally {
      setEnviando(false);
    }
  };

  return html`
    <form onSubmit=${submit} class="space-y-4">
      <div class="bg-blue-50 border border-blue-100 rounded-lg p-3 text-sm text-blue-900">
        <div class="font-semibold mb-1">Resumo da reserva</div>
        <div>${servico.nome} · ${formatDuracao(servico.duracao_min)} · ${precoResumoLabel}</div>
        <div>${profissional ? profissional.nome : 'Qualquer profissional disponível'}</div>
        <div>${formatDataLonga(dataIso)} às ${slot}</div>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
        <label class="block">
          <span class="text-sm text-gray-700">Nome completo *</span>
          <input
            type="text"
            required
            autocomplete="name"
            value=${cliente.nome}
            onInput=${e => onClienteChange({ ...cliente, nome: e.target.value })}
            class="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
            placeholder="Ex: Maria da Silva"
          />
        </label>
        <label class="block">
          <span class="text-sm text-gray-700">WhatsApp (com DDD) *</span>
          <input
            type="tel"
            required
            autocomplete="tel"
            inputMode="numeric"
            maxLength="16"
            value=${formatWhatsAppMask(cliente.telefone)}
            onInput=${e => onClienteChange({ ...cliente, telefone: onlyDigits(e.target.value) })}
            onKeyDown=${e => {
              // Bloqueia letras: aceita só dígitos, controles e teclas de navegação.
              const allow = ['Backspace', 'Delete', 'Tab', 'Enter', 'ArrowLeft', 'ArrowRight', 'Home', 'End'];
              if (allow.includes(e.key) || e.ctrlKey || e.metaKey) return;
              if (!/^\d$/.test(e.key)) e.preventDefault();
            }}
            class="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
            placeholder="Ex: (11) 99999-0000"
          />
          ${cliente.telefone && !isWhatsAppValido(cliente.telefone) && html`
            <span class="block mt-1 text-xs text-red-600">Digite DDD + número (10 ou 11 dígitos).</span>
          `}
          ${conviteAplicado && isWhatsAppValido(cliente.telefone) && html`
            <span class="block mt-1 text-xs text-blue-600">✓ WhatsApp preenchido automaticamente — você pode editar se quiser.</span>
          `}
        </label>
      </div>
      <button
        type="submit"
        disabled=${enviando}
        class="w-full md:w-auto px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50"
      >${enviando ? 'Enviando...' : 'Confirmar reserva'}</button>
      ${erro && html`<div class="text-sm text-red-600">${erro}</div>`}
    </form>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// Tela de confirmação com pagamento (Etapa 8)
// ══════════════════════════════════════════════════════════════════════

function PaginaConfirmacao({ ag, info, apiBase, onNovo }) {
  const [aba, setAba] = useState('pix');
  const [email, setEmail] = useState('');
  // `ag.status` reflete o estado REAL da reserva no momento em que a tela
  // carregou — importante pra quem chega aqui pelo link de pagamento
  // (Etapa 19, item 4) depois de já ter pago pelo código PIX direto no
  // WhatsApp: sem isso, a tela mostraria o formulário de pagamento de novo
  // mesmo já estando confirmado. No fluxo de criação visual (`AgendarScreen`)
  // `ag.status` é sempre 'pendente_pagamento' logo após o POST, então o
  // comportamento de sempre não muda.
  const [pago, setPago] = useState(ag.status === 'confirmado');
  const [erroPag, setErroPag] = useState('');

  if (ag.status === 'cancelado') {
    return html`
      <div class="min-h-screen bg-gradient-to-b from-red-50 to-white flex items-center justify-center p-4">
        <div class="max-w-md w-full bg-white border border-red-200 rounded-xl shadow-sm p-6 space-y-4 text-center">
          <div class="flex items-center justify-center w-14 h-14 rounded-full bg-red-100 mx-auto">
            <span class="text-3xl text-red-600">✕</span>
          </div>
          <h1 class="text-xl font-semibold text-gray-900">Reserva cancelada</h1>
          <p class="text-sm text-gray-500">${info?.nome || 'Clínica'} · Protocolo #${ag.id}</p>
          <p class="text-sm text-gray-600">
            Este agendamento não está mais ativo, então não é possível pagar por ele.
            Fale com a clínica pelo WhatsApp se precisar de ajuda.
          </p>
          <button type="button" onClick=${onNovo}
            class="w-full px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">
            Fazer uma nova reserva
          </button>
        </div>
      </div>
    `;
  }

  if (pago) {
    return html`<${PagamentoConcluido} ag=${ag} info=${info} onNovo=${onNovo} />`;
  }

  return html`
    <div class="min-h-screen bg-gradient-to-b from-green-50 to-white flex items-center justify-center p-4">
      <div class="max-w-md w-full space-y-4">

        <!-- Resumo da reserva -->
        <div class="bg-white border border-green-200 rounded-xl shadow-sm p-6">
          <div class="flex items-center justify-center w-12 h-12 rounded-full bg-green-100 mx-auto mb-3">
            <span class="text-2xl text-green-600">✓</span>
          </div>
          <h1 class="text-xl font-semibold text-gray-900 text-center">Reserva criada!</h1>
          <p class="text-sm text-gray-500 text-center mt-1">${info?.nome || 'Clínica'}</p>
          <div class="mt-4 border border-gray-100 rounded-lg p-3 text-sm space-y-1">
            <div class="flex justify-between"><span class="text-gray-500">Protocolo</span><span class="font-mono text-gray-800">#${ag.id}</span></div>
            <div class="flex justify-between"><span class="text-gray-500">Serviço</span><span class="font-medium text-gray-800">${ag.servico_nome}</span></div>
            <div class="flex justify-between"><span class="text-gray-500">Profissional</span><span class="font-medium text-gray-800">${ag.profissional_nome}</span></div>
            <div class="flex justify-between"><span class="text-gray-500">Data</span><span class="font-medium text-gray-800">${formatDataLonga(ag.data)}</span></div>
            <div class="flex justify-between"><span class="text-gray-500">Horário</span><span class="font-medium font-mono text-gray-800">${ag.hora_inicio}</span></div>
            <div class="flex justify-between"><span class="text-gray-500">Valor</span><span class="font-semibold text-gray-900">${formatBRL(ag.valor_centavos)}</span></div>
          </div>
        </div>

        <!-- Seção de pagamento -->
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6">
          <h2 class="font-semibold text-gray-900 mb-4">Pagamento</h2>

          <!-- E-mail (compartilhado entre abas) -->
          <label class="block mb-4">
            <span class="text-sm text-gray-700">E-mail para confirmação</span>
            <input
              type="email"
              value=${email}
              onInput=${e => setEmail(e.target.value)}
              placeholder="seu@email.com"
              class="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
            />
            <p class="text-xs text-gray-400 mt-1">Em sandbox, use e-mail de conta de teste MP.</p>
          </label>

          <!-- Tabs -->
          <div class="flex border-b border-gray-200 mb-5">
            <button type="button" onClick=${() => { setAba('pix'); setErroPag(''); }}
              class=${`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${aba === 'pix' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
            >PIX</button>
            <button type="button" onClick=${() => { setAba('card'); setErroPag(''); }}
              class=${`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${aba === 'card' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
            >Cartão de crédito</button>
          </div>

          ${erroPag && html`
            <div class="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg p-3 mb-4">${erroPag}</div>
          `}

          ${aba === 'pix'
            ? html`<${PagamentoPix} agId=${ag.id} email=${email} apiBase=${apiBase} onPago=${() => setPago(true)} onErro=${setErroPag} />`
            : html`<${PagamentoCard} agId=${ag.id} email=${email} apiBase=${apiBase} valorCentavos=${ag.valor_centavos} onPago=${() => setPago(true)} onErro=${setErroPag} />`
          }
        </div>

        <button type="button" onClick=${onNovo}
          class="w-full px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 bg-white">
          Fazer outra reserva
        </button>
      </div>
    </div>
  `;
}

// ──────────────────────────────────────────────────────────────────────
// PIX
// ──────────────────────────────────────────────────────────────────────

function PagamentoPix({ agId, email, apiBase, onPago, onErro }) {
  const [fase, setFase] = useState('idle'); // 'idle' | 'carregando' | 'qr'
  const [qrData, setQrData] = useState(null);  // { qr_code, qr_code_base64 }
  const [mpOrderId, setMpOrderId] = useState(null);
  const [mpStatus, setMpStatus] = useState(null);
  const [copiado, setCopiado] = useState(false);

  const gerarPix = async () => {
    setFase('carregando');
    onErro('');
    try {
      const payerEmail = email.trim() || `pagamento.${agId}@clinicavidaleve.com`;
      const result = await apiJson(`${apiBase}/agendamentos/${agId}/iniciar-pagamento`, {
        method: 'POST',
        body: JSON.stringify({ kind: 'pix', payer_email: payerEmail }),
      });
      setMpOrderId(result.mp_order_id);
      setMpStatus(result.mp_status);
      const payments = result.order?.transactions?.payments || [];
      const pm = payments[0]?.payment_method || {};
      setQrData({ qr_code: pm.qr_code || '', qr_code_base64: pm.qr_code_base64 || '' });
      if (result.mp_status === 'processed') { onPago(); return; }
      setFase('qr');
    } catch (e) {
      onErro(e.message);
      setFase('idle');
    }
  };

  // Polling enquanto QR está visível e pagamento pendente.
  useEffect(() => {
    if (fase !== 'qr' || !mpOrderId) return;
    const iv = setInterval(async () => {
      try {
        const r = await apiJson(`${apiBase}/agendamentos/${agId}/status-pagamento`);
        setMpStatus(r.mp_status);
        if (r.mp_status === 'processed') { clearInterval(iv); onPago(); }
      } catch {}
    }, 5000);
    return () => clearInterval(iv);
  }, [fase, agId, apiBase, mpOrderId, onPago]);

  const copiar = () => {
    if (!qrData?.qr_code) return;
    navigator.clipboard.writeText(qrData.qr_code).then(() => {
      setCopiado(true);
      setTimeout(() => setCopiado(false), 2500);
    });
  };

  if (fase === 'idle') {
    return html`
      <div class="text-center">
        <div class="text-4xl mb-3">📱</div>
        <p class="text-sm text-gray-600 mb-4">
          Pague com PIX usando qualquer banco. O QR Code expira em 30 minutos.
        </p>
        <button type="button" onClick=${gerarPix}
          class="w-full py-3 bg-blue-600 text-white rounded-lg font-semibold text-sm hover:bg-blue-700">
          Gerar QR Code PIX
        </button>
      </div>
    `;
  }

  if (fase === 'carregando') {
    return html`<div class="text-sm text-gray-500 text-center py-8">Gerando QR Code PIX...</div>`;
  }

  return html`
    <div class="space-y-4">
      ${qrData?.qr_code_base64 && html`
        <div class="flex justify-center">
          <img src=${'data:image/png;base64,' + qrData.qr_code_base64} alt="QR Code PIX"
            class="w-52 h-52 border border-gray-200 rounded-xl p-1" />
        </div>
      `}
      ${qrData?.qr_code && html`
        <div>
          <p class="text-xs font-medium text-gray-600 mb-1">Copia e Cola PIX</p>
          <div class="flex gap-2">
            <input type="text" value=${qrData.qr_code} readOnly
              class="flex-1 text-xs border border-gray-200 rounded-lg px-3 py-2 bg-gray-50 font-mono truncate" />
            <button type="button" onClick=${copiar}
              class="px-3 py-2 text-xs border border-gray-300 rounded-lg hover:bg-gray-50 whitespace-nowrap font-medium">
              ${copiado ? '✓ Copiado!' : 'Copiar'}
            </button>
          </div>
        </div>
      `}
      <div class="flex items-center gap-2 text-xs text-gray-400 justify-center">
        <span class="inline-block w-2 h-2 rounded-full bg-yellow-400 animate-pulse"></span>
        Aguardando pagamento — verificando a cada 5 s
        ${mpStatus && html`<span class="font-mono">(${mpStatus})</span>`}
      </div>
    </div>
  `;
}

// ──────────────────────────────────────────────────────────────────────
// Cartão (Card Payment Brick do MP)
// ──────────────────────────────────────────────────────────────────────

function PagamentoCard({ agId, email, apiBase, valorCentavos, onPago, onErro }) {
  const [etapa, setEtapa] = useState('init'); // 'init' | 'pronto' | 'enviando' | 'erro'
  const brickRef = useRef(null);

  useEffect(() => {
    let destroyed = false;

    const init = async () => {
      try {
        // Busca a public_key no backend (nunca exposta diretamente no código).
        const cfg = await apiJson(`${apiBase}/pagamento/config`);
        if (destroyed) return;

        // Carrega SDK externo do MP uma única vez.
        if (!window.MercadoPago) {
          await new Promise((res, rej) => {
            const s = document.createElement('script');
            s.src = 'https://sdk.mercadopago.com/js/v2';
            s.onload = res;
            s.onerror = () => rej(new Error('Falha ao carregar SDK do Mercado Pago.'));
            document.head.appendChild(s);
          });
        }
        if (destroyed) return;

        const amount = valorCentavos ? valorCentavos / 100 : 1.00;
        const mp = new window.MercadoPago(cfg.public_key, { locale: 'pt-BR' });
        const bricks = mp.bricks();
        const brick = await bricks.create('cardPayment', 'mp-card-brick', {
          initialization: { amount },
          customization: { paymentMethods: { maxInstallments: 12 } },
          callbacks: {
            onReady: () => { if (!destroyed) setEtapa('pronto'); },
            onError: (err) => {
              if (!destroyed) {
                onErro('Erro no formulário: ' + (err?.message || JSON.stringify(err)));
                setEtapa('erro');
              }
            },
            onSubmit: async (cardFormData) => {
              if (destroyed) return;
              setEtapa('enviando');
              onErro('');
              try {
                const payerEmail =
                  email.trim() ||
                  cardFormData.payer?.email ||
                  `pagamento.${agId}@clinicavidaleve.com`;
                const result = await apiJson(
                  `${apiBase}/agendamentos/${agId}/iniciar-pagamento`,
                  {
                    method: 'POST',
                    body: JSON.stringify({ kind: 'card', card_form_data: cardFormData, payer_email: payerEmail }),
                  }
                );
                if (result.mp_status === 'processed') {
                  onPago();
                } else {
                  const detalhe = result.mp_status_detail ? ` (${result.mp_status_detail})` : '';
                  onErro(`Pagamento ${result.mp_status || 'não aprovado'}${detalhe}.`);
                  setEtapa('pronto');
                }
              } catch (e) {
                onErro(e.message);
                setEtapa('pronto');
              }
            },
          },
        });

        if (!destroyed) {
          brickRef.current = brick;
        } else {
          try { brick.unmount(); } catch {}
        }
      } catch (e) {
        if (!destroyed) onErro(e.message);
      }
    };

    init();
    return () => {
      destroyed = true;
      if (brickRef.current) {
        try { brickRef.current.unmount(); } catch {}
        brickRef.current = null;
      }
    };
  }, [agId, apiBase]); // email capturado no onSubmit para ter valor atual

  return html`
    <div>
      ${etapa === 'init' && html`
        <div class="text-sm text-gray-500 text-center py-6">Carregando formulário de cartão...</div>
      `}
      ${etapa !== 'erro' && html`
        <div id="mp-card-brick" class=${etapa === 'enviando' ? 'opacity-50 pointer-events-none' : ''}></div>
      `}
      ${etapa === 'enviando' && html`
        <div class="text-sm text-gray-500 text-center mt-3">Processando pagamento...</div>
      `}
    </div>
  `;
}

// ──────────────────────────────────────────────────────────────────────
// Confirmação final (pós-pagamento aprovado)
// ──────────────────────────────────────────────────────────────────────

function PagamentoConcluido({ ag, info, onNovo }) {
  return html`
    <div class="min-h-screen bg-gradient-to-b from-green-50 to-white flex items-center justify-center p-4">
      <div class="max-w-md w-full bg-white border border-green-200 rounded-xl shadow-sm p-6 space-y-4">
        <div class="flex items-center justify-center w-14 h-14 rounded-full bg-green-100 mx-auto">
          <span class="text-3xl text-green-600">✓</span>
        </div>
        <div class="text-center">
          <h1 class="text-xl font-semibold text-gray-900">Pagamento confirmado!</h1>
          <p class="text-sm text-gray-500 mt-1">${info?.nome || 'Clínica'} · Protocolo #${ag.id}</p>
        </div>
        <div class="bg-green-50 border border-green-200 rounded-lg p-3 text-sm text-green-800 text-center">
          Seu agendamento está confirmado. Você receberá uma mensagem no WhatsApp em breve.
        </div>
        <button type="button" onClick=${onNovo}
          class="w-full px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">
          Fazer outra reserva
        </button>
      </div>
    </div>
  `;
}

// Reexportado pra `pagar.js` (Etapa 19, item 4 — link de pagamento enviado
// pela IA): mesma tela de resumo + abas PIX/Cartão, só que alimentada por
// uma reserva já existente (buscada por `?ag=<id>`) em vez de uma recém-criada.
export { PaginaConfirmacao };
