// Página pública de pagamento de uma reserva já criada (Etapa 19, item 4).
//
// Quando a IA fecha um agendamento pela conversa (tool `clinica_agendar` /
// `clinica_remarcar_agendamento`), ela sempre manda este link além do recap
// — o cliente escolhe PIX ou cartão aqui, sem depender de qual forma de
// pagamento foi dita no WhatsApp. Reaproveita os MESMOS componentes de
// pagamento da tela de agendamento visual (`agendar.js`), só trocando de
// onde a reserva vem: lá é o resultado de um POST /agendamentos recém-feito,
// aqui é buscada por `?t=<token>`.
//
// IMPORTANTE (hardening pós-review): usa o token opaco de pagamento
// (`?t=TOKEN`, endpoint `/agendamentos/por-token/{token}`), NÃO o ID
// sequencial cru (`?ag=<id>`, endpoint `/agendamentos/{id}`) — esse último é
// usado só internamente pelo fluxo visual de agendar.js, na mesma sessão do
// navegador que criou a reserva. Um link com ID cru mandado a todo cliente
// permitiria varrer nome/telefone/serviço de qualquer reserva.
//
// Endpoints consumidos (públicos):
//   GET /info
//   GET /agendamentos/por-token/{token}
//   (delegados a PaginaConfirmacao: POST /agendamentos/{id}/iniciar-pagamento,
//    GET /agendamentos/{id}/status-pagamento, GET /pagamento/config — usam o
//    ID real que veio dentro do objeto resolvido pelo token)
//
// URL: /clinica/pagar?t=<token>
//
// IMPORTANTE: este arquivo NÃO depende do token de auth do admin — usa
// fetch puro, igual a agendar.js. Precisa estar em PUBLIC_PLUGIN_SCREENS
// (web/static/js/app.js) pra não cair no portão de login do admin.

import { h } from 'preact';
import { useEffect, useState } from 'preact/hooks';
import htm from 'htm';
import { PaginaConfirmacao } from './agendar.js';

const html = htm.bind(h);

async function apiJson(url, init = {}) {
  const headers = { ...(init.headers || {}) };
  if (init.body) headers['Content-Type'] = headers['Content-Type'] || 'application/json';
  const res = await fetch(url, { ...init, headers });
  const raw = await res.text();
  let data;
  try { data = raw ? JSON.parse(raw) : {}; }
  catch { throw new Error(`Erro ${res.status}: ${raw.slice(0, 200) || res.statusText}`); }
  if (!res.ok || !data.ok) {
    throw new Error(data.error || data.detail || `Erro ${res.status}`);
  }
  return data.data;
}

function TelaErro({ titulo, mensagem, onVoltar }) {
  return html`
    <div class="min-h-screen bg-gradient-to-b from-red-50 to-white flex items-center justify-center p-4">
      <div class="max-w-md w-full bg-white border border-red-200 rounded-xl shadow-sm p-6 space-y-4 text-center">
        <h1 class="text-xl font-semibold text-gray-900">${titulo}</h1>
        <p class="text-sm text-gray-600">${mensagem}</p>
        <button type="button" onClick=${onVoltar}
          class="w-full px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">
          Fazer uma reserva
        </button>
      </div>
    </div>
  `;
}

export default function PagarScreen({ apiBase }) {
  const [info, setInfo] = useState(null);
  const [ag, setAg] = useState(null);
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(true);

  const irParaAgendar = () => { window.location.href = '/clinica/agendar'; };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const token = (params.get('t') || '').trim();
    if (!token) {
      setErro('Link inválido — falta o código de pagamento.');
      setCarregando(false);
      return;
    }
    (async () => {
      try {
        const [i, a] = await Promise.all([
          apiJson(`${apiBase}/info`),
          apiJson(`${apiBase}/agendamentos/por-token/${encodeURIComponent(token)}`),
        ]);
        setInfo(i);
        setAg(a);
      } catch (e) {
        setErro(e.message);
      } finally {
        setCarregando(false);
      }
    })();
  }, [apiBase]);

  if (carregando) {
    return html`<div class="min-h-screen flex items-center justify-center text-gray-500">Carregando...</div>`;
  }

  if (erro || !ag) {
    return html`<${TelaErro}
      titulo="Não encontrei essa reserva"
      mensagem=${erro || 'Verifique o link recebido no WhatsApp.'}
      onVoltar=${irParaAgendar}
    />`;
  }

  return html`<${PaginaConfirmacao} ag=${ag} info=${info} apiBase=${apiBase} onNovo=${irParaAgendar} />`;
}
