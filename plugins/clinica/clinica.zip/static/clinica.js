﻿// Tela do plugin Clínica Vida Leve.
//
// Etapa 1 — Visão geral (cabeçalho + listas públicas).
// Etapa 2 — Abas de admin para CRUD de profissionais e serviços.
// Etapa 3 — Vínculos serviço ↔ profissional (linha expansível por serviço).
// Etapa 4 — Horários de atendimento por profissional (linha expansível).
// Etapa 5 — Aba "Slots" para preview do cálculo de horários disponíveis.
// Etapa 6 — Página pública de agendamento movida para /clinica/agendar (arquivo agendar.js).

import { h } from 'preact';
import { useEffect, useState, useCallback, useMemo, useRef } from 'preact/hooks';
import htm from 'htm';

const html = htm.bind(h);

// ── auth helper ────────────────────────────────────────────────────────
function authHeaders(extra = {}) {
  const token = localStorage.getItem('whatsbot_token') || '';
  return token ? { ...extra, Authorization: `Bearer ${token}` } : { ...extra };
}

async function apiFetch(url, init = {}) {
  const headers = authHeaders(init.headers || {});
  const res = await fetch(url, { ...init, headers });
  if (res.status === 401) {
    localStorage.removeItem('whatsbot_token');
    window.dispatchEvent(new Event('whatsbot:unauthorized'));
    throw new Error('Não autenticado.');
  }
  return res;
}

async function apiJson(url, init = {}) {
  const res = await apiFetch(url, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init.headers || {}) },
  });
  // Backend pode devolver texto plano (ex: "Internal Server Error" em 500).
  // Tentamos JSON; se falhar, usamos o texto cru como mensagem de erro.
  const raw = await res.text();
  let data;
  try { data = raw ? JSON.parse(raw) : {}; }
  catch { throw new Error(`Erro ${res.status}: ${raw.slice(0, 200) || res.statusText}`); }
  if (!res.ok || !data.ok) {
    throw new Error(data.error || data.detail || `Erro ${res.status}`);
  }
  return data.data;
}

// ── formatadores ───────────────────────────────────────────────────────
const formatBRL = (centavos) =>
  (centavos / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const formatDuracao = (min) => {
  if (min < 60) return `${min} min`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m ? `${h}h${m.toString().padStart(2, '0')}` : `${h}h`;
};

// ══════════════════════════════════════════════════════════════════════
// Etapa 15 — Helpers da visão de calendário dos agendamentos
//
// Matemática de datas SEMPRE local (espelha agendar.js): nunca usar Date
// em UTC, senão o "hoje" e os ranges não batem com o que o backend grava
// na coluna `data` (string YYYY-MM-DD local).
// ══════════════════════════════════════════════════════════════════════

const pad2 = (n) => n.toString().padStart(2, '0');
const toISO = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const hojeLocal = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };

const MESES = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro',
];
const MESES_ABREV = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
const DIAS_SEMANA_ABREV = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];

// Os 7 dias (Date[]) da semana que contém `dataRef`, começando na segunda.
function diasDaSemana(dataRef) {
  const offset = (dataRef.getDay() + 6) % 7; // 0 = segunda
  const base = new Date(dataRef.getFullYear(), dataRef.getMonth(), dataRef.getDate() - offset);
  return Array.from({ length: 7 }, (_, i) =>
    new Date(base.getFullYear(), base.getMonth(), base.getDate() + i));
}

// Intervalo [ini, fim] (ISO) coberto por uma vista a partir da data âncora.
function rangeDaVista(vista, dataRef) {
  const ano = dataRef.getFullYear();
  const mes = dataRef.getMonth();
  if (vista === 'dia') {
    const iso = toISO(dataRef);
    return { ini: iso, fim: iso };
  }
  if (vista === 'semana') {
    const dias = diasDaSemana(dataRef);
    return { ini: toISO(dias[0]), fim: toISO(dias[6]) };
  }
  // mês: dia 1 ao último dia
  return { ini: toISO(new Date(ano, mes, 1)), fim: toISO(new Date(ano, mes + 1, 0)) };
}

// Avança/recua a data âncora de acordo com a vista (−1/+1 dia, semana ou mês).
function avancarData(vista, dataRef, dir) {
  const a = dataRef.getFullYear(), m = dataRef.getMonth(), d = dataRef.getDate();
  if (vista === 'dia') return new Date(a, m, d + dir);
  if (vista === 'semana') return new Date(a, m, d + dir * 7);
  return new Date(a, m + dir, 1);
}

// Título do período exibido na barra de controle.
function tituloPeriodo(vista, dataRef) {
  const ano = dataRef.getFullYear();
  const mes = dataRef.getMonth();
  if (vista === 'mes') return `${MESES[mes]} ${ano}`;
  if (vista === 'dia') {
    const dia = DIAS_SEMANA_ABREV[(dataRef.getDay() + 6) % 7];
    return `${dia}, ${dataRef.getDate()} ${MESES_ABREV[mes]} ${ano}`;
  }
  const dias = diasDaSemana(dataRef);
  const a = dias[0], b = dias[6];
  if (a.getMonth() === b.getMonth()) {
    return `${a.getDate()}–${b.getDate()} ${MESES_ABREV[a.getMonth()]} ${a.getFullYear()}`;
  }
  return `${a.getDate()} ${MESES_ABREV[a.getMonth()]} – ${b.getDate()} ${MESES_ABREV[b.getMonth()]} ${b.getFullYear()}`;
}

// "HH:MM" → minutos desde 00:00.
const hhmmToMin = (hhmm) => {
  if (!hhmm) return 0;
  const [h, m] = hhmm.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
};

// Paleta por profissional — 8 cores Tailwind seguras (fundo/borda/texto/ponto).
const CORES_PROF = [
  { bg: 'bg-blue-100',    border: 'border-blue-400',    text: 'text-blue-800',    dot: 'bg-blue-500' },
  { bg: 'bg-emerald-100', border: 'border-emerald-400', text: 'text-emerald-800', dot: 'bg-emerald-500' },
  { bg: 'bg-violet-100',  border: 'border-violet-400',  text: 'text-violet-800',  dot: 'bg-violet-500' },
  { bg: 'bg-amber-100',   border: 'border-amber-400',   text: 'text-amber-800',   dot: 'bg-amber-500' },
  { bg: 'bg-rose-100',    border: 'border-rose-400',    text: 'text-rose-800',    dot: 'bg-rose-500' },
  { bg: 'bg-cyan-100',    border: 'border-cyan-400',    text: 'text-cyan-800',    dot: 'bg-cyan-500' },
  { bg: 'bg-lime-100',    border: 'border-lime-400',    text: 'text-lime-800',    dot: 'bg-lime-500' },
  { bg: 'bg-fuchsia-100', border: 'border-fuchsia-400', text: 'text-fuchsia-800', dot: 'bg-fuchsia-500' },
];
const CINZA_PROF = { bg: 'bg-gray-100', border: 'border-gray-300', text: 'text-gray-700', dot: 'bg-gray-400' };

// Cor estável por profissional: índice na lista ordenada por id → mesma cor sempre.
function corDoProfissional(profId, ordemProfs) {
  const idx = ordemProfs.indexOf(profId);
  if (idx < 0) return CINZA_PROF;
  return CORES_PROF[idx % CORES_PROF.length];
}

// Ícone de status reaproveitando os STATUS_LABELS/STATUS_CLASSES existentes.
const iconeStatus = (status) => {
  if (status === 'confirmado') return '✓';
  if (status === 'cancelado') return '✕';
  return '⏳'; // pendente_pagamento
};

const primeiroNome = (nome) => (nome || '').trim().split(/\s+/)[0] || '—';

// Normaliza texto p/ busca: minúsculo e sem acentos. Telefone → só dígitos.
const normalizarBusca = (s) =>
  (s || '').toString().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
const soDigitos = (s) => (s || '').toString().replace(/\D/g, '');

// Altura de 1 hora na grade de semana/dia (px). 56px dá folga para um
// agendamento de 30min (~28px) mostrar uma linha limpa sem cortar texto.
const HORA_PX = 56;

// Faixa de horas [minM, maxM] da grade, alinhada à hora. Parte de uma faixa
// base de expediente (default 08:00–20:00) e SÓ a expande para englobar eventos
// fora dela (com folga de 1h). Assim a grade tem sempre uma altura útil para
// rolar, mesmo com o dia vazio ou com poucos agendamentos.
function faixaHoras(ags, baseMin = 8 * 60, baseMax = 20 * 60) {
  let minM = baseMin;
  let maxM = baseMax;
  const validos = ags.filter(a => a.hora_inicio && a.hora_fim);
  if (validos.length) {
    const evMin = Math.min(...validos.map(a => hhmmToMin(a.hora_inicio)));
    const evMax = Math.max(...validos.map(a => hhmmToMin(a.hora_fim)));
    minM = Math.min(minM, Math.floor(evMin / 60) * 60 - 60);
    maxM = Math.max(maxM, Math.ceil(evMax / 60) * 60 + 60);
  }
  minM = Math.max(0, minM);
  maxM = Math.min(24 * 60, maxM);
  if (maxM - minM < 60) maxM = minM + 60;
  return { minM, maxM };
}

// Layout de overlap de um dia: agrupa eventos que se sobrepõem em "clusters" e
// atribui colunas (lanes). Retorna [{a, ini, fim, lane, cols}].
function layoutDia(ags) {
  const evs = ags
    .filter(a => a.hora_inicio && a.hora_fim)
    .map(a => {
      const ini = hhmmToMin(a.hora_inicio);
      return { a, ini, fim: Math.max(hhmmToMin(a.hora_fim), ini + 15) };
    })
    .sort((x, y) => x.ini - y.ini || x.fim - y.fim);

  const resultado = [];
  let cluster = [];
  let clusterFim = -1;
  const flush = () => {
    if (!cluster.length) return;
    const lanes = []; // lanes[i] = fim do último evento naquela coluna
    for (const e of cluster) {
      let lane = lanes.findIndex(f => f <= e.ini);
      if (lane === -1) { lane = lanes.length; lanes.push(e.fim); }
      else lanes[lane] = e.fim;
      e.lane = lane;
    }
    for (const e of cluster) { e.cols = lanes.length; resultado.push(e); }
    cluster = [];
    clusterFim = -1;
  };
  for (const e of evs) {
    if (cluster.length && e.ini >= clusterFim) flush();
    cluster.push(e);
    clusterFim = Math.max(clusterFim, e.fim);
  }
  flush();
  return resultado;
}

// ══════════════════════════════════════════════════════════════════════
// Componente raiz com tabs
// ══════════════════════════════════════════════════════════════════════

export default function ClinicaScreen({ apiBase }) {
  const [tab, setTab] = useState('dashboard');

  const tabs = [
    { id: 'dashboard',     label: 'Dashboard' },
    { id: 'visao',         label: 'Visão geral' },
    { id: 'agendamentos',  label: 'Agendamentos' },
    { id: 'profissionais', label: 'Profissionais' },
    { id: 'servicos',      label: 'Serviços' },
    { id: 'slots',         label: 'Slots' },
  ];

  return html`
    <div class="p-6 w-full">
      <!-- Cabeçalho global -->
      <header class="mb-6 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 class="text-3xl font-bold text-gray-900">Clínica Vida Leve</h1>
          <p class="text-gray-500 text-sm mt-1">Painel administrativo</p>
        </div>
        <a
          href="/clinica/agendar"
          target="_blank"
          rel="noopener"
          class="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700"
          title="Abre a página pública de agendamento numa nova aba"
        >Abrir página de agendamento ↗</a>
      </header>

      <!-- Tabs -->
      <div class="border-b border-gray-200 mb-6">
        <nav class="flex gap-1 flex-wrap">
          ${tabs.map(t => html`
            <button
              key=${t.id}
              onClick=${() => setTab(t.id)}
              class=${`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                tab === t.id
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >${t.label}</button>
          `)}
        </nav>
      </div>

      <!-- Conteúdo da tab ativa -->
      ${tab === 'dashboard'     && html`<${Dashboard} apiBase=${apiBase} />`}
      ${tab === 'visao'         && html`<${VisaoGeral} apiBase=${apiBase} />`}
      ${tab === 'agendamentos'  && html`<${AdminAgendamentos} apiBase=${apiBase} />`}
      ${tab === 'profissionais' && html`<${AdminProfissionais} apiBase=${apiBase} />`}
      ${tab === 'servicos'      && html`<${AdminServicos} apiBase=${apiBase} />`}
      ${tab === 'slots'         && html`<${SlotsPreview} apiBase=${apiBase} />`}

      <footer class="text-xs text-gray-400 pt-8 mt-8 border-t border-gray-100">
        Sistema completo · página pública em <a href="/clinica/agendar" target="_blank" class="underline hover:text-gray-600">/clinica/agendar</a>.
      </footer>
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// Etapa 13 — Dashboard final
//
// Visão agregada do sistema: KPIs financeiros, funil de status, série
// diária de faturamento, ranking de serviços, ocupação por profissional
// e conversão de convites enviados pela IA.
//
// Tudo num único fetch (`/admin/dashboard?periodo=N`), renderizado em
// cards e gráficos SVG simples (sem dependências externas — Preact + HTM
// + Tailwind cobrem). O período é selecionável (7/30/90 dias) e re-
// dispara o fetch.
// ══════════════════════════════════════════════════════════════════════

const PERIODOS_DASHBOARD = [
  { id: 7,   label: 'Últimos 7 dias' },
  { id: 30,  label: 'Últimos 30 dias' },
  { id: 90,  label: 'Últimos 90 dias' },
  { id: 365, label: 'Último ano' },
];

const formatPct = (v) => `${(Math.round((Number(v) || 0) * 1000) / 10).toFixed(1)}%`;

function Dashboard({ apiBase }) {
  const [periodo, setPeriodo] = useState(30);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setErro('');
    try {
      const res = await apiJson(`${apiBase}/admin/dashboard?periodo=${periodo}`);
      setData(res);
    } catch (e) {
      setErro(e.message);
    } finally {
      setLoading(false);
    }
  }, [apiBase, periodo]);

  useEffect(() => { load(); }, [load]);

  if (loading && !data) return html`<div class="text-gray-500">Carregando dashboard...</div>`;
  if (erro)             return html`<div class="text-red-600 bg-red-50 border border-red-200 rounded p-3">Erro: ${erro}</div>`;
  if (!data)            return null;

  const { kpis, funil, faturamento_diario, ranking_servicos, ocupacao_profissionais, convites, periodo: pInfo, ocupacao_dias_futuros } = data;

  return html`
    <div class="space-y-6">
      <!-- Filtros do dashboard -->
      <div class="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 class="text-xl font-semibold text-gray-800">Visão geral do período</h2>
          <p class="text-xs text-gray-500 mt-1">
            ${pInfo.ini} a ${pInfo.fim} · atualizado agora
          </p>
        </div>
        <div class="flex items-center gap-2">
          <label class="text-xs text-gray-600">Período</label>
          <select
            value=${periodo}
            onChange=${e => setPeriodo(parseInt(e.target.value, 10))}
            class="border border-gray-300 rounded px-2 py-1.5 text-sm"
          >
            ${PERIODOS_DASHBOARD.map(p => html`
              <option key=${p.id} value=${p.id}>${p.label}</option>
            `)}
          </select>
          <button
            onClick=${load}
            disabled=${loading}
            class="px-3 py-1.5 border border-gray-300 rounded text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
            title="Recarregar dados"
          >${loading ? '...' : '↻'}</button>
        </div>
      </div>

      <!-- KPIs principais -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <${KpiCard}
          titulo="Faturamento"
          valor=${formatBRL(kpis.faturamento_centavos)}
          rodape=${`${kpis.reservas_confirmadas} reserva${kpis.reservas_confirmadas !== 1 ? 's' : ''} confirmada${kpis.reservas_confirmadas !== 1 ? 's' : ''}`}
          cor="emerald"
          icone="💰"
        />
        <${KpiCard}
          titulo="Ticket médio"
          valor=${formatBRL(kpis.ticket_medio_centavos)}
          rodape=${kpis.reservas_confirmadas ? 'Por reserva confirmada' : 'Sem reservas no período'}
          cor="blue"
          icone="🧾"
        />
        <${KpiCard}
          titulo="Taxa de conversão"
          valor=${formatPct(kpis.taxa_conversao)}
          rodape=${`${kpis.reservas_confirmadas} ok · ${kpis.reservas_canceladas} canceladas`}
          cor="violet"
          icone="🎯"
        />
        <${KpiCard}
          titulo="Aguardando pagamento"
          valor=${String(kpis.reservas_pendentes)}
          rodape="Pendentes no período"
          cor="amber"
          icone="⏳"
        />
      </div>

      <!-- Faturamento diário + Funil lado a lado -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div class="lg:col-span-2 bg-white border border-gray-200 rounded-lg p-4">
          <div class="flex items-baseline justify-between mb-3">
            <h3 class="font-semibold text-gray-800">Faturamento por dia</h3>
            <span class="text-xs text-gray-500">${pInfo.dias} dia${pInfo.dias !== 1 ? 's' : ''}</span>
          </div>
          <${BarrasFaturamento} serie=${faturamento_diario} />
        </div>

        <div class="bg-white border border-gray-200 rounded-lg p-4">
          <h3 class="font-semibold text-gray-800 mb-3">Funil de status</h3>
          <${FunilBarras} funil=${funil} />
          <p class="text-xs text-gray-500 mt-3 leading-relaxed">
            Cada agendamento percorre o funil: aguarda pagamento → confirma → cliente recebe
            comprovante no WhatsApp → recebe lembrete 1 dia antes.
          </p>
        </div>
      </div>

      <!-- Ranking de serviços + Ocupação -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div class="bg-white border border-gray-200 rounded-lg p-4">
          <h3 class="font-semibold text-gray-800 mb-3">Top serviços</h3>
          ${ranking_servicos.length === 0
            ? html`<div class="text-sm text-gray-400">Nenhum serviço confirmado no período.</div>`
            : html`<${RankingServicos} itens=${ranking_servicos} />`}
        </div>

        <div class="bg-white border border-gray-200 rounded-lg p-4">
          <div class="flex items-baseline justify-between mb-3">
            <h3 class="font-semibold text-gray-800">Ocupação por profissional</h3>
            <span class="text-xs text-gray-500">Próximos ${ocupacao_dias_futuros} dias</span>
          </div>
          ${ocupacao_profissionais.length === 0
            ? html`<div class="text-sm text-gray-400">Nenhum profissional ativo.</div>`
            : html`<${OcupacaoProfissionais} itens=${ocupacao_profissionais} />`}
        </div>
      </div>

      <!-- Conversão de convites IA -->
      <${ConvitesCard} convites=${convites} />
    </div>
  `;
}

// ──────────────────────────────────────────────────────────────────────
// Componentes auxiliares do Dashboard
// ──────────────────────────────────────────────────────────────────────

const KPI_COR_CLASS = {
  emerald: { border: 'border-emerald-200', text: 'text-emerald-700', bg: 'bg-emerald-50' },
  blue:    { border: 'border-blue-200',    text: 'text-blue-700',    bg: 'bg-blue-50' },
  violet:  { border: 'border-violet-200',  text: 'text-violet-700',  bg: 'bg-violet-50' },
  amber:   { border: 'border-amber-200',   text: 'text-amber-700',   bg: 'bg-amber-50' },
};

function KpiCard({ titulo, valor, rodape, cor = 'blue', icone }) {
  const c = KPI_COR_CLASS[cor] || KPI_COR_CLASS.blue;
  return html`
    <div class=${`bg-white border ${c.border} rounded-lg p-4`}>
      <div class="flex items-center justify-between">
        <div class="text-xs text-gray-600 uppercase tracking-wide">${titulo}</div>
        ${icone && html`<div class=${`w-8 h-8 flex items-center justify-center rounded ${c.bg} text-base`}>${icone}</div>`}
      </div>
      <div class=${`text-2xl font-bold mt-2 ${c.text}`}>${valor}</div>
      <div class="text-xs text-gray-500 mt-1">${rodape}</div>
    </div>
  `;
}

function BarrasFaturamento({ serie }) {
  if (!serie || serie.length === 0) {
    return html`<div class="text-sm text-gray-400 py-8 text-center">Sem dados no período.</div>`;
  }
  const maxValor = Math.max(1, ...serie.map(d => d.valor_centavos || 0));
  const total = serie.reduce((acc, d) => acc + (d.valor_centavos || 0), 0);
  // Pra séries longas (>=60 dias), agrupa rótulos a cada N pontos para não poluir.
  const skip = Math.max(1, Math.floor(serie.length / 10));
  return html`
    <div>
      <div class="text-xs text-gray-500 mb-2">Total no período: <strong class="text-gray-800">${formatBRL(total)}</strong></div>
      <div class="flex items-end gap-px h-32 bg-gray-50 rounded p-2 overflow-hidden">
        ${serie.map((d, i) => {
          const altura = d.valor_centavos > 0
            ? Math.max(2, Math.round((d.valor_centavos / maxValor) * 100))
            : 1;
          const titulo = `${formatarData(d.data)}: ${formatBRL(d.valor_centavos)} (${d.qtd})`;
          return html`
            <div
              key=${d.data}
              class=${`flex-1 ${d.valor_centavos > 0 ? 'bg-emerald-500' : 'bg-gray-200'} rounded-sm hover:bg-emerald-600 transition-colors`}
              style=${`height: ${altura}%; min-width: 2px;`}
              title=${titulo}
            ></div>
          `;
        })}
      </div>
      <div class="flex justify-between text-[10px] text-gray-400 mt-1">
        ${serie.filter((_, i) => i % skip === 0).map(d => html`
          <span key=${d.data}>${formatarData(d.data).slice(0, 5)}</span>
        `)}
      </div>
    </div>
  `;
}

function FunilBarras({ funil }) {
  // O "topo" do funil são todas as reservas (pendente + confirmado) — quem ainda
  // não pagou + quem já pagou. Cada estágio seguinte é um subconjunto.
  const topo = (funil.pendente_pagamento || 0) + (funil.confirmado || 0);
  const etapas = [
    { id: 'pend',  label: 'Aguardando pgto.', qtd: funil.pendente_pagamento, cor: 'bg-amber-400' },
    { id: 'conf',  label: 'Confirmado',       qtd: funil.confirmado,         cor: 'bg-emerald-500' },
    { id: 'notif', label: 'WhatsApp enviado', qtd: funil.notificacao_enviada, cor: 'bg-blue-500' },
    { id: 'lembr', label: 'Lembrete enviado', qtd: funil.lembrete_enviado,    cor: 'bg-violet-500' },
  ];
  if (topo === 0) {
    return html`<div class="text-sm text-gray-400 py-6 text-center">Sem reservas no período.</div>`;
  }
  return html`
    <div class="space-y-2">
      ${etapas.map(e => {
        const pct = topo > 0 ? (e.qtd / topo) : 0;
        return html`
          <div key=${e.id}>
            <div class="flex justify-between text-xs text-gray-600 mb-0.5">
              <span>${e.label}</span>
              <span class="font-semibold text-gray-800">${e.qtd}</span>
            </div>
            <div class="h-2.5 bg-gray-100 rounded overflow-hidden">
              <div
                class=${`h-full ${e.cor} transition-all`}
                style=${`width: ${Math.max(2, Math.round(pct * 100))}%;`}
              ></div>
            </div>
          </div>
        `;
      })}
    </div>
  `;
}

function RankingServicos({ itens }) {
  const maxQtd = Math.max(1, ...itens.map(i => i.qtd));
  return html`
    <ol class="space-y-2">
      ${itens.map((s, i) => {
        const pct = Math.round((s.qtd / maxQtd) * 100);
        return html`
          <li key=${s.servico_id} class="border border-gray-100 rounded p-2">
            <div class="flex items-baseline justify-between gap-3">
              <div class="flex items-baseline gap-2 min-w-0">
                <span class="text-xs font-mono text-gray-400 w-5 text-right">${i + 1}.</span>
                <span class="font-medium text-gray-800 truncate" title=${s.nome}>${s.nome}</span>
              </div>
              <div class="text-right whitespace-nowrap text-xs">
                <div class="font-semibold text-gray-800">${s.qtd} reserva${s.qtd !== 1 ? 's' : ''}</div>
                <div class="text-gray-500">${formatBRL(s.faturamento_centavos)}</div>
              </div>
            </div>
            <div class="h-1.5 bg-gray-100 rounded overflow-hidden mt-1.5">
              <div class="h-full bg-blue-500" style=${`width: ${pct}%;`}></div>
            </div>
          </li>
        `;
      })}
    </ol>
  `;
}

function OcupacaoProfissionais({ itens }) {
  // Ordenado pela própria query (por nome). Quem não tem horário cadastrado
  // ainda aparece com 0%/0 — útil pra ver "esse profissional precisa de horário".
  return html`
    <ul class="space-y-3">
      ${itens.map(p => {
        const pct = Math.round((p.ocupacao_pct || 0) * 100);
        const semHorarios = p.minutos_disponiveis === 0;
        const horasDisp = (p.minutos_disponiveis / 60).toFixed(1);
        const horasAg = (p.minutos_agendados / 60).toFixed(1);
        return html`
          <li key=${p.profissional_id}>
            <div class="flex items-baseline justify-between gap-3">
              <div class="min-w-0">
                <div class="font-medium text-gray-800 truncate" title=${p.nome}>${p.nome}</div>
                ${p.especialidade && html`<div class="text-xs text-gray-500 truncate">${p.especialidade}</div>`}
              </div>
              <div class="text-right whitespace-nowrap">
                <div class=${`text-sm font-semibold ${semHorarios ? 'text-gray-400' : 'text-gray-800'}`}>
                  ${semHorarios ? '—' : `${pct}%`}
                </div>
                <div class="text-[11px] text-gray-500">
                  ${semHorarios ? 'sem horários' : `${horasAg}h / ${horasDisp}h`}
                </div>
              </div>
            </div>
            <div class="h-2 bg-gray-100 rounded overflow-hidden mt-1.5">
              <div
                class=${`h-full transition-all ${pct >= 80 ? 'bg-red-500' : pct >= 50 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                style=${`width: ${semHorarios ? 0 : Math.max(2, pct)}%;`}
              ></div>
            </div>
          </li>
        `;
      })}
    </ul>
  `;
}

function ConvitesCard({ convites }) {
  // Métrica da Etapa 12.5: links que a IA mandou via tool `enviar_link_agendamento`
  // versus quantos viraram agendamento.
  const c = convites || {};
  const semDados = !c.criados;
  return html`
    <div class="bg-white border border-gray-200 rounded-lg p-4">
      <div class="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h3 class="font-semibold text-gray-800 flex items-center gap-2">
            🔗 Conversão de convites IA
          </h3>
          <p class="text-xs text-gray-500 mt-1">
            Links de agendamento gerados pela tool <code class="bg-gray-100 px-1 rounded">enviar_link_agendamento</code> e enviados pelo WhatsApp.
          </p>
        </div>
        <div class="text-right">
          <div class="text-3xl font-bold text-violet-700">${formatPct(c.taxa_conversao || 0)}</div>
          <div class="text-xs text-gray-500">taxa de conversão</div>
        </div>
      </div>
      ${semDados
        ? html`<div class="mt-3 text-sm text-gray-400">Nenhum convite criado ainda. A IA gera tokens quando o cliente pede pra agendar pelo WhatsApp.</div>`
        : html`
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4">
            <${MiniStat} label="Criados" valor=${c.criados} cor="text-gray-800" />
            <${MiniStat} label="Usados" valor=${c.usados} cor="text-emerald-700" />
            <${MiniStat} label="Ativos" valor=${c.ativos} cor="text-blue-700" />
            <${MiniStat} label="Expirados" valor=${c.expirados} cor="text-gray-400" />
          </div>
        `}
    </div>
  `;
}

function MiniStat({ label, valor, cor }) {
  return html`
    <div class="bg-gray-50 rounded p-2 text-center">
      <div class=${`text-xl font-semibold ${cor}`}>${valor}</div>
      <div class="text-xs text-gray-500">${label}</div>
    </div>
  `;
}

function formatarData(iso) {
  if (!iso) return '—';
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}

// ══════════════════════════════════════════════════════════════════════
// Admin — Agendamentos (Etapa 7)
//
// Lista todas as reservas com filtros opcionais (status, data, profissional).
// Permite confirmar (pendente → confirmado) e cancelar qualquer reserva.
// ══════════════════════════════════════════════════════════════════════

const STATUS_LABELS = {
  pendente_pagamento: 'Pendente',
  confirmado: 'Confirmado',
  cancelado: 'Cancelado',
};

const STATUS_CLASSES = {
  pendente_pagamento: 'bg-yellow-100 text-yellow-800',
  confirmado:         'bg-green-100 text-green-800',
  cancelado:          'bg-gray-200 text-gray-600',
};

// ──────────────────────────────────────────────────────────────────────────
// Configuração do horário do lembrete (Etapa 11)
//
// Card inline na aba Agendamentos. Lê/grava `plugin.clinica.lembrete_hora`
// via endpoints `GET/PUT /admin/lembrete-config`. A próxima iteração do
// background loop (até 60s) já passa a usar o valor salvo — sem reiniciar.
// ──────────────────────────────────────────────────────────────────────────
function LembreteConfigCard({ apiBase }) {
  const [hora, setHora] = useState('09:00');
  const [intervalo, setIntervalo] = useState(1);
  const [original, setOriginal] = useState({ hora: '09:00', intervalo: 1 });
  const [janelaFim, setJanelaFim] = useState('18:00');
  const [loading, setLoading] = useState(true);
  const [salvando, setSalvando] = useState(false);
  const [msg, setMsg] = useState('');
  const [erro, setErro] = useState('');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await apiJson(`${apiBase}/admin/lembrete-config`);
        if (cancelled) return;
        const h = data?.hora || '09:00';
        const i = Number.isFinite(data?.intervalo_min) ? data.intervalo_min : 1;
        const jf = data?.janela_fim || '18:00';
        setHora(h);
        setIntervalo(i);
        setOriginal({ hora: h, intervalo: i });
        setJanelaFim(jf);
      } catch (e) {
        if (!cancelled) setErro('Não foi possível carregar a configuração.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [apiBase]);

  const salvar = async () => {
    setMsg('');
    setErro('');
    setSalvando(true);
    try {
      const intervaloFinal = Math.max(1, Math.min(60, parseInt(intervalo, 10) || 1));
      await apiJson(`${apiBase}/admin/lembrete-config`, {
        method: 'PUT',
        body: JSON.stringify({ hora, intervalo_min: intervaloFinal }),
      });
      setIntervalo(intervaloFinal);
      setOriginal({ hora, intervalo: intervaloFinal });
      setMsg('Configuração salva. A próxima checagem (até 30s) já usa os novos valores.');
      setTimeout(() => setMsg(''), 5000);
    } catch (e) {
      setErro(e.message);
    } finally {
      setSalvando(false);
    }
  };

  const dirty = hora !== original.hora || Number(intervalo) !== Number(original.intervalo);

  return html`
    <div class="bg-white border border-gray-200 rounded-lg p-4">
      <div class="flex items-start justify-between gap-4 flex-wrap">
        <div class="flex-1 min-w-[280px]">
          <h3 class="font-semibold text-gray-800 flex items-center gap-2">
            🔔 Lembretes automáticos
          </h3>
          <p class="text-sm text-gray-600 mt-1">
            O sistema envia <strong>um lembrete por vez</strong> a partir do horário marcado,
            espaçando <strong>${intervalo} minuto${intervalo > 1 ? 's' : ''}</strong> entre cada um.
            Isso evita bloqueio do WhatsApp por rajada quando há muitos agendamentos no mesmo dia.
            Janela superior fixa em <strong>${janelaFim}</strong> — fora desse intervalo, a fila pausa
            e os pendentes ficam pra próxima rodada.
          </p>
        </div>
        <div class="flex items-end gap-2 flex-wrap">
          <label class="block">
            <span class="text-xs text-gray-600">Horário do início</span>
            <input
              type="time"
              value=${hora}
              disabled=${loading || salvando}
              onInput=${e => setHora(e.target.value)}
              class="mt-1 block border border-gray-300 rounded px-2 py-1.5 text-sm w-32"
            />
          </label>
          <label class="block">
            <span class="text-xs text-gray-600">Intervalo (min)</span>
            <input
              type="number"
              min="1"
              max="60"
              step="1"
              value=${intervalo}
              disabled=${loading || salvando}
              onInput=${e => setIntervalo(e.target.value)}
              class="mt-1 block border border-gray-300 rounded px-2 py-1.5 text-sm w-24"
            />
          </label>
          <button
            onClick=${salvar}
            disabled=${!dirty || loading || salvando}
            class="px-4 py-1.5 bg-blue-600 text-white rounded text-sm font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >${salvando ? 'Salvando…' : 'Salvar'}</button>
        </div>
      </div>
      ${msg && html`<div class="mt-3 text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded p-2">${msg}</div>`}
      ${erro && html`<div class="mt-3 text-sm text-red-600 bg-red-50 border border-red-200 rounded p-2">${erro}</div>`}
    </div>
  `;
}

// ──────────────────────────────────────────────────────────────────────────
// Formulário de agendamento manual (recepção)
//
// Fluxo: escolhe serviço + data → "Ver horários" chama GET /servicos/{id}/slots
// (mesmo endpoint da página pública) → clica num horário disponível de um
// profissional → preenche nome + WhatsApp + status → POST /admin/agendamentos.
//
// Como os horários vêm do mesmo cálculo de slots usado no fluxo público, só é
// possível selecionar combinações realmente válidas — o backend revalida tudo
// (serviço ativo, profissional apto, sem conflito) antes de gravar.
// ──────────────────────────────────────────────────────────────────────────

const NOVO_AG_EMPTY = {
  servicoId: '',
  data: hojeISO(),
  profissionalId: '',   // preenchido ao clicar num horário disponível
  horaInicio: '',
  clienteNome: '',
  clienteTelefone: '',
  status: 'confirmado',
};

function NovoAgendamentoForm({ apiBase, onCreated, onCancel }) {
  const [servicos, setServicos] = useState([]);
  const [form, setForm] = useState(NOVO_AG_EMPTY);
  const [slots, setSlots] = useState(null);     // resultado de /slots ou null
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [saving, setSaving] = useState(false);
  const [erro, setErro] = useState('');

  // Carrega serviços ativos uma vez para o select.
  useEffect(() => {
    apiJson(`${apiBase}/servicos`)
      .then(srv => {
        setServicos(srv);
        if (srv.length) setForm(f => ({ ...f, servicoId: String(srv[0].id) }));
      })
      .catch(e => setErro(e.message));
  }, [apiBase]);

  const set = (patch) => setForm(f => ({ ...f, ...patch }));

  // Mudar serviço ou data invalida os horários já carregados/selecionados.
  const onServico = (v) => { set({ servicoId: v, profissionalId: '', horaInicio: '' }); setSlots(null); };
  const onData = (v) => { set({ data: v, profissionalId: '', horaInicio: '' }); setSlots(null); };

  const verHorarios = async () => {
    if (!form.servicoId || !form.data) { setErro('Escolha serviço e data.'); return; }
    setLoadingSlots(true);
    setErro('');
    setSlots(null);
    set({ profissionalId: '', horaInicio: '' });
    try {
      const r = await apiJson(`${apiBase}/servicos/${form.servicoId}/slots?data=${form.data}`);
      setSlots(r);
    } catch (e) {
      setErro(e.message);
    } finally {
      setLoadingSlots(false);
    }
  };

  const selecionarSlot = (profId, hora) => set({ profissionalId: String(profId), horaInicio: hora });

  const salvar = async (e) => {
    e?.preventDefault?.();
    setErro('');
    if (!form.servicoId) { setErro('Escolha um serviço.'); return; }
    if (!form.profissionalId || !form.horaInicio) { setErro('Clique num horário disponível.'); return; }
    if (form.clienteNome.trim().length < 2) { setErro('Informe o nome do cliente.'); return; }
    const tel = form.clienteTelefone.replace(/\D/g, '');
    if (tel.length < 10) { setErro('Informe um WhatsApp válido (DDD + número).'); return; }
    setSaving(true);
    try {
      await apiJson(`${apiBase}/admin/agendamentos`, {
        method: 'POST',
        body: JSON.stringify({
          servico_id: parseInt(form.servicoId, 10),
          profissional_id: parseInt(form.profissionalId, 10),
          data: form.data,
          hora_inicio: form.horaInicio,
          cliente_nome: form.clienteNome.trim(),
          cliente_telefone: form.clienteTelefone,
          status: form.status,
        }),
      });
      onCreated?.();
    } catch (e) {
      setErro(e.message);
    } finally {
      setSaving(false);
    }
  };

  const profs = slots?.profissionais || [];

  return html`
    <form onSubmit=${salvar} class="bg-white border border-blue-200 rounded-lg p-4 space-y-4">
      <div class="flex items-center justify-between">
        <h3 class="font-semibold text-gray-800">Novo agendamento</h3>
        <button type="button" onClick=${onCancel} class="text-sm text-gray-500 hover:text-gray-700">✕ Fechar</button>
      </div>

      <!-- Serviço + data + buscar horários -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
        <label class="block md:col-span-2">
          <span class="text-xs text-gray-600">Serviço</span>
          <select
            value=${form.servicoId}
            onChange=${e => onServico(e.target.value)}
            class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
          >
            ${servicos.length === 0 && html`<option value="">Nenhum serviço ativo</option>`}
            ${servicos.map(s => html`
              <option key=${s.id} value=${s.id}>
                ${s.nome} — ${formatDuracao(s.duracao_min)} — ${formatBRL(s.valor_centavos)}
              </option>
            `)}
          </select>
        </label>
        <label class="block">
          <span class="text-xs text-gray-600">Data</span>
          <input
            type="date"
            value=${form.data}
            min=${hojeISO()}
            onInput=${e => onData(e.target.value)}
            class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
          />
        </label>
      </div>
      <div>
        <button
          type="button"
          onClick=${verHorarios}
          disabled=${loadingSlots || !form.servicoId}
          class="px-4 py-1.5 border border-blue-300 text-blue-700 rounded text-sm font-medium hover:bg-blue-50 disabled:opacity-50"
        >${loadingSlots ? 'Buscando...' : 'Ver horários disponíveis'}</button>
      </div>

      <!-- Horários disponíveis por profissional -->
      ${slots && html`
        <div class="border-t border-gray-100 pt-3">
          ${profs.length === 0
            ? html`<div class="text-sm text-gray-500 bg-gray-50 border border-gray-200 rounded p-3 text-center">
                Nenhum horário disponível nesta data. Tente outro dia.
              </div>`
            : html`
              <div class="space-y-3">
                ${profs.map(p => html`
                  <div key=${p.id}>
                    <div class="text-sm font-medium text-gray-800 mb-1.5">
                      ${p.nome}
                      ${p.especialidade && html`<span class="text-xs font-normal text-gray-500"> · ${p.especialidade}</span>`}
                    </div>
                    <div class="flex flex-wrap gap-2">
                      ${p.slots.map(s => {
                        const sel = form.profissionalId === String(p.id) && form.horaInicio === s;
                        return html`
                          <button
                            key=${s}
                            type="button"
                            onClick=${() => selecionarSlot(p.id, s)}
                            class=${`px-3 py-1 rounded text-sm font-mono border ${sel
                              ? 'bg-blue-600 border-blue-600 text-white'
                              : 'bg-blue-50 border-blue-200 text-blue-800 hover:bg-blue-100'}`}
                          >${s}</button>
                        `;
                      })}
                    </div>
                  </div>
                `)}
              </div>
            `}
        </div>
      `}

      <!-- Dados do cliente + status -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3 border-t border-gray-100 pt-3">
        <label class="block">
          <span class="text-xs text-gray-600">Nome do cliente</span>
          <input
            type="text"
            value=${form.clienteNome}
            onInput=${e => set({ clienteNome: e.target.value })}
            placeholder="Ex: Maria Silva"
            class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
          />
        </label>
        <label class="block">
          <span class="text-xs text-gray-600">WhatsApp (DDD + número)</span>
          <input
            type="text"
            value=${form.clienteTelefone}
            onInput=${e => set({ clienteTelefone: e.target.value })}
            placeholder="Ex: 11 99999-0000"
            class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
          />
        </label>
        <label class="block">
          <span class="text-xs text-gray-600">Status inicial</span>
          <select
            value=${form.status}
            onChange=${e => set({ status: e.target.value })}
            class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
          >
            <option value="confirmado">Confirmado</option>
            <option value="pendente_pagamento">Pendente (aguardando pagamento)</option>
          </select>
        </label>
      </div>

      ${form.horaInicio && html`
        <div class="text-xs text-gray-500">
          Selecionado: ${(profs.find(p => String(p.id) === form.profissionalId) || {}).nome || '—'} às <strong>${form.horaInicio}</strong>
        </div>
      `}
      ${erro && html`<div class="text-sm text-red-600 bg-red-50 border border-red-200 rounded p-2">${erro}</div>`}

      <div class="flex items-center gap-3">
        <button
          type="submit"
          disabled=${saving || !form.horaInicio}
          class="px-4 py-2 bg-blue-600 text-white rounded text-sm font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >${saving ? 'Criando...' : 'Criar agendamento'}</button>
        <button
          type="button"
          onClick=${onCancel}
          class="px-4 py-2 border border-gray-300 rounded text-sm font-medium text-gray-700 hover:bg-gray-50"
        >Cancelar</button>
      </div>
    </form>
  `;
}


// ── Dropdown de filtro com checkboxes (multi-seleção) ───────────────────
// `selecionados` é um array de valores; conjunto vazio = "todos". Fecha ao
// clicar fora. Usado para status, serviços e profissionais.
function FiltroMulti({ label, opcoes, selecionados, onChange }) {
  const [aberto, setAberto] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (!aberto) return;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setAberto(false); };
    const onEsc = (e) => { if (e.key === 'Escape') setAberto(false); };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onEsc);
    return () => { document.removeEventListener('mousedown', onDoc); document.removeEventListener('keydown', onEsc); };
  }, [aberto]);

  const toggle = (v) => {
    const set = new Set(selecionados);
    set.has(v) ? set.delete(v) : set.add(v);
    onChange([...set]);
  };

  const ativo = selecionados.length > 0;
  const resumo = !ativo
    ? `Todos os ${label.toLowerCase()}`
    : selecionados.length === 1
      ? (opcoes.find(o => o.value === selecionados[0])?.label || label)
      : `${label}: ${selecionados.length}`;

  return html`
    <div class="relative" ref=${ref}>
      <button type="button" onClick=${() => setAberto(a => !a)}
        title=${`Filtrar por ${label.toLowerCase()} (múltipla escolha)`}
        class=${`border rounded px-2 h-8 text-sm flex items-center gap-1 max-w-[200px] ${ativo
          ? 'border-blue-400 bg-blue-50 text-blue-700'
          : 'border-gray-300 text-gray-700 hover:bg-gray-50'}`}>
        <span class="truncate">${resumo}</span>
        <span class="text-gray-400 text-xs">▾</span>
      </button>
      ${aberto && html`
        <div class="absolute z-30 mt-1 left-0 bg-white border border-gray-200 rounded-lg shadow-lg p-1 min-w-[210px] max-h-72 overflow-auto">
          ${opcoes.length === 0 && html`<div class="px-2 py-1.5 text-xs text-gray-400">Nenhuma opção</div>`}
          ${opcoes.map(o => html`
            <label key=${o.value} class="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-gray-50 cursor-pointer text-sm">
              <input type="checkbox" checked=${selecionados.includes(o.value)}
                onChange=${() => toggle(o.value)} class="rounded border-gray-300" />
              <span class="truncate">${o.label}</span>
            </label>
          `)}
          ${ativo && html`
            <button type="button" onClick=${() => onChange([])}
              class="w-full text-left px-2 py-1.5 mt-1 text-xs text-gray-500 hover:bg-gray-50 rounded border-t border-gray-100">Limpar seleção</button>
          `}
        </div>
      `}
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// Etapa 15 — Container dos agendamentos: calendário (dia/semana/mês) ⇄ lista
//
// O calendário é a visão principal; a tabela antiga vira a "lista" alternável
// (subcomponente TabelaAgendamentos, idêntica ao comportamento anterior).
// Frontend-only: o mesmo GET /admin/agendamentos já devolve tudo; cada vista
// só muda o intervalo data_ini/data_fim. As ações (confirmar/cancelar/
// lembrete) sobem para o container e são compartilhadas com tabela e modal.
// ══════════════════════════════════════════════════════════════════════

function AdminAgendamentos({ apiBase }) {
  const [items, setItems] = useState([]);
  const [profissionais, setProfissionais] = useState([]);
  const [servicos, setServicos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState('');
  const [actionErro, setActionErro] = useState('');
  const [novoAberto, setNovoAberto] = useState(false);

  // Modo de exibição / navegação
  const [modo, setModo] = useState('calendario');   // 'calendario' | 'lista'
  const [vista, setVista] = useState('dia');         // 'dia' | 'semana' | 'mes' — abre no dia (uso de balcão)
  const [dataRef, setDataRef] = useState(() => hojeLocal());
  const [selecionado, setSelecionado] = useState(null); // agendamento aberto no modal

  // Datas: server-side (definem o intervalo carregado). Na lista são manuais;
  // no calendário vêm da navegação (vista + dataRef).
  const [filtroDataIni, setFiltroDataIni] = useState('');
  const [filtroDataFim, setFiltroDataFim] = useState('');
  // Filtros client-side (multi-seleção, instantâneos, sem refetch):
  // status + profissional + serviço (arrays de valores) + busca livre.
  const [filtroStatus, setFiltroStatus] = useState([]);
  const [filtroProfIds, setFiltroProfIds] = useState([]);
  const [filtroServicoIds, setFiltroServicoIds] = useState([]);
  const [busca, setBusca] = useState('');

  // Carrega profissionais (cores/select) e serviços (select de filtro) uma vez.
  useEffect(() => {
    apiJson(`${apiBase}/admin/profissionais`).then(setProfissionais).catch(() => {});
    apiJson(`${apiBase}/admin/servicos`).then(setServicos).catch(() => {});
  }, [apiBase]);

  // Ordem estável (por id) → cor consistente por profissional em qualquer vista.
  const ordemProfs = useMemo(
    () => [...profissionais].sort((a, b) => a.id - b.id).map(p => p.id),
    [profissionais],
  );

  const load = useCallback(async () => {
    setLoading(true);
    setErro('');
    setActionErro('');
    try {
      // Só o intervalo vai ao backend; status/profissional/serviço/busca são
      // filtrados client-side (suportam multi-seleção, que o backend não aceita).
      const params = new URLSearchParams();
      if (modo === 'calendario') {
        // No calendário o intervalo vem da navegação (vista + dataRef).
        const { ini, fim } = rangeDaVista(vista, dataRef);
        params.set('data_ini', ini);
        params.set('data_fim', fim);
      } else {
        // Na lista mantém os filtros de data manuais.
        if (filtroDataIni) params.set('data_ini', filtroDataIni);
        if (filtroDataFim) params.set('data_fim', filtroDataFim);
      }
      const qs = params.toString() ? '?' + params.toString() : '';
      const data = await apiJson(`${apiBase}/admin/agendamentos${qs}`);
      setItems(data);
    } catch (e) {
      setErro(e.message);
    } finally {
      setLoading(false);
    }
  }, [apiBase, modo, vista, dataRef, filtroDataIni, filtroDataFim]);

  // Carrega na montagem e sempre que modo/vista/dataRef/filtros mudam.
  useEffect(() => { load(); }, [load]);

  // Atualiza um agendamento tanto na lista quanto no modal aberto.
  const patchItem = (id, patch) => {
    setItems(prev => prev.map(a => a.id === id ? { ...a, ...patch } : a));
    setSelecionado(prev => (prev && prev.id === id ? { ...prev, ...patch } : prev));
  };

  const confirmar = async (id) => {
    setActionErro('');
    try {
      await apiJson(`${apiBase}/admin/agendamentos/${id}/confirmar`, { method: 'POST' });
      patchItem(id, { status: 'confirmado' });
    } catch (e) {
      setActionErro(e.message);
    }
  };

  const cancelar = async (id) => {
    if (!confirm('Cancelar este agendamento? O slot voltará a ficar disponível.')) return;
    setActionErro('');
    try {
      await apiJson(`${apiBase}/admin/agendamentos/${id}/cancelar`, { method: 'POST' });
      patchItem(id, { status: 'cancelado' });
    } catch (e) {
      setActionErro(e.message);
    }
  };

  const dispararLembrete = async (id) => {
    setActionErro('');
    try {
      const res = await apiJson(`${apiBase}/admin/agendamentos/${id}/disparar-lembrete`, { method: 'POST' });
      if (res?.enviado) {
        patchItem(id, { lembrete_enviado: 1 });
      } else {
        setActionErro(
          'Lembrete não enviado. Verifique se o WhatsApp está conectado, '
          + 'se o agendamento está confirmado e se o lembrete ainda não foi enviado antes.'
        );
      }
    } catch (e) {
      setActionErro(e.message);
    }
  };

  // Filtros client-side: status/profissional/serviço (multi) + busca livre.
  // Conjunto vazio = "todos" (sem restrição) para aquela dimensão.
  const itemsFiltrados = useMemo(() => {
    const q = busca.trim();
    const qNome = normalizarBusca(q);
    const qTel = soDigitos(q);
    const statusSet = new Set(filtroStatus);
    const profSet = new Set(filtroProfIds.map(String));
    const srvSet = new Set(filtroServicoIds.map(String));
    return items.filter(a => {
      if (statusSet.size && !statusSet.has(a.status)) return false;
      if (profSet.size && !profSet.has(String(a.profissional_id))) return false;
      if (srvSet.size && !srvSet.has(String(a.servico_id))) return false;
      if (q) {
        const achouNome = normalizarBusca(a.cliente_nome).includes(qNome);
        const achouTel = qTel.length > 0 && soDigitos(a.cliente_telefone).includes(qTel);
        if (!achouNome && !achouTel) return false;
      }
      return true;
    });
  }, [items, filtroStatus, filtroProfIds, filtroServicoIds, busca]);

  // Agrupa por dia (ISO → agendamentos ordenados por hora) para as vistas.
  const porDia = useMemo(() => {
    const map = {};
    for (const a of itemsFiltrados) {
      (map[a.data] || (map[a.data] = [])).push(a);
    }
    for (const k of Object.keys(map)) {
      map[k].sort((x, y) => (x.hora_inicio || '').localeCompare(y.hora_inicio || ''));
    }
    return map;
  }, [itemsFiltrados]);

  const irHoje = () => setDataRef(hojeLocal());
  const navegar = (dir) => setDataRef(d => avancarData(vista, d, dir));
  const drillDia = (d) => { setDataRef(d); setVista('dia'); };

  const VISTAS = [
    { id: 'dia', label: 'Dia' },
    { id: 'semana', label: 'Semana' },
    { id: 'mes', label: 'Mês' },
  ];

  return html`
    <div class="space-y-4">
      <!-- Ação: novo agendamento manual -->
      <div class="flex justify-end">
        <button
          onClick=${() => setNovoAberto(v => !v)}
          class=${`px-4 py-1.5 rounded text-sm font-medium ${novoAberto
            ? 'border border-gray-300 text-gray-700 hover:bg-gray-50'
            : 'bg-blue-600 text-white hover:bg-blue-700'}`}
        >${novoAberto ? 'Fechar' : '+ Novo agendamento'}</button>
      </div>
      ${novoAberto && html`
        <${NovoAgendamentoForm}
          apiBase=${apiBase}
          onCreated=${() => { setNovoAberto(false); load(); }}
          onCancel=${() => setNovoAberto(false)}
        />
      `}

      <!-- Configuração de lembretes -->
      <${LembreteConfigCard} apiBase=${apiBase} />

      <!-- Barra de controle: navegação + filtros + vista + toggle -->
      <div class="bg-white border border-gray-200 rounded-lg p-3 flex flex-wrap items-center gap-3 justify-between">
        <!-- Navegação (só no calendário) -->
        <div class="flex items-center gap-2 min-h-[34px]">
          ${modo === 'calendario' && html`
            <button type="button" onClick=${() => navegar(-1)}
              aria-label="Período anterior"
              class="w-8 h-8 rounded border border-gray-300 text-gray-600 hover:bg-gray-50">‹</button>
            <button type="button" onClick=${irHoje}
              class="px-3 h-8 rounded border border-gray-300 text-sm font-medium text-gray-700 hover:bg-gray-50">Hoje</button>
            <button type="button" onClick=${() => navegar(1)}
              aria-label="Próximo período"
              class="w-8 h-8 rounded border border-gray-300 text-gray-600 hover:bg-gray-50">›</button>
            <span class="ml-1 font-semibold text-gray-800 capitalize">${tituloPeriodo(vista, dataRef)}</span>
          `}
        </div>

        <!-- Filtros sempre visíveis: busca + status + serviço + profissional (multi) -->
        <div class="flex items-center gap-2 flex-wrap">
          <input
            type="search"
            value=${busca}
            onInput=${e => setBusca(e.target.value)}
            placeholder="🔍 Buscar cliente ou telefone"
            title="Busca pelo nome ou telefone do cliente (ignora acentos e formatação)"
            class="border border-gray-300 rounded px-2 h-8 text-sm w-52"
          />
          <${FiltroMulti}
            label="Status"
            opcoes=${[
              { value: 'pendente_pagamento', label: 'Pendente' },
              { value: 'confirmado', label: 'Confirmado' },
              { value: 'cancelado', label: 'Cancelado' },
            ]}
            selecionados=${filtroStatus}
            onChange=${setFiltroStatus} />
          <${FiltroMulti}
            label="Serviços"
            opcoes=${servicos.map(s => ({ value: String(s.id), label: s.nome }))}
            selecionados=${filtroServicoIds}
            onChange=${setFiltroServicoIds} />
          <${FiltroMulti}
            label="Profissionais"
            opcoes=${profissionais.map(p => ({ value: String(p.id), label: p.nome }))}
            selecionados=${filtroProfIds}
            onChange=${setFiltroProfIds} />
          ${(busca || filtroStatus.length || filtroServicoIds.length || filtroProfIds.length) && html`
            <button type="button"
              onClick=${() => { setBusca(''); setFiltroStatus([]); setFiltroServicoIds([]); setFiltroProfIds([]); }}
              class="px-2 h-8 rounded border border-gray-300 text-xs font-medium text-gray-600 hover:bg-gray-50"
              title="Limpar filtros">✕ Limpar</button>
          `}
        </div>

        <!-- Vista (segmented) + toggle calendário/lista -->
        <div class="flex items-center gap-2">
          <button type="button" onClick=${() => load()} disabled=${loading}
            aria-label="Recarregar" title="Recarregar agendamentos"
            class="w-8 h-8 rounded border border-gray-300 text-gray-600 hover:bg-gray-50 disabled:opacity-50">
            <span class=${`inline-block text-base leading-none ${loading ? 'animate-spin' : ''}`}>↻</span>
          </button>
          ${modo === 'calendario' && html`
            <div class="inline-flex rounded-lg border border-gray-300 overflow-hidden">
              ${VISTAS.map(v => html`
                <button key=${v.id} type="button" onClick=${() => setVista(v.id)}
                  class=${`px-3 h-8 text-sm font-medium ${vista === v.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-600 hover:bg-gray-50'}`}
                >${v.label}</button>
              `)}
            </div>
          `}
          <button type="button" onClick=${() => setModo(m => m === 'calendario' ? 'lista' : 'calendario')}
            class="px-3 h-8 rounded border border-gray-300 text-sm font-medium text-gray-700 hover:bg-gray-50"
            title="Alternar entre calendário e lista"
          >${modo === 'calendario' ? '☰ Lista' : '🗓 Calendário'}</button>
        </div>
      </div>

      ${erro && html`<div class="text-sm text-red-600 bg-red-50 border border-red-200 rounded p-3">${erro}</div>`}
      ${actionErro && html`<div class="text-sm text-red-600 bg-red-50 border border-red-200 rounded p-3">${actionErro}</div>`}

      ${modo === 'calendario'
        ? html`
          <div class="flex items-center justify-between text-xs text-gray-500">
            <span>${loading
              ? 'Carregando…'
              : `${itemsFiltrados.length} agendamento${itemsFiltrados.length !== 1 ? 's' : ''}`
                + (itemsFiltrados.length !== items.length ? ` (de ${items.length} no período)` : ' no período')}</span>
          </div>
          ${vista === 'mes' && html`<${VistaMes} dataRef=${dataRef} porDia=${porDia} ordemProfs=${ordemProfs} onSelect=${setSelecionado} onDrillDia=${drillDia} />`}
          ${vista === 'semana' && html`<${VistaSemana} dataRef=${dataRef} porDia=${porDia} ordemProfs=${ordemProfs} onSelect=${setSelecionado} onDrillDia=${drillDia} />`}
          ${vista === 'dia' && html`<${VistaDia} dataRef=${dataRef} porDia=${porDia} profissionais=${profissionais} ordemProfs=${ordemProfs} onSelect=${setSelecionado} />`}
          <${LegendaCalendario} profissionais=${profissionais} ordemProfs=${ordemProfs} />
        `
        : html`
          <!-- Filtros de data manuais (só na lista) -->
          <div class="bg-white border border-gray-200 rounded-lg p-3 flex flex-wrap items-end gap-3">
            <label class="block">
              <span class="text-xs text-gray-600">Data inicial</span>
              <input type="date" value=${filtroDataIni}
                onInput=${e => setFiltroDataIni(e.target.value)}
                class="mt-1 block border border-gray-300 rounded px-2 py-1.5 text-sm" />
            </label>
            <label class="block">
              <span class="text-xs text-gray-600">Data final</span>
              <input type="date" value=${filtroDataFim}
                onInput=${e => setFiltroDataFim(e.target.value)}
                class="mt-1 block border border-gray-300 rounded px-2 py-1.5 text-sm" />
            </label>
            <button onClick=${load} disabled=${loading}
              class="px-4 py-1.5 bg-blue-600 text-white rounded text-sm font-medium hover:bg-blue-700 disabled:opacity-50"
            >${loading ? 'Carregando...' : 'Atualizar'}</button>
            <button
              onClick=${() => { setFiltroStatus([]); setFiltroDataIni(''); setFiltroDataFim(''); setFiltroProfIds([]); setFiltroServicoIds([]); setBusca(''); }}
              class="px-4 py-1.5 border border-gray-300 rounded text-sm font-medium text-gray-700 hover:bg-gray-50"
            >Limpar filtros</button>
            <span class="text-xs text-gray-500 ml-auto">${itemsFiltrados.length} registro${itemsFiltrados.length !== 1 ? 's' : ''}</span>
          </div>
          <${TabelaAgendamentos}
            items=${itemsFiltrados} loading=${loading}
            onConfirmar=${confirmar} onCancelar=${cancelar} onLembrete=${dispararLembrete} />
        `}

      ${selecionado && html`
        <${ModalAgendamento}
          a=${selecionado}
          onClose=${() => setSelecionado(null)}
          onConfirmar=${confirmar}
          onCancelar=${cancelar}
          onLembrete=${dispararLembrete} />
      `}
    </div>
  `;
}

// ── Tabela (visão "lista", idêntica ao comportamento anterior) ──────────
function TabelaAgendamentos({ items, loading, onConfirmar, onCancelar, onLembrete }) {
  const formatData = (iso) => {
    if (!iso) return '—';
    const [y, m, d] = iso.split('-');
    return `${d}/${m}/${y}`;
  };
  const formatTs = (ts) => {
    if (!ts) return '—';
    return new Date(ts * 1000).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
  };
  return html`
    <div class="border border-gray-200 rounded-lg overflow-hidden">
      <div class="overflow-x-auto">
        <table class="w-full text-sm min-w-[900px]">
          <thead class="bg-gray-50 text-gray-600 text-left">
            <tr>
              <th class="px-4 py-2 w-14">#</th>
              <th class="px-4 py-2">Cliente</th>
              <th class="px-4 py-2">Serviço</th>
              <th class="px-4 py-2">Profissional</th>
              <th class="px-4 py-2">Data / Hora</th>
              <th class="px-4 py-2">Valor</th>
              <th class="px-4 py-2">Criado em</th>
              <th class="px-4 py-2">Status</th>
              <th class="px-4 py-2 text-right">Ações</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-100">
            ${loading && items.length === 0 && html`
              <tr><td colspan="9" class="px-4 py-8 text-center text-gray-400">Carregando...</td></tr>
            `}
            ${!loading && items.length === 0 && html`
              <tr><td colspan="9" class="px-4 py-8 text-center text-gray-400">
                Nenhum agendamento encontrado para os filtros selecionados.
              </td></tr>
            `}
            ${items.map(a => html`
              <tr key=${a.id} class=${a.status === 'cancelado' ? 'bg-gray-50 text-gray-400' : ''}>
                <td class="px-4 py-2 font-mono text-xs text-gray-500">${a.id}</td>
                <td class="px-4 py-2">
                  <div class="font-medium text-gray-900">${a.cliente_nome}</div>
                  <div class="text-xs text-gray-500">${a.cliente_telefone}</div>
                </td>
                <td class="px-4 py-2 text-gray-800">${a.servico_nome}</td>
                <td class="px-4 py-2 text-gray-800">${a.profissional_nome}</td>
                <td class="px-4 py-2 whitespace-nowrap">
                  <div class="text-gray-800">${formatData(a.data)}</div>
                  <div class="text-xs text-gray-500">${a.hora_inicio} – ${a.hora_fim}</div>
                </td>
                <td class="px-4 py-2 whitespace-nowrap text-gray-800">${formatBRL(a.valor_centavos)}</td>
                <td class="px-4 py-2 text-xs text-gray-500 whitespace-nowrap">${formatTs(a.created_at)}</td>
                <td class="px-4 py-2">
                  <span class=${`inline-block px-2 py-0.5 text-xs rounded font-medium ${STATUS_CLASSES[a.status] || 'bg-gray-100 text-gray-700'}`}>
                    ${STATUS_LABELS[a.status] || a.status}
                  </span>
                  ${a.mp_order_id && html`<div class="text-xs text-blue-500 mt-0.5" title=${'Order MP: ' + a.mp_order_id}>💳 Pag. iniciado</div>`}
                  ${a.lembrete_enviado ? html`<div class="text-xs text-emerald-600 mt-0.5" title="Lembrete WhatsApp já enviado">🔔 Lembrete enviado</div>` : null}
                </td>
                <td class="px-4 py-2 text-right whitespace-nowrap space-x-2">
                  ${a.status === 'pendente_pagamento' && html`
                    <button onClick=${() => onConfirmar(a.id)}
                      class="text-green-700 hover:underline text-xs font-medium"
                      title="Confirmar agendamento manualmente">Confirmar</button>
                  `}
                  ${a.status === 'confirmado' && !a.lembrete_enviado && html`
                    <button onClick=${() => onLembrete(a.id)}
                      class="text-blue-600 hover:underline text-xs font-medium"
                      title="Enviar lembrete WhatsApp agora (ignora o gatilho das 09:00)">Lembrete</button>
                  `}
                  ${a.status !== 'cancelado' && html`
                    <button onClick=${() => onCancelar(a.id)}
                      class="text-red-600 hover:underline text-xs font-medium"
                      title="Cancelar agendamento e liberar o slot">Cancelar</button>
                  `}
                  ${a.status === 'cancelado' && html`<span class="text-xs text-gray-400">—</span>`}
                </td>
              </tr>
            `)}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

// ── Chip de agendamento (vista Mês) ─────────────────────────────────────
function ChipAgendamento({ a, ordemProfs, onSelect }) {
  const c = corDoProfissional(a.profissional_id, ordemProfs);
  const cancelado = a.status === 'cancelado';
  return html`
    <button type="button" onClick=${() => onSelect(a)}
      title=${`${a.hora_inicio}–${a.hora_fim} · ${a.cliente_nome} · ${a.profissional_nome} · ${STATUS_LABELS[a.status] || a.status}`}
      class=${`block w-full text-left truncate rounded border px-1 py-0.5 text-[11px] leading-tight ${c.bg} ${c.border} ${c.text} hover:brightness-95 ${cancelado ? 'line-through opacity-50' : ''}`}>
      <span class="mr-0.5">${iconeStatus(a.status)}</span>
      <span class="font-mono">${a.hora_inicio}</span> ${primeiroNome(a.cliente_nome)}
    </button>
  `;
}

// ── Vista Mês ───────────────────────────────────────────────────────────
function VistaMes({ dataRef, porDia, ordemProfs, onSelect, onDrillDia }) {
  const hoje = hojeLocal();
  const ano = dataRef.getFullYear();
  const mes = dataRef.getMonth();
  const primeiroDia = new Date(ano, mes, 1);
  const ultimoDia = new Date(ano, mes + 1, 0);
  const offsetInicio = (primeiroDia.getDay() + 6) % 7; // semana começa na segunda
  const totalCelulas = Math.ceil((offsetInicio + ultimoDia.getDate()) / 7) * 7;
  const semanas = totalCelulas / 7;
  const MAX_CHIPS = 5;
  // Aproveita a altura da tela: células mais altas em meses de 5 semanas; em
  // meses de 6 semanas reduz um pouco pra não estourar a dobra.
  const alturaCelula = semanas >= 6 ? 'min-h-[120px]' : 'min-h-[150px]';

  const celulas = [];
  for (let i = 0; i < totalCelulas; i++) {
    const diaNum = i - offsetInicio + 1;
    celulas.push((diaNum < 1 || diaNum > ultimoDia.getDate()) ? null : new Date(ano, mes, diaNum));
  }

  return html`
    <div class="bg-white border border-gray-200 rounded-lg overflow-hidden">
      <div class="grid grid-cols-7 bg-gray-50 text-center text-xs font-medium text-gray-500 border-b border-gray-200">
        ${DIAS_SEMANA_ABREV.map(d => html`<div key=${d} class="py-2">${d}</div>`)}
      </div>
      <div class="grid grid-cols-7">
        ${celulas.map((d, i) => {
          if (!d) return html`<div key=${`e${i}`} class=${`${alturaCelula} border-b border-r border-gray-100 bg-gray-50/40`}></div>`;
          const iso = toISO(d);
          const isHoje = +d === +hoje;
          const ags = porDia[iso] || [];
          const extra = ags.length - MAX_CHIPS;
          return html`
            <div key=${iso} class=${`${alturaCelula} border-b border-r border-gray-100 p-1 ${isHoje ? 'bg-blue-50/40' : ''}`}>
              <button type="button" onClick=${() => onDrillDia(d)}
                class="block mb-1 px-1 text-xs font-semibold hover:text-blue-600"
                title="Ver dia">
                <span class=${isHoje
                  ? 'inline-flex items-center justify-center w-5 h-5 rounded-full bg-blue-600 text-white'
                  : 'text-gray-500'}>${d.getDate()}</span>
              </button>
              <div class="space-y-0.5">
                ${ags.slice(0, MAX_CHIPS).map(a => html`
                  <${ChipAgendamento} key=${a.id} a=${a} ordemProfs=${ordemProfs} onSelect=${onSelect} />
                `)}
                ${extra > 0 && html`
                  <button type="button" onClick=${() => onDrillDia(d)}
                    class="block w-full text-left text-[11px] text-gray-500 hover:text-blue-600 px-1">+${extra} mais</button>
                `}
              </div>
            </div>
          `;
        })}
      </div>
    </div>
  `;
}

// ── Coluna de horas (gutter) + eventos posicionados ─────────────────────
function GutterHoras({ minM, maxM }) {
  const horas = [];
  for (let m = minM; m < maxM; m += 60) horas.push(m);
  return html`
    <div class="relative w-12 flex-shrink-0" style=${`height:${(maxM - minM) * HORA_PX / 60}px`}>
      ${horas.map((m, i) => html`
        <div key=${m} class="absolute right-1 text-[10px] text-gray-400 -translate-y-1/2" style=${`top:${i * HORA_PX}px`}>
          ${pad2(Math.floor(m / 60))}:00
        </div>
      `)}
    </div>
  `;
}

function ColunaDia({ ags, minM, maxM, ordemProfs, onSelect }) {
  const layout = layoutDia(ags);
  const altura = (maxM - minM) * HORA_PX / 60;
  const px = (min) => (min - minM) * HORA_PX / 60;
  const linhas = Math.ceil((maxM - minM) / 60);
  return html`
    <div class="relative" style=${`height:${altura}px`}>
      ${Array.from({ length: linhas }, (_, i) => html`
        <div key=${i} class="absolute left-0 right-0 border-t border-gray-100" style=${`top:${i * HORA_PX}px`}></div>
      `)}
      ${layout.map(e => {
        const c = corDoProfissional(e.a.profissional_id, ordemProfs);
        const cancelado = e.a.status === 'cancelado';
        const w = 100 / e.cols;
        const top = px(e.ini);
        const height = Math.max(px(e.fim) - top, 20);
        // Quantas linhas cabem na altura do bloco → conteúdo adaptativo, nunca
        // cortando texto no meio: bloco curto mostra serviço inline; alto mostra
        // hora–fim, cliente completo e serviço em linhas separadas.
        const linhas = height >= 48 ? 3 : height >= 32 ? 2 : 1;
        return html`
          <button key=${e.a.id} type="button" onClick=${() => onSelect(e.a)}
            title=${`${e.a.hora_inicio}–${e.a.hora_fim} · ${e.a.cliente_nome} · ${e.a.servico_nome} · ${e.a.profissional_nome} · ${STATUS_LABELS[e.a.status] || e.a.status}`}
            class=${`absolute rounded border px-1 py-0.5 leading-tight overflow-hidden text-left ${c.bg} ${c.border} ${c.text} hover:brightness-95 ${cancelado ? 'line-through opacity-60' : ''}`}
            style=${`top:${top}px; height:${height}px; left:${e.lane * w}%; width:calc(${w}% - 2px)`}>
            ${linhas === 1 && html`
              <div class="truncate text-[11px] font-medium">
                <span class="mr-0.5">${iconeStatus(e.a.status)}</span>${e.a.hora_inicio} ${primeiroNome(e.a.cliente_nome)} · ${e.a.servico_nome}
              </div>
            `}
            ${linhas === 2 && html`
              <div class="truncate text-[11px] font-medium"><span class="mr-0.5">${iconeStatus(e.a.status)}</span>${e.a.hora_inicio} ${primeiroNome(e.a.cliente_nome)}</div>
              <div class="truncate text-[10px] opacity-80">${e.a.servico_nome}</div>
            `}
            ${linhas === 3 && html`
              <div class="truncate text-[11px] font-medium"><span class="mr-0.5">${iconeStatus(e.a.status)}</span>${e.a.hora_inicio}–${e.a.hora_fim}</div>
              <div class="truncate text-[11px]">${e.a.cliente_nome}</div>
              <div class="truncate text-[10px] opacity-80">${e.a.servico_nome}</div>
            `}
          </button>
        `;
      })}
    </div>
  `;
}

// ── Vista Semana ────────────────────────────────────────────────────────
function VistaSemana({ dataRef, porDia, ordemProfs, onSelect, onDrillDia }) {
  const hoje = hojeLocal();
  const dias = diasDaSemana(dataRef);
  const todos = dias.flatMap(d => porDia[toISO(d)] || []);
  const { minM, maxM } = faixaHoras(todos);
  return html`
    <div class="bg-white border border-gray-200 rounded-lg overflow-hidden">
      <div class="overflow-x-auto">
        <div class="min-w-[720px]">
          <div class="grid border-b border-gray-200" style="grid-template-columns:3rem repeat(7,1fr)">
            <div class="bg-gray-50"></div>
            ${dias.map(d => {
              const isHoje = +d === +hoje;
              return html`
                <button key=${toISO(d)} type="button" onClick=${() => onDrillDia(d)}
                  class=${`py-2 text-center border-l border-gray-100 hover:bg-blue-50 ${isHoje ? 'bg-blue-50' : 'bg-gray-50'}`}>
                  <div class="text-[10px] uppercase text-gray-400">${DIAS_SEMANA_ABREV[(d.getDay() + 6) % 7]}</div>
                  <div class=${`text-sm font-semibold ${isHoje ? 'text-blue-700' : 'text-gray-700'}`}>${d.getDate()}</div>
                </button>
              `;
            })}
          </div>
          <div class="grid" style="grid-template-columns:3rem repeat(7,1fr)">
            <${GutterHoras} minM=${minM} maxM=${maxM} />
            ${dias.map(d => html`
              <div key=${toISO(d)} class="border-l border-gray-100 px-0.5">
                <${ColunaDia} ags=${porDia[toISO(d)] || []} minM=${minM} maxM=${maxM} ordemProfs=${ordemProfs} onSelect=${onSelect} />
              </div>
            `)}
          </div>
        </div>
      </div>
    </div>
  `;
}

// ── Vista Dia (uma coluna por profissional) ─────────────────────────────
// Mostra SEMPRE a grade de horas do expediente (08:00–20:00, expandida por
// eventos fora dela), mesmo com o dia vazio — recepção rola a agenda do dia.
function VistaDia({ dataRef, porDia, profissionais, ordemProfs, onSelect }) {
  const iso = toISO(dataRef);
  const ags = porDia[iso] || [];
  const { minM, maxM } = faixaHoras(ags);

  // Colunas: profissionais com agendamento no dia; se o dia está vazio, mostra
  // todos os profissionais ativos (grade vazia rolável); se não há nenhum
  // cadastrado, cai numa coluna genérica "Agenda".
  let profIds = [...new Set(ags.map(a => a.profissional_id))]
    .sort((a, b) => ordemProfs.indexOf(a) - ordemProfs.indexOf(b));
  if (profIds.length === 0) {
    profIds = [...profissionais].filter(p => p.ativo !== 0).sort((a, b) => a.id - b.id).map(p => p.id);
  }
  const cols = profIds.length ? profIds : [null]; // null = coluna genérica
  const nomeProf = (id) => {
    const p = profissionais.find(p => p.id === id);
    return p ? p.nome : (ags.find(a => a.profissional_id === id)?.profissional_nome || '—');
  };

  return html`
    <div class="bg-white border border-gray-200 rounded-lg overflow-hidden">
      ${ags.length === 0 && html`
        <div class="px-3 py-2 text-xs text-gray-400 border-b border-gray-100 bg-gray-50">Nenhum agendamento neste dia — agenda livre.</div>
      `}
      <div class="overflow-x-auto">
        <div style=${`min-width:${cols.length * 180 + 48}px`}>
          <div class="grid border-b border-gray-200" style=${`grid-template-columns:3rem repeat(${cols.length},1fr)`}>
            <div class="bg-gray-50"></div>
            ${cols.map(id => {
              if (id == null) {
                return html`<div key="g" class="py-2 px-2 text-center border-l border-gray-100 bg-gray-50 text-sm font-medium text-gray-500">Agenda</div>`;
              }
              const c = corDoProfissional(id, ordemProfs);
              return html`
                <div key=${id} class="py-2 px-2 text-center border-l border-gray-100 bg-gray-50">
                  <span class=${`inline-block w-2 h-2 rounded-full mr-1 ${c.dot}`}></span>
                  <span class="text-sm font-medium text-gray-700">${nomeProf(id)}</span>
                </div>
              `;
            })}
          </div>
          <div class="grid" style=${`grid-template-columns:3rem repeat(${cols.length},1fr)`}>
            <${GutterHoras} minM=${minM} maxM=${maxM} />
            ${cols.map(id => html`
              <div key=${id == null ? 'g' : id} class="border-l border-gray-100 px-0.5">
                <${ColunaDia} ags=${id == null ? ags : ags.filter(a => a.profissional_id === id)} minM=${minM} maxM=${maxM} ordemProfs=${ordemProfs} onSelect=${onSelect} />
              </div>
            `)}
          </div>
        </div>
      </div>
    </div>
  `;
}

// ── Legenda (cor por profissional + ícones de status) ───────────────────
function LegendaCalendario({ profissionais, ordemProfs }) {
  return html`
    <div class="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-gray-600 bg-white border border-gray-200 rounded-lg p-3">
      <span class="font-medium text-gray-700">Profissionais:</span>
      ${profissionais.length === 0 && html`<span class="text-gray-400">—</span>`}
      ${[...profissionais].sort((a, b) => a.id - b.id).map(p => {
        const c = corDoProfissional(p.id, ordemProfs);
        return html`
          <span key=${p.id} class="inline-flex items-center gap-1">
            <span class=${`inline-block w-3 h-3 rounded ${c.bg} border ${c.border}`}></span>${p.nome}
          </span>
        `;
      })}
      <span class="mx-1 text-gray-300">|</span>
      <span class="inline-flex items-center gap-1">✓ Confirmado</span>
      <span class="inline-flex items-center gap-1">⏳ Pendente</span>
      <span class="inline-flex items-center gap-1">✕ Cancelado</span>
    </div>
  `;
}

// ── Modal de detalhes + ações ───────────────────────────────────────────
function ModalAgendamento({ a, onClose, onConfirmar, onCancelar, onLembrete }) {
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  if (!a) return null;
  const fmtData = (iso) => { if (!iso) return '—'; const [y, m, d] = iso.split('-'); return `${d}/${m}/${y}`; };

  return html`
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick=${onClose}>
      <div class="bg-white rounded-lg shadow-xl w-full max-w-md" onClick=${e => e.stopPropagation()}>
        <div class="flex items-start justify-between p-4 border-b border-gray-100">
          <div>
            <div class="text-lg font-semibold text-gray-900">${a.cliente_nome}</div>
            <div class="text-sm text-gray-500">${a.cliente_telefone}</div>
          </div>
          <button type="button" onClick=${onClose} aria-label="Fechar"
            class="text-gray-400 hover:text-gray-600 text-xl leading-none">✕</button>
        </div>
        <div class="p-4 space-y-2 text-sm">
          <div class="flex justify-between gap-3"><span class="text-gray-500">Serviço</span><span class="text-gray-900 font-medium text-right">${a.servico_nome}</span></div>
          <div class="flex justify-between gap-3"><span class="text-gray-500">Profissional</span><span class="text-gray-900 text-right">${a.profissional_nome}</span></div>
          <div class="flex justify-between gap-3"><span class="text-gray-500">Data</span><span class="text-gray-900 text-right">${fmtData(a.data)}</span></div>
          <div class="flex justify-between gap-3"><span class="text-gray-500">Horário</span><span class="text-gray-900 text-right font-mono">${a.hora_inicio} – ${a.hora_fim}</span></div>
          <div class="flex justify-between gap-3"><span class="text-gray-500">Valor</span><span class="text-gray-900 text-right">${formatBRL(a.valor_centavos)}</span></div>
          <div class="flex justify-between items-center gap-3">
            <span class="text-gray-500">Status</span>
            <span class=${`inline-block px-2 py-0.5 text-xs rounded font-medium ${STATUS_CLASSES[a.status] || 'bg-gray-100 text-gray-700'}`}>${STATUS_LABELS[a.status] || a.status}</span>
          </div>
          ${a.mp_order_id && html`<div class="text-xs text-blue-500" title=${'Order MP: ' + a.mp_order_id}>💳 Pagamento iniciado</div>`}
          ${a.lembrete_enviado ? html`<div class="text-xs text-emerald-600">🔔 Lembrete enviado</div>` : null}
        </div>
        <div class="flex flex-wrap justify-end gap-2 p-4 border-t border-gray-100">
          ${a.status === 'pendente_pagamento' && html`
            <button type="button" onClick=${() => onConfirmar(a.id)}
              class="px-3 py-1.5 bg-green-600 text-white rounded text-sm font-medium hover:bg-green-700">Confirmar</button>
          `}
          ${a.status === 'confirmado' && !a.lembrete_enviado && html`
            <button type="button" onClick=${() => onLembrete(a.id)}
              class="px-3 py-1.5 bg-blue-600 text-white rounded text-sm font-medium hover:bg-blue-700">Lembrete</button>
          `}
          ${a.status !== 'cancelado' && html`
            <button type="button" onClick=${() => onCancelar(a.id)}
              class="px-3 py-1.5 border border-red-300 text-red-600 rounded text-sm font-medium hover:bg-red-50">Cancelar</button>
          `}
          <button type="button" onClick=${onClose}
            class="px-3 py-1.5 border border-gray-300 text-gray-700 rounded text-sm font-medium hover:bg-gray-50">Fechar</button>
        </div>
      </div>
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// Visão geral (etapa 1)
// ══════════════════════════════════════════════════════════════════════

function VisaoGeral({ apiBase }) {
  const [info, setInfo] = useState(null);
  const [profissionais, setProfissionais] = useState([]);
  const [servicos, setServicos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState('');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [i, p, s] = await Promise.all([
          apiJson(`${apiBase}/info`),
          apiJson(`${apiBase}/profissionais`),
          apiJson(`${apiBase}/servicos`),
        ]);
        if (cancelled) return;
        setInfo(i);
        setProfissionais(p);
        setServicos(s);
      } catch (e) {
        if (!cancelled) setErro(e.message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [apiBase]);

  if (loading) return html`<div class="text-gray-500">Carregando...</div>`;
  if (erro)    return html`<div class="text-red-600">Erro: ${erro}</div>`;

  return html`
    <div class="space-y-8">
      <section class="bg-gray-50 rounded-lg p-4 border border-gray-200">
        <div class="font-semibold text-gray-900">${info?.nome}</div>
        ${info?.slogan && html`<div class="text-sm text-gray-600">${info.slogan}</div>`}
        <div class="text-sm text-gray-500 mt-2 space-y-1">
          ${info?.telefone && html`<div>📞 ${info.telefone}</div>`}
          ${info?.endereco && html`<div>📍 ${info.endereco}</div>`}
        </div>
      </section>

      <section>
        <h2 class="text-lg font-semibold text-gray-800 mb-3">
          Equipe ativa (${profissionais.length})
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          ${profissionais.map(p => html`
            <div key=${p.id} class="border border-gray-200 rounded-lg p-4 bg-white">
              <div class="font-semibold text-gray-900">${p.nome}</div>
              <div class="text-sm text-gray-500 mt-1">${p.especialidade}</div>
            </div>
          `)}
        </div>
      </section>

      <section>
        <h2 class="text-lg font-semibold text-gray-800 mb-3">
          Serviços ativos (${servicos.length})
        </h2>
        <div class="space-y-3">
          ${servicos.map(s => html`
            <div key=${s.id} class="border border-gray-200 rounded-lg p-4 bg-white flex items-start justify-between gap-4">
              <div class="flex-1 min-w-0">
                <div class="font-semibold text-gray-900">${s.nome}</div>
                ${s.descricao && html`<div class="text-sm text-gray-600 mt-1">${s.descricao}</div>`}
              </div>
              <div class="text-right whitespace-nowrap">
                <div class="font-semibold text-gray-900">${formatBRL(s.valor_centavos)}</div>
                <div class="text-xs text-gray-500 mt-1">${formatDuracao(s.duracao_min)}</div>
              </div>
            </div>
          `)}
        </div>
      </section>
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// Admin — Profissionais
// ══════════════════════════════════════════════════════════════════════

const PROF_EMPTY = { nome: '', especialidade: '', email: '' };

// Mapeamento dia_semana → nome (0=segunda … 6=domingo, igual a Python weekday()).
const DIAS = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];

function AdminProfissionais({ apiBase }) {
  const [items, setItems] = useState([]);
  // horarios: { [profissional_id]: [{id, dia_semana, hora_inicio, hora_fim}] }
  const [horarios, setHorarios] = useState({});
  const [expandedId, setExpandedId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState('');
  const [form, setForm] = useState(PROF_EMPTY);
  const [editingId, setEditingId] = useState(null);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setErro('');
    try {
      // Carrega profissionais e horários em paralelo — evita N+1.
      const [profs, hors] = await Promise.all([
        apiJson(`${apiBase}/admin/profissionais`),
        apiJson(`${apiBase}/admin/horarios`),
      ]);
      setItems(profs);
      setHorarios(hors || {});
    } catch (e) {
      setErro(e.message);
    } finally {
      setLoading(false);
    }
  }, [apiBase]);

  useEffect(() => { load(); }, [load]);

  const resetForm = () => { setForm(PROF_EMPTY); setEditingId(null); };

  const startEdit = (p) => {
    setEditingId(p.id);
    setForm({ nome: p.nome, especialidade: p.especialidade || '', email: p.email || '' });
  };

  // Cria a agenda Google do profissional (1 clique). Recarrega a lista.
  const criarAgenda = async (id) => {
    setErro('');
    try {
      await apiJson(`${apiBase}/admin/profissionais/${id}/google-calendar`, { method: 'POST' });
      await load();
    } catch (e) {
      setErro(e.message);
    }
  };

  // Desvincula a agenda Google (não apaga no Google).
  const desvincularAgenda = async (id) => {
    if (!confirm('Desvincular a agenda Google deste profissional? Os agendamentos param de espelhar no Google (a agenda não é apagada).')) return;
    setErro('');
    try {
      await apiJson(`${apiBase}/admin/profissionais/${id}/google-calendar`, { method: 'DELETE' });
      await load();
    } catch (e) {
      setErro(e.message);
    }
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!form.nome.trim()) return;
    setSaving(true);
    setErro('');
    try {
      if (editingId) {
        await apiJson(`${apiBase}/admin/profissionais/${editingId}`, {
          method: 'PUT',
          body: JSON.stringify(form),
        });
      } else {
        await apiJson(`${apiBase}/admin/profissionais`, {
          method: 'POST',
          body: JSON.stringify(form),
        });
      }
      resetForm();
      await load();
    } catch (e) {
      setErro(e.message);
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (id) => {
    setErro('');
    try {
      await apiJson(`${apiBase}/admin/profissionais/${id}/toggle`, { method: 'POST' });
      await load();
    } catch (e) {
      setErro(e.message);
    }
  };

  // Atualiza a lista de horários de um profissional no estado local.
  // Chamado pelo HorarioEditor quando adiciona ou remove um bloco.
  const updateHorarios = (profId, lista) => {
    setHorarios((prev) => ({ ...prev, [String(profId)]: lista }));
  };

  return html`
    <div class="space-y-6">
      <!-- Formulário -->
      <form onSubmit=${submit} class="bg-white border border-gray-200 rounded-lg p-4 space-y-3">
        <h3 class="font-semibold text-gray-800">
          ${editingId ? 'Editar profissional' : 'Novo profissional'}
        </h3>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          <label class="block">
            <span class="text-sm text-gray-700">Nome *</span>
            <input
              type="text"
              required
              value=${form.nome}
              onInput=${e => setForm({ ...form, nome: e.target.value })}
              class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
              placeholder="Ex: Dra. Ana Souza"
            />
          </label>
          <label class="block">
            <span class="text-sm text-gray-700">Especialidade</span>
            <input
              type="text"
              value=${form.especialidade}
              onInput=${e => setForm({ ...form, especialidade: e.target.value })}
              class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
              placeholder="Ex: Estética facial"
            />
          </label>
          <label class="block md:col-span-2">
            <span class="text-sm text-gray-700">E-mail (Google Agenda)</span>
            <input
              type="email"
              value=${form.email}
              onInput=${e => setForm({ ...form, email: e.target.value })}
              class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
              placeholder="profissional@gmail.com"
            />
            <span class="text-xs text-gray-400">
              Usado para criar a agenda Google do profissional — ele recebe o e-mail de compartilhamento.
            </span>
          </label>
        </div>
        <div class="flex gap-2">
          <button
            type="submit"
            disabled=${saving}
            class="px-4 py-2 bg-blue-600 text-white rounded text-sm font-medium hover:bg-blue-700 disabled:opacity-50"
          >${editingId ? 'Salvar' : 'Criar'}</button>
          ${editingId && html`
            <button
              type="button"
              onClick=${resetForm}
              class="px-4 py-2 border border-gray-300 rounded text-sm font-medium text-gray-700 hover:bg-gray-50"
            >Cancelar</button>
          `}
        </div>
        ${erro && html`<div class="text-sm text-red-600">${erro}</div>`}
      </form>

      <!-- Listagem -->
      <div>
        <h3 class="font-semibold text-gray-800 mb-3">
          Todos os profissionais (${items.length})
        </h3>
        ${loading ? html`<div class="text-gray-500">Carregando...</div>` : html`
          <div class="border border-gray-200 rounded-lg overflow-hidden">
            <table class="w-full text-sm">
              <thead class="bg-gray-50 text-gray-600 text-left">
                <tr>
                  <th class="px-4 py-2">Nome</th>
                  <th class="px-4 py-2">Especialidade</th>
                  <th class="px-4 py-2">Horários</th>
                  <th class="px-4 py-2">Agenda Google</th>
                  <th class="px-4 py-2">Status</th>
                  <th class="px-4 py-2 text-right">Ações</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-100">
                ${items.length === 0 && html`
                  <tr><td colspan="6" class="px-4 py-6 text-center text-gray-400">
                    Nenhum profissional cadastrado.
                  </td></tr>
                `}
                ${items.map(p => {
                  const blocos = horarios[String(p.id)] || [];
                  const expanded = expandedId === p.id;
                  return html`
                    <tr key=${p.id} class=${p.ativo ? '' : 'bg-gray-50 text-gray-400'}>
                      <td class="px-4 py-2 font-medium">${p.nome}</td>
                      <td class="px-4 py-2">${p.especialidade || '—'}</td>
                      <td class="px-4 py-2">
                        <button
                          onClick=${() => setExpandedId(expanded ? null : p.id)}
                          class="text-sm text-gray-700 hover:underline"
                          title="Gerenciar horários deste profissional"
                        >${blocos.length} bloco${blocos.length !== 1 ? 's' : ''} ${expanded ? '▲' : '▼'}</button>
                      </td>
                      <td class="px-4 py-2">
                        ${p.google_calendar_id
                          ? html`
                            <span class="inline-flex items-center gap-1 px-2 py-0.5 text-xs rounded bg-emerald-100 text-emerald-800" title=${p.google_calendar_id}>📅 vinculada</span>
                            <button
                              onClick=${() => desvincularAgenda(p.id)}
                              class="ml-2 text-xs text-gray-500 hover:underline"
                            >desvincular</button>
                          `
                          : html`
                            <button
                              onClick=${() => criarAgenda(p.id)}
                              disabled=${!(p.email || '').trim()}
                              title=${(p.email || '').trim() ? 'Criar agenda Google e compartilhar com o profissional' : 'Cadastre o e-mail do profissional primeiro'}
                              class="text-xs px-2 py-1 border border-emerald-300 text-emerald-700 rounded hover:bg-emerald-50 disabled:opacity-40 disabled:cursor-not-allowed"
                            >Criar agenda Google</button>
                          `}
                      </td>
                      <td class="px-4 py-2">
                        ${p.ativo
                          ? html`<span class="inline-block px-2 py-0.5 text-xs rounded bg-green-100 text-green-800">ativo</span>`
                          : html`<span class="inline-block px-2 py-0.5 text-xs rounded bg-gray-200 text-gray-600">inativo</span>`}
                      </td>
                      <td class="px-4 py-2 text-right space-x-2">
                        <button
                          onClick=${() => startEdit(p)}
                          class="text-blue-600 hover:underline text-sm"
                        >Editar</button>
                        <button
                          onClick=${() => toggle(p.id)}
                          class="text-gray-600 hover:underline text-sm"
                        >${p.ativo ? 'Desativar' : 'Ativar'}</button>
                      </td>
                    </tr>
                    ${expanded && html`
                      <tr key=${`${p.id}-hor`} class="bg-indigo-50/40">
                        <td colspan="6" class="px-4 py-3">
                          <${HorarioEditor}
                            profissional=${p}
                            apiBase=${apiBase}
                            initialHorarios=${blocos}
                            onUpdate=${(lista) => updateHorarios(p.id, lista)}
                            onClose=${() => setExpandedId(null)}
                          />
                          <${BloqueioEditor}
                            profissional=${p}
                            apiBase=${apiBase}
                          />
                        </td>
                      </tr>
                    `}
                  `;
                })}
              </tbody>
            </table>
          </div>
        `}
      </div>
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// Admin — Serviços
// ══════════════════════════════════════════════════════════════════════

const SRV_EMPTY = { nome: '', descricao: '', duracao_min: 60, valor_reais: '' };

// O backend espera valor_centavos; a UI trabalha em reais (mais natural).
function formToBody(form) {
  const reais = parseFloat(String(form.valor_reais).replace(',', '.')) || 0;
  return {
    nome: form.nome,
    descricao: form.descricao,
    duracao_min: parseInt(form.duracao_min, 10) || 60,
    valor_centavos: Math.round(reais * 100),
  };
}

function AdminServicos({ apiBase }) {
  const [items, setItems] = useState([]);
  const [profissionais, setProfissionais] = useState([]);
  // matriz: { [servico_id]: [{profissional_id, valor_centavos}, ...] } — de /admin/vinculos
  // valor_centavos null = profissional herda o preço base do serviço.
  const [vinculos, setVinculos] = useState({});
  const [expandedId, setExpandedId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState('');
  const [form, setForm] = useState(SRV_EMPTY);
  const [editingId, setEditingId] = useState(null);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setErro('');
    try {
      // 3 requisições em paralelo: serviços, profissionais (pra montar checkboxes)
      // e a matriz inteira de vínculos.
      const [srv, prof, vinc] = await Promise.all([
        apiJson(`${apiBase}/admin/servicos`),
        apiJson(`${apiBase}/admin/profissionais`),
        apiJson(`${apiBase}/admin/vinculos`),
      ]);
      setItems(srv);
      setProfissionais(prof);
      setVinculos(vinc || {});
    } catch (e) {
      setErro(e.message);
    } finally {
      setLoading(false);
    }
  }, [apiBase]);

  useEffect(() => { load(); }, [load]);

  const resetForm = () => { setForm(SRV_EMPTY); setEditingId(null); };

  const startEdit = (s) => {
    setEditingId(s.id);
    setForm({
      nome: s.nome,
      descricao: s.descricao || '',
      duracao_min: s.duracao_min,
      valor_reais: (s.valor_centavos / 100).toFixed(2),
    });
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!form.nome.trim()) return;
    setSaving(true);
    setErro('');
    try {
      const body = formToBody(form);
      if (editingId) {
        await apiJson(`${apiBase}/admin/servicos/${editingId}`, {
          method: 'PUT',
          body: JSON.stringify(body),
        });
      } else {
        await apiJson(`${apiBase}/admin/servicos`, {
          method: 'POST',
          body: JSON.stringify(body),
        });
      }
      resetForm();
      await load();
    } catch (e) {
      setErro(e.message);
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (id) => {
    setErro('');
    try {
      await apiJson(`${apiBase}/admin/servicos/${id}/toggle`, { method: 'POST' });
      await load();
    } catch (e) {
      setErro(e.message);
    }
  };

  // Salva o conjunto de profissionais vinculados ao serviço, com preço por
  // profissional. Backend faz "replace all" — mandamos a lista inteira da UI.
  // `vinc` = [{ profissional_id, valor_centavos|null }] (null = herda o base).
  const saveVinculos = async (srvId, vinc) => {
    setErro('');
    try {
      await apiJson(`${apiBase}/admin/servicos/${srvId}/profissionais`, {
        method: 'PUT',
        body: JSON.stringify({ vinculos: vinc }),
      });
      setVinculos((v) => ({
        ...v,
        [srvId]: [...vinc].sort((a, b) => a.profissional_id - b.profissional_id),
      }));
      setExpandedId(null);
    } catch (e) {
      setErro(e.message);
    }
  };

  return html`
    <div class="space-y-6">
      <!-- Formulário -->
      <form onSubmit=${submit} class="bg-white border border-gray-200 rounded-lg p-4 space-y-3">
        <h3 class="font-semibold text-gray-800">
          ${editingId ? 'Editar serviço' : 'Novo serviço'}
        </h3>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          <label class="block md:col-span-2">
            <span class="text-sm text-gray-700">Nome *</span>
            <input
              type="text"
              required
              value=${form.nome}
              onInput=${e => setForm({ ...form, nome: e.target.value })}
              class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
              placeholder="Ex: Limpeza de pele"
            />
          </label>
          <label class="block md:col-span-2">
            <span class="text-sm text-gray-700">Descrição</span>
            <textarea
              value=${form.descricao}
              onInput=${e => setForm({ ...form, descricao: e.target.value })}
              rows="2"
              class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
              placeholder="Detalhes do serviço"
            ></textarea>
          </label>
          <label class="block">
            <span class="text-sm text-gray-700">Duração (minutos) *</span>
            <input
              type="number"
              min="5" max="600" step="5"
              required
              value=${form.duracao_min}
              onInput=${e => setForm({ ...form, duracao_min: e.target.value })}
              class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
            />
          </label>
          <label class="block">
            <span class="text-sm text-gray-700">Valor (R$) *</span>
            <input
              type="text"
              required
              value=${form.valor_reais}
              onInput=${e => setForm({ ...form, valor_reais: e.target.value })}
              class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
              placeholder="Ex: 150.00"
            />
          </label>
        </div>
        <div class="flex gap-2">
          <button
            type="submit"
            disabled=${saving}
            class="px-4 py-2 bg-blue-600 text-white rounded text-sm font-medium hover:bg-blue-700 disabled:opacity-50"
          >${editingId ? 'Salvar' : 'Criar'}</button>
          ${editingId && html`
            <button
              type="button"
              onClick=${resetForm}
              class="px-4 py-2 border border-gray-300 rounded text-sm font-medium text-gray-700 hover:bg-gray-50"
            >Cancelar</button>
          `}
        </div>
        ${erro && html`<div class="text-sm text-red-600">${erro}</div>`}
      </form>

      <!-- Listagem -->
      <div>
        <h3 class="font-semibold text-gray-800 mb-3">
          Todos os serviços (${items.length})
        </h3>
        ${loading ? html`<div class="text-gray-500">Carregando...</div>` : html`
          <div class="border border-gray-200 rounded-lg overflow-hidden">
            <table class="w-full text-sm">
              <thead class="bg-gray-50 text-gray-600 text-left">
                <tr>
                  <th class="px-4 py-2">Nome</th>
                  <th class="px-4 py-2">Duração</th>
                  <th class="px-4 py-2">Valor</th>
                  <th class="px-4 py-2">Profissionais</th>
                  <th class="px-4 py-2">Status</th>
                  <th class="px-4 py-2 text-right">Ações</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-100">
                ${items.length === 0 && html`
                  <tr><td colspan="6" class="px-4 py-6 text-center text-gray-400">
                    Nenhum serviço cadastrado.
                  </td></tr>
                `}
                ${items.map(s => {
                  const ligados = vinculos[String(s.id)] || [];
                  const expanded = expandedId === s.id;
                  // Faixa de preço resolvida (override ?? base) para um resumo na coluna.
                  const precosResolvidos = ligados.map(
                    v => (v.valor_centavos == null ? s.valor_centavos : v.valor_centavos)
                  );
                  const precoMin = precosResolvidos.length ? Math.min(...precosResolvidos) : null;
                  const precoMax = precosResolvidos.length ? Math.max(...precosResolvidos) : null;
                  const faixaLabel = precoMin == null
                    ? ''
                    : (precoMin === precoMax ? formatBRL(precoMin) : `${formatBRL(precoMin)}–${formatBRL(precoMax)}`);
                  return html`
                    <tr key=${s.id} class=${s.ativo ? '' : 'bg-gray-50 text-gray-400'}>
                      <td class="px-4 py-2">
                        <div class="font-medium">${s.nome}</div>
                        ${s.descricao && html`
                          <div class="text-xs text-gray-500 truncate max-w-md">${s.descricao}</div>
                        `}
                      </td>
                      <td class="px-4 py-2">${formatDuracao(s.duracao_min)}</td>
                      <td class="px-4 py-2">${formatBRL(s.valor_centavos)}</td>
                      <td class="px-4 py-2">
                        <button
                          onClick=${() => setExpandedId(expanded ? null : s.id)}
                          class="text-sm text-gray-700 hover:underline"
                          title="Gerenciar profissionais e preços deste serviço"
                        >${ligados.length} de ${profissionais.length} ${expanded ? '▲' : '▼'}</button>
                        ${faixaLabel && html`
                          <div class="text-xs text-gray-500">${faixaLabel}</div>
                        `}
                      </td>
                      <td class="px-4 py-2">
                        ${s.ativo
                          ? html`<span class="inline-block px-2 py-0.5 text-xs rounded bg-green-100 text-green-800">ativo</span>`
                          : html`<span class="inline-block px-2 py-0.5 text-xs rounded bg-gray-200 text-gray-600">inativo</span>`}
                      </td>
                      <td class="px-4 py-2 text-right space-x-2">
                        <button
                          onClick=${() => startEdit(s)}
                          class="text-blue-600 hover:underline text-sm"
                        >Editar</button>
                        <button
                          onClick=${() => toggle(s.id)}
                          class="text-gray-600 hover:underline text-sm"
                        >${s.ativo ? 'Desativar' : 'Ativar'}</button>
                      </td>
                    </tr>
                    ${expanded && html`
                      <tr key=${`${s.id}-vinc`} class="bg-blue-50/50">
                        <td colspan="6" class="px-4 py-3">
                          <${VinculoEditor}
                            servico=${s}
                            profissionais=${profissionais}
                            iniciais=${ligados}
                            onSave=${(vinc) => saveVinculos(s.id, vinc)}
                            onCancel=${() => setExpandedId(null)}
                          />
                        </td>
                      </tr>
                    `}
                  `;
                })}
              </tbody>
            </table>
          </div>
        `}
      </div>
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// Editor de horários de atendimento (Etapa 4)
//
// Recebe a lista atual via `initialHorarios` e gerencia o estado local.
// Adiciona blocos via POST e remove via DELETE. Levanta mudanças para o
// pai através de `onUpdate(listaAtualizada)` após cada operação — evita
// recarregar a tabela inteira de profissionais.
// ══════════════════════════════════════════════════════════════════════

const HORARIO_EMPTY = { dia_semana: 0, hora_inicio: '09:00', hora_fim: '18:00' };

function HorarioEditor({ profissional, apiBase, initialHorarios, onUpdate, onClose }) {
  const [horarios, setHorarios] = useState(initialHorarios || []);
  const [form, setForm] = useState(HORARIO_EMPTY);
  const [saving, setSaving] = useState(false);
  const [erro, setErro] = useState('');

  // Agrupa os blocos por dia para exibição.
  const grouped = DIAS.map((nome, idx) => ({
    nome,
    idx,
    items: horarios.filter(h => h.dia_semana === idx),
  })).filter(d => d.items.length > 0);

  const add = async (e) => {
    e.preventDefault();
    if (form.hora_fim <= form.hora_inicio) {
      setErro('O horário de fim deve ser maior que o de início.');
      return;
    }
    setSaving(true);
    setErro('');
    try {
      const novo = await apiJson(
        `${apiBase}/admin/profissionais/${profissional.id}/horarios`,
        { method: 'POST', body: JSON.stringify(form) },
      );
      const atualizado = [...horarios, novo].sort(
        (a, b) => a.dia_semana - b.dia_semana || a.hora_inicio.localeCompare(b.hora_inicio),
      );
      setHorarios(atualizado);
      onUpdate(atualizado);
      setForm(HORARIO_EMPTY);
    } catch (e) {
      setErro(e.message);
    } finally {
      setSaving(false);
    }
  };

  const del = async (id) => {
    setErro('');
    try {
      await apiJson(`${apiBase}/admin/horarios/${id}`, { method: 'DELETE' });
      const atualizado = horarios.filter(h => h.id !== id);
      setHorarios(atualizado);
      onUpdate(atualizado);
    } catch (e) {
      setErro(e.message);
    }
  };

  return html`
    <div class="space-y-4">
      <div class="text-sm font-medium text-gray-700">
        Horários de <span class="text-gray-900">${profissional.nome}</span>
      </div>

      <!-- Blocos existentes, agrupados por dia -->
      ${grouped.length === 0
        ? html`<div class="text-sm text-gray-400 italic">Nenhum horário cadastrado.</div>`
        : html`
          <div class="flex flex-wrap gap-2">
            ${grouped.map(d => html`
              <div key=${d.idx} class="bg-white border border-gray-200 rounded-lg px-3 py-2 min-w-[110px]">
                <div class="text-xs font-semibold text-indigo-700 mb-1">${d.nome}</div>
                ${d.items.map(h => html`
                  <div key=${h.id} class="flex items-center justify-between gap-2 text-xs text-gray-800">
                    <span>${h.hora_inicio}–${h.hora_fim}</span>
                    <button
                      type="button"
                      onClick=${() => del(h.id)}
                      class="text-red-400 hover:text-red-600 leading-none"
                      title="Remover este bloco"
                    >✕</button>
                  </div>
                `)}
              </div>
            `)}
          </div>
        `}

      <!-- Formulário para adicionar novo bloco -->
      <form onSubmit=${add} class="flex flex-wrap items-end gap-3 pt-1">
        <label class="block">
          <span class="text-xs text-gray-600">Dia da semana</span>
          <select
            value=${form.dia_semana}
            onChange=${e => setForm({ ...form, dia_semana: parseInt(e.target.value, 10) })}
            class="mt-1 block border border-gray-300 rounded px-2 py-1.5 text-sm"
          >
            ${DIAS.map((d, i) => html`
              <option key=${i} value=${i}>${d}</option>
            `)}
          </select>
        </label>
        <label class="block">
          <span class="text-xs text-gray-600">Início</span>
          <input
            type="time"
            required
            value=${form.hora_inicio}
            onInput=${e => setForm({ ...form, hora_inicio: e.target.value })}
            class="mt-1 block border border-gray-300 rounded px-2 py-1.5 text-sm"
          />
        </label>
        <label class="block">
          <span class="text-xs text-gray-600">Fim</span>
          <input
            type="time"
            required
            value=${form.hora_fim}
            onInput=${e => setForm({ ...form, hora_fim: e.target.value })}
            class="mt-1 block border border-gray-300 rounded px-2 py-1.5 text-sm"
          />
        </label>
        <button
          type="submit"
          disabled=${saving}
          class="px-3 py-1.5 bg-indigo-600 text-white rounded text-sm font-medium hover:bg-indigo-700 disabled:opacity-50"
        >${saving ? 'Salvando...' : '+ Adicionar'}</button>
      </form>

      ${erro && html`<div class="text-sm text-red-600">${erro}</div>`}

      <div class="pt-1">
        <button
          type="button"
          onClick=${onClose}
          class="px-4 py-1.5 border border-gray-300 rounded text-sm font-medium text-gray-700 hover:bg-gray-50"
        >Fechar</button>
      </div>
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// Editor de bloqueios de agenda (docs/bloqueios-agenda.md — Etapa 3)
//
// Tranca a agenda do profissional num período: dia inteiro OU faixa de
// horário, pontual (1 dia) ou intervalo de datas. Bloqueios origem='google'
// vêm de eventos criados direto na agenda Google do profissional e são
// só-leitura aqui (a fonte é o Google).
// ══════════════════════════════════════════════════════════════════════

function bloqueioEmpty() {
  const hoje = new Date().toISOString().slice(0, 10);
  return {
    dia_inteiro: true,
    data_inicio: hoje,
    data_fim: hoje,
    hora_inicio: '12:00',
    hora_fim: '13:00',
    motivo: '',
  };
}

function fmtDataBR(iso) {
  if (!iso) return '';
  const [y, m, d] = String(iso).split('-');
  return `${d}/${m}/${y}`;
}

function descreveBloqueio(b) {
  const periodo = b.data_inicio === b.data_fim
    ? fmtDataBR(b.data_inicio)
    : `${fmtDataBR(b.data_inicio)} a ${fmtDataBR(b.data_fim)}`;
  const faixa = b.dia_inteiro ? 'dia inteiro' : `${b.hora_inicio}–${b.hora_fim}`;
  return `${periodo} · ${faixa}`;
}

function BloqueioEditor({ profissional, apiBase }) {
  const [bloqueios, setBloqueios] = useState([]);
  const [form, setForm] = useState(bloqueioEmpty);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [erro, setErro] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setErro('');
    try {
      const lista = await apiJson(
        `${apiBase}/admin/profissionais/${profissional.id}/bloqueios`,
      );
      setBloqueios(lista || []);
    } catch (e) {
      setErro(e.message);
    } finally {
      setLoading(false);
    }
  }, [apiBase, profissional.id]);

  useEffect(() => { load(); }, [load]);

  const add = async (e) => {
    e.preventDefault();
    if (form.data_fim < form.data_inicio) {
      setErro('A data final deve ser maior ou igual à inicial.');
      return;
    }
    if (!form.dia_inteiro && form.hora_fim <= form.hora_inicio) {
      setErro('A hora de fim deve ser maior que a de início.');
      return;
    }
    setSaving(true);
    setErro('');
    try {
      const body = {
        data_inicio: form.data_inicio,
        data_fim: form.data_fim,
        dia_inteiro: form.dia_inteiro,
        motivo: form.motivo,
      };
      if (!form.dia_inteiro) {
        body.hora_inicio = form.hora_inicio;
        body.hora_fim = form.hora_fim;
      }
      await apiJson(
        `${apiBase}/admin/profissionais/${profissional.id}/bloqueios`,
        { method: 'POST', body: JSON.stringify(body) },
      );
      setForm(bloqueioEmpty());
      await load();
    } catch (e) {
      setErro(e.message);
    } finally {
      setSaving(false);
    }
  };

  const del = async (id) => {
    setErro('');
    try {
      await apiJson(`${apiBase}/admin/bloqueios/${id}`, { method: 'DELETE' });
      setBloqueios((b) => b.filter((x) => x.id !== id));
    } catch (e) {
      setErro(e.message);
    }
  };

  return html`
    <div class="space-y-4 border-t border-indigo-100 pt-4">
      <div class="text-sm font-medium text-gray-700">
        Bloqueios de agenda de <span class="text-gray-900">${profissional.nome}</span>
        <span class="text-xs text-gray-400 font-normal">— viagem, consulta, compromisso pessoal…</span>
      </div>

      <!-- Bloqueios existentes -->
      ${loading
        ? html`<div class="text-sm text-gray-400 italic">Carregando…</div>`
        : bloqueios.length === 0
          ? html`<div class="text-sm text-gray-400 italic">Nenhum bloqueio cadastrado.</div>`
          : html`
            <div class="flex flex-col gap-1.5">
              ${bloqueios.map((b) => html`
                <div key=${b.id} class="flex items-center justify-between gap-3 bg-white border border-gray-200 rounded-lg px-3 py-2 text-sm">
                  <div class="min-w-0">
                    <div class="text-gray-800">${descreveBloqueio(b)}</div>
                    <div class="text-xs text-gray-500 truncate">
                      ${b.motivo || 'sem motivo'}
                      ${b.origem === 'google'
                        ? html`<span class="ml-1 inline-block px-1.5 py-0.5 rounded bg-amber-100 text-amber-700 text-[10px] font-medium">Google</span>`
                        : html`<span class="ml-1 inline-block px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-700 text-[10px] font-medium">clínica</span>`}
                    </div>
                  </div>
                  ${b.origem === 'google'
                    ? html`<span class="text-xs text-gray-400 italic shrink-0" title="Bloqueio criado na agenda Google — remova o evento por lá">só-leitura</span>`
                    : html`<button
                        type="button"
                        onClick=${() => del(b.id)}
                        class="text-red-400 hover:text-red-600 text-sm shrink-0"
                        title="Remover bloqueio"
                      >Remover</button>`}
                </div>
              `)}
            </div>
          `}

      <!-- Formulário para adicionar bloqueio -->
      <form onSubmit=${add} class="flex flex-wrap items-end gap-3 pt-1">
        <label class="block">
          <span class="text-xs text-gray-600">Tipo</span>
          <select
            value=${form.dia_inteiro ? 'dia' : 'faixa'}
            onChange=${e => setForm({ ...form, dia_inteiro: e.target.value === 'dia' })}
            class="mt-1 block border border-gray-300 rounded px-2 py-1.5 text-sm"
          >
            <option value="dia">Dia inteiro</option>
            <option value="faixa">Faixa de horário</option>
          </select>
        </label>
        <label class="block">
          <span class="text-xs text-gray-600">Data início</span>
          <input
            type="date"
            required
            value=${form.data_inicio}
            onInput=${e => setForm({ ...form, data_inicio: e.target.value })}
            class="mt-1 block border border-gray-300 rounded px-2 py-1.5 text-sm"
          />
        </label>
        <label class="block">
          <span class="text-xs text-gray-600">Data fim</span>
          <input
            type="date"
            required
            value=${form.data_fim}
            onInput=${e => setForm({ ...form, data_fim: e.target.value })}
            class="mt-1 block border border-gray-300 rounded px-2 py-1.5 text-sm"
          />
        </label>
        ${!form.dia_inteiro && html`
          <label class="block">
            <span class="text-xs text-gray-600">Início</span>
            <input
              type="time"
              required
              value=${form.hora_inicio}
              onInput=${e => setForm({ ...form, hora_inicio: e.target.value })}
              class="mt-1 block border border-gray-300 rounded px-2 py-1.5 text-sm"
            />
          </label>
          <label class="block">
            <span class="text-xs text-gray-600">Fim</span>
            <input
              type="time"
              required
              value=${form.hora_fim}
              onInput=${e => setForm({ ...form, hora_fim: e.target.value })}
              class="mt-1 block border border-gray-300 rounded px-2 py-1.5 text-sm"
            />
          </label>
        `}
        <label class="block grow min-w-[160px]">
          <span class="text-xs text-gray-600">Motivo</span>
          <input
            type="text"
            value=${form.motivo}
            onInput=${e => setForm({ ...form, motivo: e.target.value })}
            class="mt-1 block w-full border border-gray-300 rounded px-2 py-1.5 text-sm"
            placeholder="Ex: viagem, consulta médica…"
          />
        </label>
        <button
          type="submit"
          disabled=${saving}
          class="px-3 py-1.5 bg-indigo-600 text-white rounded text-sm font-medium hover:bg-indigo-700 disabled:opacity-50"
        >${saving ? 'Salvando...' : '+ Bloquear'}</button>
      </form>

      ${erro && html`<div class="text-sm text-red-600">${erro}</div>`}
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// Editor de vínculos serviço ↔ profissional (Etapa 3 + preço por profissional)
//
// Recebe os vínculos atuais (`iniciais` = [{profissional_id, valor_centavos}])
// e devolve os novos via `onSave([{profissional_id, valor_centavos|null}])`.
// Cada profissional marcado pode ter um preço próprio; campo vazio = herda o
// preço base do serviço. O componente pai faz o PUT e atualiza a matriz local.
// Estado local guarda os toggles/preços pendentes para permitir cancelamento.
// ══════════════════════════════════════════════════════════════════════

// Mantém só dígitos e um separador decimal (normaliza vírgula→ponto), no
// máximo 2 casas. Bloqueia letras/espaços/símbolos enquanto o usuário digita.
function sanitizePreco(raw) {
  let s = String(raw).replace(/,/g, '.').replace(/[^\d.]/g, '');
  const firstDot = s.indexOf('.');
  if (firstDot !== -1) {
    const intPart = s.slice(0, firstDot);
    const decPart = s.slice(firstDot + 1).replace(/\./g, '').slice(0, 2);
    s = `${intPart}.${decPart}`;
  }
  return s;
}

function VinculoEditor({ servico, profissionais, iniciais, onSave, onCancel }) {
  // Map profissional_id -> preço override em reais (string). A presença da
  // chave indica que o profissional está marcado; '' = herda o preço base.
  const [selected, setSelected] = useState(() => {
    const m = new Map();
    for (const v of iniciais) {
      m.set(
        v.profissional_id,
        v.valor_centavos == null ? '' : (v.valor_centavos / 100).toFixed(2),
      );
    }
    return m;
  });
  const [saving, setSaving] = useState(false);

  const toggle = (id) => {
    setSelected((prev) => {
      const next = new Map(prev);
      if (next.has(id)) next.delete(id); else next.set(id, '');
      return next;
    });
  };

  const setPreco = (id, val) => {
    setSelected((prev) => {
      const next = new Map(prev);
      if (next.has(id)) next.set(id, sanitizePreco(val));
      return next;
    });
  };

  const submit = async () => {
    setSaving(true);
    try {
      const vinc = [...selected.entries()].map(([pid, reais]) => {
        const trimmed = String(reais).trim();
        let cents = null;
        if (trimmed !== '') {
          const parsed = parseFloat(trimmed.replace(',', '.'));
          if (!Number.isNaN(parsed)) cents = Math.round(parsed * 100);
        }
        return { profissional_id: pid, valor_centavos: cents };
      });
      await onSave(vinc);
    } finally {
      setSaving(false);
    }
  };

  if (profissionais.length === 0) {
    return html`
      <div class="text-sm text-gray-500">
        Cadastre profissionais na aba "Profissionais" para vinculá-los a este serviço.
      </div>
    `;
  }

  const baseLabel = formatBRL(servico.valor_centavos);

  return html`
    <div class="space-y-3">
      <div class="text-sm text-gray-700 font-medium">
        Quem atende <span class="text-gray-900">${servico.nome}</span>?
      </div>
      <div class="text-xs text-gray-500">
        Preço por profissional — deixe em branco para usar o preço base do serviço (${baseLabel}).
      </div>
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
        ${profissionais.map((p) => {
          const marcado = selected.has(p.id);
          return html`
          <div
            key=${p.id}
            class=${`flex items-start gap-2 px-3 py-2 border rounded text-sm ${
              marcado
                ? 'border-blue-400 bg-white'
                : 'border-gray-200 bg-white hover:border-gray-300'
            } ${p.ativo ? '' : 'opacity-60'}`}
          >
            <input
              type="checkbox"
              class="mt-1"
              checked=${marcado}
              onChange=${() => toggle(p.id)}
            />
            <div class="flex-1 min-w-0">
              <label class="block cursor-pointer" onClick=${() => toggle(p.id)}>
                <span class="block font-medium text-gray-800 truncate">${p.nome}</span>
                ${p.especialidade && html`
                  <span class="block text-xs text-gray-500 truncate">${p.especialidade}</span>
                `}
                ${!p.ativo && html`<span class="text-xs text-gray-400">inativo</span>`}
              </label>
              ${marcado && html`
                <div class="mt-1.5 flex items-center gap-1">
                  <span class="text-xs text-gray-500">R$</span>
                  <input
                    type="text"
                    inputmode="decimal"
                    value=${selected.get(p.id)}
                    placeholder=${(servico.valor_centavos / 100).toFixed(2)}
                    onInput=${(e) => setPreco(p.id, e.target.value)}
                    class="w-24 px-2 py-1 border border-gray-300 rounded text-sm"
                  />
                </div>
              `}
            </div>
          </div>
        `;
        })}
      </div>
      <div class="flex gap-2 pt-1">
        <button
          type="button"
          onClick=${submit}
          disabled=${saving}
          class="px-4 py-1.5 bg-blue-600 text-white rounded text-sm font-medium hover:bg-blue-700 disabled:opacity-50"
        >${saving ? 'Salvando...' : 'Salvar vínculos'}</button>
        <button
          type="button"
          onClick=${onCancel}
          class="px-4 py-1.5 border border-gray-300 rounded text-sm font-medium text-gray-700 hover:bg-gray-50"
        >Cancelar</button>
      </div>
    </div>
  `;
}

// ══════════════════════════════════════════════════════════════════════
// Slots Preview (Etapa 5)
//
// Permite testar o endpoint GET /servicos/{id}/slots?data=YYYY-MM-DD:
// escolhe serviço + data → mostra os horários disponíveis por profissional.
// É o "olho" da Etapa 5 — a tela pública usa o mesmo endpoint na Etapa 6.
// ══════════════════════════════════════════════════════════════════════

// Default = hoje no fuso local, formato YYYY-MM-DD (input type="date" usa esse formato).
function hojeISO() {
  const d = new Date();
  const off = d.getTimezoneOffset();
  const local = new Date(d.getTime() - off * 60 * 1000);
  return local.toISOString().slice(0, 10);
}

function SlotsPreview({ apiBase }) {
  const [servicos, setServicos] = useState([]);
  const [servicoId, setServicoId] = useState('');
  const [data, setData] = useState(hojeISO());
  const [resultado, setResultado] = useState(null);
  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState('');

  // Carrega a lista de serviços ativos uma vez para o select.
  useEffect(() => {
    (async () => {
      try {
        const srv = await apiJson(`${apiBase}/servicos`);
        setServicos(srv);
        if (srv.length > 0) setServicoId(String(srv[0].id));
      } catch (e) {
        setErro(e.message);
      }
    })();
  }, [apiBase]);

  const consultar = async (e) => {
    e?.preventDefault?.();
    if (!servicoId) { setErro('Escolha um serviço.'); return; }
    setLoading(true);
    setErro('');
    setResultado(null);
    try {
      const r = await apiJson(`${apiBase}/servicos/${servicoId}/slots?data=${data}`);
      setResultado(r);
    } catch (e) {
      setErro(e.message);
    } finally {
      setLoading(false);
    }
  };

  return html`
    <div class="space-y-6">
      <form onSubmit=${consultar} class="bg-white border border-gray-200 rounded-lg p-4 space-y-3">
        <h3 class="font-semibold text-gray-800">Consultar horários disponíveis</h3>
        <p class="text-xs text-gray-500">
          Escolha um serviço e uma data: o sistema cruza a duração do serviço com
          os horários dos profissionais aptos e mostra os encaixes possíveis.
        </p>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
          <label class="block md:col-span-2">
            <span class="text-sm text-gray-700">Serviço</span>
            <select
              value=${servicoId}
              onChange=${e => setServicoId(e.target.value)}
              class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
            >
              ${servicos.length === 0 && html`<option value="">Nenhum serviço ativo</option>`}
              ${servicos.map(s => html`
                <option key=${s.id} value=${s.id}>
                  ${s.nome} — ${formatDuracao(s.duracao_min)} — ${formatBRL(s.valor_centavos)}
                </option>
              `)}
            </select>
          </label>
          <label class="block">
            <span class="text-sm text-gray-700">Data</span>
            <input
              type="date"
              required
              value=${data}
              min=${hojeISO()}
              onInput=${e => setData(e.target.value)}
              class="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-sm"
            />
          </label>
        </div>
        <div>
          <button
            type="submit"
            disabled=${loading || !servicoId}
            class="px-4 py-2 bg-blue-600 text-white rounded text-sm font-medium hover:bg-blue-700 disabled:opacity-50"
          >${loading ? 'Calculando...' : 'Calcular slots'}</button>
        </div>
        ${erro && html`<div class="text-sm text-red-600">${erro}</div>`}
      </form>

      ${resultado && html`<${SlotsResultado} resultado=${resultado} />`}
    </div>
  `;
}

function SlotsResultado({ resultado }) {
  const { data, dia_semana, servico, profissionais } = resultado;
  const profs = profissionais || [];

  return html`
    <section class="space-y-3">
      <div class="text-sm text-gray-600">
        <span class="font-semibold text-gray-800">${servico.nome}</span>
        · ${DIAS[dia_semana]}, ${data}
        · duração ${formatDuracao(servico.duracao_min)}
      </div>
      ${profs.length === 0
        ? html`
          <div class="border border-gray-200 rounded-lg p-6 text-center text-gray-500 text-sm bg-gray-50">
            Nenhum profissional disponível para esta combinação.
            <div class="text-xs text-gray-400 mt-1">
              Verifique se há profissionais ativos vinculados ao serviço com
              blocos de horário cadastrados para ${DIAS[dia_semana].toLowerCase()}.
            </div>
          </div>
        `
        : html`
          <div class="space-y-3">
            ${profs.map(p => html`
              <div key=${p.id} class="border border-gray-200 rounded-lg p-4 bg-white">
                <div class="flex items-baseline justify-between gap-3 mb-3">
                  <div>
                    <div class="font-semibold text-gray-900">${p.nome}</div>
                    ${p.especialidade && html`
                      <div class="text-xs text-gray-500">${p.especialidade}</div>
                    `}
                  </div>
                  <div class="text-xs text-gray-500">
                    ${p.slots.length} horário${p.slots.length !== 1 ? 's' : ''}
                  </div>
                </div>
                <div class="flex flex-wrap gap-2">
                  ${p.slots.map(s => html`
                    <span
                      key=${s}
                      class="px-3 py-1 bg-blue-50 border border-blue-200 text-blue-800 rounded text-sm font-mono"
                    >${s}</span>
                  `)}
                </div>
              </div>
            `)}
          </div>
        `}
    </section>
  `;
}

