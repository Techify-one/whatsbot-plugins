from pydantic import BaseModel, Field


class Settings(BaseModel):
    mp_public_key: str = Field(
        default="",
        title="MP Public Key",
        description=(
            "Mercado Pago Public Key (APP_USR-...). "
            "Usada pelo frontend para inicializar o SDK e tokenizar cartões. "
            "Pode ficar visível — é segura para o navegador."
        ),
    )
    mp_access_token: str = Field(
        default="",
        title="MP Access Token",
        description=(
            "Mercado Pago Access Token (APP_USR-...). "
            "Nunca exposta no frontend. "
            "Em desenvolvimento use as credenciais de TESTE do painel MP."
        ),
    )
    mp_webhook_secret: str = Field(
        default="",
        title="MP Webhook — Assinatura secreta",
        description=(
            "Opcional. Cole aqui a 'Assinatura secreta' gerada no painel do "
            "Mercado Pago (Notificações → Webhooks). Se preenchida, o WhatsBot "
            "valida o header x-signature de cada notificação (HMAC-SHA256). "
            "Vazio = validação desligada (aceita qualquer POST na rota do "
            "webhook). A URL a cadastrar no MP é "
            "https://SEU_DOMINIO/api/plugins/clinica/webhook-mp"
        ),
    )
    lembrete_hora: str = Field(
        default="09:00",
        pattern=r"^\d{2}:\d{2}$",
        title="Horário do lembrete (HH:MM)",
        description=(
            "Hora em que o sistema dispara o lembrete WhatsApp para "
            "agendamentos do dia seguinte. Formato 24h, ex: 09:00. "
            "O envio respeita o horário comercial — só dispara entre "
            "esse horário e as 18:00. Se o servidor estiver fora do ar "
            "no horário marcado, envia assim que voltar dentro da janela."
        ),
    )
    lembrete_intervalo_min: int = Field(
        default=1,
        ge=1,
        le=60,
        title="Intervalo entre lembretes (minutos)",
        description=(
            "Minutos de espera entre o envio de um lembrete e o próximo. "
            "Evita que o WhatsApp bloqueie o número por excesso de "
            "mensagens em sequência. Default 1 — cada cliente recebe seu "
            "lembrete espaçado em 1 minuto do anterior."
        ),
    )
    clinic_email: str = Field(
        default="",
        title="E-mail da clínica (Google Agenda)",
        description=(
            "E-mail que receberá acesso de leitura a TODAS as agendas Google "
            "criadas para os profissionais (visibilidade central da clínica). "
            "Ao criar a agenda de um profissional, ela é compartilhada com este "
            "e-mail como leitor. Vazio = não compartilha com a clínica (cada "
            "agenda fica visível só para o próprio profissional)."
        ),
    )
    clinic_notify_phone: str = Field(
        default="",
        title="WhatsApp de avisos da clínica",
        description=(
            "Número (com DDD, ex: 11999990000) que recebe um aviso no WhatsApp "
            "quando um profissional cancela um agendamento direto no Google "
            "Agenda. Vazio = sem aviso por WhatsApp (o cancelamento ainda "
            "aparece no painel em tempo real)."
        ),
    )
    base_url: str = Field(
        default="",
        title="URL pública do WhatsBot",
        description=(
            "URL base usada pela IA ao enviar o link de agendamento via "
            "WhatsApp. Deve ser uma URL absoluta SEM barra final — ex: "
            "https://clinica.exemplo.com. Em desenvolvimento pode usar "
            "http://127.0.0.1:8080. Se ficar vazia, a tool "
            "enviar_link_agendamento avisa o LLM que o link ainda não "
            "está configurado."
        ),
    )
