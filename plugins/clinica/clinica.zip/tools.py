"""Tools do plugin Clínica para o agente LLM.

Etapa 12 do roadmap: permite ao assistente do WhatsBot responder perguntas
sobre os agendamentos do próprio contato consultando ``plugin_clinica_agendamentos``
diretamente — sem precisar passar pelo painel admin.

A tool ``consultar_agendamentos`` faz match pelo telefone do contato (mesmo se
o cliente cadastrou com/sem DDI 55, ou com formatação) e devolve uma resposta
pronta para o LLM repetir ao usuário.
"""

from __future__ import annotations

import json
import logging
import secrets
import time
from datetime import date, datetime, timedelta

from fastapi import HTTPException
from sqlalchemy import text

from plugins.context import make_plugin_db

logger = logging.getLogger(__name__)


# Validade do token de convite (em segundos). 7 dias é tempo confortável
# para o cliente decidir agendar sem o link "envelhecer demais".
CONVITE_TTL_SECONDS = 7 * 24 * 60 * 60


# ──────────────────────────────────────────────────────────────────────────
# Schema da tool — descrição é a versão default; o admin pode customizar via
# tela /tools (sem precisar mexer no código).
# ──────────────────────────────────────────────────────────────────────────


CONSULTAR_AGENDAMENTOS_TOOL = {
    "type": "function",
    "display_label": "Consultar Agendamentos (Clínica)",
    "function": {
        "name": "consultar_agendamentos",
        "description": (
            "Consulta os agendamentos do CONTATO ATUAL na Clínica Vida Leve. "
            "Use SEMPRE que o usuário perguntar sobre as próprias consultas — "
            "por exemplo: 'que horas é minha consulta?', 'tenho algo marcado?', "
            "'qual o meu próximo agendamento?', 'cancelei a sessão?', "
            "'me confirma o horário de amanhã'. "
            "NÃO use para informações gerais (preços, horário da clínica) — "
            "isso é catálogo público. "
            "A tool retorna uma resposta pronta em português; repita ao usuário "
            "EXATAMENTE como veio, sem inventar dados."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "escopo": {
                    "type": "string",
                    "enum": ["proximos", "todos", "historico"],
                    "description": (
                        "'proximos' (default) = agendamentos confirmados/pendentes "
                        "a partir de hoje. 'historico' = agendamentos passados ou "
                        "cancelados. 'todos' = tudo."
                    ),
                },
            },
            "required": [],
        },
    },
}


# ──────────────────────────────────────────────────────────────────────────
# Helpers de telefone — mesmo problema do _format_phone_br em routes.py:
# o contato pode estar cadastrado em ``contacts.phone`` como 5511999990000
# (com DDI) e na ``plugin_clinica_agendamentos.cliente_telefone`` como
# 11999990000 (sem DDI) — ou vice-versa. Comparamos os últimos 10 dígitos
# (DDD + 8 ou 9), suficiente pra evitar falso positivo em demo didática.
# ──────────────────────────────────────────────────────────────────────────


def _only_digits(value: str) -> str:
    return "".join(ch for ch in (value or "") if ch.isdigit())


def _phone_tail(value: str, length: int = 10) -> str:
    """Últimos N dígitos do telefone (sem DDI 55)."""
    digits = _only_digits(value)
    if len(digits) > length:
        return digits[-length:]
    return digits


# ──────────────────────────────────────────────────────────────────────────
# Formatação de saída para o LLM
# ──────────────────────────────────────────────────────────────────────────


_STATUS_LABEL = {
    "pendente_pagamento": "aguardando pagamento",
    "confirmado": "confirmado",
    "cancelado": "cancelado",
}


def _format_data_br(iso: str) -> str:
    try:
        y, m, dd = iso.split("-")
        return f"{dd}/{m}/{y}"
    except Exception:
        return iso


def _format_valor(centavos: int | None) -> str:
    if centavos is None:
        return "—"
    return f"R$ {centavos / 100:.2f}".replace(".", ",")


def _format_row(row: dict) -> str:
    status = _STATUS_LABEL.get(row["status"], row["status"])
    linhas = [
        f"• #{row['id']} — {row['servico_nome']} com {row['profissional_nome']}",
        f"  {_format_data_br(row['data'])} às {row['hora_inicio']} "
        f"(termina {row['hora_fim']}) — {_format_valor(row['valor_centavos'])} — {status}",
    ]
    return "\n".join(linhas)


# ──────────────────────────────────────────────────────────────────────────
# Executor
# ──────────────────────────────────────────────────────────────────────────


def execute_consultar_agendamentos(ctx, args: dict) -> str | None:
    """Devolve ao LLM os agendamentos do contato atual.

    O texto retornado já vem pronto pra ser repetido ao usuário — incluímos
    instruções implícitas (ex: status, datas formatadas em BR) para reduzir
    chances do LLM reinterpretar/inventar.
    """
    phone = getattr(ctx.contact, "phone", "") or ""
    tail = _phone_tail(phone, 10)
    if not tail:
        return (
            "Não consegui identificar o telefone deste contato no sistema. "
            "Peça ao cliente para confirmar o WhatsApp usado no agendamento."
        )

    escopo = (args or {}).get("escopo") or "proximos"
    hoje = date.today().isoformat()

    # Match: cliente_telefone pode ter sido salvo com ou sem DDI. Comparamos
    # os últimos 10 dígitos (DDD + número, sem o "55"). SQLite/Postgres ambos
    # suportam ``SUBSTR(coluna, -10)`` via ``SUBSTR(col, LENGTH(col) - 9, 10)``,
    # mas a forma portável e ainda mais legível é ``LIKE :pattern``.
    pattern = f"%{tail}"

    where_status: str
    order_clause: str
    if escopo == "historico":
        # Tudo que já passou OU foi cancelado, ordenado do mais recente pro
        # mais antigo. Limitamos a 5 para não estourar contexto do LLM.
        where_status = "(a.data < :hoje OR a.status = 'cancelado')"
        order_clause = "ORDER BY a.data DESC, a.hora_inicio DESC LIMIT 5"
    elif escopo == "todos":
        where_status = "1=1"
        order_clause = "ORDER BY a.data DESC, a.hora_inicio DESC LIMIT 10"
    else:  # 'proximos'
        where_status = (
            "a.data >= :hoje AND a.status IN ('confirmado','pendente_pagamento')"
        )
        order_clause = "ORDER BY a.data ASC, a.hora_inicio ASC LIMIT 5"

    sql = (
        "SELECT a.id, a.status, a.data, a.hora_inicio, a.hora_fim, "
        "       a.valor_centavos, a.cliente_nome, "
        "       s.nome AS servico_nome, "
        "       p.nome AS profissional_nome "
        "FROM plugin_clinica_agendamentos a "
        "LEFT JOIN plugin_clinica_servicos s ON s.id = a.servico_id "
        "LEFT JOIN plugin_clinica_profissionais p ON p.id = a.profissional_id "
        f"WHERE a.cliente_telefone LIKE :pattern AND {where_status} "
        f"{order_clause}"
    )

    params = {"pattern": pattern, "hoje": hoje}

    try:
        with make_plugin_db() as conn:
            rows = conn.execute(text(sql), params).mappings().all()
    except Exception as exc:  # pragma: no cover — proteção defensiva
        logger.exception("[clinica] consultar_agendamentos falhou: %s", exc)
        return (
            "Tive um problema ao consultar a agenda agora. "
            "Pode tentar de novo em alguns instantes?"
        )

    if not rows:
        if escopo == "historico":
            return (
                "Não encontrei nenhum agendamento passado ou cancelado em nome "
                "deste WhatsApp na Clínica Vida Leve."
            )
        if escopo == "todos":
            return (
                "Não encontrei nenhum agendamento em nome deste WhatsApp na "
                "Clínica Vida Leve. Para agendar, posso te enviar o link da "
                "página de reservas."
            )
        return (
            "Você não tem nenhum agendamento futuro confirmado na Clínica Vida "
            "Leve. Posso te ajudar a marcar um horário?"
        )

    cabecalho = {
        "proximos": "📅 Seus próximos agendamentos na Clínica Vida Leve:",
        "historico": "🗂️ Histórico recente de agendamentos (até 5):",
        "todos": "📋 Agendamentos encontrados em seu WhatsApp (até 10):",
    }[escopo]

    corpo = "\n".join(_format_row(dict(r)) for r in rows)

    # Dica extra pra agendamento pendente — o LLM pode reutilizar.
    pendentes = [r for r in rows if r["status"] == "pendente_pagamento"]
    rodape = ""
    if pendentes and escopo != "historico":
        rodape = (
            "\n\nObs.: existe(m) agendamento(s) com pagamento pendente. "
            "Eles só ficam garantidos depois que o PIX/cartão for processado."
        )

    logger.info(
        "[clinica] consultar_agendamentos phone=%s tail=%s escopo=%s rows=%d",
        phone, tail, escopo, len(rows),
    )
    return f"{cabecalho}\n\n{corpo}{rodape}"


# ──────────────────────────────────────────────────────────────────────────
# Tool — enviar_link_agendamento (Etapa 12.5)
#
# Gera um token de convite, salva em plugin_clinica_convites com expiração
# de 7 dias, e devolve uma string pronta com a URL absoluta que a IA pode
# repetir ao usuário. A página pública lê ?c=TOKEN, consulta
# GET /api/plugins/clinica/convites/TOKEN e pré-preenche o WhatsApp
# (editável). Nome fica em branco — cliente pode ter cadastrado apelido.
# ──────────────────────────────────────────────────────────────────────────


ENVIAR_LINK_AGENDAMENTO_TOOL = {
    "type": "function",
    "display_label": "Enviar link de agendamento (Clínica)",
    "function": {
        "name": "enviar_link_agendamento",
        "description": (
            "Gera o link da página de agendamento da Clínica Vida Leve "
            "com o WhatsApp do contato atual JÁ PRÉ-PREENCHIDO. "
            "Use SEMPRE que o cliente pedir o link, perguntar como agendar, "
            "ou quando você sugerir abrir a página de reservas — por "
            "exemplo: 'quero agendar', 'me manda o link', 'como faço "
            "para marcar?', 'tem horário disponível?'. "
            "IMPORTANTE — formato da resposta: o resultado da tool já vem "
            "estruturado em DUAS mensagens (rotuladas como 'Mensagem 1' e "
            "'Mensagem 2'). Você DEVE devolvê-las como DOIS ELEMENTOS "
            "SEPARADOS no array JSON de resposta — NÃO junte tudo em um "
            "elemento só. A 'Mensagem 2' deve conter APENAS a URL crua, "
            "sem texto antes ou depois, sem aspas, sem markdown. Isso "
            "garante que o WhatsApp transforme a URL em link clicável."
        ),
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}


def _read_base_url() -> str:
    """Lê plugin.clinica.base_url do config (mesma chave do settings.py).

    Devolve string vazia se a chave estiver ausente ou inválida.
    """
    try:
        with make_plugin_db() as conn:
            row = conn.execute(
                text(
                    "SELECT value FROM config "
                    "WHERE key = 'plugin.clinica.base_url'"
                )
            ).mappings().first()
        if row:
            try:
                val = json.loads(row["value"])
            except (json.JSONDecodeError, TypeError):
                val = row["value"] or ""
            if isinstance(val, str):
                return val.strip().rstrip("/")
    except Exception:
        logger.debug("[clinica] falha ao ler base_url", exc_info=True)
    return ""


def execute_enviar_link_agendamento(ctx, args: dict) -> str | None:
    """Gera token de convite e devolve mensagem com URL pronta.

    Fluxo:
      1. Lê telefone do contato (sem DDI 55). Sem telefone → link genérico.
      2. Lê base_url do config. Vazio → orienta o operador a configurar.
      3. Gera secrets.token_urlsafe(6) → ~8 chars.
      4. INSERT em plugin_clinica_convites com expires_at = now + 7 dias.
      5. Devolve mensagem com instruções para o LLM repetir ao cliente.
    """
    base = _read_base_url()
    if not base:
        return (
            "Não consigo gerar o link agora porque a URL pública da clínica "
            "ainda não foi configurada. Avise que o operador precisa "
            "preencher 'URL pública do WhatsBot' em Settings → Clínica."
        )

    phone = getattr(ctx.contact, "phone", "") or ""
    digits = _only_digits(phone)
    # Remove DDI 55 se vier — armazenamos sem para casar com o formato BR
    # esperado pelo input do form (10 ou 11 dígitos).
    if len(digits) >= 12 and digits.startswith("55"):
        digits = digits[2:]

    # Sem telefone reconhecível → manda link sem token (cliente preenche tudo).
    if len(digits) < 10:
        link = f"{base}/clinica/agendar"
        logger.info("[clinica] link sem token enviado (telefone ausente phone=%r)", phone)
        return (
            "Envie ao cliente EXATAMENTE as duas mensagens abaixo, como dois "
            "elementos separados no array JSON de resposta. NÃO junte. "
            "A Mensagem 2 deve ter APENAS a URL, sem mais nada.\n\n"
            "Mensagem 1: 🗓️ Aqui está o link de agendamento da Clínica Vida Leve! "
            "É só escolher serviço, profissional, dia e horário.\n\n"
            f"Mensagem 2: {link}"
        )

    # Token curto urlsafe — 6 bytes ≈ 8 chars. Colisão é astronomicamente
    # improvável no porte didático; não vale a pena retry-on-collision.
    token = secrets.token_urlsafe(6)
    now = time.time()
    expires_at = now + CONVITE_TTL_SECONDS

    try:
        with make_plugin_db() as conn:
            conn.execute(
                text(
                    "INSERT INTO plugin_clinica_convites "
                    "(token, telefone, created_at, expires_at) "
                    "VALUES (:tk, :tel, :ca, :ea)"
                ),
                {"tk": token, "tel": digits, "ca": now, "ea": expires_at},
            )
    except Exception as exc:
        logger.exception("[clinica] enviar_link_agendamento falhou ao gravar convite: %s", exc)
        # Fallback: manda link sem token. UX degrada (cliente digita o telefone)
        # mas o agendamento ainda funciona.
        link = f"{base}/clinica/agendar"
        return (
            "Envie ao cliente EXATAMENTE as duas mensagens abaixo, como dois "
            "elementos separados no array JSON de resposta. NÃO junte. "
            "A Mensagem 2 deve ter APENAS a URL, sem mais nada.\n\n"
            "Mensagem 1: 🗓️ Aqui está o link de agendamento da Clínica Vida Leve! "
            "É só escolher serviço, profissional, dia e horário.\n\n"
            f"Mensagem 2: {link}"
        )

    link = f"{base}/clinica/agendar?c={token}"
    logger.info("[clinica] convite criado token=%s telefone=%s", token, digits)

    return (
        "Envie ao cliente EXATAMENTE as duas mensagens abaixo, como dois "
        "elementos separados no array JSON de resposta. NÃO junte. "
        "A Mensagem 2 deve ter APENAS a URL crua, sem texto antes ou depois, "
        "sem aspas, sem markdown — isso é o que faz o WhatsApp criar o link "
        "clicável.\n\n"
        "Mensagem 1: 🗓️ Aqui está seu link de agendamento na Clínica Vida Leve! "
        "Seu WhatsApp já vem preenchido — é só escolher serviço, profissional, "
        "dia e horário. O link tem validade de 7 dias.\n\n"
        f"Mensagem 2: {link}"
    )


# ──────────────────────────────────────────────────────────────────────────
# Etapa 19 — Agendamento conversacional via IA (docs/plano-agendamento-ia.md)
#
# Tools de escrita (agendar/cancelar/remarcar) importam funções de
# `whatsbot_plugins.clinica.routes` de forma TARDIA (dentro do executor, não
# no topo do módulo) — mesmo padrão já usado em `events.py` para
# `poll_pending_payments`. Evita depender da ordem de carregamento das
# entries do manifest (tools é importado antes de routes).
#
# Identidade do cliente: o telefone vem SEMPRE de `ctx.contact.phone`, nunca
# de um argumento do LLM — mesma fronteira de segurança de
# `consultar_agendamentos` (comparação pelos últimos 10 dígitos via
# `_phone_tail`). Isso é o que impede um cliente cancelar/remarcar a reserva
# de outro.
# ──────────────────────────────────────────────────────────────────────────


def _phone_sem_ddi(phone: str) -> str:
    """Dígitos do telefone sem o DDI 55 — mesmo formato salvo por `cliente_telefone`
    no fluxo público (`AgendamentoIn` armazena o que o form manda, tipicamente
    sem DDI)."""
    digits = _only_digits(phone)
    if len(digits) >= 12 and digits.startswith("55"):
        digits = digits[2:]
    return digits


# Corte de segurança pra formatar a lista de slots de UM profissional em UMA
# data. 40 cobre folgadamente até um expediente de 12h em passos de 15 min
# (48 slots no limite extremo) sem nunca esconder um horário sem avisar —
# diferente do corte cego `[:8]` que causava "não tem 14h" quando na verdade
# tinha, só que fora dos 8 primeiros da manhã (bug real, não alucinação).
_MAX_SLOTS_EXIBIDOS = 40


def _formatar_lista_slots(slots: list[str]) -> str:
    if len(slots) <= _MAX_SLOTS_EXIBIDOS:
        return ", ".join(slots)
    mostrados = slots[:_MAX_SLOTS_EXIBIDOS]
    restantes = len(slots) - _MAX_SLOTS_EXIBIDOS
    return f"{', '.join(mostrados)} (+{restantes} horários até {slots[-1]})"


def _valid_hora(h: str) -> bool:
    try:
        hh, mm = h.split(":")
        return len(hh) == 2 and len(mm) == 2 and 0 <= int(hh) <= 23 and 0 <= int(mm) <= 59
    except Exception:
        return False


def _nomes_servico_profissional(servico_id: int, profissional_id: int) -> tuple[str, str]:
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT "
                " (SELECT nome FROM plugin_clinica_servicos WHERE id = :sid) AS servico_nome, "
                " (SELECT nome FROM plugin_clinica_profissionais WHERE id = :pid) AS profissional_nome"
            ),
            {"sid": servico_id, "pid": profissional_id},
        ).mappings().first()
    if not row:
        return "", ""
    return row["servico_nome"] or "", row["profissional_nome"] or ""


def _carregar_agendamento_do_contato(ag_id: int, phone: str) -> dict | None:
    """Carrega o agendamento `ag_id` SE ele pertencer ao telefone do contato atual.

    Comparação pelos últimos 10 dígitos (mesma tolerância a DDI de
    `consultar_agendamentos`). Devolve `None` tanto para "não existe" quanto
    para "existe mas é de outro telefone" — o chamador nunca deve distinguir
    os dois casos na mensagem ao cliente (não vazar que a reserva existe).
    """
    tail = _phone_tail(phone, 10)
    if not tail:
        return None
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT a.id, a.status, a.servico_id, a.profissional_id, "
                "       a.cliente_nome, a.cliente_telefone, a.data, a.hora_inicio, "
                "       a.hora_fim, a.duracao_min, a.valor_centavos, a.mp_order_id, "
                "       s.nome AS servico_nome, p.nome AS profissional_nome "
                "FROM plugin_clinica_agendamentos a "
                "LEFT JOIN plugin_clinica_servicos s ON s.id = a.servico_id "
                "LEFT JOIN plugin_clinica_profissionais p ON p.id = a.profissional_id "
                "WHERE a.id = :id"
            ),
            {"id": ag_id},
        ).mappings().first()
    if not row or _phone_tail(row["cliente_telefone"], 10) != tail:
        return None
    return dict(row)


def _build_reserva_pendente_message(ag: dict, servico_nome: str, profissional_nome: str) -> str:
    """Mensagem de reserva recém-criada, ainda 'aguardando pagamento'.

    Distinto de `_build_confirmacao_message` (routes.py), que só se aplica
    quando o pagamento JÁ foi confirmado — usá-lo aqui diria "pagamento
    confirmado" antes da hora.
    """
    valor = _format_valor(ag["valor_centavos"])
    primeiro_nome = (ag.get("cliente_nome") or "").split(" ")[0] or ""
    saudacao = f"Show, {primeiro_nome}!" if primeiro_nome else "Show!"
    return (
        f"{saudacao} 📋 Reserva criada — falta só o pagamento pra garantir:\n\n"
        f"💼 Serviço: {servico_nome}\n"
        f"👤 Profissional: {profissional_nome}\n"
        f"📅 Data: {_format_data_br(ag['data'])}\n"
        f"⏰ Horário: {ag['hora_inicio']} às {ag['hora_fim']}\n"
        f"💳 Valor: {valor}\n"
        f"🔖 Protocolo: #{ag['id']}\n\n"
        "A reserva só fica garantida depois que o pagamento cair."
    )


def _pix_code_de(pagamento: dict) -> str:
    """Extrai o código PIX copia-e-cola da resposta de `criar_pagamento_pix`."""
    payments = ((pagamento.get("order") or {}).get("transactions") or {}).get("payments") or []
    if not payments:
        return ""
    return (payments[0].get("payment_method") or {}).get("qr_code") or ""


def _montar_link_pagamento(ag_id: int) -> str:
    """Link da página pública de pagamento (`/clinica/pagar?t=<token>`).

    O cliente escolhe PIX ou cartão nela, independente do que combinou na
    conversa — é o caminho que cobre cartão (o Card Brick só existe nessa
    tela). Vazio se `base_url` não estiver configurada (mesma checagem de
    `enviar_link_agendamento`).

    Usa um token opaco (`gerar_token_pagamento`, routes.py), não o ID
    sequencial cru — achado de review adversarial (Etapa 19, item 4): o ID
    cru permitiria varrer nome/telefone/serviço de qualquer reserva testando
    valores em sequência num endpoint público sem auth.
    """
    base = _read_base_url()
    if not base:
        return ""
    from whatsbot_plugins.clinica.routes import gerar_token_pagamento
    token = gerar_token_pagamento(ag_id)
    return f"{base}/clinica/pagar?t={token}"


def _compor_resposta_multi_mensagem(partes: list[str]) -> str:
    """Instrui o LLM a devolver `partes` como N elementos separados no array
    JSON de resposta — mesmo padrão de `enviar_link_agendamento`. Usar quando
    alguma parte é uma URL ou código PIX cru: cada uma vai isolada, sem texto
    extra, pra virar link clicável / campo copiável no WhatsApp.
    """
    n = len(partes)
    linhas = [
        f"Envie ao cliente as {n} mensagens abaixo como {n} ELEMENTOS "
        "SEPARADOS no array JSON de resposta — NÃO junte tudo em um elemento "
        "só. Toda 'Mensagem N' que for uma URL ou código PIX cru deve ir sem "
        "texto antes ou depois, sem aspas, sem markdown.",
        "",
    ]
    for i, parte in enumerate(partes, start=1):
        linhas.append(f"Mensagem {i}: {parte}")
        linhas.append("")
    return "\n".join(linhas).rstrip()


# ──────────────────────────────────────────────────────────────────────────
# Tool — clinica_catalogo
# ──────────────────────────────────────────────────────────────────────────


CLINICA_CATALOGO_TOOL = {
    "type": "function",
    "display_label": "Catálogo de serviços (Clínica)",
    "function": {
        "name": "clinica_catalogo",
        "description": (
            "Lista os serviços ativos da Clínica Vida Leve com duração, preço "
            "e OS PROFISSIONAIS que atendem cada um. Use quando o cliente "
            "perguntar quais serviços existem, quanto custam, quem atende um "
            "serviço, ou quando você precisar do ID de um serviço para chamar "
            "clinica_horarios_disponiveis / clinica_agendar. NUNCA invente "
            "serviços, preços ou profissionais — sempre consulte esta tool "
            "antes de afirmar quem atende o quê. Retorna texto pronto para "
            "repetir ao usuário."
        ),
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}


def execute_clinica_catalogo(ctx, args: dict) -> str | None:
    try:
        with make_plugin_db() as conn:
            rows = conn.execute(
                text(
                    "SELECT s.id AS servico_id, s.nome AS servico_nome, s.descricao, "
                    "       s.duracao_min, s.valor_centavos, p.nome AS profissional_nome "
                    "FROM plugin_clinica_servicos s "
                    "LEFT JOIN plugin_clinica_servicos_profissionais sp ON sp.servico_id = s.id "
                    "LEFT JOIN plugin_clinica_profissionais p "
                    "  ON p.id = sp.profissional_id AND p.ativo = 1 "
                    "WHERE s.ativo = 1 "
                    "ORDER BY s.nome, p.nome"
                )
            ).mappings().all()
    except Exception as exc:
        logger.exception("[clinica] clinica_catalogo falhou: %s", exc)
        return "Tive um problema ao consultar o catálogo agora. Pode tentar de novo?"

    if not rows:
        return "No momento não há serviços ativos cadastrados na Clínica Vida Leve."

    # Agrupa em Python (não em SQL) pra continuar dialect-agnostic — SQLite usa
    # GROUP_CONCAT, Postgres usa STRING_AGG, e o padrão do projeto é evitar
    # funções SQL específicas de dialeto (ver CLAUDE.md).
    servicos: dict[int, dict] = {}
    for r in rows:
        sid = r["servico_id"]
        if sid not in servicos:
            servicos[sid] = {
                "nome": r["servico_nome"],
                "descricao": r["descricao"],
                "duracao_min": r["duracao_min"],
                "valor_centavos": r["valor_centavos"],
                "profissionais": [],
            }
        if r["profissional_nome"]:
            servicos[sid]["profissionais"].append(r["profissional_nome"])

    linhas = []
    for sid, s in servicos.items():
        desc = f" — {s['descricao']}" if s["descricao"] else ""
        profs = (
            ", ".join(s["profissionais"])
            if s["profissionais"]
            else "nenhum profissional ativo vinculado no momento"
        )
        linhas.append(
            f"• #{sid} {s['nome']}{desc} ({s['duracao_min']} min) — "
            f"{_format_valor(s['valor_centavos'])} — profissionais: {profs}"
        )
    return "💆‍♀️ Serviços da Clínica Vida Leve:\n\n" + "\n".join(linhas)


# ──────────────────────────────────────────────────────────────────────────
# Tool — clinica_horarios_disponiveis
# ──────────────────────────────────────────────────────────────────────────


CLINICA_HORARIOS_DISPONIVEIS_TOOL = {
    "type": "function",
    "display_label": "Horários disponíveis (Clínica)",
    "function": {
        "name": "clinica_horarios_disponiveis",
        "description": (
            "Consulta os horários REALMENTE livres para um serviço numa data, "
            "por profissional. Use SEMPRE antes de propor um horário ao "
            "cliente — nunca invente horário. Se o dia estiver lotado (ou sem "
            "expediente), a tool sugere os próximos dias com vaga. Converta "
            "datas relativas ('amanhã', 'quinta') para YYYY-MM-DD antes de "
            "chamar (você já sabe a data de hoje)."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "servico_id": {
                    "type": "integer",
                    "description": "ID do serviço (veja clinica_catalogo se não souber).",
                },
                "data": {
                    "type": "string",
                    "description": "Data desejada em YYYY-MM-DD.",
                },
                "profissional_id": {
                    "type": "integer",
                    "description": "Filtra por um profissional específico (opcional).",
                },
            },
            "required": ["servico_id", "data"],
        },
    },
}


def execute_clinica_horarios_disponiveis(ctx, args: dict) -> str | None:
    from whatsbot_plugins.clinica.routes import _compute_slots

    args = args or {}
    try:
        servico_id = int(args.get("servico_id"))
    except (TypeError, ValueError):
        return "Preciso do ID do serviço (use clinica_catalogo para descobrir)."

    profissional_id = args.get("profissional_id")
    if profissional_id is not None:
        try:
            profissional_id = int(profissional_id)
        except (TypeError, ValueError):
            profissional_id = None

    try:
        data_alvo = date.fromisoformat((args.get("data") or "").strip())
    except ValueError:
        return "Data inválida — preciso do formato AAAA-MM-DD (ex: 2026-07-10)."

    if data_alvo < date.today():
        return "Essa data já passou. Quer ver horários a partir de hoje?"

    def _slots_do_dia(d: date) -> dict:
        return _compute_slots(servico_id, d.isoformat(), profissional_id)

    try:
        resultado = _slots_do_dia(data_alvo)
    except HTTPException as exc:
        if exc.status_code == 404:
            return (
                "Não encontrei esse serviço (ou ele está inativo). "
                "Use clinica_catalogo para ver os serviços disponíveis."
            )
        return f"Não consegui verificar essa data: {exc.detail}"
    except Exception:
        logger.exception("[clinica] clinica_horarios_disponiveis falhou")
        return "Tive um problema ao consultar os horários agora. Pode tentar de novo?"

    servico_nome = resultado["servico"]["nome"]
    profissionais = resultado.get("profissionais") or []
    if profissionais:
        linhas = [
            f"• {p['nome']}: " + _formatar_lista_slots(p["slots"])
            for p in profissionais
        ]
        return (
            f"📅 Horários livres em {_format_data_br(data_alvo.isoformat())} "
            f"para {servico_nome}:\n\n" + "\n".join(linhas)
        )

    # Dia lotado (ou sem expediente) — sugere os próximos dias com vaga,
    # olhando até 14 dias à frente e parando nos 3 primeiros com alguma vaga.
    sugestoes: list[date] = []
    cursor = data_alvo
    for _ in range(14):
        cursor = cursor + timedelta(days=1)
        try:
            r = _slots_do_dia(cursor)
        except HTTPException:
            break
        if r.get("profissionais"):
            sugestoes.append(cursor)
        if len(sugestoes) >= 3:
            break

    if not sugestoes:
        return (
            f"Não encontrei horários para {servico_nome} em "
            f"{_format_data_br(data_alvo.isoformat())} nem nos próximos dias. "
            "Quer tentar outro serviço ou outra data mais distante?"
        )

    dias_fmt = ", ".join(_format_data_br(d.isoformat()) for d in sugestoes)
    return (
        f"Não há horários livres para {servico_nome} em "
        f"{_format_data_br(data_alvo.isoformat())}. Tenho vaga em: {dias_fmt}. "
        "Quer que eu veja os horários de algum desses dias?"
    )


# ──────────────────────────────────────────────────────────────────────────
# Tool — clinica_agendar
# ──────────────────────────────────────────────────────────────────────────


CLINICA_AGENDAR_TOOL = {
    "type": "function",
    "display_label": "Fechar agendamento (Clínica)",
    "function": {
        "name": "clinica_agendar",
        "description": (
            "FECHA a reserva do CONTATO ATUAL na Clínica Vida Leve — grava o "
            "agendamento como 'aguardando pagamento' e devolve o link de "
            "pagamento (sempre) mais o código PIX copia-e-cola (só se o "
            "cliente já disse que quer pagar por PIX). Só chame depois de: "
            "1) confirmar serviço, profissional, dia, horário, valor e nome "
            "com o cliente; 2) ter verificado o horário com "
            "clinica_horarios_disponiveis (nunca invente horário livre); "
            "3) perguntar se ele prefere pagar por PIX ou cartão (se ele não "
            "tiver dito ainda). Deixe claro que a vaga só fica garantida "
            "após o pagamento."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "servico_id": {"type": "integer", "description": "ID do serviço escolhido."},
                "profissional_id": {
                    "type": "integer",
                    "description": "ID do profissional escolhido (omita se o cliente aceitar 'qualquer disponível').",
                },
                "data": {"type": "string", "description": "Data escolhida em YYYY-MM-DD."},
                "hora_inicio": {"type": "string", "description": "Horário de início em HH:MM (24h)."},
                "cliente_nome": {
                    "type": "string",
                    "description": (
                        "Nome do cliente. Só é usado se o contato NÃO tiver nome "
                        "cadastrado no WhatsBot — havendo nome cadastrado, ele "
                        "prevalece sobre este argumento."
                    ),
                },
                "forma_pagamento": {
                    "type": "string",
                    "enum": ["pix", "cartao"],
                    "description": (
                        "Forma de pagamento que o cliente já disse preferir, se "
                        "disse. 'pix' faz a tool enviar o código PIX copia-e-"
                        "cola direto na conversa, além do link. 'cartao' ou "
                        "omitido envia só o link — o cliente escolhe e paga na "
                        "própria página (funciona pra PIX ou cartão)."
                    ),
                },
            },
            "required": ["servico_id", "data", "hora_inicio"],
        },
    },
}


def execute_clinica_agendar(ctx, args: dict) -> str | None:
    from whatsbot_plugins.clinica.routes import (
        _criar_agendamento,
        _push_event_to_google,
        criar_pagamento_pix,
    )

    args = args or {}
    phone = getattr(ctx.contact, "phone", "") or ""
    telefone_digits = _phone_sem_ddi(phone)
    if len(telefone_digits) < 10:
        return "Não consegui identificar seu WhatsApp para fazer a reserva."

    try:
        servico_id = int(args.get("servico_id"))
    except (TypeError, ValueError):
        return "Preciso do ID do serviço (use clinica_catalogo ou clinica_horarios_disponiveis)."

    profissional_id = args.get("profissional_id")
    if profissional_id is not None:
        try:
            profissional_id = int(profissional_id)
        except (TypeError, ValueError):
            profissional_id = None

    data_str = (args.get("data") or "").strip()
    try:
        date.fromisoformat(data_str)
    except ValueError:
        return "Data inválida — preciso do formato AAAA-MM-DD (ex: 2026-07-10)."

    hora_str = (args.get("hora_inicio") or "").strip()
    if not _valid_hora(hora_str):
        return "Horário inválido — preciso do formato HH:MM (ex: 14:00)."

    forma_pagamento = (args.get("forma_pagamento") or "").strip().lower()
    if forma_pagamento not in ("pix", "cartao"):
        forma_pagamento = ""

    nome_cadastro = (ctx.contact.info.get("name") or "").strip()
    nome_arg = (args.get("cliente_nome") or "").strip()
    cliente_nome = nome_cadastro or nome_arg
    if not cliente_nome:
        return "Preciso do seu nome completo para finalizar o agendamento. Pode me informar?"

    try:
        ag = _criar_agendamento(
            servico_id=servico_id,
            profissional_id=profissional_id,
            data=data_str,
            hora_inicio=hora_str,
            cliente_nome=cliente_nome,
            cliente_telefone=telefone_digits,
            status="pendente_pagamento",
        )
    except HTTPException as exc:
        logger.info("[clinica] clinica_agendar recusado: %s", exc.detail)
        return f"Não consegui fechar esse agendamento: {exc.detail} Quer que eu veja outro horário?"
    except Exception as exc:
        logger.exception("[clinica] clinica_agendar falhou: %s", exc)
        return "Tive um problema para gravar o agendamento agora. Pode tentar de novo?"

    try:
        _push_event_to_google(ag["id"])
    except Exception:
        logger.debug("[clinica] push google (agendar) falhou ag=%s", ag["id"], exc_info=True)

    servico_nome, profissional_nome = _nomes_servico_profissional(
        ag["servico_id"], ag["profissional_id"]
    )
    mensagem_reserva = _build_reserva_pendente_message(ag, servico_nome, profissional_nome)

    # Sempre tenta gerar o PIX (mesmo se o cliente pediu cartão) — assim a
    # página de pagamento já carrega com a order pronta, sem esperar o
    # cliente clicar. Só devolvemos o CÓDIGO na conversa se pix foi escolhido.
    link = _montar_link_pagamento(ag["id"])
    pix_code = ""
    try:
        pagamento = criar_pagamento_pix(ag["id"])
        pix_code = _pix_code_de(pagamento)
    except Exception as exc:
        logger.warning("[clinica] criar_pagamento_pix (agendar) falhou ag=%s: %s", ag["id"], exc)

    # O guard precisa checar o que o cliente VAI VER, não se pix_code existe
    # internamente — se forma_pagamento != "pix", o código nunca entra em
    # `partes`, então "pix_code existe mas não vamos mostrar" não conta como
    # "o cliente tem como pagar". Sem essa distinção, um estado de config
    # parcial (PIX configurado mas base_url vazio) fazia a tool devolver só o
    # recap, sem link nem código nem aviso — cliente sem nenhum jeito de
    # pagar e sem saber que algo falhou (achado #1 do review, confirmado).
    pix_sera_mostrado = forma_pagamento == "pix" and bool(pix_code)
    if not link and not pix_sera_mostrado:
        return (
            f"{mensagem_reserva}\n\n"
            "⚠️ Não consegui gerar o pagamento automaticamente agora. "
            "Avise a recepção informando o protocolo acima para finalizar o pagamento."
        )

    partes = [mensagem_reserva]
    if link:
        partes.append(link)
    if pix_sera_mostrado:
        partes.append(pix_code)

    logger.info(
        "[clinica] clinica_agendar sucesso ag=%s phone=%s forma_pagamento=%s link=%s pix=%s",
        ag["id"], phone, forma_pagamento or "-", bool(link), bool(pix_code),
    )
    return _compor_resposta_multi_mensagem(partes)


# ──────────────────────────────────────────────────────────────────────────
# Tool — clinica_cancelar_agendamento
# ──────────────────────────────────────────────────────────────────────────


CLINICA_CANCELAR_AGENDAMENTO_TOOL = {
    "type": "function",
    "display_label": "Cancelar agendamento (Clínica)",
    "function": {
        "name": "clinica_cancelar_agendamento",
        "description": (
            "Cancela um agendamento do CONTATO ATUAL na Clínica Vida Leve. "
            "Antes de chamar, use consultar_agendamentos para achar o ID (#) "
            "do agendamento e confirme com o cliente qual é. Só cancela "
            "reservas do próprio WhatsApp de quem está conversando."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "agendamento_id": {"type": "integer", "description": "ID (#) do agendamento a cancelar."},
            },
            "required": ["agendamento_id"],
        },
    },
}


def execute_clinica_cancelar_agendamento(ctx, args: dict) -> str | None:
    args = args or {}
    phone = getattr(ctx.contact, "phone", "") or ""
    try:
        ag_id = int(args.get("agendamento_id"))
    except (TypeError, ValueError):
        return "Preciso do número do agendamento (#) para cancelar."

    ag = _carregar_agendamento_do_contato(ag_id, phone)
    if not ag:
        return "Não encontrei esse agendamento no seu WhatsApp."
    if ag["status"] == "cancelado":
        return f"O agendamento #{ag_id} já estava cancelado."

    with make_plugin_db() as conn:
        conn.execute(
            text("UPDATE plugin_clinica_agendamentos SET status = 'cancelado' WHERE id = :id"),
            {"id": ag_id},
        )

    try:
        from whatsbot_plugins.clinica.routes import _cancel_event_in_google
        _cancel_event_in_google(ag_id)
    except Exception:
        logger.debug("[clinica] cancel google falhou ag=%s", ag_id, exc_info=True)

    logger.info("[clinica] clinica_cancelar_agendamento ag=%s phone=%s", ag_id, phone)
    return (
        f"Prontinho! Cancelei o agendamento #{ag_id} "
        f"({ag['servico_nome']} em {_format_data_br(ag['data'])} às {ag['hora_inicio']}). "
        "Se quiser remarcar, é só me chamar."
    )


# ──────────────────────────────────────────────────────────────────────────
# Tool — clinica_remarcar_agendamento
# ──────────────────────────────────────────────────────────────────────────


CLINICA_REMARCAR_AGENDAMENTO_TOOL = {
    "type": "function",
    "display_label": "Remarcar agendamento (Clínica)",
    "function": {
        "name": "clinica_remarcar_agendamento",
        "description": (
            "Move um agendamento do CONTATO ATUAL para outro dia/horário "
            "(mesmo serviço). Use consultar_agendamentos antes para achar o "
            "ID (#) e verifique o novo horário com "
            "clinica_horarios_disponiveis antes de propor. Se o agendamento "
            "original já estava pago, o novo nasce confirmado sem cobrar de "
            "novo; se ainda estava aguardando pagamento, o novo reenvia o "
            "link de pagamento (e o código PIX, se o cliente quiser PIX)."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "agendamento_id": {"type": "integer", "description": "ID (#) do agendamento a remarcar."},
                "nova_data": {"type": "string", "description": "Nova data em YYYY-MM-DD."},
                "nova_hora_inicio": {"type": "string", "description": "Novo horário de início em HH:MM."},
                "profissional_id": {
                    "type": "integer",
                    "description": "Trocar de profissional (opcional; default mantém o mesmo).",
                },
                "forma_pagamento": {
                    "type": "string",
                    "enum": ["pix", "cartao"],
                    "description": (
                        "Só se importa quando a reserva original ainda estava "
                        "aguardando pagamento. 'pix' reenvia o código PIX "
                        "copia-e-cola além do link; 'cartao' ou omitido manda "
                        "só o link."
                    ),
                },
            },
            "required": ["agendamento_id", "nova_data", "nova_hora_inicio"],
        },
    },
}


def execute_clinica_remarcar_agendamento(ctx, args: dict) -> str | None:
    from whatsbot_plugins.clinica.routes import (
        _build_confirmacao_message,
        _cancel_event_in_google,
        _criar_agendamento,
        _push_event_to_google,
        criar_pagamento_pix,
    )

    args = args or {}
    phone = getattr(ctx.contact, "phone", "") or ""
    try:
        ag_id = int(args.get("agendamento_id"))
    except (TypeError, ValueError):
        return "Preciso do número do agendamento (#) para remarcar."

    nova_data = (args.get("nova_data") or "").strip()
    try:
        date.fromisoformat(nova_data)
    except ValueError:
        return "Data inválida — preciso do formato AAAA-MM-DD (ex: 2026-07-10)."

    nova_hora = (args.get("nova_hora_inicio") or "").strip()
    if not _valid_hora(nova_hora):
        return "Horário inválido — preciso do formato HH:MM (ex: 14:00)."

    novo_profissional_id = args.get("profissional_id")
    if novo_profissional_id is not None:
        try:
            novo_profissional_id = int(novo_profissional_id)
        except (TypeError, ValueError):
            novo_profissional_id = None

    forma_pagamento = (args.get("forma_pagamento") or "").strip().lower()
    if forma_pagamento not in ("pix", "cartao"):
        forma_pagamento = ""

    original = _carregar_agendamento_do_contato(ag_id, phone)
    if not original:
        return "Não encontrei esse agendamento no seu WhatsApp."
    if original["status"] == "cancelado":
        return (
            f"O agendamento #{ag_id} já está cancelado — não dá para remarcar. "
            "Posso criar um novo, se quiser."
        )

    novo_status = "confirmado" if original["status"] == "confirmado" else "pendente_pagamento"
    profissional_alvo = (
        novo_profissional_id if novo_profissional_id is not None else original["profissional_id"]
    )

    try:
        novo_ag = _criar_agendamento(
            servico_id=original["servico_id"],
            profissional_id=profissional_alvo,
            data=nova_data,
            hora_inicio=nova_hora,
            cliente_nome=original["cliente_nome"],
            cliente_telefone=original["cliente_telefone"],
            status=novo_status,
        )
    except HTTPException as exc:
        logger.info("[clinica] clinica_remarcar_agendamento recusado: %s", exc.detail)
        return (
            f"Não consegui remarcar para esse horário: {exc.detail} "
            "Quer que eu veja outro horário? Seu agendamento original continua valendo."
        )
    except Exception as exc:
        logger.exception("[clinica] clinica_remarcar_agendamento falhou: %s", exc)
        return (
            "Tive um problema para remarcar agora. "
            "Seu agendamento original continua valendo — pode tentar de novo?"
        )

    # Só cancela o antigo DEPOIS que o novo foi criado com sucesso — evita
    # deixar o cliente sem reserva se o novo horário falhar.
    with make_plugin_db() as conn:
        conn.execute(
            text("UPDATE plugin_clinica_agendamentos SET status = 'cancelado' WHERE id = :id"),
            {"id": ag_id},
        )
    try:
        _cancel_event_in_google(ag_id)
    except Exception:
        logger.debug("[clinica] cancel google (remarcar) falhou ag=%s", ag_id, exc_info=True)
    try:
        _push_event_to_google(novo_ag["id"])
    except Exception:
        logger.debug("[clinica] push google (remarcar) falhou ag=%s", novo_ag["id"], exc_info=True)

    logger.info(
        "[clinica] clinica_remarcar_agendamento ag_antigo=%s ag_novo=%s status=%s phone=%s",
        ag_id, novo_ag["id"], novo_status, phone,
    )

    servico_nome, profissional_nome = _nomes_servico_profissional(
        novo_ag["servico_id"], novo_ag["profissional_id"]
    )

    if novo_status == "confirmado":
        novo_ag_full = dict(novo_ag)
        novo_ag_full["servico_nome"] = servico_nome
        novo_ag_full["profissional_nome"] = profissional_nome
        novo_ag_full["mp_order_id"] = original.get("mp_order_id")
        return _build_confirmacao_message(novo_ag_full) + (
            f"\n\n(Remarcado do agendamento #{ag_id} — nenhuma cobrança nova foi feita.)"
        )

    mensagem_reserva = _build_reserva_pendente_message(novo_ag, servico_nome, profissional_nome)

    link = _montar_link_pagamento(novo_ag["id"])
    pix_code = ""
    try:
        pagamento = criar_pagamento_pix(novo_ag["id"])
        pix_code = _pix_code_de(pagamento)
    except Exception as exc:
        logger.warning(
            "[clinica] criar_pagamento_pix (remarcar) falhou ag=%s: %s", novo_ag["id"], exc
        )

    # Mesmo raciocínio de execute_clinica_agendar: o guard checa o que vai
    # ser MOSTRADO ao cliente, não se pix_code existe internamente.
    pix_sera_mostrado = forma_pagamento == "pix" and bool(pix_code)
    if not link and not pix_sera_mostrado:
        return (
            f"{mensagem_reserva}\n\n"
            "⚠️ Não consegui gerar o pagamento automaticamente agora. "
            "Avise a recepção informando o protocolo acima para finalizar o pagamento."
        )

    partes = [mensagem_reserva]
    if link:
        partes.append(link)
    if pix_sera_mostrado:
        partes.append(pix_code)

    return _compor_resposta_multi_mensagem(partes)


# ──────────────────────────────────────────────────────────────────────────
# Registry (lido pelo plugin loader via entry.tools)
# ──────────────────────────────────────────────────────────────────────────


CORE_TOOLS = [
    (CONSULTAR_AGENDAMENTOS_TOOL, execute_consultar_agendamentos),
    (ENVIAR_LINK_AGENDAMENTO_TOOL, execute_enviar_link_agendamento),
    (CLINICA_CATALOGO_TOOL, execute_clinica_catalogo),
    (CLINICA_HORARIOS_DISPONIVEIS_TOOL, execute_clinica_horarios_disponiveis),
    (CLINICA_AGENDAR_TOOL, execute_clinica_agendar),
    (CLINICA_CANCELAR_AGENDAMENTO_TOOL, execute_clinica_cancelar_agendamento),
    (CLINICA_REMARCAR_AGENDAMENTO_TOOL, execute_clinica_remarcar_agendamento),
]
