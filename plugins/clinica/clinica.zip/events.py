"""Background tasks do plugin Clínica.

Sobe dois loops assíncronos no `app.startup` (cancelados em `app.shutdown`):

* **`clinica-mp-poller`** (Etapa 9) — a cada `POLL_INTERVAL` segundos
  varre `plugin_clinica_agendamentos` com `mp_order_id` preenchido e
  ainda em `pendente_pagamento`. Confirma + envia WhatsApp quando o MP
  retorna `processed`. Cobre o caso em que o cliente fechou o navegador
  antes do PIX cair.

* **`clinica-lembrete-loop`** (Etapa 11) — tick a cada
  `LEMBRETE_CHECK_INTERVAL` segundos. Dentro da janela
  `[lembrete_hora, 18:00)` (lembrete_hora editável via UI),
  envia **um** lembrete por vez, espaçando `lembrete_intervalo_min`
  minutos entre cada um — evita rajada que faria o WhatsApp bloquear
  o número.
"""

from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime

logger = logging.getLogger(__name__)

# Etapa 9 — poller MP.
POLL_INTERVAL = 15  # segundos — equilibra latência vs. carga na API MP

# Etapa 11 — lembrete diário.
LEMBRETE_CHECK_INTERVAL = 30  # tick do loop — checa a cada 30s
LEMBRETE_HORA_FIM = "18:00"   # upper bound — não envia depois do expediente

_task_mp: asyncio.Task | None = None
_task_lembrete: asyncio.Task | None = None
_last_lembrete_send_ts: float = 0.0  # Unix ts do último envio (sucesso ou falha)


async def _mp_poller_loop() -> None:
    # Import tardio evita ciclo (routes.py importa pouco, mas seguro).
    from whatsbot_plugins.clinica.routes import poll_pending_payments

    logger.info("[clinica] poller MP iniciado (intervalo=%ss)", POLL_INTERVAL)
    while True:
        try:
            await asyncio.sleep(POLL_INTERVAL)
            enviados = await poll_pending_payments()
            if enviados:
                logger.info("[clinica] poller MP: %s notificacoes enviadas", enviados)
        except asyncio.CancelledError:
            logger.info("[clinica] poller MP encerrado")
            raise
        except Exception as exc:
            logger.exception("[clinica] poller MP erro inesperado: %s", exc)
            # Não derruba o loop — espera e tenta de novo.


async def _lembrete_loop() -> None:
    """Loop diário do lembrete 24h antes, com pacing por minuto.

    Estratégia:
      - Tick rápido (30s) para reagir a mudanças de hora/intervalo.
      - Dentro da janela `[lembrete_hora, 18:00)`:
          se passou `intervalo_min` minutos desde o último envio,
          tenta mandar UM lembrete da fila.
      - Fora da janela: idle.

    A fila é montada pelo SQL `data = amanhã AND status = 'confirmado'
    AND lembrete_enviado = 0`. Idempotência real vem da flag no DB —
    o `_last_lembrete_send_ts` só protege o ritmo.
    """
    from whatsbot_plugins.clinica.routes import (
        enviar_proximo_lembrete,
        _lembrete_hora,
        _lembrete_intervalo_min,
    )

    global _last_lembrete_send_ts
    logger.info(
        "[clinica] loop de lembretes iniciado (gatilho=%s ate %s, intervalo=%smin)",
        _lembrete_hora(), LEMBRETE_HORA_FIM, _lembrete_intervalo_min(),
    )
    while True:
        try:
            await asyncio.sleep(LEMBRETE_CHECK_INTERVAL)
            now = datetime.now()
            now_hhmm = now.strftime("%H:%M")
            now_ts = time.time()
            hora_alvo = _lembrete_hora()
            intervalo_seg = max(1, _lembrete_intervalo_min()) * 60

            # Fora da janela comercial? Apenas espera.
            if not (now_hhmm >= hora_alvo and now_hhmm < LEMBRETE_HORA_FIM):
                continue

            # Respeita o intervalo entre envios.
            if (now_ts - _last_lembrete_send_ts) < intervalo_seg:
                continue

            result = await asyncio.to_thread(enviar_proximo_lembrete)
            if not result["tentou"]:
                # Fila vazia. Não atualiza o timestamp — assim que aparecer
                # um lembrete novo, ele sai sem precisar esperar o intervalo.
                continue

            _last_lembrete_send_ts = now_ts
            if result["enviado"]:
                logger.info(
                    "[clinica] lembrete enviado ag=%s (restantes=%s, proximo em %smin)",
                    result["ag_id"], result["restantes_antes"] - 1,
                    intervalo_seg // 60,
                )
            else:
                logger.warning(
                    "[clinica] envio falhou ag=%s (restantes=%s, tentara de novo em %smin)",
                    result["ag_id"], result["restantes_antes"],
                    intervalo_seg // 60,
                )
        except asyncio.CancelledError:
            logger.info("[clinica] loop de lembretes encerrado")
            raise
        except Exception as exc:
            logger.exception("[clinica] loop de lembretes erro: %s", exc)


def _handle_cancelamento_externo(payload: dict) -> None:
    """Síncrono: reage a um cancelamento feito pelo médico direto no Google.

    Só trata eventos `direction == "external"` originados na clínica
    (`source_plugin == "clinica"`). Cancelamentos in-app emitem o mesmo evento
    com `direction == "internal"` — esses já foram tratados pela própria rota
    e não devem disparar aviso de novo.

    Marca o agendamento como `cancelado`, avisa a clínica por WhatsApp (se
    `clinic_notify_phone` estiver setado) e empurra a mudança para o painel.
    """
    from sqlalchemy import text
    from plugins.context import make_plugin_db, broadcast
    from whatsbot_plugins.clinica.routes import (
        _send_whatsapp,
        _clinic_notify_phone,
        _format_data_br,
    )

    try:
        ag_id = int(payload.get("source_ref"))
    except (TypeError, ValueError):
        return

    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT a.id, a.status, a.cliente_nome, a.cliente_telefone, "
                "       a.data, a.hora_inicio, a.hora_fim, "
                "       s.nome AS servico_nome, p.nome AS profissional_nome "
                "FROM plugin_clinica_agendamentos a "
                "LEFT JOIN plugin_clinica_servicos s ON s.id = a.servico_id "
                "LEFT JOIN plugin_clinica_profissionais p ON p.id = a.profissional_id "
                "WHERE a.id = :id"
            ),
            {"id": ag_id},
        ).mappings().first()
        if not row:
            return
        if row["status"] == "cancelado":
            return  # já estava cancelado — nada a fazer
        conn.execute(
            text(
                "UPDATE plugin_clinica_agendamentos SET status = 'cancelado' "
                "WHERE id = :id"
            ),
            {"id": ag_id},
        )
    ag = dict(row)
    logger.info(
        "[clinica] agendamento %s cancelado pelo médico no Google Agenda", ag_id
    )

    # Empurra para o painel (a tela escuta este evento e atualiza a lista).
    try:
        broadcast("clinica_agendamento_cancelado", {
            "id": ag_id,
            "origem": "google_agenda",
            "profissional_nome": ag.get("profissional_nome"),
        })
    except Exception as exc:
        logger.debug("[clinica] broadcast cancelamento falhou: %s", exc)

    # Aviso por WhatsApp para o número da clínica (se configurado).
    phone = _clinic_notify_phone()
    if phone:
        msg = (
            "⚠️ *Cancelamento pelo profissional*\n\n"
            f"O profissional *{ag.get('profissional_nome') or '—'}* cancelou um "
            "atendimento direto no Google Agenda:\n\n"
            f"👤 Cliente: {ag.get('cliente_nome') or '—'}\n"
            f"💆 Serviço: {ag.get('servico_nome') or '—'}\n"
            f"📅 Data: {_format_data_br(ag.get('data') or '')}\n"
            f"⏰ Horário: {ag.get('hora_inicio')} às {ag.get('hora_fim')}\n\n"
            "O horário foi liberado na agenda da clínica."
        )
        _send_whatsapp(phone, msg, source="clinica_cancelamento_externo")


def _handle_bloqueio_cancelado_externo(payload: dict) -> None:
    """Médico apagou o evento de BLOQUEIO direto no Google → remove o bloqueio.

    Libera as datas na agenda da clínica. `source_ref` chega como
    `bloqueio:<id>`; extraímos o id e apagamos a linha (qualquer origem —
    tanto o espelho `clinica` quanto um bloqueio `google` somem ao apagar lá).
    """
    from sqlalchemy import text
    from plugins.context import make_plugin_db, broadcast

    raw = str(payload.get("source_ref") or "")
    try:
        bloqueio_id = int(raw.split(":", 1)[1])
    except (IndexError, ValueError):
        return

    with make_plugin_db() as conn:
        row = conn.execute(
            text("SELECT id, profissional_id FROM plugin_clinica_bloqueios WHERE id = :id"),
            {"id": bloqueio_id},
        ).mappings().first()
        if not row:
            return
        conn.execute(
            text("DELETE FROM plugin_clinica_bloqueios WHERE id = :id"),
            {"id": bloqueio_id},
        )
    logger.info(
        "[clinica] bloqueio %s removido (evento apagado no Google pelo profissional)",
        bloqueio_id,
    )
    try:
        broadcast("clinica_bloqueio_removido", {
            "id": bloqueio_id,
            "profissional_id": row["profissional_id"],
            "origem": "google_agenda",
        })
    except Exception as exc:
        logger.debug("[clinica] broadcast bloqueio removido falhou: %s", exc)


async def on_agenda_event_cancelled(ctx, payload) -> None:
    """Handler do bus para `agenda.event_cancelled` (Etapas 4 e 5).

    Roteia por prefixo do `source_ref`: `bloqueio:<id>` → remove o bloqueio
    (libera as datas); caso contrário → fluxo de cancelamento de agendamento.
    """
    if (payload or {}).get("source_plugin") != "clinica":
        return
    if (payload or {}).get("direction") != "external":
        return  # cancelamento in-app já tratado pela rota
    source_ref = str((payload or {}).get("source_ref") or "")
    if source_ref.startswith("bloqueio:"):
        await asyncio.to_thread(_handle_bloqueio_cancelado_externo, payload)
    else:
        await asyncio.to_thread(_handle_cancelamento_externo, payload)


def _handle_agenda_external_event(payload: dict) -> None:
    """Opção B: evento criado direto na agenda Google vira bloqueio na clínica.

    Mapeia `calendar_id` → profissional (via google_calendar_id). Upsert por
    `google_event_id` com `origem='google'`. `status='cancelled'` remove o
    bloqueio (libera o horário). Eventos que a própria clínica criou (inclusive
    bloqueios já espelhados) NÃO chegam aqui — o gateway só emite
    `agenda.external_event` para eventos fora do nosso espelho.
    """
    from datetime import datetime, timedelta
    from sqlalchemy import text
    from plugins.context import make_plugin_db, broadcast

    calendar_id = payload.get("calendar_id")
    gid = payload.get("google_event_id")
    if not calendar_id or not gid:
        return

    removido = False
    with make_plugin_db() as conn:
        prof = conn.execute(
            text(
                "SELECT id FROM plugin_clinica_profissionais "
                "WHERE google_calendar_id = :cid"
            ),
            {"cid": calendar_id},
        ).mappings().first()
        if not prof:
            return  # agenda não pertence a nenhum profissional da clínica
        prof_id = prof["id"]

        if payload.get("status") == "cancelled":
            conn.execute(
                text(
                    "DELETE FROM plugin_clinica_bloqueios "
                    "WHERE google_event_id = :g AND origem = 'google'"
                ),
                {"g": gid},
            )
            removido = True
        else:
            start_ts = payload.get("start_ts")
            end_ts = payload.get("end_ts")
            if start_ts is None or end_ts is None:
                return
            start_dt = datetime.fromtimestamp(float(start_ts))
            end_dt = datetime.fromtimestamp(float(end_ts))
            if payload.get("all_day"):
                data_inicio = start_dt.date().isoformat()
                # No Google, o `end` de all-day é exclusivo (dia seguinte ao último).
                data_fim = (end_dt.date() - timedelta(days=1)).isoformat()
                if data_fim < data_inicio:
                    data_fim = data_inicio
                dia_inteiro, hora_inicio, hora_fim = 1, None, None
            else:
                data_inicio = start_dt.date().isoformat()
                data_fim = end_dt.date().isoformat()
                dia_inteiro = 0
                hora_inicio = start_dt.strftime("%H:%M")
                hora_fim = end_dt.strftime("%H:%M")
                # Evento degenerado (fim <= início no mesmo dia) — ignora.
                if data_inicio == data_fim and hora_fim <= hora_inicio:
                    return
            motivo = (payload.get("summary") or "Compromisso (Google)").strip()
            now = time.time()
            existing = conn.execute(
                text(
                    "SELECT id FROM plugin_clinica_bloqueios WHERE google_event_id = :g"
                ),
                {"g": gid},
            ).mappings().first()
            if existing:
                conn.execute(
                    text(
                        "UPDATE plugin_clinica_bloqueios SET "
                        " profissional_id = :pid, data_inicio = :di, data_fim = :df, "
                        " dia_inteiro = :dia, hora_inicio = :hi, hora_fim = :hf, "
                        " motivo = :mot, origem = 'google' "
                        "WHERE id = :id"
                    ),
                    {
                        "pid": prof_id, "di": data_inicio, "df": data_fim,
                        "dia": dia_inteiro, "hi": hora_inicio, "hf": hora_fim,
                        "mot": motivo, "id": existing["id"],
                    },
                )
            else:
                conn.execute(
                    text(
                        "INSERT INTO plugin_clinica_bloqueios "
                        "(profissional_id, data_inicio, data_fim, dia_inteiro, "
                        " hora_inicio, hora_fim, motivo, origem, google_event_id, created_at) "
                        "VALUES (:pid, :di, :df, :dia, :hi, :hf, :mot, 'google', :g, :ts)"
                    ),
                    {
                        "pid": prof_id, "di": data_inicio, "df": data_fim,
                        "dia": dia_inteiro, "hi": hora_inicio, "hf": hora_fim,
                        "mot": motivo, "g": gid, "ts": now,
                    },
                )

    logger.info(
        "[clinica] bloqueio origem=google %s prof=%s (%s)",
        "removido" if removido else "upsert", prof_id, gid,
    )
    try:
        broadcast("clinica_bloqueio_externo", {
            "profissional_id": prof_id,
            "google_event_id": gid,
            "removido": removido,
        })
    except Exception as exc:
        logger.debug("[clinica] broadcast bloqueio externo falhou: %s", exc)


async def on_agenda_external_event(ctx, payload) -> None:
    """Handler do bus para `agenda.external_event` (Etapa 5 de bloqueios)."""
    await asyncio.to_thread(_handle_agenda_external_event, payload or {})


async def on_startup(ctx, payload) -> None:
    global _task_mp, _task_lembrete
    if _task_mp is None or _task_mp.done():
        _task_mp = asyncio.create_task(_mp_poller_loop(), name="clinica-mp-poller")
    if _task_lembrete is None or _task_lembrete.done():
        _task_lembrete = asyncio.create_task(_lembrete_loop(), name="clinica-lembrete-loop")


async def on_shutdown(ctx, payload) -> None:
    global _task_mp, _task_lembrete
    for t in (_task_mp, _task_lembrete):
        if t is not None:
            t.cancel()
    _task_mp = None
    _task_lembrete = None


EVENT_HANDLERS = {
    "app.startup": on_startup,
    "app.shutdown": on_shutdown,
    "agenda.event_cancelled": on_agenda_event_cancelled,
    "agenda.external_event": on_agenda_external_event,
}
