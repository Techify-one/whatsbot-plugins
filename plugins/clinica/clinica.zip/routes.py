"""Endpoints REST do plugin Clínica.

Etapa 1: leitura pública (info/profissionais/servicos).
Etapa 2: CRUD admin (criar, editar, ativar/desativar profissionais e serviços).
Etapa 3: relação N:N serviços ↔ profissionais (quem atende o quê).
Etapa 4: horários de atendimento por profissional (dia da semana + início/fim).
Etapa 5: cálculo de slots disponíveis.
Etapa 6: agendamentos públicos (POST /agendamentos) + subtração de slots ocupados.

"Desativar" = soft delete via flag `ativo=0`. Nunca apagamos linhas porque
agendamentos futuros (Etapa 6+) vão referenciar profissionais/serviços e não
podemos perder essa âncora.

Todos os endpoints são montados em /api/plugins/clinica/* automaticamente
pelo loader do WhatsBot.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import secrets
import time
import urllib.error
import urllib.request
import uuid
from calendar import monthrange
from datetime import date, datetime, timedelta
from typing import Any

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import text

from plugins.context import make_plugin_db

logger = logging.getLogger(__name__)

router = APIRouter()


def _ok(data: Any) -> dict:
    return {"ok": True, "data": data}


# ──────────────────────────────────────────────────────────────────────────
# Endpoints PÚBLICOS (leitura) — usados pela visão geral e, no futuro, pela
# página pública de agendamento (Etapa 6).
# ──────────────────────────────────────────────────────────────────────────


@router.get("/info")
async def clinica_info() -> dict:
    """Dados básicos da clínica (fixos por enquanto, Settings entram em etapa futura)."""
    return _ok({
        "nome": "Clínica Vida Leve",
        "slogan": "Cuidando do seu bem-estar com leveza",
        "telefone": "(11) 99999-0000",
        "endereco": "Rua das Acácias, 123 — São Paulo/SP",
    })


@router.get("/profissionais")
async def list_profissionais() -> dict:
    with make_plugin_db() as conn:
        rows = conn.execute(text(
            "SELECT id, nome, especialidade, ativo "
            "FROM plugin_clinica_profissionais "
            "WHERE ativo = 1 "
            "ORDER BY nome"
        )).mappings().all()
    return _ok([dict(r) for r in rows])


@router.get("/servicos")
async def list_servicos() -> dict:
    with make_plugin_db() as conn:
        # preco_min/max: faixa de preço resolvida (override do par, ou base) entre
        # os profissionais ATIVOS que atendem o serviço. NULL = sem profissional
        # ativo vinculado → o frontend cai no valor_centavos base.
        rows = conn.execute(text(
            "SELECT s.id, s.nome, s.descricao, s.duracao_min, s.valor_centavos, s.ativo, "
            "  (SELECT MIN(COALESCE(sp.valor_centavos, s.valor_centavos)) "
            "     FROM plugin_clinica_servicos_profissionais sp "
            "     JOIN plugin_clinica_profissionais p ON p.id = sp.profissional_id "
            "    WHERE sp.servico_id = s.id AND p.ativo = 1) AS preco_min_centavos, "
            "  (SELECT MAX(COALESCE(sp.valor_centavos, s.valor_centavos)) "
            "     FROM plugin_clinica_servicos_profissionais sp "
            "     JOIN plugin_clinica_profissionais p ON p.id = sp.profissional_id "
            "    WHERE sp.servico_id = s.id AND p.ativo = 1) AS preco_max_centavos "
            "FROM plugin_clinica_servicos s "
            "WHERE s.ativo = 1 "
            "ORDER BY s.nome"
        )).mappings().all()
    return _ok([dict(r) for r in rows])


@router.get("/servicos/{srv_id}/profissionais")
async def list_profissionais_do_servico(srv_id: int) -> dict:
    """Profissionais ATIVOS que atendem este serviço.

    Usado pela página pública de agendamento (Etapa 6): cliente escolhe um
    serviço e só vê profissionais aptos a executá-lo.
    """
    with make_plugin_db() as conn:
        rows = conn.execute(
            text(
                "SELECT p.id, p.nome, p.especialidade, "
                "       COALESCE(sp.valor_centavos, s.valor_centavos) AS valor_centavos "
                "FROM plugin_clinica_profissionais p "
                "JOIN plugin_clinica_servicos_profissionais sp "
                "  ON sp.profissional_id = p.id "
                "JOIN plugin_clinica_servicos s ON s.id = sp.servico_id "
                "WHERE sp.servico_id = :id AND p.ativo = 1 "
                "ORDER BY p.nome"
            ),
            {"id": srv_id},
        ).mappings().all()
    return _ok([dict(r) for r in rows])


# ──────────────────────────────────────────────────────────────────────────
# Schemas Pydantic — validação automática dos bodies pelo FastAPI.
# ──────────────────────────────────────────────────────────────────────────


class ProfissionalIn(BaseModel):
    nome: str = Field(min_length=1, max_length=200)
    especialidade: str = Field(default="", max_length=200)
    email: str = Field(
        default="",
        max_length=320,
        description="E-mail do profissional — vira o dono da agenda Google.",
    )

    @field_validator("nome", "especialidade", "email")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()


class ServicoIn(BaseModel):
    nome: str = Field(min_length=1, max_length=200)
    descricao: str = Field(default="", max_length=1000)
    duracao_min: int = Field(ge=5, le=600, description="Duração em minutos (5 a 600).")
    valor_centavos: int = Field(ge=0, description="Valor em centavos (R$ 50,00 = 5000).")

    @field_validator("nome", "descricao")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()


# ──────────────────────────────────────────────────────────────────────────
# Admin — Profissionais
# ──────────────────────────────────────────────────────────────────────────


@router.get("/admin/profissionais")
async def admin_list_profissionais() -> dict:
    """Lista TODOS (ativos e inativos), para o painel admin."""
    with make_plugin_db() as conn:
        rows = conn.execute(text(
            "SELECT id, nome, especialidade, email, google_calendar_id, "
            "       ativo, created_at "
            "FROM plugin_clinica_profissionais "
            "ORDER BY ativo DESC, nome"
        )).mappings().all()
    return _ok([dict(r) for r in rows])


@router.post("/admin/profissionais")
async def admin_create_profissional(body: ProfissionalIn) -> dict:
    now = int(time.time())
    with make_plugin_db() as conn:
        # RETURNING funciona em SQLite >= 3.35 e Postgres — dialect-agnóstico.
        # Não usar `result.inserted_primary_key` com text() raw: só funciona com Table.insert().
        new_id = conn.execute(
            text(
                "INSERT INTO plugin_clinica_profissionais "
                "(nome, especialidade, email, ativo, created_at) "
                "VALUES (:nome, :esp, :email, 1, :ts) RETURNING id"
            ),
            {"nome": body.nome, "esp": body.especialidade, "email": body.email, "ts": now},
        ).scalar_one()
    logger.info("[clinica] profissional criado id=%s nome=%s", new_id, body.nome)
    return _ok({
        "id": new_id, "nome": body.nome, "especialidade": body.especialidade,
        "email": body.email, "ativo": 1,
    })


@router.put("/admin/profissionais/{prof_id}")
async def admin_update_profissional(prof_id: int, body: ProfissionalIn) -> dict:
    with make_plugin_db() as conn:
        result = conn.execute(
            text(
                "UPDATE plugin_clinica_profissionais "
                "SET nome = :nome, especialidade = :esp, email = :email "
                "WHERE id = :id"
            ),
            {"nome": body.nome, "esp": body.especialidade, "email": body.email, "id": prof_id},
        )
        if result.rowcount == 0:
            raise HTTPException(status_code=404, detail="Profissional não encontrado.")
    return _ok({
        "id": prof_id, "nome": body.nome, "especialidade": body.especialidade,
        "email": body.email,
    })


@router.post("/admin/profissionais/{prof_id}/toggle")
async def admin_toggle_profissional(prof_id: int) -> dict:
    """Alterna entre ativo (1) e inativo (0)."""
    with make_plugin_db() as conn:
        result = conn.execute(
            text("UPDATE plugin_clinica_profissionais SET ativo = 1 - ativo WHERE id = :id"),
            {"id": prof_id},
        )
        if result.rowcount == 0:
            raise HTTPException(status_code=404, detail="Profissional não encontrado.")
        novo = conn.execute(
            text("SELECT ativo FROM plugin_clinica_profissionais WHERE id = :id"),
            {"id": prof_id},
        ).scalar()
    return _ok({"id": prof_id, "ativo": int(novo)})


@router.post("/admin/profissionais/{prof_id}/google-calendar")
async def admin_criar_agenda_google(prof_id: int) -> dict:
    """Cria a agenda Google do profissional com 1 clique (Etapa 5).

    Usa o gateway do plugin `agenda` (service registry). A agenda é
    compartilhada com o e-mail do profissional (dono, recebe o e-mail de
    confirmação do Google) e, se a setting `clinic_email` estiver preenchida,
    também com a clínica como leitor — garantindo a visibilidade central
    sem nunca cruzar agenda de um médico com a de outro (Etapa 6).
    """
    gateway = _agenda_gateway()
    if gateway is None:
        raise HTTPException(
            status_code=503,
            detail="Plugin 'agenda' não está ativo. Ative-o e configure as credenciais do Google.",
        )

    with make_plugin_db() as conn:
        prof = conn.execute(
            text(
                "SELECT id, nome, email, google_calendar_id "
                "FROM plugin_clinica_profissionais WHERE id = :id"
            ),
            {"id": prof_id},
        ).mappings().first()
    if not prof:
        raise HTTPException(status_code=404, detail="Profissional não encontrado.")
    if prof["google_calendar_id"]:
        raise HTTPException(
            status_code=400,
            detail="Este profissional já tem uma agenda Google vinculada.",
        )
    if not (prof["email"] or "").strip():
        raise HTTPException(
            status_code=400,
            detail="Cadastre o e-mail do profissional antes de criar a agenda Google.",
        )

    label = f"Agenda — {prof['nome']}"
    try:
        cal = await asyncio.to_thread(
            gateway.create_calendar_for,
            prof["email"].strip(),
            label,
            _clinic_email() or None,  # share_with: clínica como leitor (Etapa 6)
        )
    except Exception as exc:
        logger.exception("[clinica] falha ao criar agenda Google prof=%s: %s", prof_id, exc)
        raise HTTPException(status_code=502, detail=f"Erro ao criar agenda no Google: {exc}")

    calendar_id = cal.get("calendar_id")
    with make_plugin_db() as conn:
        conn.execute(
            text(
                "UPDATE plugin_clinica_profissionais "
                "SET google_calendar_id = :cid WHERE id = :id"
            ),
            {"cid": calendar_id, "id": prof_id},
        )
    logger.info("[clinica] agenda Google criada prof=%s cal=%s", prof_id, calendar_id)
    return _ok({
        "id": prof_id,
        "google_calendar_id": calendar_id,
        "share_state": cal.get("share_state"),
        "clinic_shared": bool(cal.get("clinic_shared")),
    })


@router.delete("/admin/profissionais/{prof_id}/google-calendar")
async def admin_desvincular_agenda_google(prof_id: int) -> dict:
    """Desvincula a agenda Google do profissional (não apaga no Google).

    Apenas limpa `google_calendar_id` — novos agendamentos param de espelhar.
    A agenda continua existindo no Google; o gateway mantém seu próprio espelho.
    """
    with make_plugin_db() as conn:
        result = conn.execute(
            text(
                "UPDATE plugin_clinica_profissionais "
                "SET google_calendar_id = NULL WHERE id = :id"
            ),
            {"id": prof_id},
        )
        if result.rowcount == 0:
            raise HTTPException(status_code=404, detail="Profissional não encontrado.")
    logger.info("[clinica] agenda Google desvinculada prof=%s", prof_id)
    return _ok({"id": prof_id, "google_calendar_id": None})


# ──────────────────────────────────────────────────────────────────────────
# Admin — Serviços
# ──────────────────────────────────────────────────────────────────────────


@router.get("/admin/servicos")
async def admin_list_servicos() -> dict:
    """Lista TODOS (ativos e inativos), para o painel admin."""
    with make_plugin_db() as conn:
        rows = conn.execute(text(
            "SELECT id, nome, descricao, duracao_min, valor_centavos, ativo, created_at "
            "FROM plugin_clinica_servicos "
            "ORDER BY ativo DESC, nome"
        )).mappings().all()
    return _ok([dict(r) for r in rows])


@router.post("/admin/servicos")
async def admin_create_servico(body: ServicoIn) -> dict:
    now = int(time.time())
    with make_plugin_db() as conn:
        new_id = conn.execute(
            text(
                "INSERT INTO plugin_clinica_servicos "
                "(nome, descricao, duracao_min, valor_centavos, ativo, created_at) "
                "VALUES (:nome, :desc, :dur, :val, 1, :ts) RETURNING id"
            ),
            {
                "nome": body.nome,
                "desc": body.descricao,
                "dur": body.duracao_min,
                "val": body.valor_centavos,
                "ts": now,
            },
        ).scalar_one()
    logger.info("[clinica] servico criado id=%s nome=%s", new_id, body.nome)
    return _ok({
        "id": new_id,
        "nome": body.nome,
        "descricao": body.descricao,
        "duracao_min": body.duracao_min,
        "valor_centavos": body.valor_centavos,
        "ativo": 1,
    })


@router.put("/admin/servicos/{srv_id}")
async def admin_update_servico(srv_id: int, body: ServicoIn) -> dict:
    with make_plugin_db() as conn:
        result = conn.execute(
            text(
                "UPDATE plugin_clinica_servicos "
                "SET nome = :nome, descricao = :desc, "
                "    duracao_min = :dur, valor_centavos = :val "
                "WHERE id = :id"
            ),
            {
                "nome": body.nome,
                "desc": body.descricao,
                "dur": body.duracao_min,
                "val": body.valor_centavos,
                "id": srv_id,
            },
        )
        if result.rowcount == 0:
            raise HTTPException(status_code=404, detail="Serviço não encontrado.")
    return _ok({
        "id": srv_id,
        "nome": body.nome,
        "descricao": body.descricao,
        "duracao_min": body.duracao_min,
        "valor_centavos": body.valor_centavos,
    })


@router.post("/admin/servicos/{srv_id}/toggle")
async def admin_toggle_servico(srv_id: int) -> dict:
    with make_plugin_db() as conn:
        result = conn.execute(
            text("UPDATE plugin_clinica_servicos SET ativo = 1 - ativo WHERE id = :id"),
            {"id": srv_id},
        )
        if result.rowcount == 0:
            raise HTTPException(status_code=404, detail="Serviço não encontrado.")
        novo = conn.execute(
            text("SELECT ativo FROM plugin_clinica_servicos WHERE id = :id"),
            {"id": srv_id},
        ).scalar()
    return _ok({"id": srv_id, "ativo": int(novo)})


# ──────────────────────────────────────────────────────────────────────────
# Admin — Vínculos serviço ↔ profissional (Etapa 3)
#
# A relação é N:N: um profissional atende vários serviços e um serviço pode
# ser atendido por vários profissionais. Guardada em
# `plugin_clinica_servicos_profissionais (servico_id, profissional_id)`.
#
# Endpoint do tipo "snapshot replace": o frontend manda a lista completa de
# profissionais que devem ficar vinculados ao serviço e o backend apaga +
# reinsere. É mais simples que diff incremental e atômico dentro do begin().
# ──────────────────────────────────────────────────────────────────────────


class VinculoItemIn(BaseModel):
    """Um vínculo profissional↔serviço, com preço opcional.

    `valor_centavos = None` significa "herda o preço base do serviço".
    """

    profissional_id: int
    valor_centavos: int | None = Field(default=None, ge=0)


class VinculoServicoIn(BaseModel):
    """Conjunto completo de profissionais que atendem o serviço.

    Aceita dois formatos (o handler normaliza):
    - novo: `vinculos = [{profissional_id, valor_centavos?}]` (com preço por profissional)
    - legado: `profissional_ids = [int]` (preço herda o base do serviço)
    """

    vinculos: list[VinculoItemIn] | None = None
    profissional_ids: list[int] | None = None


class VinculoProfissionalIn(BaseModel):
    """Conjunto completo de serviços atendidos pelo profissional."""

    servico_ids: list[int] = Field(default_factory=list)


def _ensure_servico_exists(conn, srv_id: int) -> None:
    found = conn.execute(
        text("SELECT 1 FROM plugin_clinica_servicos WHERE id = :id"),
        {"id": srv_id},
    ).scalar()
    if not found:
        raise HTTPException(status_code=404, detail="Serviço não encontrado.")


def _ensure_profissional_exists(conn, prof_id: int) -> None:
    found = conn.execute(
        text("SELECT 1 FROM plugin_clinica_profissionais WHERE id = :id"),
        {"id": prof_id},
    ).scalar()
    if not found:
        raise HTTPException(status_code=404, detail="Profissional não encontrado.")


def _validate_ids(conn, table: str, ids: list[int], label: str) -> None:
    """Valida que TODOS os ids existem na tabela; senão 400 com a lista que faltou."""
    if not ids:
        return
    # IN(...) com placeholders nomeados — text() não suporta expandable params
    # cross-dialect sem bindparam(), então construímos `:p0, :p1, ...`.
    placeholders = ", ".join(f":p{i}" for i in range(len(ids)))
    params = {f"p{i}": pid for i, pid in enumerate(ids)}
    found = set(
        conn.execute(
            text(f"SELECT id FROM {table} WHERE id IN ({placeholders})"),
            params,
        ).scalars().all()
    )
    missing = sorted(set(ids) - found)
    if missing:
        raise HTTPException(
            status_code=400,
            detail=f"{label} não encontrados: {missing}",
        )


@router.get("/admin/vinculos")
async def admin_list_vinculos() -> dict:
    """Matriz completa: `{ servico_id: [{profissional_id, valor_centavos}] }`.

    Carregada de uma vez pela UI para mostrar a contagem de profissionais
    em cada serviço (e o preço por profissional) sem disparar N requisições.
    `valor_centavos` pode vir `null` — significa "herda o preço base do serviço".
    """
    with make_plugin_db() as conn:
        rows = conn.execute(
            text(
                "SELECT servico_id, profissional_id, valor_centavos "
                "FROM plugin_clinica_servicos_profissionais "
                "ORDER BY servico_id, profissional_id"
            )
        ).mappings().all()
    matriz: dict[str, list[dict]] = {}
    for r in rows:
        matriz.setdefault(str(r["servico_id"]), []).append({
            "profissional_id": r["profissional_id"],
            "valor_centavos": r["valor_centavos"],
        })
    # JSON object keys são string; o frontend faz parseInt na chave quando precisa.
    return _ok(matriz)


@router.get("/admin/servicos/{srv_id}/profissionais")
async def admin_get_servico_profissionais(srv_id: int) -> dict:
    """Lista os IDs de profissionais vinculados ao serviço (ativos OU inativos)."""
    with make_plugin_db() as conn:
        _ensure_servico_exists(conn, srv_id)
        ids = conn.execute(
            text(
                "SELECT profissional_id FROM plugin_clinica_servicos_profissionais "
                "WHERE servico_id = :id ORDER BY profissional_id"
            ),
            {"id": srv_id},
        ).scalars().all()
    return _ok({"servico_id": srv_id, "profissional_ids": list(ids)})


@router.put("/admin/servicos/{srv_id}/profissionais")
async def admin_set_servico_profissionais(
    srv_id: int, body: VinculoServicoIn
) -> dict:
    """Define quais profissionais atendem o serviço (substitui o conjunto inteiro).

    Estratégia "replace all": apaga os vínculos do serviço e reinsere a lista
    enviada, com o preço por profissional (`valor_centavos`, ou `None` = base).
    """
    # Normaliza os dois formatos aceitos para {profissional_id: valor_centavos|None}.
    if body.vinculos is not None:
        precos = {v.profissional_id: v.valor_centavos for v in body.vinculos}
    elif body.profissional_ids is not None:
        precos = {pid: None for pid in body.profissional_ids}
    else:
        precos = {}
    ids = sorted(precos)  # dedup + ordem estável
    now = int(time.time())
    with make_plugin_db() as conn:
        _ensure_servico_exists(conn, srv_id)
        _validate_ids(conn, "plugin_clinica_profissionais", ids, "Profissionais")
        conn.execute(
            text(
                "DELETE FROM plugin_clinica_servicos_profissionais "
                "WHERE servico_id = :id"
            ),
            {"id": srv_id},
        )
        for pid in ids:
            conn.execute(
                text(
                    "INSERT INTO plugin_clinica_servicos_profissionais "
                    "(servico_id, profissional_id, valor_centavos, created_at) "
                    "VALUES (:s, :p, :val, :ts)"
                ),
                {"s": srv_id, "p": pid, "val": precos[pid], "ts": now},
            )
    logger.info("[clinica] vinculos servico=%s profissionais=%s", srv_id, ids)
    return _ok({"servico_id": srv_id, "profissional_ids": ids})


@router.get("/admin/profissionais/{prof_id}/servicos")
async def admin_get_profissional_servicos(prof_id: int) -> dict:
    """Lista os IDs de serviços que o profissional atende."""
    with make_plugin_db() as conn:
        _ensure_profissional_exists(conn, prof_id)
        ids = conn.execute(
            text(
                "SELECT servico_id FROM plugin_clinica_servicos_profissionais "
                "WHERE profissional_id = :id ORDER BY servico_id"
            ),
            {"id": prof_id},
        ).scalars().all()
    return _ok({"profissional_id": prof_id, "servico_ids": list(ids)})


@router.put("/admin/profissionais/{prof_id}/servicos")
async def admin_set_profissional_servicos(
    prof_id: int, body: VinculoProfissionalIn
) -> dict:
    """Define quais serviços o profissional atende (substitui o conjunto).

    Preserva os preços (`valor_centavos`) já definidos por par — o preço é
    editado pela aba Serviços, então este replace-all não pode descartá-los.
    """
    ids = sorted(set(body.servico_ids))
    now = int(time.time())
    with make_plugin_db() as conn:
        _ensure_profissional_exists(conn, prof_id)
        _validate_ids(conn, "plugin_clinica_servicos", ids, "Serviços")
        # Captura preços atuais para reaplicar nos vínculos que permanecem.
        precos_atuais = {
            row[0]: row[1]
            for row in conn.execute(
                text(
                    "SELECT servico_id, valor_centavos "
                    "FROM plugin_clinica_servicos_profissionais "
                    "WHERE profissional_id = :id"
                ),
                {"id": prof_id},
            ).all()
        }
        conn.execute(
            text(
                "DELETE FROM plugin_clinica_servicos_profissionais "
                "WHERE profissional_id = :id"
            ),
            {"id": prof_id},
        )
        for sid in ids:
            conn.execute(
                text(
                    "INSERT INTO plugin_clinica_servicos_profissionais "
                    "(servico_id, profissional_id, valor_centavos, created_at) "
                    "VALUES (:s, :p, :val, :ts)"
                ),
                {"s": sid, "p": prof_id, "val": precos_atuais.get(sid), "ts": now},
            )
    logger.info("[clinica] vinculos profissional=%s servicos=%s", prof_id, ids)
    return _ok({"profissional_id": prof_id, "servico_ids": ids})


# ──────────────────────────────────────────────────────────────────────────
# Admin — Horários de atendimento (Etapa 4)
#
# Cada registro é um bloco semanal recorrente por profissional:
#   "toda <dia_semana> das <hora_inicio> às <hora_fim>".
#
# dia_semana segue a convenção de Python (0=seg ... 6=dom) para facilitar
# o cálculo de slots disponíveis na Etapa 5.
# Horas em TEXT "HH:MM" — comparação lexicográfica funciona corretamente.
# ──────────────────────────────────────────────────────────────────────────


class HorarioIn(BaseModel):
    dia_semana: int = Field(ge=0, le=6, description="0=segunda … 6=domingo")
    hora_inicio: str = Field(pattern=r"^\d{2}:\d{2}$", description="HH:MM")
    hora_fim: str = Field(pattern=r"^\d{2}:\d{2}$", description="HH:MM")

    @field_validator("hora_inicio", "hora_fim")
    @classmethod
    def _valid_time(cls, v: str) -> str:
        h, m = v.split(":")
        if not (0 <= int(h) <= 23 and 0 <= int(m) <= 59):
            raise ValueError("Hora inválida.")
        return v


@router.get("/admin/horarios")
async def admin_list_all_horarios() -> dict:
    """Todos os horários agrupados por profissional: `{profissional_id: [{...}]}`.

    Carregado de uma vez pela UI para exibir contagens sem N+1.
    """
    with make_plugin_db() as conn:
        rows = conn.execute(text(
            "SELECT id, profissional_id, dia_semana, hora_inicio, hora_fim, ativo "
            "FROM plugin_clinica_horarios "
            "ORDER BY profissional_id, dia_semana, hora_inicio"
        )).mappings().all()
    result: dict[str, list] = {}
    for r in rows:
        d = dict(r)
        key = str(d["profissional_id"])
        result.setdefault(key, []).append(d)
    return _ok(result)


@router.get("/admin/profissionais/{prof_id}/horarios")
async def admin_get_horarios(prof_id: int) -> dict:
    """Lista os horários de um profissional, ordenados por dia e hora."""
    with make_plugin_db() as conn:
        _ensure_profissional_exists(conn, prof_id)
        rows = conn.execute(
            text(
                "SELECT id, dia_semana, hora_inicio, hora_fim, ativo "
                "FROM plugin_clinica_horarios "
                "WHERE profissional_id = :id "
                "ORDER BY dia_semana, hora_inicio"
            ),
            {"id": prof_id},
        ).mappings().all()
    return _ok([dict(r) for r in rows])


@router.post("/admin/profissionais/{prof_id}/horarios")
async def admin_create_horario(prof_id: int, body: HorarioIn) -> dict:
    """Adiciona um bloco de horário ao profissional."""
    if body.hora_fim <= body.hora_inicio:
        raise HTTPException(status_code=400, detail="hora_fim deve ser maior que hora_inicio.")
    now = int(time.time())
    with make_plugin_db() as conn:
        _ensure_profissional_exists(conn, prof_id)
        new_id = conn.execute(
            text(
                "INSERT INTO plugin_clinica_horarios "
                "(profissional_id, dia_semana, hora_inicio, hora_fim, ativo, created_at) "
                "VALUES (:pid, :dia, :ini, :fim, 1, :ts) RETURNING id"
            ),
            {
                "pid": prof_id,
                "dia": body.dia_semana,
                "ini": body.hora_inicio,
                "fim": body.hora_fim,
                "ts": now,
            },
        ).scalar_one()
    logger.info(
        "[clinica] horario criado id=%s prof=%s dia=%s %s-%s",
        new_id, prof_id, body.dia_semana, body.hora_inicio, body.hora_fim,
    )
    return _ok({
        "id": new_id,
        "profissional_id": prof_id,
        "dia_semana": body.dia_semana,
        "hora_inicio": body.hora_inicio,
        "hora_fim": body.hora_fim,
        "ativo": 1,
    })


# ──────────────────────────────────────────────────────────────────────────
# Slots disponíveis (Etapa 5)
#
# Dada uma (data, serviço), retorna por profissional apto a lista de horários
# de início onde o atendimento cabe inteiro dentro de algum bloco semanal.
#
# Step = duração do serviço — slots adjacentes não se sobrepõem, decisão
# que simplifica a subtração de agendamentos ocupados.
#
# Etapa 6: descontamos agendamentos não-cancelados do mesmo profissional/data
# cujas janelas [hora_inicio, hora_fim) colidem com a janela do slot candidato.
# ──────────────────────────────────────────────────────────────────────────


def _hhmm_to_min(s: str) -> int:
    h, m = s.split(":")
    return int(h) * 60 + int(m)


def _min_to_hhmm(t: int) -> str:
    return f"{t // 60:02d}:{t % 60:02d}"


def _generate_slots(hora_inicio: str, hora_fim: str, duracao_min: int) -> list[str]:
    """Slots de início dentro de [hora_inicio, hora_fim] cujo término cabe no bloco.

    Step = duracao_min. Ex: bloco 09:00–12:00 com duração 60 → ["09:00","10:00","11:00"].
    """
    start = _hhmm_to_min(hora_inicio)
    end = _hhmm_to_min(hora_fim)
    slots: list[str] = []
    t = start
    while t + duracao_min <= end:
        slots.append(_min_to_hhmm(t))
        t += duracao_min
    return slots


# ──────────────────────────────────────────────────────────────────────────
# Bloqueios de agenda (docs/bloqueios-agenda.md)
#
# Um bloqueio tranca parte (ou todo) o expediente de um profissional num
# intervalo de datas. Helpers de leitura compartilhados pelos 3 pontos de
# disponibilidade (slots do dia, contagem mensal e validação na reserva).
# ──────────────────────────────────────────────────────────────────────────


def _bloqueios_no_intervalo(
    conn, prof_ids: list[int] | None, data_ini: str, data_fim: str
) -> dict[int, list[dict]]:
    """Bloqueios que tocam o intervalo `[data_ini, data_fim]`, por profissional.

    Um bloqueio toca o intervalo quando `data_inicio <= data_fim` do intervalo
    pedido E `data_fim >= data_ini` (comparação lexicográfica de YYYY-MM-DD).
    `prof_ids=None` traz todos; lista vazia traz `{}` sem ir ao banco.
    """
    if prof_ids is not None and not prof_ids:
        return {}

    params: dict[str, Any] = {"ini": data_ini, "fim": data_fim}
    prof_filter = ""
    if prof_ids is not None:
        placeholders = ", ".join(f":b{i}" for i in range(len(prof_ids)))
        prof_filter = f" AND profissional_id IN ({placeholders})"
        for i, pid in enumerate(prof_ids):
            params[f"b{i}"] = pid

    rows = conn.execute(
        text(
            "SELECT id, profissional_id, data_inicio, data_fim, dia_inteiro, "
            "       hora_inicio, hora_fim, motivo, origem "
            "FROM plugin_clinica_bloqueios "
            "WHERE data_inicio <= :fim AND data_fim >= :ini"
            + prof_filter
        ),
        params,
    ).mappings().all()

    por_prof: dict[int, list[dict]] = {}
    for r in rows:
        por_prof.setdefault(r["profissional_id"], []).append(dict(r))
    return por_prof


def _slot_bloqueado(
    bloqueios_do_prof: list[dict], data: str, ini_min: int, fim_min: int
) -> bool:
    """True se a janela `[ini_min, fim_min)` (minutos) na `data` cai num bloqueio.

    `bloqueios_do_prof` é a lista já filtrada para um profissional (saída de
    `_bloqueios_no_intervalo`). Para cada bloqueio que cobre a `data`:
    dia inteiro tranca sempre; faixa tranca se intersecta a janela do slot.
    """
    for b in bloqueios_do_prof:
        if not (b["data_inicio"] <= data <= b["data_fim"]):
            continue
        if b["dia_inteiro"]:
            return True
        ai = _hhmm_to_min(b["hora_inicio"])
        af = _hhmm_to_min(b["hora_fim"])
        # Overlap [ini_min, fim_min) ∩ [ai, af) ≠ ∅ ⇔ ini_min < af AND fim_min > ai
        if ini_min < af and fim_min > ai:
            return True
    return False


def _compute_slots(
    srv_id: int, data: str, profissional_id: int | None = None
) -> dict:
    """Núcleo síncrono de `GET /servicos/{id}/slots` — sem I/O assíncrono.

    Extraído do endpoint para ser reutilizável pela tool `clinica_horarios_disponiveis`
    do agendamento por IA, que roda fora do ciclo de request do FastAPI (não pode
    `await` a rota). Levanta `HTTPException` nas mesmas condições da rota.
    """
    try:
        d = date.fromisoformat(data)
    except ValueError:
        raise HTTPException(status_code=400, detail="Data inválida. Use YYYY-MM-DD.")

    today = date.today()
    if d < today:
        raise HTTPException(status_code=400, detail="Data no passado.")

    dia_semana = d.weekday()  # 0=seg … 6=dom (idêntico à convenção do schema)
    is_today = d == today
    now_hhmm = datetime.now().strftime("%H:%M") if is_today else None

    with make_plugin_db() as conn:
        srv = conn.execute(
            text(
                "SELECT id, nome, descricao, duracao_min, valor_centavos "
                "FROM plugin_clinica_servicos WHERE id = :id AND ativo = 1"
            ),
            {"id": srv_id},
        ).mappings().first()
        if not srv:
            raise HTTPException(status_code=404, detail="Serviço não encontrado ou inativo.")

        # Uma única query traz os blocos do dia para todos os profissionais
        # ativos vinculados ao serviço. Sem N+1.
        params: dict[str, Any] = {"srv": srv_id, "dia": dia_semana}
        prof_filter = ""
        if profissional_id is not None:
            prof_filter = " AND p.id = :pid"
            params["pid"] = profissional_id
        rows = conn.execute(
            text(
                "SELECT p.id AS prof_id, p.nome AS prof_nome, "
                "       p.especialidade AS prof_esp, "
                "       sp.valor_centavos AS override, "
                "       h.hora_inicio, h.hora_fim "
                "FROM plugin_clinica_profissionais p "
                "JOIN plugin_clinica_servicos_profissionais sp "
                "  ON sp.profissional_id = p.id "
                "JOIN plugin_clinica_horarios h "
                "  ON h.profissional_id = p.id "
                "WHERE sp.servico_id = :srv "
                "  AND p.ativo = 1 AND h.ativo = 1 "
                "  AND h.dia_semana = :dia "
                + prof_filter +
                " ORDER BY p.nome, h.hora_inicio"
            ),
            params,
        ).mappings().all()

        # Agendamentos vigentes na data — usados para subtrair slots ocupados.
        # Filtramos por status != 'cancelado' (pendente OU confirmado bloqueiam).
        ocupados_rows = conn.execute(
            text(
                "SELECT profissional_id, hora_inicio, hora_fim "
                "FROM plugin_clinica_agendamentos "
                "WHERE data = :d AND status != 'cancelado'"
            ),
            {"d": data},
        ).mappings().all()

        # Bloqueios que tocam a data — trancam o dia (ou faixas dele) por prof.
        prof_ids = sorted({r["prof_id"] for r in rows})
        bloqueios_por_prof = _bloqueios_no_intervalo(conn, prof_ids, data, data)

    # Indexa as janelas ocupadas por profissional, em minutos pra comparação rápida.
    ocupados_por_prof: dict[int, list[tuple[int, int]]] = {}
    for o in ocupados_rows:
        ocupados_por_prof.setdefault(o["profissional_id"], []).append(
            (_hhmm_to_min(o["hora_inicio"]), _hhmm_to_min(o["hora_fim"]))
        )

    duracao = int(srv["duracao_min"])
    by_prof: dict[int, dict] = {}
    for r in rows:
        pid = r["prof_id"]
        if pid not in by_prof:
            by_prof[pid] = {
                "id": pid,
                "nome": r["prof_nome"],
                "especialidade": r["prof_esp"] or "",
                "valor_centavos": (
                    int(r["override"]) if r["override"] is not None
                    else int(srv["valor_centavos"])
                ),
                "slots": [],
            }
        janelas_ocupadas = ocupados_por_prof.get(pid, [])
        bloqueios_prof = bloqueios_por_prof.get(pid, [])
        for slot in _generate_slots(r["hora_inicio"], r["hora_fim"], duracao):
            if is_today and slot <= now_hhmm:
                continue
            # Overlap: [slot, slot+dur) ∩ [ai, af) ≠ ∅ ⇔ slot < af AND slot+dur > ai
            s_ini = _hhmm_to_min(slot)
            s_fim = s_ini + duracao
            if any(s_ini < af and s_fim > ai for ai, af in janelas_ocupadas):
                continue
            if _slot_bloqueado(bloqueios_prof, data, s_ini, s_fim):
                continue
            by_prof[pid]["slots"].append(slot)

    # Dedup + ordena (proteção contra blocos sobrepostos no mesmo dia).
    # Profissionais sem slots ficam de fora — UI mostra "indisponível".
    profissionais = []
    for p in by_prof.values():
        p["slots"] = sorted(set(p["slots"]))
        if p["slots"]:
            profissionais.append(p)

    return {
        "data": data,
        "dia_semana": dia_semana,
        "servico": dict(srv),
        "profissionais": profissionais,
    }


@router.get("/servicos/{srv_id}/slots")
async def public_get_slots(
    srv_id: int,
    data: str = Query(..., description="Data desejada no formato YYYY-MM-DD"),
    profissional_id: int | None = Query(None, description="Filtrar por um profissional"),
) -> dict:
    """Horários disponíveis para um serviço numa data específica.

    Retorna a lista de profissionais aptos ao serviço e, para cada um, os
    horários de início onde o atendimento cabe nos blocos cadastrados no
    `dia_semana` da `data`. Profissionais sem slots no dia são omitidos.
    """
    return _ok(_compute_slots(srv_id, data, profissional_id))


# ──────────────────────────────────────────────────────────────────────────
# Disponibilidade do mês (Etapa 6 — calendário público)
#
# Retorna, pra cada dia do mês pedido, a contagem de slots livres pro serviço
# (opcionalmente filtrado por profissional). O frontend usa essa informação
# pra pintar o calendário: dias com 0 vagas ficam acinzentados, dias com
# vagas ficam clicáveis com indicador visual.
#
# Estratégia: carrega TUDO uma vez (horários elegíveis + agendamentos do mês)
# e itera por dia em Python. Para escala didática (3 profs, ~30 dias) é
# barato e simples de ler.
# ──────────────────────────────────────────────────────────────────────────


@router.get("/servicos/{srv_id}/disponibilidade")
async def public_get_disponibilidade(
    srv_id: int,
    mes: str = Query(..., description="Mês desejado no formato YYYY-MM"),
    profissional_id: int | None = Query(None, description="Filtrar por um profissional"),
) -> dict:
    """Contagem de slots livres por dia, para o mês inteiro."""
    try:
        ano, mes_num = mes.split("-")
        ano_i, mes_i = int(ano), int(mes_num)
        primeiro = date(ano_i, mes_i, 1)
    except (ValueError, TypeError):
        raise HTTPException(status_code=400, detail="Mês inválido. Use YYYY-MM.")
    _, ultimo_dia = monthrange(ano_i, mes_i)
    ultimo = date(ano_i, mes_i, ultimo_dia)

    today = date.today()
    now_hhmm = datetime.now().strftime("%H:%M")

    with make_plugin_db() as conn:
        srv = conn.execute(
            text(
                "SELECT id, duracao_min FROM plugin_clinica_servicos "
                "WHERE id = :id AND ativo = 1"
            ),
            {"id": srv_id},
        ).mappings().first()
        if not srv:
            raise HTTPException(status_code=404, detail="Serviço não encontrado ou inativo.")
        duracao = int(srv["duracao_min"])

        # Horários elegíveis: profissionais ativos vinculados ao serviço.
        params: dict[str, Any] = {"srv": srv_id}
        prof_filter = ""
        if profissional_id is not None:
            prof_filter = " AND p.id = :pid"
            params["pid"] = profissional_id
        horarios = conn.execute(
            text(
                "SELECT p.id AS prof_id, h.dia_semana, h.hora_inicio, h.hora_fim "
                "FROM plugin_clinica_profissionais p "
                "JOIN plugin_clinica_servicos_profissionais sp "
                "  ON sp.profissional_id = p.id "
                "JOIN plugin_clinica_horarios h "
                "  ON h.profissional_id = p.id "
                "WHERE sp.servico_id = :srv "
                "  AND p.ativo = 1 AND h.ativo = 1 "
                + prof_filter
            ),
            params,
        ).mappings().all()

        # Agendamentos do mês inteiro (não cancelados), só dos profs elegíveis.
        # Filtrar por intervalo de data é eficiente com o índice (data, prof).
        ocupados_rows = conn.execute(
            text(
                "SELECT profissional_id, data, hora_inicio, hora_fim "
                "FROM plugin_clinica_agendamentos "
                "WHERE data >= :ini AND data <= :fim AND status != 'cancelado'"
            ),
            {"ini": primeiro.isoformat(), "fim": ultimo.isoformat()},
        ).mappings().all()

        # Bloqueios que tocam qualquer dia do mês, por profissional elegível.
        prof_ids = sorted({h["prof_id"] for h in horarios})
        bloqueios_por_prof = _bloqueios_no_intervalo(
            conn, prof_ids, primeiro.isoformat(), ultimo.isoformat()
        )

    # Indexa horários por (prof_id, dia_semana) e ocupados por (prof_id, data).
    horarios_idx: dict[tuple[int, int], list[tuple[str, str]]] = {}
    for h in horarios:
        horarios_idx.setdefault((h["prof_id"], h["dia_semana"]), []).append(
            (h["hora_inicio"], h["hora_fim"])
        )
    ocupados_idx: dict[tuple[int, str], list[tuple[int, int]]] = {}
    for o in ocupados_rows:
        ocupados_idx.setdefault((o["profissional_id"], o["data"]), []).append(
            (_hhmm_to_min(o["hora_inicio"]), _hhmm_to_min(o["hora_fim"]))
        )

    # Itera dia a dia. Dias passados → 0 (não aparecem como disponíveis).
    resultado: dict[str, int] = {}
    dia = primeiro
    while dia <= ultimo:
        iso = dia.isoformat()
        if dia < today:
            resultado[iso] = 0
            dia += timedelta(days=1)
            continue
        is_today = dia == today
        dia_semana = dia.weekday()
        total = 0
        # Pra cada profissional elegível, soma seus slots não ocupados.
        profs_no_dia = {pid for (pid, ds) in horarios_idx if ds == dia_semana}
        for pid in profs_no_dia:
            blocos = horarios_idx.get((pid, dia_semana), [])
            janelas = ocupados_idx.get((pid, iso), [])
            bloqueios_prof = bloqueios_por_prof.get(pid, [])
            for ini, fim in blocos:
                for slot in _generate_slots(ini, fim, duracao):
                    if is_today and slot <= now_hhmm:
                        continue
                    s_ini = _hhmm_to_min(slot)
                    s_fim = s_ini + duracao
                    if any(s_ini < af and s_fim > ai for ai, af in janelas):
                        continue
                    if _slot_bloqueado(bloqueios_prof, iso, s_ini, s_fim):
                        continue
                    total += 1
        resultado[iso] = total
        dia += timedelta(days=1)

    return _ok({
        "mes": mes,
        "servico_id": srv_id,
        "profissional_id": profissional_id,
        "dias": resultado,
    })


# ──────────────────────────────────────────────────────────────────────────
# Agendamentos (Etapa 6)
#
# Fluxo público: o cliente escolhe serviço → data → profissional → horário,
# preenche nome e telefone, e o POST cria um agendamento com status
# 'pendente_pagamento'. Etapa 8 vai gerar o link de pagamento; Etapa 9 vai
# atualizar o status para 'confirmado' quando o pagamento for detectado.
#
# Validações server-side (defesa contra UI desatualizada e race):
#   - serviço existe e está ativo
#   - profissional existe, está ativo e atende o serviço
#   - profissional tem horário cadastrado naquele dia da semana cobrindo
#     [hora_inicio, hora_fim] do slot pedido
#   - não há agendamento conflitante no mesmo profissional/data
#   - data não está no passado
# ──────────────────────────────────────────────────────────────────────────


class AgendamentoIn(BaseModel):
    servico_id: int = Field(gt=0)
    # null = "qualquer profissional disponível" — backend escolhe um apto.
    profissional_id: int | None = Field(default=None, ge=1)
    data: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$", description="YYYY-MM-DD")
    hora_inicio: str = Field(pattern=r"^\d{2}:\d{2}$", description="HH:MM")
    cliente_nome: str = Field(min_length=2, max_length=200)
    cliente_telefone: str = Field(min_length=10, max_length=30)
    # Etapa 12.5: token do convite gerado pela tool enviar_link_agendamento.
    # Quando vem preenchido e é válido, marca used_at no convite — métrica de
    # conversão "links enviados pela IA → agendamentos efetivados".
    convite_token: str | None = Field(default=None, max_length=64)

    @field_validator("cliente_nome")
    @classmethod
    def _strip_nome(cls, v: str) -> str:
        v = v.strip()
        if len(v) < 2:
            raise ValueError("Nome muito curto.")
        return v

    @field_validator("cliente_telefone")
    @classmethod
    def _normalize_phone(cls, v: str) -> str:
        # Aceita qualquer entrada com formatação ("(11) 99999-0000", "+55 11 ...")
        # mas grava apenas os dígitos. Validação dupla com o frontend.
        digits = "".join(ch for ch in (v or "") if ch.isdigit())
        # Brasil: 10 (fixo) ou 11 (celular). Aceita também com DDI 55 (12-13 dígitos).
        if len(digits) < 10 or len(digits) > 13:
            raise ValueError(
                "WhatsApp inválido. Use DDD + número (ex: 11 99999-0000)."
            )
        return digits


def _criar_agendamento(
    *,
    servico_id: int,
    profissional_id: int | None,
    data: str,
    hora_inicio: str,
    cliente_nome: str,
    cliente_telefone: str,
    status: str,
    convite_token: str | None = None,
) -> dict:
    """Núcleo de criação de agendamento, compartilhado pelos fluxos público e admin.

    O fluxo público (`POST /agendamentos`) cria sempre como 'pendente_pagamento';
    o admin (`POST /admin/agendamentos`) passa o status escolhido na recepção
    (normalmente 'confirmado', quando a reserva é feita por telefone/balcão).

    Aplica as mesmas validações em ambos os casos — serviço ativo, profissional
    apto, horário dentro de um bloco e sem conflito — dentro de uma única
    transação. Levanta HTTPException em qualquer falha. `profissional_id` null =
    "qualquer disponível" (backend escolhe o primeiro apto sem conflito).
    """
    try:
        d = date.fromisoformat(data)
    except ValueError:
        raise HTTPException(status_code=400, detail="Data inválida. Use YYYY-MM-DD.")
    if d < date.today():
        raise HTTPException(status_code=400, detail="Data no passado.")

    # Hoje + hora já passada também é inválido.
    if d == date.today() and hora_inicio <= datetime.now().strftime("%H:%M"):
        raise HTTPException(status_code=400, detail="Esse horário já passou.")

    dia_semana = d.weekday()
    now = int(time.time())

    with make_plugin_db() as conn:
        srv = conn.execute(
            text(
                "SELECT id, duracao_min, valor_centavos "
                "FROM plugin_clinica_servicos "
                "WHERE id = :id AND ativo = 1"
            ),
            {"id": servico_id},
        ).mappings().first()
        if not srv:
            raise HTTPException(status_code=404, detail="Serviço não encontrado ou inativo.")

        duracao = int(srv["duracao_min"])
        ini_min = _hhmm_to_min(hora_inicio)
        fim_min = ini_min + duracao
        hora_fim = _min_to_hhmm(fim_min)

        # Lista de candidatos: profissionais ativos vinculados ao serviço com
        # bloco cobrindo a janela. Se foi escolhido um, filtra; senão,
        # consideramos todos pra "qualquer disponível".
        cand_params: dict[str, Any] = {
            "sid": servico_id,
            "dia": dia_semana,
            "ini": hora_inicio,
            "fim": hora_fim,
        }
        cand_sql = (
            "SELECT p.id AS pid, sp.valor_centavos AS override "
            "FROM plugin_clinica_profissionais p "
            "JOIN plugin_clinica_servicos_profissionais sp "
            "  ON sp.profissional_id = p.id "
            "JOIN plugin_clinica_horarios h ON h.profissional_id = p.id "
            "WHERE sp.servico_id = :sid AND p.ativo = 1 AND h.ativo = 1 "
            "  AND h.dia_semana = :dia "
            "  AND h.hora_inicio <= :ini AND h.hora_fim >= :fim"
        )
        if profissional_id is not None:
            cand_sql += " AND p.id = :pid"
            cand_params["pid"] = profissional_id
        cand_rows = conn.execute(
            text(cand_sql + " GROUP BY p.id, sp.valor_centavos ORDER BY p.id"),
            cand_params,
        ).mappings().all()
        candidatos = [r["pid"] for r in cand_rows]
        # Preço resolvido por candidato: override do vínculo, ou o base do serviço.
        base_val = int(srv["valor_centavos"])
        precos = {
            r["pid"]: (int(r["override"]) if r["override"] is not None else base_val)
            for r in cand_rows
        }

        if not candidatos:
            if profissional_id is not None:
                raise HTTPException(
                    status_code=400,
                    detail="Profissional não atende esse serviço, está inativo, "
                    "ou não tem horário no intervalo escolhido.",
                )
            raise HTTPException(
                status_code=400,
                detail="Nenhum profissional disponível para esse serviço no intervalo escolhido.",
            )

        # Filtra candidatos que JÁ têm conflito nesse horário.
        # Carrega ocupações dos candidatos numa query só.
        placeholders = ", ".join(f":c{i}" for i in range(len(candidatos)))
        conf_params: dict[str, Any] = {
            "d": data, "ini": hora_inicio, "fim": hora_fim,
        }
        for i, pid in enumerate(candidatos):
            conf_params[f"c{i}"] = pid
        ocupados = set(
            conn.execute(
                text(
                    f"SELECT DISTINCT profissional_id "
                    f"FROM plugin_clinica_agendamentos "
                    f"WHERE profissional_id IN ({placeholders}) "
                    f"  AND data = :d AND status != 'cancelado' "
                    f"  AND hora_inicio < :fim AND hora_fim > :ini"
                ),
                conf_params,
            ).scalars().all()
        )
        # Bloqueios do profissional cobrindo a data/janela pedida.
        bloqueios_por_prof = _bloqueios_no_intervalo(conn, candidatos, data, data)
        bloqueados = {
            pid for pid in candidatos
            if _slot_bloqueado(bloqueios_por_prof.get(pid, []), data, ini_min, fim_min)
        }
        # Se pediram um profissional específico e ele está bloqueado, erro claro.
        if profissional_id is not None and profissional_id in bloqueados:
            raise HTTPException(
                status_code=409,
                detail="Profissional indisponível nesse horário (bloqueio).",
            )

        livres = [
            pid for pid in candidatos
            if pid not in ocupados and pid not in bloqueados
        ]
        if not livres:
            # Distingue "todos bloqueados" de "horário acabou de ser reservado".
            if bloqueados and all(pid in bloqueados for pid in candidatos):
                raise HTTPException(
                    status_code=409,
                    detail="Profissional indisponível nesse horário (bloqueio).",
                )
            raise HTTPException(
                status_code=409,
                detail="Horário acabou de ser reservado. Escolha outro.",
            )
        # Para "qualquer disponível": pega o livre de MENOR preço (desempate por
        # id, estável). Assim o cliente paga o valor anunciado "a partir de R$X".
        escolhido = min(livres, key=lambda pid: (precos[pid], pid))
        valor_escolhido = precos[escolhido]

        new_id = conn.execute(
            text(
                "INSERT INTO plugin_clinica_agendamentos "
                "(servico_id, profissional_id, cliente_nome, cliente_telefone, "
                " data, hora_inicio, hora_fim, duracao_min, valor_centavos, "
                " status, created_at) "
                "VALUES (:sid, :pid, :nome, :tel, :d, :ini, :fim, :dur, :val, "
                "        :status, :ts) RETURNING id"
            ),
            {
                "sid": servico_id,
                "pid": escolhido,
                "nome": cliente_nome,
                "tel": cliente_telefone,
                "d": data,
                "ini": hora_inicio,
                "fim": hora_fim,
                "dur": duracao,
                "val": valor_escolhido,
                "status": status,
                "ts": now,
            },
        ).scalar_one()

        # Etapa 12.5: se o cliente chegou via link gerado pela IA, marca
        # used_at no convite (apenas na primeira conversão). Falhas silenciosas
        # — token inválido/expirado não bloqueia o agendamento.
        if convite_token:
            try:
                conn.execute(
                    text(
                        "UPDATE plugin_clinica_convites "
                        "SET used_at = :ts "
                        "WHERE token = :tk AND used_at IS NULL "
                        "  AND expires_at >= :ts"
                    ),
                    {"ts": now, "tk": convite_token},
                )
            except Exception:
                logger.debug("[clinica] falha ao marcar convite %s como usado",
                             convite_token, exc_info=True)

    logger.info(
        "[clinica] agendamento criado id=%s srv=%s prof=%s (pedido=%s) %s %s-%s status=%s",
        new_id, servico_id, escolhido, profissional_id,
        data, hora_inicio, hora_fim, status,
    )
    return {
        "id": new_id,
        "servico_id": servico_id,
        "profissional_id": escolhido,
        "data": data,
        "hora_inicio": hora_inicio,
        "hora_fim": hora_fim,
        "duracao_min": duracao,
        "valor_centavos": valor_escolhido,
        "cliente_nome": cliente_nome,
        "cliente_telefone": cliente_telefone,
        "status": status,
    }


@router.post("/agendamentos")
async def public_create_agendamento(body: AgendamentoIn) -> dict:
    """Cria um agendamento (endpoint público — sem auth). Status 'pendente_pagamento'."""
    return _ok(_criar_agendamento(
        servico_id=body.servico_id,
        profissional_id=body.profissional_id,
        data=body.data,
        hora_inicio=body.hora_inicio,
        cliente_nome=body.cliente_nome,
        cliente_telefone=body.cliente_telefone,
        status="pendente_pagamento",
        convite_token=body.convite_token,
    ))


def _agendamento_publico_query(where_clause: str, params: dict) -> dict | None:
    """Núcleo compartilhado de `public_get_agendamento`/`public_get_agendamento_por_token`."""
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT a.id, a.servico_id, a.profissional_id, a.cliente_nome, "
                "       a.cliente_telefone, a.data, a.hora_inicio, a.hora_fim, "
                "       a.duracao_min, a.valor_centavos, a.status, a.mp_order_id, a.created_at, "
                "       s.nome AS servico_nome, "
                "       p.nome AS profissional_nome, "
                "       p.especialidade AS profissional_especialidade "
                "FROM plugin_clinica_agendamentos a "
                "JOIN plugin_clinica_servicos s ON s.id = a.servico_id "
                "JOIN plugin_clinica_profissionais p ON p.id = a.profissional_id "
                f"WHERE {where_clause}"
            ),
            params,
        ).mappings().first()
    return dict(row) if row else None


@router.get("/agendamentos/{ag_id}")
async def public_get_agendamento(ag_id: int) -> dict:
    """Detalhe do agendamento — usado pelo próprio fluxo visual de agendamento
    (`agendar.js`), logo após o cliente criar a reserva na MESMA sessão do
    navegador. Devolve o agendamento com nomes resolvidos (serviço,
    profissional) pra UI montar a tela de "Reserva confirmada" sem outra
    requisição.

    NÃO usar este endpoint (por ID cru) como alvo de link mandado fora dessa
    sessão — para isso existe `public_get_agendamento_por_token` (token
    opaco, não enumerável). Ver Etapa 19 item 4 em docs/clinica-vida-leve.md.
    """
    row = _agendamento_publico_query("a.id = :id", {"id": ag_id})
    if not row:
        raise HTTPException(status_code=404, detail="Agendamento não encontrado.")
    return _ok(row)


def gerar_token_pagamento(ag_id: int) -> str:
    """Gera (ou reaproveita) o token opaco de pagamento de um agendamento.

    Usado por `_montar_link_pagamento` (tools.py) pra montar o link público
    de pagamento sem expor o ID sequencial na URL — `GET /agendamentos/{id}`
    por ID cru permitiria varrer nome/telefone/serviço de qualquer reserva só
    testando IDs em sequência (dado sensível numa clínica estética).
    Idempotente: chamadas repetidas pro mesmo agendamento devolvem o MESMO
    token (não gera um novo a cada mensagem).
    """
    with make_plugin_db() as conn:
        row = conn.execute(
            text("SELECT pagamento_token FROM plugin_clinica_agendamentos WHERE id = :id"),
            {"id": ag_id},
        ).mappings().first()
        if row and row["pagamento_token"]:
            return row["pagamento_token"]

        # Colisão de token_urlsafe(6) é astronomicamente improvável em
        # escala didática — mesma decisão já tomada pelos convites
        # (plugin_clinica_convites), não vale a pena retry-on-collision.
        token = secrets.token_urlsafe(6)
        conn.execute(
            text("UPDATE plugin_clinica_agendamentos SET pagamento_token = :tk WHERE id = :id"),
            {"tk": token, "id": ag_id},
        )
    return token


@router.get("/agendamentos/por-token/{token}")
async def public_get_agendamento_por_token(token: str) -> dict:
    """Detalhe do agendamento via token de pagamento (Etapa 19, item 4) —
    alvo do link `/clinica/pagar?t=TOKEN` que `clinica_agendar`/
    `clinica_remarcar_agendamento` mandam na conversa. Mesmo formato de
    `public_get_agendamento`, mas por token opaco em vez do ID sequencial cru
    (não dá pra enumerar reservas testando valores em sequência).

    404 genérico para token inválido/inexistente — mesmo padrão de
    `public_get_convite` (não vira oráculo de quais tokens existem).
    """
    if not token or len(token) > 64:
        raise HTTPException(status_code=404, detail="Link de pagamento inválido ou expirado.")

    row = _agendamento_publico_query("a.pagamento_token = :tk", {"tk": token})
    if not row:
        raise HTTPException(status_code=404, detail="Link de pagamento inválido ou expirado.")
    return _ok(row)


# ──────────────────────────────────────────────────────────────────────────
# Etapa 12.5 — Convites de agendamento
#
# Quando a IA decide mandar o link de reservas ao cliente, ela chama a tool
# `enviar_link_agendamento` (definida em `tools.py`), que cria uma linha em
# `plugin_clinica_convites` com um token curto (`secrets.token_urlsafe(6)`)
# e devolve a URL `BASE/clinica/agendar?c=TOKEN`. Esse endpoint público é
# consultado pelo `agendar.js` no boot para pré-preencher o WhatsApp.
#
# Decisões:
#   - Resposta 404 idêntica para token inexistente ou expirado — não dá
#     oráculo de quais tokens existem.
#   - Token NÃO é invalidado no primeiro lookup (cliente pode abrir, fechar
#     e reabrir dentro dos 7 dias).
#   - Só devolve o telefone — nome fica em branco no form (cliente pode
#     ter cadastrado apelido no contato).
# ──────────────────────────────────────────────────────────────────────────


@router.get("/convites/{token}")
async def public_get_convite(token: str) -> dict:
    """Resolve um token de convite para o telefone do contato.

    Endpoint público (sem auth). Retorna `{telefone}` se o token está válido
    e dentro do prazo. 404 com mensagem genérica em qualquer outro caso.
    """
    # Sanity check antes de bater no banco — tokens reais têm ~8 chars urlsafe.
    if not token or len(token) > 64:
        raise HTTPException(status_code=404, detail="Convite expirado ou inexistente.")

    now = time.time()
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT telefone, expires_at "
                "FROM plugin_clinica_convites "
                "WHERE token = :tk"
            ),
            {"tk": token},
        ).mappings().first()

    if not row or float(row["expires_at"]) < now:
        raise HTTPException(status_code=404, detail="Convite expirado ou inexistente.")

    return _ok({"telefone": row["telefone"]})


@router.delete("/admin/horarios/{h_id}")
async def admin_delete_horario(h_id: int) -> dict:
    """Remove um bloco de horário (hard delete — não há FK apontando para esta tabela)."""
    with make_plugin_db() as conn:
        result = conn.execute(
            text("DELETE FROM plugin_clinica_horarios WHERE id = :id"),
            {"id": h_id},
        )
        if result.rowcount == 0:
            raise HTTPException(status_code=404, detail="Horário não encontrado.")
    logger.info("[clinica] horario removido id=%s", h_id)
    return _ok({"id": h_id, "deleted": True})


# ──────────────────────────────────────────────────────────────────────────
# Admin — Bloqueios de agenda (docs/bloqueios-agenda.md)
#
# CRUD dos bloqueios in-app (origem='clinica'). Bloqueios origem='google'
# são criados pelo handler de eventos (Etapa 5) e são só-leitura aqui — o
# DELETE recusa removê-los pela UI (a fonte é o Google).
# ──────────────────────────────────────────────────────────────────────────


class BloqueioIn(BaseModel):
    data_inicio: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$", description="YYYY-MM-DD")
    data_fim: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$", description="YYYY-MM-DD")
    dia_inteiro: bool = Field(default=True)
    hora_inicio: str | None = Field(default=None, description="HH:MM (só quando faixa)")
    hora_fim: str | None = Field(default=None, description="HH:MM (só quando faixa)")
    motivo: str = Field(default="", max_length=500)

    @field_validator("hora_inicio", "hora_fim")
    @classmethod
    def _valid_time(cls, v: str | None) -> str | None:
        if v is None or v == "":
            return None
        import re
        if not re.match(r"^\d{2}:\d{2}$", v):
            raise ValueError("Hora deve estar no formato HH:MM.")
        h, m = v.split(":")
        if not (0 <= int(h) <= 23 and 0 <= int(m) <= 59):
            raise ValueError("Hora inválida.")
        return v

    @field_validator("motivo")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()


def _bloqueio_row_to_dict(r) -> dict:
    """Normaliza uma linha de bloqueio (dia_inteiro como bool no JSON)."""
    d = dict(r)
    d["dia_inteiro"] = bool(d.get("dia_inteiro"))
    return d


@router.get("/admin/profissionais/{prof_id}/bloqueios")
async def admin_list_bloqueios(prof_id: int) -> dict:
    """Bloqueios do profissional: futuros + passados recentes (últimos 30 dias)."""
    corte = (date.today() - timedelta(days=30)).isoformat()
    with make_plugin_db() as conn:
        _ensure_profissional_exists(conn, prof_id)
        rows = conn.execute(
            text(
                "SELECT id, profissional_id, data_inicio, data_fim, dia_inteiro, "
                "       hora_inicio, hora_fim, motivo, origem, google_event_id, created_at "
                "FROM plugin_clinica_bloqueios "
                "WHERE profissional_id = :pid AND data_fim >= :corte "
                "ORDER BY data_inicio, hora_inicio"
            ),
            {"pid": prof_id, "corte": corte},
        ).mappings().all()
    return _ok([_bloqueio_row_to_dict(r) for r in rows])


@router.get("/admin/bloqueios")
async def admin_list_bloqueios_periodo(
    data_ini: str = Query(..., description="Data inicial YYYY-MM-DD"),
    data_fim: str = Query(..., description="Data final YYYY-MM-DD"),
) -> dict:
    """Todos os bloqueios que tocam o período (para a visão de calendário admin)."""
    with make_plugin_db() as conn:
        por_prof = _bloqueios_no_intervalo(conn, None, data_ini, data_fim)
    out = [
        _bloqueio_row_to_dict(b)
        for blist in por_prof.values()
        for b in blist
    ]
    out.sort(key=lambda b: (b["data_inicio"], b.get("hora_inicio") or "", b["id"]))
    return _ok(out)


@router.post("/admin/profissionais/{prof_id}/bloqueios")
async def admin_create_bloqueio(prof_id: int, body: BloqueioIn) -> dict:
    """Cria um bloqueio in-app (origem='clinica'). Espelha no Google (Etapa 4)."""
    if body.data_fim < body.data_inicio:
        raise HTTPException(
            status_code=400, detail="data_fim deve ser maior ou igual a data_inicio."
        )
    if body.dia_inteiro:
        hora_ini, hora_fim = None, None
    else:
        if not body.hora_inicio or not body.hora_fim:
            raise HTTPException(
                status_code=400,
                detail="Informe hora_inicio e hora_fim para bloqueio por faixa.",
            )
        if body.hora_fim <= body.hora_inicio:
            raise HTTPException(
                status_code=400, detail="hora_fim deve ser maior que hora_inicio."
            )
        hora_ini, hora_fim = body.hora_inicio, body.hora_fim

    now = time.time()
    with make_plugin_db() as conn:
        _ensure_profissional_exists(conn, prof_id)
        new_id = conn.execute(
            text(
                "INSERT INTO plugin_clinica_bloqueios "
                "(profissional_id, data_inicio, data_fim, dia_inteiro, "
                " hora_inicio, hora_fim, motivo, origem, created_at) "
                "VALUES (:pid, :di, :df, :dia, :hi, :hf, :mot, 'clinica', :ts) "
                "RETURNING id"
            ),
            {
                "pid": prof_id,
                "di": body.data_inicio,
                "df": body.data_fim,
                "dia": 1 if body.dia_inteiro else 0,
                "hi": hora_ini,
                "hf": hora_fim,
                "mot": body.motivo,
                "ts": now,
            },
        ).scalar_one()
    logger.info(
        "[clinica] bloqueio criado id=%s prof=%s %s..%s dia_inteiro=%s",
        new_id, prof_id, body.data_inicio, body.data_fim, body.dia_inteiro,
    )
    # Espelha na agenda Google do profissional (best-effort, Etapa 4).
    await asyncio.to_thread(_push_bloqueio_to_google, new_id)
    return _ok({
        "id": new_id,
        "profissional_id": prof_id,
        "data_inicio": body.data_inicio,
        "data_fim": body.data_fim,
        "dia_inteiro": body.dia_inteiro,
        "hora_inicio": hora_ini,
        "hora_fim": hora_fim,
        "motivo": body.motivo,
        "origem": "clinica",
    })


@router.delete("/admin/bloqueios/{bloqueio_id}")
async def admin_delete_bloqueio(bloqueio_id: int) -> dict:
    """Remove um bloqueio in-app e cancela o evento espelhado no Google (Etapa 4).

    Bloqueios `origem='google'` não podem ser removidos por aqui — a fonte é
    o Google; apague o evento lá que o polling remove o bloqueio (Etapa 5).
    """
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT id, origem FROM plugin_clinica_bloqueios WHERE id = :id"
            ),
            {"id": bloqueio_id},
        ).mappings().first()
        if not row:
            raise HTTPException(status_code=404, detail="Bloqueio não encontrado.")
        if row["origem"] == "google":
            raise HTTPException(
                status_code=400,
                detail="Bloqueio originado no Google — remova o evento na própria "
                "agenda do profissional.",
            )
    # Cancela no Google ANTES de apagar (ainda precisamos do google_event_id).
    await asyncio.to_thread(_cancel_bloqueio_in_google, bloqueio_id)
    with make_plugin_db() as conn:
        conn.execute(
            text("DELETE FROM plugin_clinica_bloqueios WHERE id = :id"),
            {"id": bloqueio_id},
        )
    logger.info("[clinica] bloqueio removido id=%s", bloqueio_id)
    return _ok({"id": bloqueio_id, "deleted": True})


# ──────────────────────────────────────────────────────────────────────────
# Admin — Agendamentos (Etapa 7)
#
# Painel para a clínica visualizar, confirmar e cancelar reservas.
# Filtros opcionais: status, intervalo de data, profissional_id.
# ──────────────────────────────────────────────────────────────────────────


@router.get("/admin/agendamentos")
async def admin_list_agendamentos(
    status: str | None = Query(None, description="pendente_pagamento | confirmado | cancelado"),
    data_ini: str | None = Query(None, description="Data inicial YYYY-MM-DD"),
    data_fim: str | None = Query(None, description="Data final YYYY-MM-DD"),
    profissional_id: int | None = Query(None, description="Filtrar por profissional"),
) -> dict:
    """Lista agendamentos com filtros opcionais, trazendo nomes de serviço e profissional."""
    clauses = []
    params: dict[str, Any] = {}

    if status:
        clauses.append("a.status = :status")
        params["status"] = status
    if data_ini:
        clauses.append("a.data >= :data_ini")
        params["data_ini"] = data_ini
    if data_fim:
        clauses.append("a.data <= :data_fim")
        params["data_fim"] = data_fim
    if profissional_id is not None:
        clauses.append("a.profissional_id = :pid")
        params["pid"] = profissional_id

    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""

    with make_plugin_db() as conn:
        rows = conn.execute(
            text(
                "SELECT a.id, a.servico_id, a.profissional_id, "
                "       a.cliente_nome, a.cliente_telefone, "
                "       a.data, a.hora_inicio, a.hora_fim, "
                "       a.duracao_min, a.valor_centavos, a.status, a.mp_order_id, a.created_at, "
                "       a.lembrete_enviado, "
                "       s.nome AS servico_nome, "
                "       p.nome AS profissional_nome "
                "FROM plugin_clinica_agendamentos a "
                "JOIN plugin_clinica_servicos s ON s.id = a.servico_id "
                "JOIN plugin_clinica_profissionais p ON p.id = a.profissional_id "
                + where +
                " ORDER BY a.data DESC, a.hora_inicio DESC, a.id DESC"
            ),
            params,
        ).mappings().all()
    return _ok([dict(r) for r in rows])


@router.post("/admin/agendamentos/{ag_id}/confirmar")
async def admin_confirmar_agendamento(ag_id: int) -> dict:
    """Confirma manualmente um agendamento (muda status para 'confirmado')."""
    with make_plugin_db() as conn:
        row = conn.execute(
            text("SELECT status FROM plugin_clinica_agendamentos WHERE id = :id"),
            {"id": ag_id},
        ).mappings().first()
        if not row:
            raise HTTPException(status_code=404, detail="Agendamento não encontrado.")
        if row["status"] == "cancelado":
            raise HTTPException(status_code=400, detail="Não é possível confirmar um agendamento cancelado.")
        conn.execute(
            text("UPDATE plugin_clinica_agendamentos SET status = 'confirmado' WHERE id = :id"),
            {"id": ag_id},
        )
    await asyncio.to_thread(_push_event_to_google, ag_id)
    logger.info("[clinica] agendamento confirmado id=%s", ag_id)
    return _ok({"id": ag_id, "status": "confirmado"})


@router.post("/admin/agendamentos/{ag_id}/cancelar")
async def admin_cancelar_agendamento(ag_id: int) -> dict:
    """Cancela um agendamento (libera o slot para novas reservas)."""
    with make_plugin_db() as conn:
        row = conn.execute(
            text("SELECT status FROM plugin_clinica_agendamentos WHERE id = :id"),
            {"id": ag_id},
        ).mappings().first()
        if not row:
            raise HTTPException(status_code=404, detail="Agendamento não encontrado.")
        if row["status"] == "cancelado":
            raise HTTPException(status_code=400, detail="Agendamento já está cancelado.")
        conn.execute(
            text("UPDATE plugin_clinica_agendamentos SET status = 'cancelado' WHERE id = :id"),
            {"id": ag_id},
        )
    # Cancela também o evento espelhado no Google (best-effort).
    await asyncio.to_thread(_cancel_event_in_google, ag_id)
    logger.info("[clinica] agendamento cancelado id=%s", ag_id)
    return _ok({"id": ag_id, "status": "cancelado"})


class AdminAgendamentoIn(AgendamentoIn):
    """Igual ao agendamento público, mas a recepção escolhe o status inicial.

    Default 'confirmado': reserva feita por telefone/balcão já entra confirmada
    (não há fluxo de pagamento online). 'pendente_pagamento' fica disponível
    caso a clínica queira cobrar o cliente depois.
    """

    status: str = Field(default="confirmado")

    @field_validator("status")
    @classmethod
    def _valid_status(cls, v: str) -> str:
        if v not in ("pendente_pagamento", "confirmado"):
            raise ValueError("Status deve ser 'pendente_pagamento' ou 'confirmado'.")
        return v


@router.post("/admin/agendamentos")
async def admin_create_agendamento(body: AdminAgendamentoIn) -> dict:
    """Cria um agendamento manualmente pelo painel (recepção).

    Reutiliza toda a validação do fluxo público (serviço ativo, profissional
    apto, horário dentro do bloco, sem conflito), mas permite escolher o
    profissional e o status inicial. `profissional_id` null = qualquer apto.
    """
    ag = _criar_agendamento(
        servico_id=body.servico_id,
        profissional_id=body.profissional_id,
        data=body.data,
        hora_inicio=body.hora_inicio,
        cliente_nome=body.cliente_nome,
        cliente_telefone=body.cliente_telefone,
        status=body.status,
    )
    # Reserva de balcão já entra confirmada → espelha no Google na hora.
    if body.status == "confirmado":
        await asyncio.to_thread(_push_event_to_google, ag["id"])
    return _ok(ag)


class LembreteConfigIn(BaseModel):
    hora: str = Field(
        pattern=r"^\d{2}:\d{2}$",
        description="Horário diário do lembrete no formato HH:MM (24h).",
    )
    intervalo_min: int = Field(
        default=1,
        ge=1,
        le=60,
        description="Minutos de espera entre cada envio. Default 1.",
    )

    @field_validator("hora")
    @classmethod
    def _valid_time(cls, v: str) -> str:
        h, m = v.split(":")
        if not (0 <= int(h) <= 23 and 0 <= int(m) <= 59):
            raise ValueError("Hora inválida.")
        return v


@router.get("/admin/lembrete-config")
async def admin_get_lembrete_config() -> dict:
    """Retorna a configuração atual do envio de lembretes."""
    return _ok({
        "hora": _lembrete_hora(),
        "intervalo_min": _lembrete_intervalo_min(),
        "janela_fim": "18:00",
    })


@router.put("/admin/lembrete-config")
async def admin_set_lembrete_config(body: LembreteConfigIn) -> dict:
    """Grava horário e intervalo do lembrete em config.

    A próxima iteração do loop em events.py (até 60s) já usa os novos
    valores — não precisa reiniciar o servidor.
    """
    with make_plugin_db() as conn:
        conn.execute(
            text(
                "INSERT INTO config (key, value) VALUES (:k, :v) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value"
            ),
            {"k": "plugin.clinica.lembrete_hora", "v": json.dumps(body.hora)},
        )
        conn.execute(
            text(
                "INSERT INTO config (key, value) VALUES (:k, :v) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value"
            ),
            {
                "k": "plugin.clinica.lembrete_intervalo_min",
                "v": json.dumps(body.intervalo_min),
            },
        )
    logger.info(
        "[clinica] lembrete config atualizada hora=%s intervalo=%smin",
        body.hora, body.intervalo_min,
    )
    return _ok({"hora": body.hora, "intervalo_min": body.intervalo_min})


@router.post("/admin/agendamentos/{ag_id}/disparar-lembrete")
async def admin_disparar_lembrete(ag_id: int) -> dict:
    """Força o envio do lembrete WhatsApp agora, ignorando data e janela horária.

    Útil pra testar a integração sem esperar o gatilho diário das 09h.
    Respeita a flag `lembrete_enviado` — chamadas repetidas para o mesmo
    agendamento retornam `enviado=false` (a primeira já marcou).
    """
    enviado = await asyncio.to_thread(enviar_lembrete, ag_id)
    return _ok({"id": ag_id, "enviado": enviado})


# ──────────────────────────────────────────────────────────────────────────
# Etapa 8 — Pagamento via Mercado Pago (API Orders)
#
# Arquitetura: navegador → backend → api.mercadopago.com
# A MP API bloqueia chamadas CORS do navegador; o access_token nunca vai
# ao frontend. Apenas a public_key é exposta (via GET /pagamento/config).
#
# Fluxo PIX:
#   1. Frontend POST /agendamentos/{id}/iniciar-pagamento {kind:"pix"}
#   2. Backend cria order MP → devolve qr_code_base64 + qr_code (copia-e-cola)
#   3. Frontend exibe QR e faz polling GET /agendamentos/{id}/status-pagamento
#   4. Quando mp_status == "processed", mostra tela de confirmação
#
# Fluxo Cartão:
#   1. Frontend carrega SDK MP + renderiza Card Payment Brick (iframes do MP)
#   2. Brick tokeniza o cartão e chama onSubmit com cardFormData
#   3. Frontend envia cardFormData ao backend {kind:"card", card_form_data}
#   4. Backend cria order MP com o token e retorna status imediato
# ──────────────────────────────────────────────────────────────────────────

_MP_ORDERS_URL = "https://api.mercadopago.com/v1/orders"


def _mp_creds() -> tuple[str, str]:
    """Retorna (access_token, public_key) de env vars ou das settings do plugin."""
    token = os.getenv("MP_ACCESS_TOKEN", "")
    pubkey = os.getenv("MP_PUBLIC_KEY", "")
    if not token or not pubkey:
        try:
            with make_plugin_db() as conn:
                rows = conn.execute(
                    text(
                        "SELECT key, value FROM config "
                        "WHERE key IN ('plugin.clinica.mp_access_token', 'plugin.clinica.mp_public_key')"
                    )
                ).mappings().all()
            cfg: dict[str, str] = {}
            for r in rows:
                try:
                    cfg[r["key"]] = json.loads(r["value"])
                except (json.JSONDecodeError, TypeError):
                    cfg[r["key"]] = r["value"] or ""
            if not token:
                token = cfg.get("plugin.clinica.mp_access_token", "") or ""
            if not pubkey:
                pubkey = cfg.get("plugin.clinica.mp_public_key", "") or ""
        except Exception:
            pass
    return token, pubkey


def _mp_post_order_sync(payload: dict, access_token: str) -> dict:
    """Núcleo síncrono (bloqueante) do POST de order no Mercado Pago.

    Extraído para ser chamável tanto de dentro de `asyncio.to_thread` (rotas
    FastAPI) quanto direto de código síncrono (tool `clinica_agendar`, que
    roda fora do ciclo de request e não pode `await`).
    """
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        _MP_ORDERS_URL,
        data=data,
        headers={
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
            "X-Idempotency-Key": str(uuid.uuid4()),
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        body = exc.read()
        raise HTTPException(
            status_code=502,
            detail=f"Mercado Pago {exc.code}: {body.decode()[:300]}",
        )


def _mp_get_order_sync(order_id: str, access_token: str) -> dict:
    """Núcleo síncrono (bloqueante) do GET de order no Mercado Pago."""
    req = urllib.request.Request(
        f"{_MP_ORDERS_URL}/{order_id}",
        headers={"Authorization": f"Bearer {access_token}"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        body = exc.read()
        raise HTTPException(
            status_code=502,
            detail=f"Mercado Pago {exc.code}: {body.decode()[:200]}",
        )


async def _mp_post_order(payload: dict, access_token: str) -> dict:
    return await asyncio.to_thread(_mp_post_order_sync, payload, access_token)


async def _mp_get_order(order_id: str, access_token: str) -> dict:
    return await asyncio.to_thread(_mp_get_order_sync, order_id, access_token)


@router.get("/pagamento/config")
async def pagamento_config() -> dict:
    """Expõe apenas a Public Key do MP para o frontend inicializar o SDK do Brick."""
    _, pubkey = _mp_creds()
    if not pubkey:
        raise HTTPException(
            status_code=503,
            detail=(
                "Mercado Pago não configurado. "
                "Defina MP_PUBLIC_KEY via variável de ambiente ou em Settings → Clínica."
            ),
        )
    return _ok({"public_key": pubkey})


def criar_pagamento_pix(ag_id: int, payer_email: str | None = None) -> dict:
    """Cria (ou recupera) uma order PIX no Mercado Pago para o agendamento.

    Núcleo síncrono do fluxo PIX de `POST /agendamentos/{id}/iniciar-pagamento`
    (extraído para ser reutilizável pela tool `clinica_agendar`/
    `clinica_remarcar_agendamento` do agendamento por IA, que roda fora do
    ciclo de request do FastAPI e não pode `await` a rota). Idempotente: se
    `mp_order_id` já existe, apenas consulta o estado atual dela.
    """
    access_token, _ = _mp_creds()
    if not access_token:
        raise HTTPException(
            status_code=503,
            detail=(
                "Mercado Pago não configurado. "
                "Defina MP_ACCESS_TOKEN via variável de ambiente ou em Settings → Clínica."
            ),
        )

    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT status, valor_centavos, mp_order_id "
                "FROM plugin_clinica_agendamentos WHERE id = :id"
            ),
            {"id": ag_id},
        ).mappings().first()

    if not row:
        raise HTTPException(status_code=404, detail="Agendamento não encontrado.")
    if row["status"] == "cancelado":
        raise HTTPException(status_code=400, detail="Agendamento cancelado — pagamento não permitido.")

    # Idempotência: se já criou order, retorna o estado atual dela.
    if row["mp_order_id"]:
        mp_order = _mp_get_order_sync(row["mp_order_id"], access_token)
        return {
            "mp_order_id": row["mp_order_id"],
            "mp_status": mp_order.get("status"),
            "mp_status_detail": mp_order.get("status_detail"),
            "order": mp_order,
        }

    amount_str = f"{row['valor_centavos'] / 100:.2f}"
    external_ref = f"clinica-ag-{ag_id}"
    email = (payer_email or "").strip() or f"pagamento.{ag_id}@clinicavidaleve.com"
    payload = {
        "type": "online",
        "processing_mode": "automatic",
        "total_amount": amount_str,
        "external_reference": external_ref,
        "description": f"Agendamento #{ag_id} — Clinica Vida Leve",
        "payer": {"email": email},
        "transactions": {
            "payments": [{
                "amount": amount_str,
                "payment_method": {"id": "pix", "type": "bank_transfer"},
            }]
        },
    }

    mp_order = _mp_post_order_sync(payload, access_token)
    mp_order_id = mp_order.get("id", "")

    with make_plugin_db() as conn:
        conn.execute(
            text("UPDATE plugin_clinica_agendamentos SET mp_order_id = :oid WHERE id = :id"),
            {"oid": mp_order_id, "id": ag_id},
        )

    logger.info(
        "[clinica] MP order PIX criada ag=%s order=%s status=%s",
        ag_id, mp_order_id, mp_order.get("status"),
    )
    return {
        "mp_order_id": mp_order_id,
        "mp_status": mp_order.get("status"),
        "mp_status_detail": mp_order.get("status_detail"),
        "order": mp_order,
    }


class IniciarPagamentoBody(BaseModel):
    kind: str = Field(..., description="'pix' ou 'card'")
    card_form_data: dict | None = Field(None, description="Dados do Card Brick (só para kind='card').")
    payer_email: str = Field(
        "pagamento@clinicavidaleve.com",
        description="E-mail do pagador (sandbox: use e-mail de conta de teste MP).",
    )


@router.post("/agendamentos/{ag_id}/iniciar-pagamento")
async def iniciar_pagamento(ag_id: int, body: IniciarPagamentoBody) -> dict:
    """Cria (ou recupera) uma order no Mercado Pago para o agendamento.

    Idempotente: se mp_order_id já existe, consulta o estado atual e retorna.
    PIX delega para `criar_pagamento_pix` (compartilhado com a tool
    `clinica_agendar`); cartão mantém o fluxo original (Card Brick tokeniza
    no frontend).
    """
    if body.kind == "pix":
        result = await asyncio.to_thread(criar_pagamento_pix, ag_id, body.payer_email)
        return _ok(result)

    if body.kind != "card":
        raise HTTPException(status_code=422, detail="kind deve ser 'pix' ou 'card'.")

    access_token, _ = _mp_creds()
    if not access_token:
        raise HTTPException(
            status_code=503,
            detail=(
                "Mercado Pago não configurado. "
                "Defina MP_ACCESS_TOKEN via variável de ambiente ou em Settings → Clínica."
            ),
        )

    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT status, valor_centavos, mp_order_id_card "
                "FROM plugin_clinica_agendamentos WHERE id = :id"
            ),
            {"id": ag_id},
        ).mappings().first()

    if not row:
        raise HTTPException(status_code=404, detail="Agendamento não encontrado.")
    if row["status"] == "cancelado":
        raise HTTPException(status_code=400, detail="Agendamento cancelado — pagamento não permitido.")

    # Idempotência POR MÉTODO: o cartão tem sua própria order (mp_order_id_card),
    # separada da order PIX (mp_order_id) que a tool clinica_agendar cria
    # antecipadamente. Só reaproveitamos a order de cartão existente se ela já
    # foi APROVADA (processed) — aí devolvemos o mesmo resultado sem cobrar de
    # novo. Se a tentativa anterior falhou (recusada/expirada), deixamos criar
    # uma order nova com o token deste submit (cada submit do Brick gera um
    # token de uso único), permitindo o cliente tentar outro cartão.
    if row["mp_order_id_card"]:
        existing = await _mp_get_order(row["mp_order_id_card"], access_token)
        if existing.get("status") == "processed":
            return _ok({
                "mp_order_id": row["mp_order_id_card"],
                "mp_status": existing.get("status"),
                "mp_status_detail": existing.get("status_detail"),
                "order": existing,
            })

    amount_str = f"{row['valor_centavos'] / 100:.2f}"
    external_ref = f"clinica-ag-{ag_id}"
    payer_email = (body.payer_email or "").strip() or f"pagamento.{ag_id}@clinicavidaleve.com"

    if not body.card_form_data:
        raise HTTPException(status_code=422, detail="card_form_data obrigatório para kind='card'.")
    cfd = body.card_form_data
    payload = {
        "type": "online",
        "processing_mode": "automatic",
        "total_amount": amount_str,
        "external_reference": external_ref,
        "description": f"Agendamento #{ag_id} — Clinica Vida Leve",
        "payer": {"email": cfd.get("payer", {}).get("email") or payer_email},
        "transactions": {
            "payments": [{
                "amount": amount_str,
                "payment_method": {
                    "id": cfd.get("payment_method_id", ""),
                    "type": "credit_card",
                    "token": cfd.get("token", ""),
                    "installments": int(cfd.get("installments", 1)),
                },
            }]
        },
    }

    mp_order = await _mp_post_order(payload, access_token)
    mp_order_id = mp_order.get("id", "")

    with make_plugin_db() as conn:
        conn.execute(
            text("UPDATE plugin_clinica_agendamentos SET mp_order_id_card = :oid WHERE id = :id"),
            {"oid": mp_order_id, "id": ag_id},
        )

    # Cartão aprova na hora (processing_mode=automatic, sem 3DS): se já veio
    # processed, confirma a reserva e manda o WhatsApp agora — mesmo padrão que
    # status_pagamento usa no PIX. O poller/webhook fica como rede de segurança
    # caso a resposta desta request se perca.
    if mp_order.get("status") == "processed":
        await asyncio.to_thread(confirmar_e_notificar, ag_id, mp_order_id)

    logger.info(
        "[clinica] MP order cartão ag=%s order=%s status=%s",
        ag_id, mp_order_id, mp_order.get("status"),
    )
    return _ok({
        "mp_order_id": mp_order_id,
        "mp_status": mp_order.get("status"),
        "mp_status_detail": mp_order.get("status_detail"),
        "order": mp_order,
    })


@router.get("/agendamentos/{ag_id}/status-pagamento")
async def status_pagamento(ag_id: int) -> dict:
    """Polling de status: consulta a order no MP e devolve o estado atual.

    Quando o MP responde `processed` e o agendamento ainda está
    `pendente_pagamento`, este endpoint dispara o fluxo de confirmação
    (mudar status + enviar WhatsApp) imediatamente, então o navegador do
    cliente vê a confirmação no próximo poll sem esperar o background task.
    """
    access_token, _ = _mp_creds()
    if not access_token:
        raise HTTPException(status_code=503, detail="Mercado Pago não configurado.")

    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT status, mp_order_id, mp_order_id_card "
                "FROM plugin_clinica_agendamentos WHERE id = :id"
            ),
            {"id": ag_id},
        ).mappings().first()

    if not row:
        raise HTTPException(status_code=404, detail="Agendamento não encontrado.")

    # Considera as duas orders possíveis: a PIX (mp_order_id, criada eager pela
    # tool) e a de cartão (mp_order_id_card). Percorre as duas e para na primeira
    # que estiver 'processed'; se nenhuma pagou, usa a última consultada só para
    # exibir o status atual ao frontend.
    order_ids = [
        o.strip()
        for o in (row.get("mp_order_id"), row.get("mp_order_id_card"))
        if o and o.strip()
    ]
    if not order_ids:
        return _ok({"ag_status": row["status"], "mp_status": None, "mp_order_id": None})

    ag_status = row["status"]
    order_id, mp_order = order_ids[0], None
    for oid in order_ids:
        mp_order = await _mp_get_order(oid, access_token)
        order_id = oid
        if mp_order.get("status") == "processed":
            break

    mp_status = mp_order.get("status")

    # Etapa 9: se o MP confirmou e o agendamento ainda está pendente, confirma
    # agora e envia o WhatsApp. Idempotente (não envia duas vezes).
    if mp_status == "processed" and ag_status == "pendente_pagamento":
        await asyncio.to_thread(confirmar_e_notificar, ag_id, order_id)
        ag_status = "confirmado"

    return _ok({
        "ag_status": ag_status,
        "mp_status": mp_status,
        "mp_status_detail": mp_order.get("status_detail"),
        "mp_order_id": order_id,
    })


# ──────────────────────────────────────────────────────────────────────────
# Etapa 14 — Webhook do Mercado Pago (substitui/complementa o polling)
#
# O MP faz POST nesta rota assim que o pagamento muda de estado (PIX cai,
# cartão aprova). Em vez de parsear o payload do MP — que varia conforme o
# topic assinado (`payment`, `order`, `merchant_order`) e nem sempre traz o
# nosso `mp_order_id` — usamos o webhook só como GATILHO: disparamos uma
# varredura `poll_pending_payments()` na hora. A varredura já contém toda a
# lógica testada (consulta cada order pendente, confirma as `processed`,
# envia o WhatsApp idempotente). Assim o webhook é robusto a qualquer formato.
#
# O background poller (events.py) continua vivo como rede de segurança caso
# o MP não consiga entregar a notificação (servidor reiniciando, etc.).
#
# Config no painel MP: Notificações → Webhooks → Modo de produção →
#   URL:  https://SEU_DOMINIO/api/plugins/clinica/webhook-mp
#   Eventos: marque "Pagamentos" (e "Order (Mercado Pago)" se quiser).
#
# Assinatura secreta: opcional. Se preencher `mp_webhook_secret` nas settings
# do plugin, validamos o header `x-signature` (HMAC-SHA256). Vazio = sem
# validação (default — MVP didático).
# ──────────────────────────────────────────────────────────────────────────


def _mp_webhook_secret() -> str:
    """Segredo de assinatura do webhook MP. Vazio = validação desligada."""
    secret = os.getenv("MP_WEBHOOK_SECRET", "")
    if secret:
        return secret
    try:
        with make_plugin_db() as conn:
            row = conn.execute(
                text(
                    "SELECT value FROM config "
                    "WHERE key = 'plugin.clinica.mp_webhook_secret'"
                )
            ).mappings().first()
        if row:
            try:
                val = json.loads(row["value"])
            except (json.JSONDecodeError, TypeError):
                val = row["value"] or ""
            if isinstance(val, str):
                return val.strip()
    except Exception:
        pass
    return ""


def _verify_mp_signature(request: Request, secret: str) -> bool:
    """Valida o header `x-signature` do Mercado Pago (HMAC-SHA256).

    Template assinado pelo MP:
        id:<data.id>;request-id:<x-request-id>;ts:<ts>;

    `data.id` vem da query string (`?data.id=...`), `ts` e `v1` vêm do
    header `x-signature` no formato `ts=...,v1=...`. Comparação em tempo
    constante. Retorna True se válido ou se faltar dado pra validar (fail-open
    — preferimos não derrubar confirmação legítima por header malformado).
    """
    import hashlib
    import hmac

    sig = request.headers.get("x-signature", "")
    req_id = request.headers.get("x-request-id", "")
    if not sig:
        return True  # nada pra validar

    parts = {}
    for chunk in sig.split(","):
        if "=" in chunk:
            k, v = chunk.split("=", 1)
            parts[k.strip()] = v.strip()
    ts = parts.get("ts", "")
    v1 = parts.get("v1", "")
    data_id = request.query_params.get("data.id", "") or request.query_params.get("id", "")
    if not (ts and v1):
        return True

    manifest = f"id:{data_id};request-id:{req_id};ts:{ts};"
    expected = hmac.new(secret.encode(), manifest.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, v1)


@router.post("/webhook-mp")
async def webhook_mp(request: Request) -> dict:
    """Recebe notificações do Mercado Pago e dispara a varredura de pagamentos.

    Responde rápido (o MP exige 200/201 em poucos segundos) e roda a
    confirmação em background via `asyncio.create_task`.
    """
    try:
        body = await request.json()
    except Exception:
        body = {}

    secret = _mp_webhook_secret()
    if secret and not _verify_mp_signature(request, secret):
        logger.warning("[clinica] webhook MP com assinatura inválida — ignorado")
        raise HTTPException(status_code=401, detail="Assinatura inválida.")

    logger.info(
        "[clinica] webhook MP recebido type=%s action=%s data=%s",
        body.get("type"), body.get("action"), body.get("data"),
    )

    # Gatilho de varredura em background — não bloqueia a resposta ao MP.
    async def _sweep() -> None:
        try:
            enviados = await poll_pending_payments()
            if enviados:
                logger.info("[clinica] webhook MP: %s notificacoes enviadas", enviados)
        except Exception as exc:
            logger.warning("[clinica] webhook MP sweep falhou: %s", exc)

    asyncio.create_task(_sweep())
    return _ok({"received": True})


# ──────────────────────────────────────────────────────────────────────────
# Etapa 9 — Confirmação automática + notificação WhatsApp
#
# Quando o MP processa o pagamento:
#   1. Marca o agendamento como `confirmado` (libera fluxo da Etapa 7)
#   2. Envia mensagem WhatsApp com comprovante + detalhes
#   3. Flag `notificacao_enviada=1` garante envio único
#
# Dois disparos:
#   • Síncrono — no GET /status-pagamento quando o cliente está na tela
#   • Periódico — em events.py via background task (cobre cliente que
#     fechou o navegador antes do PIX cair)
# ──────────────────────────────────────────────────────────────────────────


def _gowa_port() -> int:
    """Resolve a porta do GOWA na MESMA ordem que o core (default 3000).

    Precedência: env var `WHATSBOT_GOWA_PORT` > tabela `config` > 3000.

    O core resolve `gowa_port` via `Settings.get`, que aplica o override de
    env ANTES de olhar a tabela (config/settings.py `_ENV_OVERRIDES`). Em
    produção (Coolify) a porta vem da env `WHATSBOT_GOWA_PORT` e NÃO é
    persistida na tabela — que continua com o default 3000. Se o plugin
    lesse só a tabela, conectaria em 127.0.0.1:3000 (onde nada escuta) e
    todo envio de WhatsApp falharia com ConnectError ("WhatsApp não está
    acessível"), enquanto o GOWA real está em outra porta. Por isso aqui
    espelhamos a resolução do core: env primeiro.
    """
    env_port = (os.getenv("WHATSBOT_GOWA_PORT", "") or "").strip()
    if env_port:
        try:
            return int(env_port)
        except ValueError:
            pass
    try:
        with make_plugin_db() as conn:
            row = conn.execute(
                text("SELECT value FROM config WHERE key = 'gowa_port'")
            ).mappings().first()
        if row:
            try:
                return int(json.loads(row["value"]))
            except (json.JSONDecodeError, TypeError, ValueError):
                pass
    except Exception:
        pass
    return 3000


def _lembrete_hora() -> str:
    """Horário diário em que o lembrete dispara (HH:MM). Default 09:00.

    Lê de `config` a chave `plugin.clinica.lembrete_hora`. O Pydantic da
    settings garante o formato HH:MM ao gravar via UI — aqui só fazemos
    fallback defensivo caso a chave esteja ausente ou inválida.
    """
    try:
        with make_plugin_db() as conn:
            row = conn.execute(
                text(
                    "SELECT value FROM config "
                    "WHERE key = 'plugin.clinica.lembrete_hora'"
                )
            ).mappings().first()
        if row:
            try:
                val = json.loads(row["value"])
            except (json.JSONDecodeError, TypeError):
                val = row["value"] or ""
            if isinstance(val, str) and len(val) == 5 and val[2] == ":":
                return val
    except Exception:
        pass
    return "09:00"


def _lembrete_intervalo_min() -> int:
    """Minutos de espera entre envios consecutivos de lembrete. Default 1.

    Trava de proteção pra não tomar bloqueio do WhatsApp em rajadas.
    Clamp [1, 60] como segurança caso a chave esteja corrompida.
    """
    try:
        with make_plugin_db() as conn:
            row = conn.execute(
                text(
                    "SELECT value FROM config "
                    "WHERE key = 'plugin.clinica.lembrete_intervalo_min'"
                )
            ).mappings().first()
        if row:
            try:
                val = json.loads(row["value"])
            except (json.JSONDecodeError, TypeError):
                val = row["value"]
            try:
                n = int(val)
                if 1 <= n <= 60:
                    return n
            except (TypeError, ValueError):
                pass
    except Exception:
        pass
    return 1


def _base_url() -> str:
    """URL pública do WhatsBot (sem barra final). Vazio = não configurado.

    Lê de `config` a chave `plugin.clinica.base_url`. Usado pela tool
    `enviar_link_agendamento` para montar a URL absoluta que vai no WhatsApp.
    """
    try:
        with make_plugin_db() as conn:
            row = conn.execute(
                text(
                    "SELECT value FROM config "
                    "WHERE key = 'plugin.clinica.base_url'"
                )
            ).mappings().first()
        if row:
            try:
                val = json.loads(row["value"])
            except (json.JSONDecodeError, TypeError):
                val = row["value"] or ""
            if isinstance(val, str):
                return val.strip().rstrip("/")
    except Exception:
        pass
    return ""


def _clinica_str_setting(key: str) -> str:
    """Lê uma setting string do plugin (`plugin.clinica.<key>`). '' se ausente."""
    try:
        with make_plugin_db() as conn:
            row = conn.execute(
                text("SELECT value FROM config WHERE key = :k"),
                {"k": f"plugin.clinica.{key}"},
            ).mappings().first()
        if row:
            try:
                val = json.loads(row["value"])
            except (json.JSONDecodeError, TypeError):
                val = row["value"] or ""
            if isinstance(val, str):
                return val.strip()
    except Exception:
        pass
    return ""


def _clinic_email() -> str:
    """E-mail da clínica para compartilhar (reader) as agendas dos profissionais."""
    return _clinica_str_setting("clinic_email")


def _clinic_notify_phone() -> str:
    """Número da clínica que recebe avisos de cancelamento externo. '' = sem aviso."""
    return _clinica_str_setting("clinic_notify_phone")


# ── Integração com o gateway `agenda` (Google Calendar) ───────────────────
#
# O plugin `agenda` registra um `AgendaGateway` no service registry do core.
# A clínica é apenas consumidora: nunca importa o módulo direto — pega via
# `get_service("agenda")` e tolera `None` (plugin desativado / sem credenciais).


def _agenda_gateway():
    """Retorna o `AgendaGateway` do plugin `agenda`, ou None se indisponível."""
    try:
        from plugins.context import get_service
        return get_service("agenda")
    except Exception as exc:
        logger.debug("[clinica] gateway agenda indisponível: %s", exc)
        return None


def _iso_dt(data: str, hora: str) -> str:
    """`('2026-05-28', '14:00')` → `'2026-05-28T14:00:00'` (ISO local, sem tz)."""
    return f"{data}T{hora}:00"


def _push_event_to_google(ag_id: int) -> None:
    """Espelha um agendamento confirmado na agenda Google do profissional.

    Best-effort e idempotente — nunca quebra a confirmação:
      * se o plugin `agenda` está off → no-op;
      * se o profissional não tem `google_calendar_id` → no-op;
      * se já existe evento nosso (não cancelado) para este agendamento → no-op.
    """
    gateway = _agenda_gateway()
    if gateway is None:
        return
    try:
        with make_plugin_db() as conn:
            ag = conn.execute(
                text(
                    "SELECT a.id, a.data, a.hora_inicio, a.hora_fim, a.cliente_nome, "
                    "       p.google_calendar_id, p.nome AS profissional_nome, "
                    "       s.nome AS servico_nome "
                    "FROM plugin_clinica_agendamentos a "
                    "JOIN plugin_clinica_profissionais p ON p.id = a.profissional_id "
                    "LEFT JOIN plugin_clinica_servicos s ON s.id = a.servico_id "
                    "WHERE a.id = :id"
                ),
                {"id": ag_id},
            ).mappings().first()
        if not ag or not ag["google_calendar_id"]:
            return

        # Idempotência: já espelhamos este agendamento? (lê o espelho do gateway)
        try:
            with make_plugin_db() as conn:
                existente = conn.execute(
                    text(
                        "SELECT 1 FROM plugin_agenda_events "
                        "WHERE source_plugin = 'clinica' AND source_ref = :sr "
                        "  AND status != 'cancelled' LIMIT 1"
                    ),
                    {"sr": str(ag_id)},
                ).first()
            if existente:
                return
        except Exception:
            # Tabela do agenda ausente (plugin nunca migrou) — segue e deixa o
            # gateway resolver; pior caso loga erro abaixo.
            pass

        summary = f"{ag['servico_nome'] or 'Atendimento'} — {ag['cliente_nome']}"
        gateway.create_event(
            ag["google_calendar_id"],
            summary,
            _iso_dt(ag["data"], ag["hora_inicio"]),
            _iso_dt(ag["data"], ag["hora_fim"]),
            source_plugin="clinica",
            source_ref=ag_id,
            description=f"Profissional: {ag['profissional_nome']}",
        )
        logger.info("[clinica] agendamento %s espelhado no Google", ag_id)
    except Exception as exc:
        logger.warning("[clinica] falha ao espelhar agendamento %s no Google: %s", ag_id, exc)


def _cancel_event_in_google(ag_id: int) -> None:
    """Cancela o evento Google de um agendamento (best-effort).

    No-op se o plugin `agenda` está off ou o profissional não tem agenda Google.
    """
    gateway = _agenda_gateway()
    if gateway is None:
        return
    try:
        with make_plugin_db() as conn:
            row = conn.execute(
                text(
                    "SELECT p.google_calendar_id "
                    "FROM plugin_clinica_agendamentos a "
                    "JOIN plugin_clinica_profissionais p ON p.id = a.profissional_id "
                    "WHERE a.id = :id"
                ),
                {"id": ag_id},
            ).mappings().first()
        if not row or not row["google_calendar_id"]:
            return
        gateway.cancel_event(row["google_calendar_id"], source_ref=ag_id)
        logger.info("[clinica] evento Google do agendamento %s cancelado", ag_id)
    except Exception as exc:
        # Evento pode não existir no espelho (agendamento nunca foi confirmado)
        # — não é erro de fato. Loga em debug.
        logger.debug("[clinica] cancel_event Google ag=%s: %s", ag_id, exc)


def _bloqueio_google_window(b: dict) -> tuple[str, str]:
    """(start_iso, end_iso) ISO local para espelhar o bloqueio no Google.

    Dia inteiro: cobre `data_inicio 00:00` → `data_fim 23:59`. Faixa: usa a
    faixa horária aplicada do primeiro ao último dia. Para faixa multi-dia o
    espelho vira um único bloco contínuo (aproximação visual; a fonte da
    verdade é a clínica, que aplica a faixa a cada dia corretamente).
    """
    if b["dia_inteiro"]:
        return _iso_dt(b["data_inicio"], "00:00"), _iso_dt(b["data_fim"], "23:59")
    return _iso_dt(b["data_inicio"], b["hora_inicio"]), _iso_dt(b["data_fim"], b["hora_fim"])


def _push_bloqueio_to_google(bloqueio_id: int) -> None:
    """Espelha um bloqueio in-app na agenda Google do profissional.

    Best-effort: no-op se o plugin `agenda` está off, se o profissional não
    tem `google_calendar_id`, ou se o bloqueio veio do próprio Google.
    Grava o `google_event_id` retornado na linha do bloqueio.
    """
    gateway = _agenda_gateway()
    if gateway is None:
        return
    try:
        with make_plugin_db() as conn:
            b = conn.execute(
                text(
                    "SELECT b.id, b.data_inicio, b.data_fim, b.dia_inteiro, "
                    "       b.hora_inicio, b.hora_fim, b.motivo, b.origem, "
                    "       p.google_calendar_id "
                    "FROM plugin_clinica_bloqueios b "
                    "JOIN plugin_clinica_profissionais p ON p.id = b.profissional_id "
                    "WHERE b.id = :id"
                ),
                {"id": bloqueio_id},
            ).mappings().first()
        if not b or b["origem"] == "google" or not b["google_calendar_id"]:
            return
        start_iso, end_iso = _bloqueio_google_window(dict(b))
        motivo = (b["motivo"] or "").strip()
        summary = f"🔒 Bloqueio — {motivo}" if motivo else "🔒 Bloqueio"
        ev = gateway.create_event(
            b["google_calendar_id"],
            summary,
            start_iso,
            end_iso,
            source_plugin="clinica",
            source_ref=f"bloqueio:{bloqueio_id}",
            description="Bloqueio de agenda (Clínica Vida Leve)",
        )
        gid = ev.get("id") if isinstance(ev, dict) else None
        if gid:
            with make_plugin_db() as conn:
                conn.execute(
                    text(
                        "UPDATE plugin_clinica_bloqueios "
                        "SET google_event_id = :g WHERE id = :id"
                    ),
                    {"g": gid, "id": bloqueio_id},
                )
        logger.info("[clinica] bloqueio %s espelhado no Google", bloqueio_id)
    except Exception as exc:
        logger.warning(
            "[clinica] falha ao espelhar bloqueio %s no Google: %s", bloqueio_id, exc
        )


def _cancel_bloqueio_in_google(bloqueio_id: int) -> None:
    """Cancela o evento Google de um bloqueio (best-effort)."""
    gateway = _agenda_gateway()
    if gateway is None:
        return
    try:
        with make_plugin_db() as conn:
            row = conn.execute(
                text(
                    "SELECT p.google_calendar_id "
                    "FROM plugin_clinica_bloqueios b "
                    "JOIN plugin_clinica_profissionais p ON p.id = b.profissional_id "
                    "WHERE b.id = :id"
                ),
                {"id": bloqueio_id},
            ).mappings().first()
        if not row or not row["google_calendar_id"]:
            return
        gateway.cancel_event(
            row["google_calendar_id"], source_ref=f"bloqueio:{bloqueio_id}"
        )
        logger.info("[clinica] evento Google do bloqueio %s cancelado", bloqueio_id)
    except Exception as exc:
        logger.debug("[clinica] cancel_event Google bloqueio=%s: %s", bloqueio_id, exc)


def _format_phone_br(digits: str) -> str:
    """Acrescenta DDI 55 se o número veio só com DDD+celular.

    GOWA aceita ambos formatos (`5511...` e `11...`), mas com DDI fica
    mais robusto para contas internacionais. Mantém grupos (`@g.us`).
    """
    d = "".join(ch for ch in (digits or "") if ch.isdigit())
    if not d:
        return digits or ""
    if len(d) in (10, 11):
        return "55" + d
    return d


def _format_data_br(iso: str) -> str:
    """`2026-05-28` → `28/05/2026`."""
    try:
        y, m, dd = iso.split("-")
        return f"{dd}/{m}/{y}"
    except Exception:
        return iso


def _register_outgoing_message(phone: str, message: str, msg_id: str | None,
                                source: str) -> None:
    """Grava a mensagem enviada no histórico do contato e empurra para a UI.

    Sem isto, a mensagem chega no WhatsApp mas a tela de conversa do WhatsBot
    não exibe nada (a tela lê da tabela `messages` e escuta `new_message` via
    WebSocket). Replica o pós-envio que `server/routes/contacts.py` faz quando
    o operador envia uma mensagem manual.
    """
    import time as _time

    # AgentHandler é exposto pelo core via `plugins.events.set_runtime`.
    try:
        from plugins import events as plugin_events
        handler = plugin_events._agent_handler
    except Exception as exc:
        logger.debug("[clinica] handler indisponível para registrar mensagem: %s", exc)
        handler = None

    saved = None
    if handler is not None:
        try:
            saved = handler.save_assistant_message(
                phone, message, msg_id=msg_id, status="sent",
            )
        except Exception as exc:
            logger.warning("[clinica] falha ao salvar mensagem enviada para %s: %s",
                           phone, exc)

    msg_payload = saved or {
        "role": "assistant",
        "content": message,
        "ts": _time.time(),
        "status": "sent",
        "msg_id": msg_id,
    }

    # Broadcast WebSocket — a tela de conversa do WhatsBot escuta `new_message`
    # e adiciona a linha em tempo real (sem precisar refrescar).
    try:
        from plugins.context import broadcast
        broadcast("new_message", {"phone": phone, "message": msg_payload})
    except Exception as exc:
        logger.debug("[clinica] broadcast new_message falhou: %s", exc)

    # Evento `message.sent` — mantém outros plugins (event_logger etc.) cientes.
    try:
        from plugins.events import emit_with_filter_sync
        emit_with_filter_sync("message.sent", {
            "phone": phone,
            "text": message,
            "msg_id": msg_id,
            "media_type": None,
            "media_path": None,
            "source": source,
            "status": "sent",
            "ts": msg_payload.get("ts", _time.time()),
        })
    except Exception as exc:
        logger.debug("[clinica] emit message.sent falhou: %s", exc)


def _send_whatsapp(phone: str, message: str, *, source: str = "clinica") -> bool:
    """Best-effort: envia mensagem via GOWA e registra na conversa. True em sucesso.

    Importa GOWAClient on-demand para não criar dependência em import time.
    Falhas são logadas (e re-tentadas no próximo poll) — nunca explodem.

    Após o envio bem-sucedido, grava a mensagem no histórico do contato e
    notifica a UI por WebSocket — assim a tela de conversa exibe a mensagem
    enviada, igual ao que acontece quando a IA ou o operador respondem.
    """
    try:
        from gowa.client import GOWAClient, GOWASendError, extract_msg_id
    except Exception as exc:
        logger.error("[clinica] GOWA client indisponível: %s", exc)
        return False
    try:
        client = GOWAClient(port=_gowa_port())
        # Resolve o device real do GOWA antes de enviar. Sem isto o client
        # nasce com device_id="whatsbot" (nome default) e _device_ready=False;
        # se o GOWA tiver registrado o device com outro id (ex: UUID gerado),
        # o envio vai com X-Device-Id errado → 404 DEVICE_NOT_FOUND → falha
        # silenciosa (o comprovante nunca chega). O core faz isto no startup.
        client.ensure_device()
        response = client.send_message(_format_phone_br(phone), message)
    except GOWASendError as exc:
        logger.warning("[clinica] GOWA recusou envio para %s: %s", phone, exc)
        return False
    except Exception as exc:
        logger.exception("[clinica] erro ao enviar WhatsApp para %s: %s", phone, exc)
        return False

    msg_id = extract_msg_id(response if isinstance(response, dict) else None)
    _register_outgoing_message(phone, message, msg_id, source)
    return True


def _build_confirmacao_message(ag: dict) -> str:
    """Mensagem enviada ao cliente quando o pagamento é confirmado."""
    valor = f"R$ {ag['valor_centavos'] / 100:.2f}".replace(".", ",")
    return (
        f"Olá, {ag['cliente_nome'].split(' ')[0]}! 💆‍♀️\n\n"
        f"Pagamento confirmado ✅\n"
        f"Sua reserva na *Clínica Vida Leve* está garantida.\n\n"
        f"📋 *Protocolo:* #{ag['id']}\n"
        f"💼 *Serviço:* {ag['servico_nome']}\n"
        f"👤 *Profissional:* {ag['profissional_nome']}\n"
        f"📅 *Data:* {_format_data_br(ag['data'])}\n"
        f"⏰ *Horário:* {ag['hora_inicio']} às {ag['hora_fim']}\n"
        f"💳 *Valor pago:* {valor}\n"
        f"🧾 *Comprovante MP:* {ag.get('mp_order_id') or '—'}\n\n"
        f"Te esperamos! Em caso de imprevisto, é só responder essa mensagem. 🌸"
    )


def confirmar_e_notificar(ag_id: int, mp_order_id: str | None = None) -> bool:
    """Confirma o agendamento + envia WhatsApp. Idempotente.

    Retorna True se enviou a notificação nessa chamada; False se já estava
    confirmado/notificado, foi cancelado, ou houve erro no envio.

    Roda síncrono — o caller decide se quer `asyncio.to_thread`.
    """
    now = int(time.time())
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT a.id, a.status, a.notificacao_enviada, a.mp_order_id, "
                "       a.cliente_nome, a.cliente_telefone, a.data, "
                "       a.hora_inicio, a.hora_fim, a.valor_centavos, "
                "       s.nome AS servico_nome, p.nome AS profissional_nome "
                "FROM plugin_clinica_agendamentos a "
                "LEFT JOIN plugin_clinica_servicos s ON s.id = a.servico_id "
                "LEFT JOIN plugin_clinica_profissionais p ON p.id = a.profissional_id "
                "WHERE a.id = :id"
            ),
            {"id": ag_id},
        ).mappings().first()

        if not row:
            return False
        if row["status"] == "cancelado":
            return False
        if row["notificacao_enviada"]:
            # Garante que o status está confirmado mesmo se o WhatsApp já saiu.
            if row["status"] != "confirmado":
                conn.execute(
                    text(
                        "UPDATE plugin_clinica_agendamentos "
                        "SET status = 'confirmado', confirmado_em = :ts "
                        "WHERE id = :id AND status = 'pendente_pagamento'"
                    ),
                    {"ts": now, "id": ag_id},
                )
            return False

        ag = dict(row)
        # O comprovante mostra a order que REALMENTE pagou (PIX ou cartão),
        # não a order PIX pré-gerada que pode ter ficado sem uso. Todos os
        # callers passam o id da order aprovada.
        if mp_order_id:
            ag["mp_order_id"] = mp_order_id

    # Envio fora da transação — não segura locks no DB durante o HTTP request.
    message = _build_confirmacao_message(ag)
    enviado = _send_whatsapp(ag["cliente_telefone"], message, source="clinica_confirmacao")

    with make_plugin_db() as conn:
        if enviado:
            conn.execute(
                text(
                    "UPDATE plugin_clinica_agendamentos "
                    "SET status = 'confirmado', confirmado_em = :ts, "
                    "    notificacao_enviada = 1 "
                    "WHERE id = :id AND status != 'cancelado'"
                ),
                {"ts": now, "id": ag_id},
            )
        else:
            # Confirma o status mas deixa notificacao_enviada=0 para retentar.
            conn.execute(
                text(
                    "UPDATE plugin_clinica_agendamentos "
                    "SET status = 'confirmado', confirmado_em = :ts "
                    "WHERE id = :id AND status = 'pendente_pagamento'"
                ),
                {"ts": now, "id": ag_id},
            )

    # Espelha o agendamento confirmado na agenda Google do profissional
    # (best-effort + idempotente; no-op se o plugin `agenda` estiver off).
    _push_event_to_google(ag_id)

    logger.info(
        "[clinica] ag=%s confirmado mp_order=%s whatsapp=%s",
        ag_id, ag.get("mp_order_id"), "ok" if enviado else "falhou",
    )
    return enviado


async def poll_pending_payments() -> int:
    """Varre agendamentos com order MP pendente e confirma os processados.

    Retorna a quantidade de notificações WhatsApp enviadas nessa rodada.
    Chamada pelo background loop em `events.py` a cada N segundos.
    """
    access_token, _ = _mp_creds()
    if not access_token:
        return 0

    with make_plugin_db() as conn:
        rows = conn.execute(
            text(
                "SELECT id, mp_order_id, mp_order_id_card, status, notificacao_enviada "
                "FROM plugin_clinica_agendamentos "
                "WHERE ((mp_order_id IS NOT NULL AND mp_order_id != '') "
                "    OR (mp_order_id_card IS NOT NULL AND mp_order_id_card != '')) "
                "  AND status != 'cancelado' "
                "  AND (status = 'pendente_pagamento' OR notificacao_enviada = 0)"
            )
        ).mappings().all()

    enviados = 0
    for r in rows:
        # Cada agendamento pode ter até duas orders pendentes (PIX + cartão).
        # A primeira que estiver 'processed' confirma a reserva.
        order_ids = [
            o.strip()
            for o in (r.get("mp_order_id"), r.get("mp_order_id_card"))
            if o and o.strip()
        ]
        for oid in order_ids:
            try:
                mp_order = await _mp_get_order(oid, access_token)
            except HTTPException as exc:
                logger.warning("[clinica] poll ag=%s erro MP: %s", r["id"], exc.detail)
                continue
            except Exception as exc:
                logger.warning("[clinica] poll ag=%s erro: %s", r["id"], exc)
                continue
            if mp_order.get("status") == "processed":
                if await asyncio.to_thread(confirmar_e_notificar, r["id"], oid):
                    enviados += 1
                break  # já confirmou — não precisa checar a outra order
    return enviados


# ──────────────────────────────────────────────────────────────────────────
# Etapa 11 — Lembrete automático 1 dia antes
#
# Para cada agendamento `confirmado` cuja `data == amanhã`, envia uma
# mensagem WhatsApp de lembrete. Disparado pelo loop diário em events.py
# dentro da janela 09:00–18:00 (horário comercial).
#
# Flag `lembrete_enviado` garante envio único — se o servidor reiniciar
# durante a janela, o próximo tick não duplica a mensagem.
# ──────────────────────────────────────────────────────────────────────────


def _build_lembrete_message(ag: dict) -> str:
    """Mensagem de lembrete enviada 1 dia antes do agendamento."""
    return (
        f"Oi, {ag['cliente_nome'].split(' ')[0]}! 💆‍♀️\n\n"
        f"Passando para lembrar do seu atendimento *amanhã* na "
        f"*Clínica Vida Leve*:\n\n"
        f"📋 *Protocolo:* #{ag['id']}\n"
        f"💼 *Serviço:* {ag['servico_nome']}\n"
        f"👤 *Profissional:* {ag['profissional_nome']}\n"
        f"📅 *Data:* {_format_data_br(ag['data'])}\n"
        f"⏰ *Horário:* {ag['hora_inicio']} às {ag['hora_fim']}\n\n"
        f"Caso precise remarcar ou cancelar, é só responder essa "
        f"mensagem que a gente se organiza. 🌸"
    )


def enviar_lembrete(ag_id: int) -> bool:
    """Envia o lembrete WhatsApp de um agendamento. Idempotente.

    Retorna True se enviou nesta chamada. False se já estava enviado,
    se o agendamento não é mais elegível (cancelado / não-confirmado),
    ou se o envio falhou — nesse último caso a flag continua em 0 para
    a próxima rodada do loop tentar de novo.

    Roda síncrono — o caller decide se quer `asyncio.to_thread`.
    """
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT a.id, a.status, a.lembrete_enviado, "
                "       a.cliente_nome, a.cliente_telefone, a.data, "
                "       a.hora_inicio, a.hora_fim, "
                "       s.nome AS servico_nome, p.nome AS profissional_nome "
                "FROM plugin_clinica_agendamentos a "
                "LEFT JOIN plugin_clinica_servicos s ON s.id = a.servico_id "
                "LEFT JOIN plugin_clinica_profissionais p ON p.id = a.profissional_id "
                "WHERE a.id = :id"
            ),
            {"id": ag_id},
        ).mappings().first()

        if not row:
            return False
        if row["status"] != "confirmado":
            return False
        if row["lembrete_enviado"]:
            return False

        ag = dict(row)

    # Envio fora da transação — HTTP request não pode segurar locks do DB.
    message = _build_lembrete_message(ag)
    enviado = _send_whatsapp(ag["cliente_telefone"], message, source="clinica_lembrete")

    if enviado:
        with make_plugin_db() as conn:
            conn.execute(
                text(
                    "UPDATE plugin_clinica_agendamentos "
                    "SET lembrete_enviado = 1 "
                    "WHERE id = :id"
                ),
                {"id": ag_id},
            )
        logger.info("[clinica] lembrete enviado ag=%s", ag_id)
    else:
        logger.warning("[clinica] lembrete falhou ag=%s — sera retentado", ag_id)
    return enviado


def enviar_proximo_lembrete() -> dict:
    """Envia UM lembrete pendente (o próximo na fila) e retorna o resultado.

    Mantém o ritmo de envio sob controle: o loop em events.py chama esta
    função no máximo uma vez a cada `lembrete_intervalo_min` minutos,
    garantindo que cada cliente receba sua mensagem espaçada da próxima.
    Isso protege o número contra bloqueio do WhatsApp por rajada.

    Retorno:
      {
        "tentou":  bool,  # houve algum candidato pra tentar enviar
        "enviado": bool,  # mensagem saiu com sucesso pra GOWA
        "ag_id":   int|None,
        "restantes_antes": int,  # quantos havia na fila incluindo este
      }

    Roda síncrono — caller usa `asyncio.to_thread`.
    """
    amanha = (date.today() + timedelta(days=1)).isoformat()
    with make_plugin_db() as conn:
        ids = conn.execute(
            text(
                "SELECT id FROM plugin_clinica_agendamentos "
                "WHERE data = :amanha "
                "  AND status = 'confirmado' "
                "  AND lembrete_enviado = 0 "
                "ORDER BY hora_inicio, id"
            ),
            {"amanha": amanha},
        ).scalars().all()

    if not ids:
        return {"tentou": False, "enviado": False, "ag_id": None, "restantes_antes": 0}

    ag_id = ids[0]
    enviado = enviar_lembrete(ag_id)
    return {
        "tentou": True,
        "enviado": enviado,
        "ag_id": ag_id,
        "restantes_antes": len(ids),
    }


# ──────────────────────────────────────────────────────────────────────────
# Etapa 13 — Dashboard final
#
# Endpoint único de leitura agregada para o painel admin. Tudo é calculado
# on-demand a partir das tabelas existentes (sem nova migration); o custo
# fica abaixo de uma dezena de queries simples mesmo em demo com centenas
# de agendamentos.
#
# Métricas:
#   • KPIs do período: faturamento, confirmados, ticket médio, taxa de
#     conversão (confirmado / (confirmado + cancelado)).
#   • Funil: pendente_pagamento → confirmado → notificação WhatsApp →
#     lembrete WhatsApp. Usa as flags `notificacao_enviada` e
#     `lembrete_enviado` introduzidas nas Etapas 9 e 11.
#   • Série diária de faturamento (para gráfico de barras simples no front).
#   • Top serviços por reservas confirmadas no período.
#   • Ocupação por profissional nos próximos N dias (minutos agendados /
#     minutos disponíveis nos horários cadastrados, recortando dias
#     passados pra que o cálculo seja "olhando pra frente").
#   • Conversão de convites (Etapa 12.5): criados × usados × expirados.
#
# Decisão didática: "ocupação" é em minutos (não slots de duração X),
# porque os serviços têm durações variadas e o gerador de slots usa
# step = duração — qualquer aproximação por slot ficaria amarrada a um
# serviço específico. Minutos é uma métrica mais honesta e mais simples
# de explicar.
# ──────────────────────────────────────────────────────────────────────────


def _dashboard_periodo(dias: int) -> tuple[str, str]:
    """Retorna (ini_iso, fim_iso) do período hoje-N+1 ... hoje."""
    fim = date.today()
    ini = fim - timedelta(days=max(0, dias - 1))
    return ini.isoformat(), fim.isoformat()


def _dashboard_kpis(conn, ini_iso: str, fim_iso: str) -> dict:
    """Faturamento, contagens por status e ticket médio dentro do período."""
    row = conn.execute(
        text(
            "SELECT "
            " SUM(CASE WHEN status = 'confirmado' THEN valor_centavos ELSE 0 END) AS faturamento, "
            " SUM(CASE WHEN status = 'confirmado' THEN 1 ELSE 0 END) AS confirmados, "
            " SUM(CASE WHEN status = 'pendente_pagamento' THEN 1 ELSE 0 END) AS pendentes, "
            " SUM(CASE WHEN status = 'cancelado' THEN 1 ELSE 0 END) AS cancelados "
            "FROM plugin_clinica_agendamentos "
            "WHERE data >= :ini AND data <= :fim"
        ),
        {"ini": ini_iso, "fim": fim_iso},
    ).mappings().first() or {}

    faturamento = int(row.get("faturamento") or 0)
    confirmados = int(row.get("confirmados") or 0)
    pendentes = int(row.get("pendentes") or 0)
    cancelados = int(row.get("cancelados") or 0)

    decididos = confirmados + cancelados
    taxa = (confirmados / decididos) if decididos else 0.0
    ticket = (faturamento // confirmados) if confirmados else 0

    return {
        "faturamento_centavos": faturamento,
        "reservas_confirmadas": confirmados,
        "reservas_pendentes": pendentes,
        "reservas_canceladas": cancelados,
        "ticket_medio_centavos": ticket,
        "taxa_conversao": round(taxa, 4),
    }


def _dashboard_funil(conn, ini_iso: str, fim_iso: str) -> dict:
    """Quantos agendamentos passaram por cada estágio do funil no período."""
    row = conn.execute(
        text(
            "SELECT "
            " SUM(CASE WHEN status = 'pendente_pagamento' THEN 1 ELSE 0 END) AS pendentes, "
            " SUM(CASE WHEN status = 'confirmado' THEN 1 ELSE 0 END) AS confirmados, "
            " SUM(CASE WHEN status != 'cancelado' AND notificacao_enviada = 1 THEN 1 ELSE 0 END) AS notificados, "
            " SUM(CASE WHEN status != 'cancelado' AND lembrete_enviado = 1 THEN 1 ELSE 0 END) AS lembrados "
            "FROM plugin_clinica_agendamentos "
            "WHERE data >= :ini AND data <= :fim"
        ),
        {"ini": ini_iso, "fim": fim_iso},
    ).mappings().first() or {}
    return {
        "pendente_pagamento": int(row.get("pendentes") or 0),
        "confirmado": int(row.get("confirmados") or 0),
        "notificacao_enviada": int(row.get("notificados") or 0),
        "lembrete_enviado": int(row.get("lembrados") or 0),
    }


def _dashboard_faturamento_diario(conn, ini_iso: str, fim_iso: str) -> list[dict]:
    """Série diária de faturamento confirmado.

    Garante que TODOS os dias do período aparecem (mesmo zerados) — facilita
    o gráfico no front sem precisar pivotar.
    """
    rows = conn.execute(
        text(
            "SELECT data, SUM(valor_centavos) AS valor, COUNT(*) AS qtd "
            "FROM plugin_clinica_agendamentos "
            "WHERE status = 'confirmado' AND data >= :ini AND data <= :fim "
            "GROUP BY data ORDER BY data"
        ),
        {"ini": ini_iso, "fim": fim_iso},
    ).mappings().all()
    por_data = {r["data"]: (int(r["valor"] or 0), int(r["qtd"] or 0)) for r in rows}

    ini = date.fromisoformat(ini_iso)
    fim = date.fromisoformat(fim_iso)
    out: list[dict] = []
    d = ini
    while d <= fim:
        iso = d.isoformat()
        valor, qtd = por_data.get(iso, (0, 0))
        out.append({"data": iso, "valor_centavos": valor, "qtd": qtd})
        d += timedelta(days=1)
    return out


def _dashboard_top_servicos(conn, ini_iso: str, fim_iso: str, limit: int = 5) -> list[dict]:
    """Top serviços por agendamentos confirmados no período."""
    rows = conn.execute(
        text(
            "SELECT a.servico_id, s.nome AS servico_nome, "
            "       COUNT(*) AS qtd, "
            "       SUM(a.valor_centavos) AS faturamento "
            "FROM plugin_clinica_agendamentos a "
            "JOIN plugin_clinica_servicos s ON s.id = a.servico_id "
            "WHERE a.status = 'confirmado' "
            "  AND a.data >= :ini AND a.data <= :fim "
            "GROUP BY a.servico_id, s.nome "
            "ORDER BY qtd DESC, faturamento DESC "
            "LIMIT :lim"
        ),
        {"ini": ini_iso, "fim": fim_iso, "lim": int(limit)},
    ).mappings().all()
    return [
        {
            "servico_id": r["servico_id"],
            "nome": r["servico_nome"],
            "qtd": int(r["qtd"] or 0),
            "faturamento_centavos": int(r["faturamento"] or 0),
        }
        for r in rows
    ]


def _dashboard_ocupacao(conn, dias_futuros: int = 30) -> list[dict]:
    """Ocupação por profissional nos próximos N dias.

    Conta minutos AGENDADOS (status != cancelado, data ∈ [hoje, hoje+N))
    sobre minutos DISPONÍVEIS (soma de blocos de horário recorrentes,
    aplicados a cada dia útil do intervalo). É uma métrica em minutos —
    mais honesta que "slots" quando há serviços de durações diferentes.

    Dias passados não entram (a métrica é olhar pra frente). Hoje conta
    inteiro — não recortamos pelas horas que já passaram, pra manter a
    leitura simples ("agenda do profissional pros próximos 30 dias").
    """
    today = date.today()
    fim = today + timedelta(days=max(1, dias_futuros) - 1)

    profs = conn.execute(
        text(
            "SELECT id, nome, especialidade "
            "FROM plugin_clinica_profissionais "
            "WHERE ativo = 1 "
            "ORDER BY nome"
        )
    ).mappings().all()

    if not profs:
        return []

    horarios = conn.execute(
        text(
            "SELECT profissional_id, dia_semana, hora_inicio, hora_fim "
            "FROM plugin_clinica_horarios "
            "WHERE ativo = 1"
        )
    ).mappings().all()

    # Minutos por (profissional_id, dia_semana)
    min_por_dia: dict[tuple[int, int], int] = {}
    for h in horarios:
        delta = _hhmm_to_min(h["hora_fim"]) - _hhmm_to_min(h["hora_inicio"])
        if delta <= 0:
            continue
        key = (h["profissional_id"], h["dia_semana"])
        min_por_dia[key] = min_por_dia.get(key, 0) + delta

    # Agendados por profissional no intervalo (status != cancelado)
    agendados_rows = conn.execute(
        text(
            "SELECT profissional_id, SUM(duracao_min) AS total "
            "FROM plugin_clinica_agendamentos "
            "WHERE status != 'cancelado' "
            "  AND data >= :ini AND data <= :fim "
            "GROUP BY profissional_id"
        ),
        {"ini": today.isoformat(), "fim": fim.isoformat()},
    ).mappings().all()
    agendados = {r["profissional_id"]: int(r["total"] or 0) for r in agendados_rows}

    # Pré-calcula quantas vezes cada dia_semana aparece no intervalo.
    contagem_dias: dict[int, int] = {i: 0 for i in range(7)}
    d = today
    while d <= fim:
        contagem_dias[d.weekday()] += 1
        d += timedelta(days=1)

    out: list[dict] = []
    for p in profs:
        disponivel = 0
        for ds, vezes in contagem_dias.items():
            disponivel += min_por_dia.get((p["id"], ds), 0) * vezes
        ocupado = min(agendados.get(p["id"], 0), disponivel) if disponivel else agendados.get(p["id"], 0)
        pct = (ocupado / disponivel) if disponivel else 0.0
        out.append({
            "profissional_id": p["id"],
            "nome": p["nome"],
            "especialidade": p["especialidade"] or "",
            "minutos_disponiveis": disponivel,
            "minutos_agendados": agendados.get(p["id"], 0),
            "ocupacao_pct": round(pct, 4),
        })
    return out


def _dashboard_convites(conn) -> dict:
    """Conversão dos convites criados pela tool `enviar_link_agendamento`.

    Métrica de eficácia da Etapa 12.5: quantos links a IA mandou e quantos
    viraram agendamento de fato. Métricas globais (não recortadas por período
    — convites têm TTL de 7 dias e o volume é baixo na escala didática).
    """
    now = time.time()
    row = conn.execute(
        text(
            "SELECT "
            " COUNT(*) AS criados, "
            " SUM(CASE WHEN used_at IS NOT NULL THEN 1 ELSE 0 END) AS usados, "
            " SUM(CASE WHEN used_at IS NULL AND expires_at < :now THEN 1 ELSE 0 END) AS expirados, "
            " SUM(CASE WHEN used_at IS NULL AND expires_at >= :now THEN 1 ELSE 0 END) AS ativos "
            "FROM plugin_clinica_convites"
        ),
        {"now": now},
    ).mappings().first() or {}
    criados = int(row.get("criados") or 0)
    usados = int(row.get("usados") or 0)
    taxa = (usados / criados) if criados else 0.0
    return {
        "criados": criados,
        "usados": usados,
        "expirados": int(row.get("expirados") or 0),
        "ativos": int(row.get("ativos") or 0),
        "taxa_conversao": round(taxa, 4),
    }


@router.get("/admin/dashboard")
async def admin_dashboard(
    periodo: int = Query(30, ge=1, le=365, description="Janela em dias (default 30, máximo 365)."),
    dias_ocupacao: int = Query(30, ge=1, le=180, description="Janela futura para ocupação (default 30)."),
    top_servicos: int = Query(5, ge=1, le=20, description="Quantos serviços no ranking (default 5)."),
) -> dict:
    """Retorna o pacote completo de métricas do dashboard.

    Um endpoint só pra evitar latência de N round-trips. O custo é
    ~6 queries simples — escala bem em demo (~centenas de linhas) e
    permite o front renderizar tudo numa única passada.
    """
    ini_iso, fim_iso = _dashboard_periodo(periodo)
    with make_plugin_db() as conn:
        kpis = _dashboard_kpis(conn, ini_iso, fim_iso)
        funil = _dashboard_funil(conn, ini_iso, fim_iso)
        faturamento_diario = _dashboard_faturamento_diario(conn, ini_iso, fim_iso)
        top = _dashboard_top_servicos(conn, ini_iso, fim_iso, limit=top_servicos)
        ocupacao = _dashboard_ocupacao(conn, dias_futuros=dias_ocupacao)
        convites = _dashboard_convites(conn)

    return _ok({
        "periodo": {
            "dias": periodo,
            "ini": ini_iso,
            "fim": fim_iso,
        },
        "kpis": kpis,
        "funil": funil,
        "faturamento_diario": faturamento_diario,
        "ranking_servicos": top,
        "ocupacao_profissionais": ocupacao,
        "ocupacao_dias_futuros": dias_ocupacao,
        "convites": convites,
    })
