-- Cartao de credito ganha sua propria order MP, separada da order PIX.
--
-- Antes, PIX e cartao gravavam na mesma coluna mp_order_id. Como a tool
-- clinica_agendar cria a order PIX ANTECIPADAMENTE (pra ja mandar o codigo
-- no WhatsApp e deixar o QR pronto quando o cliente abre o link), a coluna
-- ficava ocupada pela order PIX. Ao pagar no cartao, o endpoint
-- iniciar-pagamento caia no curto-circuito de idempotencia (checava so se
-- mp_order_id existia) e devolvia o status da order PIX pendente
-- (action_required / waiting_transfer) SEM nunca cobrar o cartao.
--
-- Com uma coluna dedicada ao cartao, PIX e cartao coexistem: o cliente paga
-- o que preferir e a reserva confirma na primeira order que for aprovada.
--
-- Nullable: so e preenchida quando o cliente inicia um pagamento por cartao.

ALTER TABLE plugin_clinica_agendamentos ADD COLUMN mp_order_id_card TEXT;
