-- Etapa 1 — Base do sistema da Clinica Vida Leve
-- Cria tabelas de profissionais e servicos.
-- Sem dados de demonstracao. O plugin sobe virgem para a Loja e o admin
-- cadastra seus proprios profissionais e servicos pela interface.

CREATE TABLE IF NOT EXISTS plugin_clinica_profissionais (
    id            INTEGER PRIMARY KEY,
    nome          TEXT    NOT NULL,
    especialidade TEXT    NOT NULL DEFAULT '',
    ativo         INTEGER NOT NULL DEFAULT 1,
    created_at    REAL    NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_clinica_profissionais_ativo
    ON plugin_clinica_profissionais(ativo);

CREATE TABLE IF NOT EXISTS plugin_clinica_servicos (
    id              INTEGER PRIMARY KEY,
    nome            TEXT    NOT NULL,
    descricao       TEXT    NOT NULL DEFAULT '',
    duracao_min     INTEGER NOT NULL DEFAULT 60,
    valor_centavos  INTEGER NOT NULL DEFAULT 0,
    ativo           INTEGER NOT NULL DEFAULT 1,
    created_at      REAL    NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_clinica_servicos_ativo
    ON plugin_clinica_servicos(ativo);
