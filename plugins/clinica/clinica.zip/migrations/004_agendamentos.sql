-- Etapa 6: Agendamentos.
--
-- Cada linha e uma reserva concreta (cliente, servico, profissional, data, hora).
-- Campos de snapshot (duracao_min, valor_centavos, hora_fim) preservam o estado
-- na hora da reserva: se o servico mudar de preco ou duracao depois, o
-- agendamento continua coerente com o que o cliente viu.
--
-- status pode ser: pendente_pagamento, confirmado ou cancelado.
-- O default e pendente_pagamento. cancelado libera o slot de novo.
--
-- FKs sem ON DELETE CASCADE: agendamento referencia o historico de
-- profissional e servico. Como esses sao soft-deleted (ativo=0), as linhas
-- nunca somem do banco.
--
-- ATENCAO: o splitter de migration do WhatsBot respeita aspas simples mas NAO
-- respeita comentarios. Evite ponto-e-virgula e apostrofo dentro de -- ...

CREATE TABLE IF NOT EXISTS plugin_clinica_agendamentos (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    servico_id       INTEGER NOT NULL REFERENCES plugin_clinica_servicos(id),
    profissional_id  INTEGER NOT NULL REFERENCES plugin_clinica_profissionais(id),
    cliente_nome     TEXT    NOT NULL,
    cliente_telefone TEXT    NOT NULL,
    data             TEXT    NOT NULL,
    hora_inicio      TEXT    NOT NULL,
    hora_fim         TEXT    NOT NULL,
    duracao_min      INTEGER NOT NULL,
    valor_centavos   INTEGER NOT NULL,
    status           TEXT    NOT NULL DEFAULT 'pendente_pagamento',
    created_at       REAL    NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_clinica_agendamentos_data_prof_idx
    ON plugin_clinica_agendamentos (data, profissional_id);

CREATE INDEX IF NOT EXISTS plugin_clinica_agendamentos_status_idx
    ON plugin_clinica_agendamentos (status);
