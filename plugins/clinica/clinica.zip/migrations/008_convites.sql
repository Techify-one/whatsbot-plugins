-- Etapa 12.5 convites de agendamento pre-preenchimento do WhatsApp
--
-- Cada linha e um token curto gerado pela tool enviar_link_agendamento
-- ao decidir mandar o link de reservas ao cliente. O token vai na URL
-- como /clinica/agendar?c=TOKEN e a pagina publica consulta
-- GET /api/plugins/clinica/convites/TOKEN para descobrir o telefone do
-- contato e pre-preencher o campo WhatsApp editavel.
--
-- O nome NAO e armazenado por escolha de UX o cliente pode ter
-- cadastrado um apelido no contato e digitar nome completo no form.
--
-- Campos
--   token       chave primaria 8 chars urlsafe
--   telefone    digitos do WhatsApp do contato sem DDI 55
--   created_at  unix timestamp
--   expires_at  unix timestamp default 7 dias apos created_at
--   used_at     unix timestamp da primeira conversao opcional

CREATE TABLE IF NOT EXISTS plugin_clinica_convites (
  token       TEXT PRIMARY KEY,
  telefone    TEXT NOT NULL,
  created_at  REAL NOT NULL,
  expires_at  REAL NOT NULL,
  used_at     REAL
);

CREATE INDEX IF NOT EXISTS plugin_clinica_convites_telefone_idx
  ON plugin_clinica_convites(telefone);
