-- Bloqueios de agenda do profissional.
--
-- Tranca parte (ou toda) a agenda de um profissional para nao receber
-- marcacoes em um periodo. Motivo livre (compromisso pessoal, consulta,
-- viagem, ferias) e generico. Nunca chamamos de folga.
--
-- Granularidade dupla controlada por dia_inteiro:
--   dia_inteiro=1 tranca o dia todo de cada dia do intervalo data_inicio..data_fim.
--   dia_inteiro=0 tranca apenas a faixa hora_inicio..hora_fim de cada dia do intervalo.
--
-- origem distingue de onde nasceu o bloqueio:
--   clinica  cadastrado no painel (pode espelhar no Google).
--   google   evento criado direto na agenda Google do profissional (so leitura na UI).
--
-- google_event_id guarda o id do evento espelhado ou originado no Google.
--
-- ATENCAO ao splitter de migrations sem ponto e virgula sem apostrofo e sem
-- dois pontos dentro de comentarios.

CREATE TABLE IF NOT EXISTS plugin_clinica_bloqueios (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    profissional_id  INTEGER NOT NULL REFERENCES plugin_clinica_profissionais(id) ON DELETE CASCADE,
    data_inicio      TEXT    NOT NULL,
    data_fim         TEXT    NOT NULL,
    dia_inteiro      INTEGER NOT NULL DEFAULT 1,
    hora_inicio      TEXT,
    hora_fim         TEXT,
    motivo           TEXT    NOT NULL DEFAULT '',
    origem           TEXT    NOT NULL DEFAULT 'clinica',
    google_event_id  TEXT,
    created_at       REAL    NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_clinica_bloqueios_prof_data_idx
    ON plugin_clinica_bloqueios (profissional_id, data_inicio, data_fim);

CREATE INDEX IF NOT EXISTS plugin_clinica_bloqueios_google_idx
    ON plugin_clinica_bloqueios (google_event_id);
