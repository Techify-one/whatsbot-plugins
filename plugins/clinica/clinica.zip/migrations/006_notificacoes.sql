-- Etapa 9 pagamento confirmado automaticamente e notificacao WhatsApp.
--
-- Adiciona duas colunas em plugin_clinica_agendamentos
--   notificacao_enviada  flag 0 ainda nao avisado 1 ja enviou no WhatsApp
--   confirmado_em        timestamp Unix quando o status virou confirmado
--
-- Sao usadas pelo background poller events.py e pelos endpoints de
-- pagamento routes.py para garantir idempotencia a mensagem so e
-- enviada uma vez por agendamento mesmo se o poller rodar varias vezes
-- ou o frontend tambem detectar o pagamento.

ALTER TABLE plugin_clinica_agendamentos ADD COLUMN notificacao_enviada INTEGER NOT NULL DEFAULT 0;
ALTER TABLE plugin_clinica_agendamentos ADD COLUMN confirmado_em REAL;
