-- Etapa 5 integracao com o gateway agenda (Google Calendar)
--
-- Cada profissional pode ter uma agenda Google propria criada com 1 clique pelo
-- painel. Guardamos o id da agenda Google (google_calendar_id) para criar e
-- cancelar eventos do profissional, e o email do profissional (email) que vira
-- o dono compartilhado da agenda via acl.insert do gateway.
--
-- google_calendar_id NULL significa que o profissional ainda nao tem agenda
-- Google vinculada (os agendamentos seguem funcionando in app sem espelhar no
-- Google). email vazio significa que nao foi cadastrado ainda.
--
-- Migracao nao destrutiva as linhas existentes ficam com as duas colunas
-- vazias e seguem o comportamento atual sem mudanca.
--
-- ATENCAO ao splitter de migrations sem ponto e virgula sem apostrofo e sem
-- dois pontos dentro de comentarios.

ALTER TABLE plugin_clinica_profissionais ADD COLUMN email TEXT;

ALTER TABLE plugin_clinica_profissionais ADD COLUMN google_calendar_id TEXT;
