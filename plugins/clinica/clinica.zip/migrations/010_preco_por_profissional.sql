-- Etapa 16 preco de servico por profissional
--
-- Adiciona um override de preco no vinculo servico profissional. Antes o preco
-- era unico por servico agora cada profissional pode cobrar um valor diferente
-- pelo mesmo servico (ex Dra Carla 100 e Dra Bruna 200 na avaliacao estetica).
--
-- valor_centavos NULL significa herdar o preco base do servico
-- (plugin_clinica_servicos.valor_centavos). Migracao nao destrutiva os vinculos
-- existentes ficam NULL e seguem usando o preco base sem mudanca de comportamento.
--
-- ATENCAO ao splitter de migrations sem ponto e virgula sem apostrofo e sem
-- dois pontos dentro de comentarios.

ALTER TABLE plugin_clinica_servicos_profissionais ADD COLUMN valor_centavos INTEGER;
