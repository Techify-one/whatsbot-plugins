-- Etapa 14 recuperacao recria todas as tabelas do plugin clinica
--
-- Contexto um delete parcial dropou as tabelas mas o historico de migrations
-- 001 a 008 permaneceu o que faria o migrator pular a recriacao. Esta migration
-- tem numero novo 009 entao roda mesmo com o historico antigo presente.
--
-- Idempotente usa CREATE TABLE IF NOT EXISTS e os seeds so inserem quando a
-- tabela esta vazia portanto e seguro tambem numa instalacao limpa onde 001 a
-- 008 ja criaram e populram as tabelas.
--
-- ATENCAO ao splitter de migrations sem ponto e virgula sem apostrofo e sem
-- dois pontos dentro de comentarios

CREATE TABLE IF NOT EXISTS plugin_clinica_profissionais (
    id            INTEGER PRIMARY KEY,
    nome          TEXT    NOT NULL,
    especialidade TEXT    NOT NULL DEFAULT '',
    ativo         INTEGER NOT NULL DEFAULT 1,
    created_at    REAL    NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_clinica_profissionais_ativo
    ON plugin_clinica_profissionais(ativo);

CREATE TABLE IF NOT EXISTS plugin_clinica_servicos (
    id              INTEGER PRIMARY KEY,
    nome            TEXT    NOT NULL,
    descricao       TEXT    NOT NULL DEFAULT '',
    duracao_min     INTEGER NOT NULL DEFAULT 60,
    valor_centavos  INTEGER NOT NULL DEFAULT 0,
    ativo           INTEGER NOT NULL DEFAULT 1,
    created_at      REAL    NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_clinica_servicos_ativo
    ON plugin_clinica_servicos(ativo);

CREATE TABLE IF NOT EXISTS plugin_clinica_servicos_profissionais (
    servico_id      INTEGER NOT NULL,
    profissional_id INTEGER NOT NULL,
    created_at      REAL    NOT NULL,
    PRIMARY KEY (servico_id, profissional_id),
    FOREIGN KEY (servico_id)      REFERENCES plugin_clinica_servicos(id)      ON DELETE CASCADE,
    FOREIGN KEY (profissional_id) REFERENCES plugin_clinica_profissionais(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS plugin_clinica_servicos_profissionais_prof
    ON plugin_clinica_servicos_profissionais(profissional_id);

CREATE TABLE IF NOT EXISTS plugin_clinica_horarios (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    profissional_id INTEGER NOT NULL
        REFERENCES plugin_clinica_profissionais(id) ON DELETE CASCADE,
    dia_semana      INTEGER NOT NULL CHECK (dia_semana BETWEEN 0 AND 6),
    hora_inicio     TEXT    NOT NULL,
    hora_fim        TEXT    NOT NULL,
    ativo           INTEGER NOT NULL DEFAULT 1,
    created_at      REAL    NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_clinica_horarios_prof_idx
    ON plugin_clinica_horarios (profissional_id);

CREATE TABLE IF NOT EXISTS plugin_clinica_agendamentos (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    servico_id          INTEGER NOT NULL REFERENCES plugin_clinica_servicos(id),
    profissional_id     INTEGER NOT NULL REFERENCES plugin_clinica_profissionais(id),
    cliente_nome        TEXT    NOT NULL,
    cliente_telefone    TEXT    NOT NULL,
    data                TEXT    NOT NULL,
    hora_inicio         TEXT    NOT NULL,
    hora_fim            TEXT    NOT NULL,
    duracao_min         INTEGER NOT NULL,
    valor_centavos      INTEGER NOT NULL,
    status              TEXT    NOT NULL DEFAULT 'pendente_pagamento',
    created_at          REAL    NOT NULL,
    mp_order_id         TEXT,
    notificacao_enviada INTEGER NOT NULL DEFAULT 0,
    confirmado_em       REAL,
    lembrete_enviado    INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS plugin_clinica_agendamentos_data_prof_idx
    ON plugin_clinica_agendamentos (data, profissional_id);

CREATE INDEX IF NOT EXISTS plugin_clinica_agendamentos_status_idx
    ON plugin_clinica_agendamentos (status);

CREATE TABLE IF NOT EXISTS plugin_clinica_convites (
    token       TEXT PRIMARY KEY,
    telefone    TEXT NOT NULL,
    created_at  REAL NOT NULL,
    expires_at  REAL NOT NULL,
    used_at     REAL
);

CREATE INDEX IF NOT EXISTS plugin_clinica_convites_telefone_idx
    ON plugin_clinica_convites(telefone);

-- Sem seed de demonstracao. O plugin sobe virgem para a Loja. As tabelas sao
-- apenas (re)criadas se faltarem. Profissionais, servicos, vinculos e horarios
-- sao cadastrados pelo admin na interface. Antes esta migration re-semeava
-- dados ficticios quando as tabelas estavam vazias, removido para publicacao.
