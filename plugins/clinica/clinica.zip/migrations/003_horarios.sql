-- Etapa 4: Horários de atendimento por profissional.
--
-- Cada linha é um bloco semanal recorrente: "todo <dia_semana> das <hora_inicio> às <hora_fim>".
-- dia_semana: 0=segunda, 1=terça, 2=quarta, 3=quinta, 4=sexta, 5=sábado, 6=domingo
-- (Mesma convenção de Python datetime.weekday() — facilita o cálculo de slots na Etapa 5.)
-- Horas armazenadas como TEXT "HH:MM" (00:00–23:59), comparação lexicográfica funciona corretamente.

CREATE TABLE IF NOT EXISTS plugin_clinica_horarios (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    profissional_id INTEGER NOT NULL
        REFERENCES plugin_clinica_profissionais(id) ON DELETE CASCADE,
    dia_semana      INTEGER NOT NULL CHECK (dia_semana BETWEEN 0 AND 6),
    hora_inicio     TEXT    NOT NULL,
    hora_fim        TEXT    NOT NULL,
    ativo           INTEGER NOT NULL DEFAULT 1,
    created_at      REAL    NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_clinica_horarios_prof_idx
    ON plugin_clinica_horarios (profissional_id);

-- Sem seed. Os horarios de atendimento sao cadastrados pelo admin na
-- interface (aba Profissionais, editar horarios de cada profissional).
