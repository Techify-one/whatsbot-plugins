-- Etapa 19, item 4 (hardening pos-review de seguranca).
--
-- Token opaco para o link publico de pagamento, em vez do ID sequencial
-- cru na URL. Sem isso, GET /agendamentos/{id} (endpoint publico, sem auth)
-- permitia varrer nome, telefone e servico de qualquer reserva so testando
-- IDs sequenciais em ordem - dado sensivel numa clinica estetica.
--
-- pagamento_token e gerado sob demanda (na primeira vez que a tool
-- clinica_agendar ou clinica_remarcar_agendamento monta o link de
-- pagamento) e reaproveitado depois - nao muda a cada chamada.

ALTER TABLE plugin_clinica_agendamentos ADD COLUMN pagamento_token TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS plugin_clinica_agendamentos_pagamento_token_idx
  ON plugin_clinica_agendamentos (pagamento_token);
