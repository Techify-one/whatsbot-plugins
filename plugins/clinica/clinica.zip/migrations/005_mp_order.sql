-- Etapa 8: Pagamento via Mercado Pago.
--
-- Adiciona mp_order_id a tabela de agendamentos para rastrear
-- a order criada no Mercado Pago. Nullable porque so e preenchido
-- quando o pagamento e iniciado (POST /agendamentos/{id}/iniciar-pagamento).
--
-- SQLite suporta ALTER TABLE ADD COLUMN sem restriacoes extras desde 3.x.

ALTER TABLE plugin_clinica_agendamentos ADD COLUMN mp_order_id TEXT;
