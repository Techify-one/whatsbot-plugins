-- Etapa 3 — Relação N:N entre serviços e profissionais
-- Define QUAIS profissionais atendem QUAIS serviços.
-- A página pública de agendamento (Etapa 6) vai usar isso para mostrar
-- ao cliente só os profissionais que realmente fazem o serviço escolhido.

CREATE TABLE IF NOT EXISTS plugin_clinica_servicos_profissionais (
    servico_id      INTEGER NOT NULL,
    profissional_id INTEGER NOT NULL,
    created_at      REAL    NOT NULL,
    PRIMARY KEY (servico_id, profissional_id),
    FOREIGN KEY (servico_id)      REFERENCES plugin_clinica_servicos(id)      ON DELETE CASCADE,
    FOREIGN KEY (profissional_id) REFERENCES plugin_clinica_profissionais(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS plugin_clinica_servicos_profissionais_prof
    ON plugin_clinica_servicos_profissionais(profissional_id);

-- Sem seed. Os vinculos servico-profissional sao definidos pelo admin na
-- interface (aba Servicos, botao de profissionais de cada servico).
