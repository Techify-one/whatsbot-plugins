-- Etapa 11 lembrete automatico 1 dia antes do agendamento.
--
-- Adiciona coluna lembrete_enviado em plugin_clinica_agendamentos
--   flag de idempotencia 0 ainda nao avisado 1 ja enviou no WhatsApp
--
-- O background loop em events py executa uma vez por dia dentro da
-- janela de horario comercial entre 09 e 18 horas varrendo
-- agendamentos confirmados com data igual a amanha e disparando
-- lembrete WhatsApp para cada um.

ALTER TABLE plugin_clinica_agendamentos ADD COLUMN lembrete_enviado INTEGER NOT NULL DEFAULT 0;
