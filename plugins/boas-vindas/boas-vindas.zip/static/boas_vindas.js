// Tela de configuração do plugin "Boas-vindas em Grupos".
// Renderizada dentro do modal "Configurar" do card em /plugins (config: true).
// Preact + HTM, classes wa-* / .wa-field pra ficar legível nos dois temas.
import { h } from 'preact';
import { useEffect, useMemo, useState } from 'preact/hooks';
import htm from 'htm';

const html = htm.bind(h);

function authHeaders(extra = {}) {
  const token = localStorage.getItem('whatsbot_token') || '';
  return token ? { ...extra, Authorization: `Bearer ${token}` } : { ...extra };
}

async function apiFetch(url, init = {}) {
  const headers = authHeaders(init.headers || {});
  const res = await fetch(url, { ...init, headers });
  if (res.status === 401) {
    localStorage.removeItem('whatsbot_token');
    window.dispatchEvent(new Event('whatsbot:unauthorized'));
    throw new Error('Não autenticado.');
  }
  return res;
}

function Toggle({ checked, disabled, onChange }) {
  return html`
    <label class="inline-flex items-center cursor-pointer align-middle ${disabled ? 'opacity-60 cursor-not-allowed' : ''}">
      <input
        type="checkbox"
        class="sr-only peer"
        checked=${checked}
        disabled=${disabled}
        onChange=${(e) => onChange(e.currentTarget.checked)}
      />
      <div class="relative w-9 h-5 bg-gray-300 rounded-full peer peer-checked:bg-wa-teal transition-colors after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-transform peer-checked:after:translate-x-4"></div>
    </label>
  `;
}

export default function BoasVindas({ apiBase = '/api/plugins/boas_vindas' } = {}) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [okMsg, setOkMsg] = useState('');

  // Config global
  const [delay, setDelay] = useState(10);
  const [template, setTemplate] = useState('');
  const [savingCfg, setSavingCfg] = useState(false);

  // Grupos
  const [groups, setGroups] = useState([]);
  const [saving, setSaving] = useState({});
  const [query, setQuery] = useState('');
  const [showArchived, setShowArchived] = useState(false);

  async function loadAll() {
    setLoading(true);
    setError(null);
    try {
      const [cfgRes, grpRes] = await Promise.all([
        apiFetch(`${apiBase}/config`),
        apiFetch(`${apiBase}/groups`),
      ]);
      const cfg = await cfgRes.json();
      const grp = await grpRes.json();
      if (!cfg.ok) throw new Error(cfg.error || 'erro');
      if (!grp.ok) throw new Error(grp.error || 'erro');
      setDelay(cfg.data.delay_seconds);
      setTemplate(cfg.data.message_template);
      setGroups(grp.data.groups || []);
    } catch (e) {
      setError(String(e.message || e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadAll(); }, []);

  async function saveConfig() {
    setSavingCfg(true);
    setError(null);
    setOkMsg('');
    try {
      const r = await apiFetch(`${apiBase}/config`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          delay_seconds: Number(delay),
          message_template: template,
        }),
      });
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || 'erro');
      setDelay(data.data.delay_seconds);
      setTemplate(data.data.message_template);
      setOkMsg('Configuração salva');
      setTimeout(() => setOkMsg(''), 1500);
    } catch (e) {
      setError(String(e.message || e));
    } finally {
      setSavingCfg(false);
    }
  }

  async function toggleGroup(jid, enabled) {
    setSaving((p) => ({ ...p, [jid]: true }));
    setError(null);
    try {
      const r = await apiFetch(`${apiBase}/groups/${encodeURIComponent(jid)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled }),
      });
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || 'erro');
      setGroups((prev) => prev.map((g) => (
        g.chat_jid === jid ? { ...g, enabled: data.data.enabled } : g
      )));
    } catch (e) {
      setError(String(e.message || e));
    } finally {
      setSaving((p) => { const n = { ...p }; delete n[jid]; return n; });
    }
  }

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return groups.filter((g) => {
      if (!showArchived && g.is_archived) return false;
      if (!q) return true;
      return (g.name || '').toLowerCase().includes(q)
        || (g.chat_jid || '').toLowerCase().includes(q);
    });
  }, [groups, query, showArchived]);

  const enabledCount = useMemo(
    () => groups.filter((g) => g.enabled).length, [groups]
  );

  return html`
    <div class="p-6 max-w-3xl mx-auto text-wa-text">
      <h1 class="text-2xl font-bold mb-1">Boas-vindas em Grupos</h1>
      <p class="text-sm text-wa-secondary mb-5">
        Quando alguém entra num grupo <strong>ativado</strong>, o bot espera
        alguns segundos e marca a pessoa com <code>@</code> pedindo que ela se
        apresente. Os grupos vêm <strong>todos desativados</strong> por padrão —
        ative abaixo só os que você quiser.
      </p>

      ${error ? html`<div class="text-red-600 mb-3 text-sm">${error}</div>` : null}

      <!-- Configuração global -->
      <div class="bg-wa-panel border border-wa-border rounded-lg p-4 mb-6">
        <h2 class="text-sm font-semibold mb-3">Mensagem e tempo de espera</h2>

        <label class="block text-[13px] font-medium mb-1">
          Esperar antes de enviar (segundos)
        </label>
        <input
          type="number"
          min="0"
          max="3600"
          value=${delay}
          onInput=${(e) => setDelay(e.currentTarget.value)}
          class="wa-field w-32 text-[13px] rounded px-3 py-2 mb-1 focus:outline-none focus:border-wa-teal"
        />
        <p class="text-[11px] text-wa-secondary mb-4">
          Tempo entre a pessoa entrar e o bot enviar a mensagem. Padrão: 10s.
        </p>

        <label class="block text-[13px] font-medium mb-1">
          Texto da mensagem
        </label>
        <textarea
          rows="4"
          value=${template}
          onInput=${(e) => setTemplate(e.currentTarget.value)}
          class="wa-field w-full text-[13px] rounded px-3 py-2 mb-1 focus:outline-none focus:border-wa-teal"
        ></textarea>
        <p class="text-[11px] text-wa-secondary mb-4">
          Use <code>{mention}</code> onde quiser marcar a pessoa — é o que faz
          ela <strong>receber a notificação</strong> e mostra o nome dela.
          Opcional: <code>{primeiro_nome}</code> insere só o primeiro nome em
          texto (sem notificar). Se você não usar <code>{mention}</code>, a
          marcação é adicionada automaticamente no fim.
        </p>

        <div class="flex items-center gap-3">
          <button
            onClick=${saveConfig}
            disabled=${savingCfg}
            class="text-[13px] px-4 py-2 rounded bg-wa-teal text-white hover:opacity-90 disabled:opacity-50"
          >
            ${savingCfg ? 'Salvando…' : 'Salvar'}
          </button>
          ${okMsg ? html`<span class="text-[12px] text-green-600">${okMsg}</span>` : null}
        </div>
      </div>

      <!-- Grupos -->
      <div class="flex items-center gap-2 mb-2">
        <h2 class="text-sm font-semibold">Grupos</h2>
        ${enabledCount > 0 ? html`
          <span class="text-xs px-2 py-0.5 rounded bg-wa-teal/15 text-wa-teal">
            ${enabledCount} ativo${enabledCount === 1 ? '' : 's'}
          </span>
        ` : null}
      </div>

      <div class="flex flex-wrap items-center gap-3 mb-3">
        <input
          type="search"
          value=${query}
          onInput=${(e) => setQuery(e.currentTarget.value)}
          placeholder="Buscar grupo…"
          class="wa-field flex-1 min-w-[200px] md:max-w-sm text-[13px] rounded px-3 py-2 focus:outline-none focus:border-wa-teal"
        />
        <label class="inline-flex items-center gap-2 text-[12px] text-wa-secondary cursor-pointer">
          <input
            type="checkbox"
            checked=${showArchived}
            onChange=${(e) => setShowArchived(e.currentTarget.checked)}
            class="rounded border-wa-border"
          />
          mostrar arquivados
        </label>
        <button
          onClick=${loadAll}
          disabled=${loading}
          class="text-[13px] px-3 py-2 border border-wa-border rounded hover:bg-wa-hover disabled:opacity-50"
        >
          ${loading ? 'Carregando…' : 'Atualizar'}
        </button>
      </div>

      ${loading && groups.length === 0
        ? html`<div class="text-wa-secondary text-sm">Carregando…</div>`
        : filtered.length === 0
          ? html`
            <div class="bg-wa-panel border border-wa-border rounded-lg px-4 py-8 text-center text-wa-secondary text-[13px]">
              ${groups.length === 0
                ? 'Nenhum grupo encontrado. Receba uma mensagem em algum grupo pra ele aparecer aqui.'
                : 'Nenhum grupo encontrado com esse filtro.'}
            </div>
          `
          : html`
            <div class="bg-wa-panel border border-wa-border rounded-lg overflow-hidden">
              <table class="w-full text-[13px]">
                <thead class="bg-wa-bg border-b border-wa-border text-wa-secondary text-[12px] uppercase tracking-wide">
                  <tr>
                    <th class="text-left px-3 py-2 font-medium">Grupo</th>
                    <th class="text-center px-3 py-2 font-medium w-28">Saudação</th>
                  </tr>
                </thead>
                <tbody>
                  ${filtered.map((g) => {
                    const isSaving = !!saving[g.chat_jid];
                    return html`
                      <tr key=${g.chat_jid} class="border-b border-wa-border last:border-b-0 hover:bg-wa-hover">
                        <td class="px-3 py-2">
                          <div class="flex items-center gap-2">
                            <span class="font-medium truncate">${g.name}</span>
                            ${g.is_archived ? html`<span class="text-[10px] uppercase px-1.5 py-0.5 rounded bg-wa-bg text-wa-secondary">arquivado</span>` : null}
                          </div>
                          <div class="text-[11px] text-wa-secondary font-mono truncate max-w-[420px]">${g.chat_jid}</div>
                        </td>
                        <td class="px-3 py-2 text-center">
                          <div class="flex flex-col items-center gap-0.5">
                            <${Toggle}
                              checked=${g.enabled}
                              disabled=${isSaving}
                              onChange=${(v) => toggleGroup(g.chat_jid, v)}
                            />
                            <span class="text-[10px] ${g.enabled ? 'text-wa-teal' : 'text-wa-secondary'}">
                              ${g.enabled ? 'ativo' : 'desligado'}
                            </span>
                          </div>
                        </td>
                      </tr>
                    `;
                  })}
                </tbody>
              </table>
            </div>
          `
      }
    </div>
  `;
}
