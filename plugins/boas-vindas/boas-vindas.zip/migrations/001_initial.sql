-- Estado do plugin boas_vindas (welcome em grupos).
-- Todas as tabelas DEVEM começar com o prefixo plugin_boas_vindas_.

-- Quais grupos têm a saudação ligada. Um grupo só é considerado ATIVO se
-- existir uma linha aqui com enabled = 1. Grupos sem linha (ou enabled = 0)
-- ficam DESLIGADOS — é por isso que tudo vem desativado por padrão e grupos
-- novos também.
CREATE TABLE IF NOT EXISTS plugin_boas_vindas_groups (
    chat_jid    TEXT    PRIMARY KEY,
    enabled     INTEGER NOT NULL DEFAULT 0,
    updated_at  REAL    NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_boas_vindas_groups_enabled
    ON plugin_boas_vindas_groups(enabled);

-- Configuração global do plugin (key/value): delay_seconds e message_template.
CREATE TABLE IF NOT EXISTS plugin_boas_vindas_config (
    key    TEXT PRIMARY KEY,
    value  TEXT
);
