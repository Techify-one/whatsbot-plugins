"""Boas-vindas em grupos.

Quando alguém entra num grupo que foi ativado na tela de configuração do
plugin, aguarda alguns segundos (configurável) e envia uma mensagem no grupo
marcando a pessoa com @ (pra ela receber a notificação) pedindo que se
apresente.

Não toca no core: assina o evento ``group.participants_changed`` do bus de
plugins e envia a mensagem reusando a instância de GOWA client que o servidor
já ligou no startup (``agent.group_mentions._client``). A mensagem enviada volta
pelo webhook como echo (``is_from_me``) e o core já a persiste/mostra no painel,
então o plugin não precisa salvar nada.
"""

from __future__ import annotations

import json
import logging
import threading
import time

from sqlalchemy import text

from plugins.context import make_plugin_db

logger = logging.getLogger(__name__)

PLUGIN_ID = "boas_vindas"

DEFAULT_DELAY_SECONDS = 10
DEFAULT_TEMPLATE = (
    "Olá, {mention}! Poderia se apresentar? 😊\n\n"
    "Conta pra gente de onde você é e com o que você trabalha."
)


# ── Configuração / estado (tabelas plugin_boas_vindas_*) ───────────────────
def _load_config() -> dict:
    """Lê delay_seconds + message_template, com defaults."""
    delay = DEFAULT_DELAY_SECONDS
    template = DEFAULT_TEMPLATE
    try:
        with make_plugin_db() as conn:
            rows = conn.execute(
                text(
                    "SELECT key, value FROM plugin_boas_vindas_config "
                    "WHERE key IN ('delay_seconds', 'message_template')"
                )
            ).all()
        for key, value in rows:
            if key == "delay_seconds" and value is not None:
                try:
                    delay = max(0, int(float(value)))
                except (TypeError, ValueError):
                    pass
            elif key == "message_template" and value:
                template = value
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("[boas_vindas] falha lendo config: %s", exc)
    return {"delay_seconds": delay, "message_template": template}


def _group_enabled(chat_jid: str) -> bool:
    """True só se houver linha com enabled = 1 para esse grupo."""
    if not chat_jid:
        return False
    try:
        with make_plugin_db() as conn:
            row = conn.execute(
                text(
                    "SELECT enabled FROM plugin_boas_vindas_groups "
                    "WHERE chat_jid = :jid"
                ),
                {"jid": chat_jid},
            ).first()
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("[boas_vindas] falha lendo grupo %s: %s", chat_jid, exc)
        return False
    return bool(row and row[0])


# ── GOWA client (reusa a instância já ligada pelo servidor) ────────────────
def _get_gowa_client():
    try:
        from agent import group_mentions
        if getattr(group_mentions, "_client", None) is not None:
            return group_mentions._client
    except Exception:
        pass
    try:
        from gowa.client import GOWAClient
        port = 3000
        try:
            with make_plugin_db() as conn:
                row = conn.execute(
                    text("SELECT value FROM config WHERE key = 'gowa_port'")
                ).first()
            if row and row[0]:
                try:
                    port = int(json.loads(row[0]))
                except Exception:
                    port = int(row[0])
        except Exception:
            pass
        return GOWAClient(port=port)
    except Exception as exc:  # pragma: no cover - defensive
        logger.error("[boas_vindas] sem GOWA client: %s", exc)
        return None


# ── Resolução de quem entrou ───────────────────────────────────────────────
def _resolve_target(group_jid: str, jid: str) -> tuple[str, str]:
    """Devolve (phone_para_mencao, primeiro_nome) de um participante que entrou.

    O ``jid`` vem do webhook (ex.: ``5511...@s.whatsapp.net`` ou ``...@lid``).
    Usa o serviço de menções do core pra achar o telefone canônico (que a API
    do GOWA aceita em ``mentions``) e o nome já resolvido do participante.
    """
    from agent import group_mentions
    d = group_mentions._digits(jid)
    phone, name = d, ""
    try:
        for m in group_mentions.get_members(group_jid):
            if d and d in (m.get("phone"), m.get("lid")):
                phone = m.get("phone") or d
                name = (m.get("name") or "").strip()
                break
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("[boas_vindas] get_members falhou: %s", exc)
    if not name:
        try:
            name = (group_mentions._resolve_name(d) or "").strip()
        except Exception:
            name = ""
    first = ""
    if name and not name.startswith("+"):
        first = name.split()[0]
    return phone, first


def _build_message(template: str, phone: str, first_name: str) -> str:
    """Monta a mensagem. ``{mention}`` vira o @ que notifica; ``{primeiro_nome}``
    / ``{nome}`` viram o primeiro nome em texto puro (pode ser vazio)."""
    mention_token = f"@{phone}"
    msg = template.replace("{mention}", mention_token)
    msg = msg.replace("{primeiro_nome}", first_name).replace("{nome}", first_name)
    # Garante que a pessoa é SEMPRE marcada/notificada, mesmo que o template
    # não inclua {mention}.
    if mention_token not in msg:
        msg = f"{msg}\n\n{mention_token}".strip()
    return msg


def _send_welcome(group_jid: str, jids: list[str]) -> None:
    """Roda numa thread própria: espera o delay e envia a saudação."""
    cfg = _load_config()
    time.sleep(max(0, int(cfg["delay_seconds"])))

    client = _get_gowa_client()
    if client is None:
        return
    try:
        if not client.is_connected():
            logger.info("[boas_vindas] WhatsApp desconectado; pulando")
            return
    except Exception:
        pass  # se o check falhar, tenta enviar mesmo assim

    try:
        from agent import group_mentions
        bot_phone = getattr(group_mentions, "_bot_phone", "") or ""
    except Exception:
        bot_phone = ""

    template = cfg["message_template"]
    seen: set[str] = set()
    for jid in jids:
        phone, first = _resolve_target(group_jid, jid)
        if not phone or phone in seen:
            continue
        seen.add(phone)
        if bot_phone and phone == bot_phone:
            continue  # nunca dá boas-vindas pro próprio bot
        message = _build_message(template, phone, first)
        try:
            client.send_message(group_jid, message, mentions=[phone])
            logger.info(
                "[boas_vindas] apresentou %s no grupo %s", phone, group_jid
            )
        except Exception as exc:
            logger.warning("[boas_vindas] envio falhou p/ %s: %s", phone, exc)


# ── Event handler ──────────────────────────────────────────────────────────
def on_participants_changed(ctx, payload: dict) -> None:
    if (payload.get("type") or "").lower() != "join":
        return
    group_jid = payload.get("chat_id") or ""
    if "@g.us" not in group_jid:
        return
    jids = [j for j in (payload.get("jids") or []) if j]
    if not jids:
        return
    if not _group_enabled(group_jid):
        return
    # Dispara numa thread daemon pra não segurar o bus durante o delay.
    threading.Thread(
        target=_send_welcome, args=(group_jid, jids), daemon=True
    ).start()


EVENT_HANDLERS = {"group.participants_changed": on_participants_changed}
