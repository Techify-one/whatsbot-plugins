"""REST endpoints do plugin boas_vindas.

Montados sob /api/plugins/boas_vindas/... (protegidos pela senha do painel).

- GET/PUT /config           → delay (segundos) + texto da mensagem
- GET     /groups           → lista de grupos com o flag ativo/inativo
- PUT     /groups/{chat_jid} → liga/desliga a saudação num grupo
"""

import logging
import time
from typing import Any

from fastapi import APIRouter, HTTPException
from sqlalchemy import text

from plugins.context import make_plugin_db

logger = logging.getLogger(__name__)

router = APIRouter()

DEFAULT_DELAY_SECONDS = 10
DEFAULT_TEMPLATE = (
    "Olá, {mention}! Poderia se apresentar? 😊\n\n"
    "Conta pra gente de onde você é e com o que você trabalha."
)


def _ok(data: Any) -> dict:
    return {"ok": True, "data": data}


# ── Config global ──────────────────────────────────────────────────────────
def _read_config() -> dict:
    delay = DEFAULT_DELAY_SECONDS
    template = DEFAULT_TEMPLATE
    with make_plugin_db() as conn:
        rows = conn.execute(
            text(
                "SELECT key, value FROM plugin_boas_vindas_config "
                "WHERE key IN ('delay_seconds', 'message_template')"
            )
        ).all()
    for key, value in rows:
        if key == "delay_seconds" and value is not None:
            try:
                delay = max(0, int(float(value)))
            except (TypeError, ValueError):
                pass
        elif key == "message_template" and value:
            template = value
    return {"delay_seconds": delay, "message_template": template}


def _set_config_value(key: str, value: str) -> None:
    with make_plugin_db() as conn:
        exists = conn.execute(
            text("SELECT 1 FROM plugin_boas_vindas_config WHERE key = :k"),
            {"k": key},
        ).first()
        if exists:
            conn.execute(
                text(
                    "UPDATE plugin_boas_vindas_config "
                    "SET value = :v WHERE key = :k"
                ),
                {"v": value, "k": key},
            )
        else:
            conn.execute(
                text(
                    "INSERT INTO plugin_boas_vindas_config (key, value) "
                    "VALUES (:k, :v)"
                ),
                {"k": key, "v": value},
            )


@router.get("/config")
async def get_config() -> dict:
    return _ok(_read_config())


@router.put("/config")
async def update_config(body: dict) -> dict:
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="body inválido")

    if "delay_seconds" in body:
        try:
            delay = max(0, min(3600, int(body["delay_seconds"])))
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail="delay_seconds inválido")
        _set_config_value("delay_seconds", str(delay))

    if "message_template" in body:
        template = str(body.get("message_template") or "").strip()
        if not template:
            raise HTTPException(
                status_code=400, detail="A mensagem não pode ser vazia."
            )
        _set_config_value("message_template", template)

    return _ok(_read_config())


# ── Grupos (ativo/inativo por grupo) ───────────────────────────────────────
@router.get("/groups")
async def list_groups() -> dict:
    with make_plugin_db() as conn:
        rows = conn.execute(
            text(
                """
                SELECT c.phone, c.name, c.group_name, c.is_archived,
                       g.enabled AS enabled
                FROM contacts c
                LEFT JOIN plugin_boas_vindas_groups g
                    ON g.chat_jid = c.phone
                WHERE c.is_group = 1
                ORDER BY
                    CASE WHEN c.group_name IS NULL OR c.group_name = ''
                         THEN 1 ELSE 0 END,
                    LOWER(COALESCE(c.group_name, c.name, c.phone))
                """
            )
        ).mappings().all()

    items = []
    for row in rows:
        items.append({
            "chat_jid": row["phone"],
            "name": (row.get("group_name") or row.get("name") or row["phone"]),
            "is_archived": bool(row.get("is_archived")),
            "enabled": bool(row.get("enabled")),
        })

    enabled_count = sum(1 for it in items if it["enabled"])
    return _ok({"groups": items, "enabled_count": enabled_count})


@router.put("/groups/{chat_jid:path}")
async def update_group(chat_jid: str, body: dict) -> dict:
    if "@g.us" not in chat_jid:
        raise HTTPException(status_code=400, detail="chat_jid inválido")
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="body inválido")

    enabled = bool(body.get("enabled"))
    now = time.time()
    with make_plugin_db() as conn:
        exists = conn.execute(
            text(
                "SELECT 1 FROM plugin_boas_vindas_groups WHERE chat_jid = :jid"
            ),
            {"jid": chat_jid},
        ).first()
        if exists:
            conn.execute(
                text(
                    "UPDATE plugin_boas_vindas_groups "
                    "SET enabled = :en, updated_at = :ts WHERE chat_jid = :jid"
                ),
                {"en": 1 if enabled else 0, "ts": now, "jid": chat_jid},
            )
        else:
            conn.execute(
                text(
                    "INSERT INTO plugin_boas_vindas_groups "
                    "(chat_jid, enabled, updated_at) VALUES (:jid, :en, :ts)"
                ),
                {"jid": chat_jid, "en": 1 if enabled else 0, "ts": now},
            )

    return _ok({"chat_jid": chat_jid, "enabled": enabled})
