"""Connection monitor — polling loop + Telegram alerts.

Design (polling as the primary mechanism, per the GOWA status semantics):

    GET /app/status is an in-memory flag read on the GOWA side (no network
    I/O, no DB), so polling every ~30s costs practically nothing and covers
    strictly more failure modes than the WS ``connection.changed`` event
    (network drop, StreamReplaced, container restart, GOWA down), while
    failing loudly instead of silently.

State machine over the two booleans returned by ``/app/status``:

    is_connected  is_logged_in  category        action
    true          true          healthy         nothing (clear any alert)
    false         true          network_down    auto-reconnect (no QR) + alert
    *             false          session_dead    alert (needs QR re-scan)
    HTTP error / unreachable    gowa_down       infra alert (separate category)

Two false-alarm guards:
  * require N consecutive readings in the same degraded category before
    alerting (transient reconnects are normal in whatsmeow);
  * treat "GOWA unreachable" as its own category so an infra blip is never
    mistaken for the number logging out.
"""

import asyncio
import logging

import httpx

from db.repositories import config_repo
from gowa.client import GOWAClient

from .settings import Settings

logger = logging.getLogger("whatsbot.plugin.monitor_conexao")

PLUGIN_ID = "monitor_conexao"

# The background polling task. Module-level so app.startup can create it and
# app.shutdown can cancel it. Transient per-run only; it does not need to
# survive a restart (a restart just starts a fresh loop).
_task: "asyncio.Task | None" = None


# ── config ────────────────────────────────────────────────────────────────

def _load_settings() -> Settings:
    """Build the Settings model from persisted config, falling back to defaults."""
    prefix = f"plugin.{PLUGIN_ID}."
    data = {}
    for field in Settings.model_fields:
        val = config_repo.get(prefix + field)
        if val is not None and val != "":
            data[field] = val
    try:
        return Settings(**data)
    except Exception as e:
        logger.warning("monitor_conexao: settings inválidas (%s), usando defaults", e)
        return Settings()


def _gowa_port() -> int:
    try:
        return int(config_repo.get("gowa_port", 3000) or 3000)
    except (TypeError, ValueError):
        return 3000


# ── blocking probes (run inside asyncio.to_thread) ──────────────────────────

def _probe(client: GOWAClient) -> str:
    """Return the connection category. ``None`` status = GOWA unreachable."""
    status = client.get_status()
    if status is None:
        return "gowa_down"
    results = status.get("results", status.get("data", status)) or {}
    if not isinstance(results, dict):
        results = {}
    is_connected = bool(results.get("is_connected", False))
    is_logged_in = bool(results.get("is_logged_in", False))
    if is_connected and is_logged_in:
        return "healthy"
    if not is_connected and is_logged_in:
        return "network_down"
    return "session_dead"


def _do_reconnect(client: GOWAClient) -> None:
    client.reconnect()


# ── Telegram ────────────────────────────────────────────────────────────────

async def _send_telegram(cfg: Settings, text: str) -> None:
    token = (cfg.telegram_bot_token or "").strip()
    chat_id = (cfg.telegram_chat_id or "").strip()
    if not token or not chat_id:
        logger.warning(
            "monitor_conexao: Telegram não configurado (token/chat_id vazios); "
            "aviso não enviado: %s", text.splitlines()[0],
        )
        return
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(url, json={
                "chat_id": chat_id,
                "text": text,
                "disable_web_page_preview": True,
            })
            resp.raise_for_status()
        logger.info("monitor_conexao: aviso enviado ao Telegram")
    except Exception as e:
        logger.error("monitor_conexao: falha ao enviar Telegram: %s", e)


def _alert_msg(category: str) -> str:
    return {
        "network_down": (
            "⚠️ WhatsApp DESCONECTADO\n\n"
            "A sessão continua viva, mas o número perdeu conexão "
            "(provável queda de rede). Tentando reconectar automaticamente."
        ),
        "session_dead": (
            "🔴 WhatsApp DESLOGADO\n\n"
            "A sessão caiu de vez. É preciso ler o QR Code de novo no painel "
            "para reconectar o número."
        ),
        "gowa_down": (
            "🚨 Serviço do WhatsBot fora do ar\n\n"
            "Não consegui falar com o serviço do WhatsApp (GOWA). Pode ser o "
            "processo caído ou o servidor reiniciando. Verifique a infraestrutura."
        ),
    }.get(category, f"Estado de conexão degradado: {category}")


def _recovery_msg() -> str:
    return "✅ WhatsApp reconectado\n\nA conexão voltou ao normal."


# ── polling loop ────────────────────────────────────────────────────────────

async def _monitor_loop() -> None:
    logger.info("monitor_conexao: loop de monitoramento iniciado")
    client = GOWAClient(port=_gowa_port())

    pending_cat: "str | None" = None   # degraded category currently accumulating
    pending_count = 0                  # consecutive readings in pending_cat
    alerted_cat: "str | None" = None   # category already alerted this episode
    reconnect_tried = False            # avoid reconnect spam within one episode

    try:
        while True:
            cfg = _load_settings()
            interval = max(10, int(cfg.poll_interval_seconds or 30))
            need = max(1, int(cfg.confirm_readings or 2))

            try:
                category = await asyncio.to_thread(_probe, client)
            except Exception as e:
                logger.error("monitor_conexao: erro ao consultar status: %s", e)
                category = "gowa_down"

            if category == "healthy":
                if alerted_cat is not None and cfg.notify_on_recovery:
                    await _send_telegram(cfg, _recovery_msg())
                pending_cat, pending_count = None, 0
                alerted_cat = None
                reconnect_tried = False
            else:
                if category == pending_cat:
                    pending_count += 1
                else:
                    pending_cat, pending_count = category, 1
                    if category != "network_down":
                        reconnect_tried = False

                confirmed = pending_count >= need

                # Auto-reconnect: session alive but disconnected → no QR needed.
                if (confirmed and category == "network_down"
                        and cfg.auto_reconnect and not reconnect_tried):
                    reconnect_tried = True
                    logger.info(
                        "monitor_conexao: sessão viva mas desconectada — tentando reconnect")
                    try:
                        await asyncio.to_thread(_do_reconnect, client)
                    except Exception as e:
                        logger.error("monitor_conexao: reconnect falhou: %s", e)

                # Alert once per degraded episode, after N confirmations.
                if confirmed and alerted_cat != category:
                    if category == "gowa_down" and not cfg.alert_on_gowa_down:
                        pass
                    else:
                        alerted_cat = category
                        logger.warning(
                            "monitor_conexao: estado degradado confirmado: %s", category)
                        await _send_telegram(cfg, _alert_msg(category))

            await asyncio.sleep(interval)
    except asyncio.CancelledError:
        logger.info("monitor_conexao: loop cancelado")
        raise
    except Exception as e:  # never let the loop die silently
        logger.exception("monitor_conexao: loop encerrado por erro: %s", e)


# ── lifecycle handlers ──────────────────────────────────────────────────────

async def _on_startup(ctx, payload) -> None:
    global _task
    if _task and not _task.done():
        return
    _task = asyncio.create_task(_monitor_loop())


async def _on_shutdown(ctx, payload) -> None:
    global _task
    if _task and not _task.done():
        _task.cancel()
        try:
            await _task
        except asyncio.CancelledError:
            pass
        except Exception:
            pass
    _task = None


EVENT_HANDLERS = {
    "app.startup": _on_startup,
    "app.shutdown": _on_shutdown,
}
