"""REST endpoints do Monitor de Conexão (/api/plugins/monitor_conexao).

Expõe apenas o teste de envio para o Telegram, usado pelo botão "Testar envio"
da tela de configuração. Aceita token/chat_id no corpo (para testar valores
ainda não salvos) e cai para os valores persistidos quando ausentes.
"""

import logging

import httpx
from fastapi import APIRouter, Request

from db.repositories import config_repo

router = APIRouter()
logger = logging.getLogger("whatsbot.plugin.monitor_conexao")

PLUGIN_ID = "monitor_conexao"


def _saved(key: str) -> str:
    val = config_repo.get(f"plugin.{PLUGIN_ID}.{key}")
    return (val or "").strip() if isinstance(val, str) else ""


@router.post("/test-telegram")
async def test_telegram(request: Request):
    """Send a test message to Telegram to validate token + chat_id."""
    try:
        body = await request.json()
    except Exception:
        body = {}
    body = body or {}

    token = (body.get("telegram_bot_token") or "").strip() or _saved("telegram_bot_token")
    chat_id = (body.get("telegram_chat_id") or "").strip() or _saved("telegram_chat_id")

    if not token or not chat_id:
        return {"ok": False, "error": "Preencha o token do bot e o chat ID antes de testar."}

    text = (
        "✅ Teste do WhatsBot\n\n"
        "Se você recebeu esta mensagem, o Monitor de Conexão está configurado "
        "corretamente e os alertas de queda vão chegar aqui."
    )
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(url, json={
                "chat_id": chat_id,
                "text": text,
                "disable_web_page_preview": True,
            })
    except Exception as e:
        return {"ok": False, "error": f"Falha ao contatar o Telegram: {e}"}

    if resp.status_code == 200:
        return {"ok": True, "data": {"message": "Mensagem de teste enviada. Confira o Telegram."}}

    # Telegram returns a JSON body with a human-readable "description" on error
    # (e.g. 401 "Unauthorized" = token errado, 400 "chat not found" = chat_id errado).
    detail = ""
    try:
        detail = (resp.json() or {}).get("description", "")
    except Exception:
        detail = (resp.text or "")[:200]
    return {"ok": False, "error": f"Telegram recusou (HTTP {resp.status_code}): {detail}".strip()}
