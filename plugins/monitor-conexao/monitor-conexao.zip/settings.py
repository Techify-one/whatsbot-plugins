"""Declarative settings for the connection monitor plugin.

Rendered as an auto-generated form in the plugin's "Configurar" modal.
Values persist under config keys ``plugin.monitor_conexao.<field>``.
"""

from pydantic import BaseModel, Field


class Settings(BaseModel):
    telegram_bot_token: str = Field(
        default="",
        title="Token do bot do Telegram",
        description="Token do BotFather, no formato 123456:ABC-DEF...",
    )
    telegram_chat_id: str = Field(
        default="",
        title="Chat ID do Telegram",
        description="ID do chat/grupo/canal que vai receber os avisos (ex: 123456789 ou -1001234567890).",
    )
    instance_label: str = Field(
        default="",
        title="Identificação deste número",
        description="Rótulo curto (ex: 'WhatsApp Vendas' ou o número) enviado junto de toda mensagem, para saber de qual número é o aviso quando vários usam o mesmo chat. Opcional.",
    )
    poll_interval_seconds: int = Field(
        default=30,
        title="Intervalo de verificação (segundos)",
        description="De quanto em quanto tempo checar o status. Mínimo 10s.",
    )
    confirm_readings: int = Field(
        default=2,
        title="Leituras consecutivas antes de alertar",
        description="Quantas verificações seguidas no mesmo estado ruim antes de disparar o aviso (evita alarme falso em reconexões rápidas).",
    )
    auto_reconnect: bool = Field(
        default=True,
        title="Reconectar automaticamente",
        description="Quando a sessão ainda está viva mas caiu a rede, tenta reconectar sozinho (sem pedir QR).",
    )
    alert_on_gowa_down: bool = Field(
        default=True,
        title="Avisar quando o serviço estiver fora do ar",
        description="Dispara um aviso de infraestrutura quando não consigo falar com o serviço do WhatsApp (GOWA caído / reiniciando).",
    )
    notify_on_recovery: bool = Field(
        default=True,
        title="Avisar quando reconectar",
        description="Manda uma mensagem no Telegram quando a conexão voltar ao normal.",
    )
