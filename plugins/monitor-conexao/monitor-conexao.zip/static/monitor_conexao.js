// Tela de configuração do Monitor de Conexão — Preact + HTM, sem build.
// Renderiza os campos (persistidos via GET/PUT /api/plugins/monitor_conexao/settings)
// e adiciona um botão "Testar envio no Telegram" que dispara /test-telegram.
import { h } from 'preact';
import { useEffect, useState } from 'preact/hooks';
import htm from 'htm';

const html = htm.bind(h);

function authHeaders(extra = {}) {
  const token = localStorage.getItem('whatsbot_token') || '';
  return token ? { ...extra, Authorization: `Bearer ${token}` } : { ...extra };
}

async function apiFetch(url, init = {}) {
  const headers = authHeaders({ 'Content-Type': 'application/json', ...(init.headers || {}) });
  const res = await fetch(url, { ...init, headers });
  if (res.status === 401) {
    localStorage.removeItem('whatsbot_token');
    window.dispatchEvent(new Event('whatsbot:unauthorized'));
    throw new Error('Não autenticado.');
  }
  return res;
}

const FIELDS = [
  { key: 'telegram_bot_token', label: 'Token do bot do Telegram', type: 'text',
    placeholder: '123456:ABC-DEF...', help: 'Token gerado pelo @BotFather.' },
  { key: 'telegram_chat_id', label: 'Chat ID de destino', type: 'text',
    placeholder: '123456789 ou -1001234567890',
    help: 'ID de um usuário ou de um grupo. Para grupo/canal geralmente começa com -100.' },
  { key: 'poll_interval_seconds', label: 'Intervalo de verificação (segundos)', type: 'number',
    min: 10, help: 'De quanto em quanto tempo checar o status. Mínimo 10s.' },
  { key: 'confirm_readings', label: 'Leituras consecutivas antes de alertar', type: 'number',
    min: 1, help: 'Checagens seguidas no mesmo estado ruim antes de avisar (evita alarme falso).' },
  { key: 'auto_reconnect', label: 'Reconectar automaticamente', type: 'bool',
    help: 'Sessão viva mas sem rede: tenta reconectar sozinho, sem pedir QR.' },
  { key: 'alert_on_gowa_down', label: 'Avisar quando o serviço estiver fora do ar', type: 'bool',
    help: 'Alerta de infraestrutura quando o serviço do WhatsApp (GOWA) não responde.' },
  { key: 'notify_on_recovery', label: 'Avisar quando reconectar', type: 'bool',
    help: 'Manda uma mensagem no Telegram quando a conexão voltar ao normal.' },
];

export default function MonitorConexaoConfig({ apiBase = '/api/plugins/monitor_conexao' } = {}) {
  const [values, setValues] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [msg, setMsg] = useState(null); // { type: 'ok' | 'err', text }

  async function load() {
    try {
      const r = await apiFetch(`${apiBase}/settings`);
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || 'erro');
      setValues((data.data && data.data.values) || {});
    } catch (e) {
      setMsg({ type: 'err', text: String(e.message || e) });
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, []);

  function setField(key, v) { setValues(prev => ({ ...prev, [key]: v })); }

  async function save() {
    setSaving(true); setMsg(null);
    try {
      const r = await apiFetch(`${apiBase}/settings`, { method: 'PUT', body: JSON.stringify(values) });
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || 'Falha ao salvar.');
      setMsg({ type: 'ok', text: 'Configuração salva.' });
    } catch (e) {
      setMsg({ type: 'err', text: String(e.message || e) });
    } finally {
      setSaving(false);
    }
  }

  async function testSend() {
    setTesting(true); setMsg(null);
    try {
      const r = await apiFetch(`${apiBase}/test-telegram`, {
        method: 'POST',
        body: JSON.stringify({
          telegram_bot_token: values.telegram_bot_token,
          telegram_chat_id: values.telegram_chat_id,
        }),
      });
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || 'Falha no teste.');
      setMsg({ type: 'ok', text: (data.data && data.data.message) || 'Mensagem de teste enviada.' });
    } catch (e) {
      setMsg({ type: 'err', text: String(e.message || e) });
    } finally {
      setTesting(false);
    }
  }

  if (loading) return html`<div class="p-4 text-wa-secondary">Carregando…</div>`;
  if (!values) return html`<div class="p-4 text-red-600">Não foi possível carregar as configurações.</div>`;

  const inputCls = 'w-full wa-field border border-wa-border rounded px-3 py-2 text-[14px] focus:outline-none focus:border-wa-teal';

  return html`
    <div class="p-4 space-y-4 max-w-xl">
      ${FIELDS.map(f => html`
        <div>
          ${f.type === 'bool'
            ? html`<label class="inline-flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked=${!!values[f.key]}
                  onChange=${e => setField(f.key, e.target.checked)} />
                <span class="text-wa-text text-[14px] font-medium">${f.label}</span>
              </label>`
            : html`<div>
                <label class="block text-wa-text text-[13px] font-medium mb-1">${f.label}</label>
                <input class=${inputCls} type=${f.type} min=${f.min ?? ''} placeholder=${f.placeholder || ''}
                  value=${values[f.key] ?? ''}
                  onInput=${e => setField(f.key, f.type === 'number' ? Number(e.target.value) : e.target.value)} />
              </div>`}
          ${f.help ? html`<p class="text-wa-secondary text-[12px] mt-1">${f.help}</p>` : null}
        </div>
      `)}

      ${msg ? html`<div class=${'text-[13px] px-3 py-2 rounded ' + (msg.type === 'ok' ? 'bg-wa-teal/10 text-wa-teal' : 'bg-red-500/10 text-red-600')}>${msg.text}</div>` : null}

      <div class="flex flex-wrap items-center gap-2 pt-1">
        <button class="bg-wa-teal text-white px-4 py-2 rounded text-[14px] font-medium disabled:opacity-50"
          disabled=${saving} onClick=${save}>${saving ? 'Salvando…' : 'Salvar'}</button>
        <button class="border border-wa-border text-wa-text px-4 py-2 rounded text-[14px] font-medium disabled:opacity-50"
          disabled=${testing} onClick=${testSend}>${testing ? 'Enviando…' : 'Testar envio no Telegram'}</button>
      </div>
      <p class="text-wa-secondary text-[12px]">O teste usa o token e o chat ID digitados acima (não precisa salvar antes).</p>
    </div>
  `;
}
