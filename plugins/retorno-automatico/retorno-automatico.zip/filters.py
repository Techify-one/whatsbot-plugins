"""Evita duplicar no histórico as mensagens que ESTE plugin acabou de mandar.

Só entra em jogo quando ``ai_auto_reply`` está ligado e a IA manda uma resposta de
verdade pro cliente via GOWA (``logic._ai_reply_in_chat``): o core usa
``state.recently_sent`` para reconhecer o eco de um envio próprio quando ele volta
pelo webhook (``is_from_me=True``) — sem isso, o GOWA ecoaria a mensagem de volta e
o core salvaria uma bolha "Manual" duplicada. Esse dicionário não é exposto a
plugins, então o ``retorno_automatico`` mantém a própria cópia
(``logic._recently_sent``, escrita em ``_ai_reply_in_chat``) e usa
``filter.message.outgoing`` — o mesmo ponto que o core usa para reconhecer eco —
para descartar antes de virar uma bolha duplicada no painel. Mesmo padrão do
``agendamento_retorno``.
"""

from __future__ import annotations

from . import logic


def drop_own_echo(ctx, value):
    if not isinstance(value, dict):
        return value
    phone = value.get("phone") or ""
    text_ = value.get("text") or ""
    if logic.consume_recent_echo(phone, text_):
        return None
    return value


FILTERS = {
    "filter.message.outgoing": drop_own_echo,
}
