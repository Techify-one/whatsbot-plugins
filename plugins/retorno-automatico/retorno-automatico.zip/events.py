"""Verificador de silêncio do cliente — abre um loop próprio no boot do app.

No whatsbot-pro, um "lifecycle" com ``ctx.spawn_task`` registra uma tarefa
supervisionada (``retorno_automatico:scheduler``) no TaskSupervisor do core. Isso não
existe no whatsbot "simples" (exclusivo do pro): o único jeito de rodar algo periódico
aqui é assinar ``app.startup``/``app.shutdown`` e gerenciar o próprio ``asyncio.Task`` —
mesmo padrão já usado pelos plugins ``agendamento_retorno`` e ``monitor_conexao``.
"""

from __future__ import annotations

import asyncio
import logging

from plugins.context import broadcast

from . import logic

logger = logging.getLogger("plugin.retorno_automatico")

CHECK_INTERVAL_SECONDS = 60.0

# Task de polling. Módulo-level para app.startup criar e app.shutdown cancelar.
_task: "asyncio.Task | None" = None


async def _checker_loop() -> None:
    logger.info("retorno_automatico: verificador iniciado")
    try:
        while True:
            try:
                summary = await logic.run_cycle()
                # "Tick" opcional p/ observabilidade (espelha o whatsbot-pro).
                try:
                    broadcast("retorno_automatico_tick", {
                        "checked_at": summary.get("checked_at"),
                        "checked": summary.get("checked", 0),
                        "fired": summary.get("fired", 0),
                        "skipped": summary.get("skipped", 0),
                        "failed": summary.get("failed", 0),
                    })
                except Exception:  # noqa: BLE001 — broadcast ruim nunca mata o laço
                    logger.debug("retorno_automatico: tick broadcast falhou")
                if summary.get("fired") or summary.get("failed"):
                    logger.info("[RetornoAutomatico] ciclo: %s", summary)
            except Exception as e:  # noqa: BLE001 — um ciclo com erro não derruba o laço
                logger.warning("[RetornoAutomatico] ciclo falhou: %s", e)
            await asyncio.sleep(CHECK_INTERVAL_SECONDS)
    except asyncio.CancelledError:
        logger.info("retorno_automatico: verificador cancelado")
        raise


async def _on_startup(ctx, payload) -> None:
    global _task
    logic.set_handler(ctx.handler)
    if _task and not _task.done():
        return
    _task = asyncio.create_task(_checker_loop())


async def _on_shutdown(ctx, payload) -> None:
    global _task
    if _task and not _task.done():
        _task.cancel()
        try:
            await _task
        except asyncio.CancelledError:
            pass
        except Exception:  # noqa: BLE001
            pass
    _task = None


EVENT_HANDLERS = {
    "app.startup": _on_startup,
    "app.shutdown": _on_shutdown,
}
