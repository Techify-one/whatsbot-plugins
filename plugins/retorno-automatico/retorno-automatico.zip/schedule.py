"""Expediente — funções PURAS e testáveis (sem DB, sem estado).

Idêntico ao plugin homônimo do whatsbot-pro (nenhuma dependência de conversa/canal aqui,
então nada precisou mudar na adaptação). Não há cálculo de "próxima janela": o disparo é
GATED por :func:`is_open_now`; o loop por minuto dispara sozinho no 1º tick dentro do
expediente. Fuso é um offset FIXO (padrão −3, Brasil sem DST) — evita ``datetime.now()``
naïve (mesmo cuidado do plugin ``horario_funcionamento``).
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Mapping

logger = logging.getLogger("plugin.retorno_automatico")

# weekday() → 0=segunda … 6=domingo; casa com a ordem dos toggles abaixo.
_DAY_KEYS = ("day_mon", "day_tue", "day_wed", "day_thu", "day_fri", "day_sat", "day_sun")


def parse_hhmm(value: str | None) -> int | None:
    """"HH:MM" → minutos desde a meia-noite (0..1439), ou ``None`` se inválido."""
    if not value or not isinstance(value, str):
        return None
    parts = value.strip().split(":")
    if len(parts) != 2:
        return None
    try:
        hh, mm = int(parts[0]), int(parts[1])
    except (TypeError, ValueError):
        return None
    if not (0 <= hh <= 23 and 0 <= mm <= 59):
        return None
    return hh * 60 + mm


def _cfg_get(cfg: Any, key: str, default: Any = None) -> Any:
    """Lê ``key`` de um Mapping OU de um objeto (Settings) por atributo."""
    if isinstance(cfg, Mapping):
        return cfg.get(key, default)
    return getattr(cfg, key, default)


def is_open_now(now_epoch: float, cfg: Any) -> bool:
    """Estamos DENTRO do expediente no instante ``now_epoch``?

    ``cfg`` pode ser um dict (``Settings.model_dump()``) ou o próprio ``Settings``.
    Usa ``tz_offset_hours`` (offset fixo). Retorna ``False`` de forma defensiva se a
    config estiver malformada (nunca levanta — o pior caso é "não dispara agora").
    """
    try:
        tz = float(_cfg_get(cfg, "tz_offset_hours", -3.0) or 0.0)
        local = datetime.fromtimestamp(now_epoch + tz * 3600, timezone.utc)

        weekday = local.weekday()  # 0=segunda … 6=domingo
        if not bool(_cfg_get(cfg, _DAY_KEYS[weekday], False)):
            return False

        start = parse_hhmm(_cfg_get(cfg, "business_start", "08:00"))
        end = parse_hhmm(_cfg_get(cfg, "business_end", "18:00"))
        if start is None or end is None:
            logger.warning("retorno_automatico: expediente com HH:MM inválido "
                           "(start=%r end=%r) — tratando como fechado",
                           _cfg_get(cfg, "business_start"), _cfg_get(cfg, "business_end"))
            return False
        if start >= end:
            # Sem caso overnight: start>=end ⇒ "sem expediente".
            logger.warning("retorno_automatico: business_start (%s) >= business_end (%s) "
                           "— tratando como fechado", start, end)
            return False

        m = local.hour * 60 + local.minute
        return start <= m < end
    except Exception:  # noqa: BLE001 — expediente nunca derruba o ciclo
        logger.exception("retorno_automatico: is_open_now falhou — tratando como fechado")
        return False
