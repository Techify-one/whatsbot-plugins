"""Núcleo do plugin Retorno Automático (IA).

Adaptação do plugin homônimo do whatsbot-pro para o whatsbot "simples" (single-channel
via GOWA, um único agente de IA por contato, sem conversas/atendentes/canais). Duas
diferenças estruturais em relação ao original que valem a pena ter em mente lendo este
arquivo (mesmo espírito de ``agendamento_retorno/logic.py``):

  * Não existe "conversa"/"atendimento" como entidade — o escopo de um contato em
    silêncio é o próprio ``contact_id`` (== o ``phone``). "Atribuído a uma IA, sem
    humano" vira simplesmente ``contacts.ai_enabled = 1`` (não há canal/atendente
    separado para checar).
  * A tabela ``messages`` daqui não tem uma coluna de autor (o whatsbot-pro marca as
    próprias notas com ``sent_by_name = NOTE_AUTHOR``). Em vez disso, TODA nota deste
    plugin carrega um prefixo fixo (:data:`NOTE_MARKER`) no início do ``content`` — é
    esse prefixo, não uma coluna, que a consulta agregada usa para reconhecer "notas
    do plugin" e ignorar notas de outra origem (operador, outro plugin). O prefixo é
    aplicado automaticamente em :func:`dispatch_note`, fora do template editável pelo
    usuário — editar o template não quebra a detecção.

Design STATELESS (mesmo do original): as próprias ``private_note`` do plugin SÃO a
memória. Uma consulta agregada por contato devolve ``last_client_ts``,
``last_outbound_ts``, ``last_note_ts`` e o contador de notas desde a última resposta do
cliente. Sem tabela própria, sem migration, sem drift; auto-recupera após restart.

Camadas:
  * :func:`load_settings`   — lê a config a cada ciclo (vale sem restart).
  * :func:`list_candidates` — SELECT read-only dos contatos elegíveis.
  * :func:`contact_signals` — consulta agregada por contato.
  * :func:`decide`          — decisão PURA.
  * :func:`dispatch_note`   — posta a nota privada e, se ``ai_auto_reply`` estiver
    ligado (default), aciona a IA pra ler essa nota e responder de verdade ao
    cliente no chat — igual ao toggle "IA lê" + "IA responde no chat" da Mensagem
    Privada manual (``server/routes/contacts.py::_run_private_ai``). ASYNC porque
    precisa chamar ``AgentHandler.aprocess_message`` (async) e mandar a resposta
    via GOWA.
  * :func:`run_cycle`       — amarra tudo (try/except por item + sumário). ASYNC —
    quem chama (``events.py``) faz ``await`` direto (sem ``asyncio.to_thread`` do
    ciclo inteiro, porque agora há trechos que precisam do event loop); as leituras
    só-DB continuam envolvidas em ``asyncio.to_thread`` individualmente.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Any, Mapping

from sqlalchemy import text

from plugins.context import broadcast

from .schedule import is_open_now

logger = logging.getLogger("plugin.retorno_automatico")

PLUGIN_ID = "retorno_automatico"

# Marcador stateless: toda nota postada pelo plugin começa com este prefixo. É a CHAVE
# que distingue as notas do plugin de qualquer outra nota do painel — o contador e a
# âncora do relógio só olham para notas com este prefixo. Fica FORA do note_template
# editável (dispatch_note o antepõe sempre) para não quebrar a detecção se o usuário
# customizar o texto.
NOTE_MARKER = "🔔 Retorno Automático: "


# ── AgentHandler capturado no boot (events.py) ───────────────────────────────
#
# Não existe ``deps``/``get_deps()`` neste whatsbot (isso é exclusivo do whatsbot-pro).
# ``EventContext.handler`` já É o ``AgentHandler`` real (setado pelo core antes de
# emitir ``app.startup``); guardamos a referência aqui pra o ciclo (que roda fora de
# qualquer dispatch de evento, dentro de um ``asyncio.to_thread``) conseguir usá-la.
_HANDLER = None


def set_handler(handler) -> None:
    global _HANDLER
    if handler is not None:
        _HANDLER = handler


def _handler():
    return _HANDLER


# ── Dedup do próprio eco (mesmo padrão do ``agendamento_retorno``) ────────────
#
# O core usa ``state.recently_sent`` para reconhecer o eco de uma mensagem que
# ELE mandou quando ela volta pelo webhook (``is_from_me=True``) — sem isso, o
# GOWA ecoaria a resposta da IA de volta e o core salvaria uma bolha "Manual"
# duplicada. ``state`` não é exposto a plugins, então mantemos aqui a MESMA
# ideia numa cópia local, escrita em :func:`_ai_reply_in_chat` e consumida por
# ``filters.py`` via ``filter.message.outgoing``.
_recently_sent: dict[str, float] = {}


def mark_sent(phone: str, wire_text: str) -> None:
    _recently_sent[f"{phone}:{(wire_text or '')[:120]}"] = time.time()


def consume_recent_echo(phone: str, text_: str) -> bool:
    """``True`` (e remove) se este texto foi mandado por nós há menos de 30s."""
    key = f"{phone}:{(text_ or '')[:120]}"
    ts = _recently_sent.pop(key, None)
    if ts is None:
        return False
    return (time.time() - ts) < 30


def _prune_recently_sent() -> None:
    cutoff = time.time() - 60
    for key in [k for k, v in _recently_sent.items() if v < cutoff]:
        _recently_sent.pop(key, None)


# ── Config (lida a cada ciclo — vale sem restart) ─────────────────────────────

def load_settings():
    """Constrói um ``Settings`` a partir das chaves ``plugin.retorno_automatico.*``.

    Só as chaves efetivamente salvas sobrescrevem os defaults do modelo (campos não
    salvos herdam o default declarativo). Valores inválidos em config caem para os
    defaults inteiros (fail-safe) — o verificador nunca quebra por config ruim.
    """
    from db.repositories import config_repo

    from .settings import Settings

    prefix = f"plugin.{PLUGIN_ID}."
    _MISSING = object()
    data: dict[str, Any] = {}
    for field_name in Settings.model_fields:
        raw = config_repo.get(prefix + field_name, _MISSING)
        if raw is not _MISSING:
            data[field_name] = raw
    try:
        return Settings(**data)
    except Exception:  # noqa: BLE001 — config malformada nunca derruba o ciclo
        logger.warning("retorno_automatico: settings inválidas em config — usando defaults",
                       exc_info=True)
        return Settings()


def _cfg(cfg: Any, key: str, default: Any = None) -> Any:
    """Lê ``key`` de um Mapping (model_dump) OU de um objeto Settings."""
    if isinstance(cfg, Mapping):
        return cfg.get(key, default)
    return getattr(cfg, key, default)


# ── Enumeração de candidatos (SELECT read-only) ────────────────────────────────

def list_candidates(apply_to_groups: bool) -> list[dict]:
    """Contatos com a IA ligada e não arquivados — os candidatos do ciclo.

    Read-only e parametrizado. Sem "conversa"/"atendente" aqui: o filtro é só
    ``ai_enabled = 1 AND is_archived = 0``. Grupos entram só com ``apply_to_groups``
    (default: pula grupos).
    """
    from db.engine import get_engine

    sql = text(
        "SELECT id AS contact_id, phone, name AS contact_name, is_group "
        "FROM contacts "
        "WHERE ai_enabled = 1 AND is_archived = 0 "
        "  AND (is_group = 0 OR :apply_to_groups = 1) "
        "ORDER BY id"
    )
    with get_engine().connect() as conn:
        rows = conn.execute(sql, {"apply_to_groups": 1 if apply_to_groups else 0}).mappings().all()
    return [dict(r) for r in rows]


# ── Sinais por contato (consulta agregada única) ───────────────────────────────

def contact_signals(contact_id: int) -> dict:
    """Os 4 sinais stateless de um contato numa única consulta agregada.

    * ``last_client_ts``   — MAX(ts) de ``role='user'`` (o RESET).
    * ``last_outbound_ts`` — MAX(ts) de ``role='assistant'`` com ``status<>'failed'``
      (IA + operador; exclui envio falho que não chegou ao cliente).
    * ``last_note_ts``     — MAX(ts) das notas do plugin (``content`` começando com
      :data:`NOTE_MARKER`).
    * ``notes_since_reply``— nº dessas notas com ``ts > last_client_ts`` (o contador).

    Usa ``CASE WHEN`` em vez da cláusula ``FILTER`` (que também funcionaria) para não
    depender de uma versão mínima de SQLite — o resto do projeto não usa ``FILTER``.
    """
    from db.engine import get_engine

    sql = text(
        "WITH lc AS ("
        "  SELECT MAX(ts) AS t FROM messages "
        "  WHERE contact_id = :cid AND role = 'user'"
        ") "
        "SELECT "
        "  (SELECT t FROM lc) AS last_client_ts, "
        "  MAX(CASE WHEN role = 'assistant' AND (status IS NULL OR status <> 'failed') "
        "           THEN ts END) AS last_outbound_ts, "
        "  MAX(CASE WHEN role = 'private_note' AND content LIKE :marker "
        "           THEN ts END) AS last_note_ts, "
        "  SUM(CASE WHEN role = 'private_note' AND content LIKE :marker "
        "                AND ts > COALESCE((SELECT t FROM lc), 0) "
        "           THEN 1 ELSE 0 END) AS notes_since_reply "
        "FROM messages "
        "WHERE contact_id = :cid"
    )
    with get_engine().connect() as conn:
        row = conn.execute(
            sql, {"cid": contact_id, "marker": NOTE_MARKER + "%"}
        ).mappings().first()

    if row is None:
        return {"last_client_ts": None, "last_outbound_ts": None,
                "last_note_ts": None, "notes_since_reply": 0}
    return {
        "last_client_ts": _as_float(row["last_client_ts"]),
        "last_outbound_ts": _as_float(row["last_outbound_ts"]),
        "last_note_ts": _as_float(row["last_note_ts"]),
        "notes_since_reply": int(row["notes_since_reply"] or 0),
    }


def _as_float(v) -> float | None:
    return float(v) if v is not None else None


# ── Decisão (pura) ─────────────────────────────────────────────────────────────

@dataclass
class Decision:
    fire: bool
    reason: str
    tentativa: int | None = None


def decide(now: float, signals: Mapping, cfg: Any) -> Decision:
    """Decide se um contato deve receber uma nota AGORA (pura, sem efeitos).

    Reasons de SKIP: ``sem_saida`` (IA/operador nunca falou), ``cliente_respondeu``,
    ``limite_atingido`` (standby), ``nao_venceu`` (relógio de N horas), ``fora_expediente``
    (defere p/ o próximo tick útil). FIRE ⇒ ``tentativa = notes_since_reply + 1``.
    """
    last_client = signals.get("last_client_ts")
    last_out = signals.get("last_outbound_ts")
    last_note = signals.get("last_note_ts")
    notes = int(signals.get("notes_since_reply") or 0)

    silence_minutes = float(_cfg(cfg, "silence_minutes", 180) or 0.0)
    max_notes = int(_cfg(cfg, "max_consecutive_notes", 3) or 1)

    # 1) A IA/operador nunca falou → não há retorno a cobrar.
    if last_out is None:
        return Decision(False, "sem_saida")
    # 2) Cliente respondeu por último → não está em silêncio (contador zera naturalmente).
    cliente_em_silencio = (last_client is None) or (last_client < last_out)
    if not cliente_em_silencio:
        return Decision(False, "cliente_respondeu")
    # 3) Limite de notas consecutivas → standby até o cliente responder.
    if notes >= max_notes:
        return Decision(False, "limite_atingido")
    # 4) Relógio de N minutos a partir da última saída OU da última nota (idempotência).
    anchor = max(last_out, last_note or 0.0)
    if (now - anchor) < silence_minutes * 60:
        return Decision(False, "nao_venceu")
    # 5) Fora do expediente → defere; dispara no próximo tick dentro do expediente.
    if not is_open_now(now, cfg):
        return Decision(False, "fora_expediente")
    # 6) Dispara.
    return Decision(True, "fire", tentativa=notes + 1)


# ── Render + Dispatch ───────────────────────────────────────────────────────────

class _SafeDict(dict):
    def __missing__(self, key):  # placeholder desconhecido fica literal
        return "{" + key + "}"


def _fmt_hours(h) -> str:
    try:
        return "%g" % float(h)
    except (TypeError, ValueError):
        return str(h)


def _human_duration(total_minutes) -> str:
    """Duração amigável: 45→'45min', 60→'1h', 90→'1h30min', 180→'3h'."""
    try:
        m = int(round(float(total_minutes)))
    except (TypeError, ValueError):
        return str(total_minutes)
    if m < 60:
        return f"{m}min"
    h, rem = divmod(m, 60)
    return f"{h}h" if rem == 0 else f"{h}h{rem}min"


def render_note(template: str, *, cliente: str | None, minutes, tentativa, max_notes) -> str:
    try:
        _hours = float(minutes) / 60.0
    except (TypeError, ValueError):
        _hours = minutes
    values = _SafeDict(
        cliente=(cliente or "cliente").strip() or "cliente",
        tempo=_human_duration(minutes),
        minutos=int(minutes) if str(minutes).lstrip("-").isdigit() else minutes,
        horas=_fmt_hours(_hours),
        tentativa=tentativa, max=max_notes)
    try:
        return str(template).format_map(values)
    except Exception:  # noqa: BLE001 — template quebrado nunca impede o disparo
        return str(template)


def _gowa_client():
    from db.repositories import config_repo
    from gowa.client import GOWAClient
    port = int(config_repo.get("gowa_port", 3000) or 3000)
    return GOWAClient(port=port)


async def _resolve_send_text(phone: str, part: str) -> tuple[str, list[str] | None]:
    send_text, mentions = part, None
    if "@g.us" in phone:
        try:
            from agent import group_mentions
            send_text, mentions = await asyncio.to_thread(
                group_mentions.resolve_outgoing, phone, part)
        except Exception:  # noqa: BLE001 — grupo sem resolução cai pro texto cru
            logger.debug("retorno_automatico: resolve_outgoing falhou", exc_info=True)
    return send_text, mentions


async def _emit_sent(phone: str, text_: str, msg_id: str | None, *, status: str) -> None:
    try:
        from plugins.events import emit_with_filter
        await emit_with_filter("message.sent", {
            "phone": phone, "text": text_, "msg_id": msg_id,
            "media_type": None, "media_path": None,
            "source": "retorno_automatico_ia", "status": status, "ts": time.time(),
        })
    except Exception:  # noqa: BLE001
        logger.debug("retorno_automatico: emit message.sent falhou", exc_info=True)


async def _ai_reply_in_chat(handler, phone: str, note_body: str) -> None:
    """Aciona a IA pra ler a nota recém-postada e responder DE VERDADE ao cliente
    no chat — igual ao toggle "IA lê" + "IA responde no chat" da Mensagem Privada
    manual (``_run_private_ai``). A nota privada já salva em ``dispatch_note`` é o
    ÚNICO veículo da instrução até o modelo (``get_context_messages`` traduz
    ``private_note`` para ``role="user"`` com o prefixo "[Nota privada do
    operador]: ..." — por isso ``save_user_message=False`` aqui: ``note_body`` não
    é reenviado, só documenta a chamada).

    Best-effort: qualquer falha aqui deixa a nota informativa como está — não
    derruba o ciclo nem desfaz o que ``dispatch_note`` já postou.
    """
    from plugins.events import apply_filter

    try:
        result = await handler.aprocess_message(
            phone, note_body, save_user_message=False, save_response=False)
    except Exception as e:  # noqa: BLE001
        logger.warning("[RetornoAutomatico] turno da IA falhou (phone=%s): %s", phone, e)
        return

    reply = (getattr(result, "reply", "") or "").strip()
    if not reply or reply.startswith("[WhatsBot]"):
        return

    # Reconfere: a IA pode ter sido desligada pro contato enquanto o turno rodava
    # (ele pode levar dezenas de segundos) — não fala por cima de quem desligou.
    from db.repositories import contact_repo
    contact2 = await asyncio.to_thread(contact_repo.get_by_phone, phone)
    if not contact2 or not contact2.get("ai_enabled"):
        logger.debug("retorno_automatico: IA desligada durante o turno (phone=%s)", phone)
        return

    reply = await apply_filter("filter.reply.raw", reply, {"phone": phone})
    if reply is None:
        return

    split = True
    try:
        from db.repositories import config_repo
        split = bool(config_repo.get("split_messages", True))
    except Exception:  # noqa: BLE001
        pass
    from server.helpers import parse_split_reply
    parts = parse_split_reply(reply) if split else [reply]
    parts = await apply_filter(
        "filter.reply.parts", parts, {"phone": phone, "source": "retorno_automatico_ia"})
    if not parts:
        return

    from gowa.client import extract_msg_id
    client = _gowa_client()

    for index, raw in enumerate(parts):
        part = await apply_filter(
            "filter.reply.part", raw,
            {"phone": phone, "index": index, "total": len(parts),
             "source": "retorno_automatico_ia"})
        if part is None or not str(part).strip():
            continue
        part = str(part).strip()

        send_text, mentions = await _resolve_send_text(phone, part)
        mark_sent(phone, send_text)
        try:
            send_result = await asyncio.to_thread(client.send_message, phone, send_text, mentions)
        except Exception as e:  # noqa: BLE001 — para no meio, o que já saiu fica salvo
            logger.warning(
                "[RetornoAutomatico] envio da resposta da IA falhou (phone=%s): %s", phone, e)
            break

        msg_id = extract_msg_id(send_result)
        await asyncio.to_thread(
            handler.save_assistant_message, phone, part, msg_id=msg_id, status="sent")
        try:
            contact_mem = await asyncio.to_thread(handler._get_contact, phone)
            await asyncio.to_thread(contact_mem.increment_unread_ai)
        except Exception:  # noqa: BLE001
            pass
        try:
            broadcast("new_message", {"phone": phone, "message": {
                "role": "assistant", "content": part, "ts": time.time(),
                "status": "sent", "msg_id": msg_id,
            }})
        except Exception:  # noqa: BLE001
            pass
        await _emit_sent(phone, part, msg_id, status="sent")


async def dispatch_note(candidate: Mapping, tentativa: int, cfg: Any) -> dict:
    """Posta a nota privada no contato do candidato. Levanta em caso de falha ao
    postar a nota (a resposta da IA no chat, se ligada, é best-effort — ver
    :func:`_ai_reply_in_chat`)."""
    from db.repositories import message_repo

    handler = _handler()
    if handler is None:
        raise RuntimeError("agent_handler indisponível (runtime não conectado)")

    phone = candidate.get("phone")
    if not phone:
        raise RuntimeError("candidato sem phone")

    body = NOTE_MARKER + render_note(
        _cfg(cfg, "note_template", ""),
        cliente=candidate.get("contact_name"),
        minutes=_cfg(cfg, "silence_minutes", 180),
        tentativa=tentativa,
        max_notes=_cfg(cfg, "max_consecutive_notes", 3),
    )

    def _save():
        contact = handler._get_contact(phone)
        contact.add_message("private_note", body)
        return message_repo.get_last(contact.id)

    saved = await asyncio.to_thread(_save)
    saved = saved or {"content": body, "ts": time.time()}
    try:
        broadcast("new_message", {
            "phone": phone,
            "message": {
                "role": "private_note",
                "content": body,
                "ts": saved.get("ts"),
                "status": None,
                "msg_id": saved.get("msg_id"),
            },
        })
    except Exception:  # noqa: BLE001 — broadcast nunca quebra o disparo
        logger.debug("retorno_automatico: broadcast new_message falhou")

    if bool(_cfg(cfg, "ai_auto_reply", True)):
        await _ai_reply_in_chat(handler, phone, body)

    return saved


# ── Ciclo do verificador (chamado a cada minuto por events.py) ────────────────

async def run_cycle() -> dict:
    """Um ciclo do verificador. ASYNC: :func:`dispatch_note` pode precisar
    chamar a IA e enviar de verdade via GOWA — as leituras só-DB (settings,
    candidatos, sinais) continuam envolvidas em ``asyncio.to_thread``
    individualmente pra não travar o event loop.

    Falha de um item nunca derruba o ciclo. Retorna um sumário
    ``{checked, fired, skipped, failed, checked_at}``.
    """
    cfg = await asyncio.to_thread(load_settings)
    if not bool(_cfg(cfg, "enabled", True)):
        return {"checked": 0, "fired": 0, "skipped": 0, "failed": 0,
                "checked_at": time.time(), "enabled": False}

    _prune_recently_sent()
    now = time.time()
    apply_groups = bool(_cfg(cfg, "apply_to_groups", False))
    candidates = await asyncio.to_thread(list_candidates, apply_groups)

    fired = skipped = failed = 0
    for cand in candidates:
        try:
            signals = await asyncio.to_thread(contact_signals, cand["contact_id"])
            decision = decide(now, signals, cfg)
            if not decision.fire:
                skipped += 1
                continue
            await dispatch_note(cand, decision.tentativa, cfg)
            fired += 1
        except Exception as e:  # noqa: BLE001 — um item ruim não derruba o ciclo
            failed += 1
            logger.warning("[RetornoAutomatico] item falhou (contato=%s): %s",
                           cand.get("contact_id"), e)

    return {"checked": len(candidates), "fired": fired, "skipped": skipped,
            "failed": failed, "checked_at": now, "enabled": True}
