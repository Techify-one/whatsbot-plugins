"""Settings declarativas do plugin (form auto-gerado no modal "Configurar" do card).

Lidas a CADA ciclo do verificador via ``config_repo.get("plugin.retorno_automatico.<campo>")``
(ver ``logic.load_settings``) — editar na UI vale no ciclo seguinte, sem restart, igual ao
``agendamento_retorno``. Campos idênticos ao plugin homônimo do whatsbot-pro (mesma UX de
configuração); só a leitura embaixo muda (contato em vez de conversa).
"""

from pydantic import BaseModel, Field


class Settings(BaseModel):
    enabled: bool = Field(
        default=True,
        title="Ativar retorno automático",
        description="Interruptor mestre do plugin. Desligado, o verificador não posta nenhuma nota.",
    )
    silence_minutes: int = Field(
        default=180, ge=1, le=10080,
        title="Silêncio do cliente antes da nota (minutos)",
        description=(
            "Minutos que o cliente pode ficar sem responder (contado a partir da última "
            "resposta da IA/operador ou da última nota) antes de uma nova nota ser postada. "
            "Ex.: 180 = 3 horas, 30 = meia hora, 1 = teste rápido."
        ),
    )
    max_consecutive_notes: int = Field(
        default=3, ge=1, le=20,
        title="Máximo de notas consecutivas",
        description=(
            "Quantas notas podem ser postadas sem o cliente responder. Ao atingir o limite, "
            "o plugin entra em standby para esse contato até o cliente responder (reset)."
        ),
    )
    business_start: str = Field(
        default="08:00",
        title="Início do expediente (HH:MM)",
        description="Notas só são postadas dentro do expediente. Formato 24h, ex.: 08:00.",
    )
    business_end: str = Field(
        default="18:00",
        title="Fim do expediente (HH:MM)",
        description="Limite superior EXCLUSIVO do expediente. Formato 24h, ex.: 18:00.",
    )
    day_mon: bool = Field(default=True, title="Segunda-feira", description="Expediente ativo na segunda.")
    day_tue: bool = Field(default=True, title="Terça-feira", description="Expediente ativo na terça.")
    day_wed: bool = Field(default=True, title="Quarta-feira", description="Expediente ativo na quarta.")
    day_thu: bool = Field(default=True, title="Quinta-feira", description="Expediente ativo na quinta.")
    day_fri: bool = Field(default=True, title="Sexta-feira", description="Expediente ativo na sexta.")
    day_sat: bool = Field(default=False, title="Sábado", description="Expediente ativo no sábado.")
    day_sun: bool = Field(default=False, title="Domingo", description="Expediente ativo no domingo.")
    tz_offset_hours: float = Field(
        default=-3.0, ge=-12.0, le=14.0,
        title="Fuso horário (horas UTC)",
        description="Deslocamento fixo em relação ao UTC (Brasil = −3). Sem horário de verão.",
    )
    apply_to_groups: bool = Field(
        default=False,
        title="Aplicar a grupos",
        description="Se desligado (padrão), grupos são ignorados — só contatos individuais.",
    )
    ai_auto_reply: bool = Field(
        default=True,
        title="IA responde automaticamente no chat",
        description=(
            "Além de postar a nota privada, aciona a IA para ler essa nota e responder "
            "DE VERDADE ao cliente no chat — igual ao toggle \"IA lê\" + \"IA responde no "
            "chat\" da Mensagem Privada manual. Desligado, o plugin volta ao "
            "comportamento original: só posta a nota, cabe ao operador retomar a "
            "conversa. Uma falha nessa etapa (ex.: IA desligada durante o turno) nunca "
            "impede a nota de ser postada."
        ),
    )
    note_template: str = Field(
        default=(
            "O cliente {cliente} está sem responder há {tempo}. "
            "Reative a IA para dar seguimento. (Tentativa {tentativa}/{max})"
        ),
        title="Modelo da nota",
        description=(
            "Texto da nota privada (o prefixo \"🔔 Retorno Automático: \" é adicionado "
            "automaticamente antes deste texto — é assim que o plugin reconhece as próprias "
            "notas depois de um restart, e não precisa ser digitado aqui). Placeholders: "
            "{cliente}, {tempo} (ex.: 3h / 30min), {minutos}, {horas}, {tentativa}, {max}. "
            "Um placeholder desconhecido é mantido literal (não quebra o disparo)."
        ),
    )
