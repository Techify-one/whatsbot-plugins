"""Núcleo do plugin Agendamento de Retorno.

Adaptação do plugin homônimo do whatsbot-pro para o whatsbot "simples"
(single-channel via GOWA, um único agente de IA por contato, sem conversas/
atendentes/protocolos/RBAC/auditoria). Duas diferenças estruturais em relação
ao original que valem a pena ter em mente lendo este arquivo:

  * Não existe "lifecycle"/tarefa supervisionada de plugin aqui — o verificador
    que roda a cada minuto é um `asyncio.Task` comum, aberto pelo próprio
    plugin em `events.py` (`EVENT_HANDLERS["app.startup"]`), igual ao padrão
    já usado pelo plugin `monitor_conexao`. Por isso ele roda inteiro dentro
    do event loop principal — sem a ponte thread→loop que o plugin pro
    precisava (`_run_on_loop`): aqui dá pra `await` direto.
  * Não existe "conversa" como entidade — o escopo de um retorno é o
    `phone` (== o contato). Um contato só tem uma "caixa" (o WhatsApp
    conectado via GOWA), então não há canal/janela de envio pra checar.
"""

from __future__ import annotations

import asyncio
import contextvars
import logging
import time
from datetime import datetime, timedelta, timezone

from sqlalchemy import text as sqltext

from plugins.context import broadcast, make_plugin_db

logger = logging.getLogger("plugin.agendamento_retorno")

PLUGIN_ID = "agendamento_retorno"
TABLE = "plugin_agendamento_retorno_items"

# Fuso do bloco "--- Data e hora atual ---" que o core injeta no system prompt
# (agent/handler.py: `_BRT = timezone(timedelta(hours=-3))`): offset FIXO
# -03:00, sem DST e sem depender do timezone do processo/SO.
BRT = timezone(timedelta(hours=-3))

DEFAULT_TOLERANCE_MINUTES = 60
TURN_TIMEOUT_SECONDS = 120.0

# Status possíveis (persistidos).
STATUS_SCHEDULED = "agendado"
STATUS_PROCESSING = "processando"  # claim atômico durante o turno da IA
STATUS_SENT = "enviado"
STATUS_FAILED = "falhou"
STATUS_EXPIRED = "expirado"
STATUS_CANCELLED = "cancelado"

ACTIVE_STATUSES = (STATUS_SCHEDULED,)


def is_active(status: str | None) -> bool:
    return (status or "") in ACTIVE_STATUSES


# Modo de disparo.
SEND_MODE_MESSAGE = "message"   # manual: o texto digitado é enviado como está
SEND_MODE_IA = "ia_turn"        # agendado pela própria IA: ela compõe a mensagem

# Resultado do disparo (coluna `outcome`).
OUTCOME_SENT = "enviado"
OUTCOME_NOTE = "nota_privada"
OUTCOME_NO_REPLY = "sem_resposta"
OUTCOME_REPLACED = "substituido"
OUTCOME_CLIENT_REPLIED = "cliente_respondeu"

# Motivo (coluna `outcome_reason`).
REASON_AI_OFF = "ia_desligada"
REASON_NO_REPLY = "sem_resposta"
REASON_PLUGIN_BLOCKED = "bloqueado_por_plugin"

IA_NOTE_AUTHOR = "Retorno da IA"
IA_BRIEFING_MARKER = "Retorno agendado por você — instrução para esta mensagem:"
IA_FALLBACK_MARKER = "Retorno agendado pela IA não foi disparado"

_MOTIVOS = {
    REASON_AI_OFF: "a IA está desligada para este contato agora.",
}


def _now() -> float:
    return time.time()


# ── AgentHandler capturado no boot (events.py) ───────────────────────────────
#
# Não existe `deps`/`get_deps()` neste whatsbot (isso é exclusivo do pro).
# `EventContext.handler` já É o `AgentHandler` real (setado pelo core antes de
# emitir `app.startup`); guardamos a referência aqui pra o checker conseguir
# usá-la fora do handler de evento.
_HANDLER = None


def set_handler(handler) -> None:
    global _HANDLER
    if handler is not None:
        _HANDLER = handler


def _handler():
    return _HANDLER


# ── Dedup do próprio eco ──────────────────────────────────────────────────
#
# O core usa `state.recently_sent` para reconhecer o eco de uma mensagem que
# ELE mandou quando ela volta pelo webhook (`is_from_me=True`) — sem isso, o
# GOWA ecoaria a mensagem de volta e o core salvaria uma bolha "Manual"
# duplicada. `state` não é exposto a plugins (`EventContext`/`ToolContext` só
# trazem handler/plugin_id/plugin_db), então mantemos aqui a MESMA ideia numa
# tabela local, escrita nos dois pontos de disparo (`_dispatch_manual` e o
# turno da IA) e consumida por `filters.py` via `filter.message.outgoing`.
_recently_sent: dict[str, float] = {}


def mark_sent(phone: str, wire_text: str) -> None:
    _recently_sent[f"{phone}:{(wire_text or '')[:120]}"] = _now()


def consume_recent_echo(phone: str, text_: str) -> bool:
    """``True`` (e remove) se este texto foi mandado por nós há menos de 30s."""
    key = f"{phone}:{(text_ or '')[:120]}"
    ts = _recently_sent.pop(key, None)
    if ts is None:
        return False
    return (_now() - ts) < 30


def _prune_recently_sent() -> None:
    cutoff = _now() - 60
    for key in [k for k, v in _recently_sent.items() if v < cutoff]:
        _recently_sent.pop(key, None)


# ── Settings ─────────────────────────────────────────────────────────────────

def _cfg(key: str, default):
    try:
        from db.repositories import config_repo
        value = config_repo.get(f"plugin.{PLUGIN_ID}.{key}", default)
    except Exception:  # noqa: BLE001 — settings ruins nunca derrubam o ciclo
        return default
    return default if value is None else value


def _cfg_bool(key: str, default: bool) -> bool:
    value = _cfg(key, default)
    if isinstance(value, str):
        return value.strip().lower() not in ("0", "false", "no", "nao", "não", "off", "")
    return bool(value)


def _cfg_int(key: str, default: int) -> int:
    try:
        return int(_cfg(key, default))
    except (TypeError, ValueError):
        return default


def tolerance_seconds() -> int:
    return max(0, _cfg_int("tolerance_minutes", DEFAULT_TOLERANCE_MINUTES)) * 60


def retorno_ia_enabled() -> bool:
    """Kill-switch das duas tools. Desligado, a tool recusa com uma frase que o
    modelo entende e a conversa segue normal."""
    return _cfg_bool("retorno_ia_enabled", True)


def min_lead_seconds() -> int:
    return max(60, _cfg_int("retorno_ia_min_lead_minutes", 5) * 60)


def max_horizon_seconds() -> int:
    return max(86400, _cfg_int("retorno_ia_max_horizon_days", 30) * 86400)


def max_chain() -> int:
    return max(1, _cfg_int("retorno_ia_max_chain", 3))


# ── Anti-loop: turno proativo em curso ────────────────────────────────────────
#
# Ligado ao redor da chamada de `aprocess_message` no turno da IA. Durante o
# próprio turno do retorno, chamar `agendar_retorno_ia` de novo criaria uma
# corrente IA→IA sem o cliente nunca falar. `ContextVar` porque o executor da
# tool roda na mesma cadeia de awaits/tasks do turno.
_IN_TURN: contextvars.ContextVar = contextvars.ContextVar(
    "agendamento_retorno_in_turn", default=False)


def in_proactive_turn() -> bool:
    return bool(_IN_TURN.get())


# ── CRUD ─────────────────────────────────────────────────────────────────────

def get_item(item_id: int) -> dict | None:
    with make_plugin_db() as conn:
        row = conn.execute(
            sqltext(f"SELECT * FROM {TABLE} WHERE id = :id"), {"id": item_id}
        ).mappings().first()
    return dict(row) if row else None


def list_items(*, status=None, phone=None, limit: int = 500) -> list[dict]:
    clauses, params = [], {"limit": max(1, min(int(limit or 500), 1000))}
    if status and status not in ("todos", "all", ""):
        if status in ("ativos", "ativo"):
            clauses.append("status = :status")
            params["status"] = STATUS_SCHEDULED
        else:
            clauses.append("status = :status")
            params["status"] = status
    if phone:
        clauses.append("phone = :phone")
        params["phone"] = phone
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    with make_plugin_db() as conn:
        rows = conn.execute(
            sqltext(f"SELECT * FROM {TABLE} {where} ORDER BY due_at DESC LIMIT :limit"),
            params,
        ).mappings().all()
    return [dict(r) for r in rows]


def _notify(item_id, status) -> None:
    try:
        broadcast("agendamento_retorno_changed", {"id": item_id, "status": status})
    except Exception:  # noqa: BLE001 — broadcast nunca quebra a operação
        pass


def create_manual_item(*, phone: str, message: str, due_at, contact_name: str | None = None):
    """Cria um agendamento manual (send_mode='message'). Devolve ``(item, error)``."""
    from db.repositories import contact_repo

    phone = (phone or "").strip()
    message = (message or "").strip()
    if not phone:
        return None, "Informe o telefone do contato."
    if not message:
        return None, "Informe a mensagem a enviar."
    try:
        due_at = float(due_at)
    except (TypeError, ValueError):
        return None, "Data/hora inválida."
    if due_at < _now() - 60:
        return None, "Escolha uma data/hora no futuro."

    contact = contact_repo.get_or_create(phone)
    display_name = (contact_name or "").strip() or (contact.get("name") or "")
    now = _now()
    params = {
        "contact_id": contact["id"],
        "phone": contact.get("phone") or phone,
        "contact_name": display_name,
        "due_at": due_at,
        "message_text": message,
        "created_at": now,
        "updated_at": now,
    }
    with make_plugin_db() as conn:
        new_id = conn.execute(
            sqltext(
                f"INSERT INTO {TABLE} (contact_id, phone, contact_name, due_at, send_mode, "
                f"message_text, status, created_at, updated_at) VALUES (:contact_id, :phone, "
                f":contact_name, :due_at, '{SEND_MODE_MESSAGE}', :message_text, "
                f"'{STATUS_SCHEDULED}', :created_at, :updated_at) RETURNING id"
            ),
            params,
        ).scalar()
    _notify(new_id, STATUS_SCHEDULED)
    return get_item(new_id), None


def cancel_item(item_id: int):
    row = get_item(item_id)
    if not row:
        return None, "Agendamento não encontrado."
    if row["status"] != STATUS_SCHEDULED:
        return None, "Só é possível cancelar agendamentos ativos."
    _set_status(item_id, STATUS_CANCELLED)
    _notify(item_id, STATUS_CANCELLED)
    return get_item(item_id), None


def delete_item(item_id: int) -> bool:
    with make_plugin_db() as conn:
        res = conn.execute(sqltext(f"DELETE FROM {TABLE} WHERE id = :id"), {"id": item_id})
    ok = (res.rowcount or 0) > 0
    if ok:
        _notify(item_id, "deleted")
    return ok


def _set_status(item_id: int, status: str, *, last_error=None, sent_at=None) -> None:
    with make_plugin_db() as conn:
        conn.execute(
            sqltext(
                f"UPDATE {TABLE} SET status = :s, updated_at = :u, last_error = :e, "
                f"sent_at = COALESCE(:sent, sent_at) WHERE id = :id"
            ),
            {"s": status, "u": _now(), "e": last_error, "sent": sent_at, "id": item_id},
        )


# ── Retorno agendado pela própria IA — CRUD ──────────────────────────────────

def active_ia_item(phone: str) -> dict | None:
    """O retorno da IA ainda pendente com este contato (no máximo um), ou ``None``."""
    with make_plugin_db() as conn:
        row = conn.execute(
            sqltext(
                f"SELECT * FROM {TABLE} WHERE phone = :phone AND send_mode = :mode "
                f"AND created_by_ia = 1 AND status = :st ORDER BY id DESC LIMIT 1"
            ),
            {"phone": phone, "mode": SEND_MODE_IA, "st": STATUS_SCHEDULED},
        ).mappings().first()
    return dict(row) if row else None


def cliente_respondeu(phone: str, since: float) -> bool:
    """Houve mensagem DO CLIENTE depois de ``since``?

    Se o cliente voltou a falar sozinho, o retorno perde a razão de existir —
    a IA não "cobra" quem já retomou."""
    try:
        from db.repositories import contact_repo, message_repo
        contact = contact_repo.get_by_phone(phone)
        if not contact:
            return False
        last_user = message_repo.get_last_user_message(contact["id"])
    except Exception:  # noqa: BLE001 — na dúvida, NÃO cancela (o retorno foi combinado)
        return False
    if not last_user:
        return False
    return float(last_user.get("ts") or 0) > float(since or 0)


def chain_depth_for(phone: str) -> int:
    """Quantos retornos da IA já dispararam com este contato SEM ele responder.

    Uma mensagem do cliente depois do último disparo ZERA a corrente."""
    with make_plugin_db() as conn:
        row = conn.execute(
            sqltext(
                f"SELECT chain_depth, sent_at, updated_at FROM {TABLE} "
                f"WHERE phone = :phone AND send_mode = :mode "
                f"AND status IN ('{STATUS_SENT}', '{STATUS_FAILED}') "
                f"ORDER BY COALESCE(sent_at, updated_at) DESC, id DESC LIMIT 1"
            ),
            {"phone": phone, "mode": SEND_MODE_IA},
        ).mappings().first()
    if not row:
        return 0
    quando = row.get("sent_at") or row.get("updated_at") or 0
    if cliente_respondeu(phone, since=float(quando)):
        return 0
    return int(row.get("chain_depth") or 0) + 1


def create_ia_item(*, contact: dict, due_at: float, briefing: str, chain_depth: int = 0):
    """Cria o agendamento da IA, SUBSTITUINDO o anterior para o mesmo contato.

    Só um retorno ativo da IA por contato: agendar de novo substitui em vez de
    recusar (o cliente que corrige o horário não deveria receber uma recusa
    que o modelo não sabe traduzir). Substituição e inserção na MESMA
    transação, para um vencimento nunca pegar duas linhas ativas."""
    contact_id = contact.get("id")
    if not contact_id:
        return None, "contato inválido"
    now = _now()
    phone = contact.get("phone") or ""
    display_name = (contact.get("name") or "").strip()
    params = {
        "contact_id": contact_id,
        "phone": phone,
        "contact_name": display_name,
        "due_at": float(due_at),
        "briefing": (briefing or "").strip(),
        "chain_depth": int(chain_depth or 0),
        "message_text": f"{IA_BRIEFING_MARKER}\n\n{(briefing or '').strip()}",
        "created_at": now,
        "updated_at": now,
    }
    with make_plugin_db() as conn:
        replaced = conn.execute(
            sqltext(
                f"UPDATE {TABLE} SET status = :cancelled, outcome = :outcome, "
                f"updated_at = :now WHERE phone = :phone AND send_mode = :mode "
                f"AND created_by_ia = 1 AND status = :scheduled"
            ),
            {"cancelled": STATUS_CANCELLED, "outcome": OUTCOME_REPLACED, "now": now,
             "phone": phone, "mode": SEND_MODE_IA, "scheduled": STATUS_SCHEDULED},
        ).rowcount or 0
        new_id = conn.execute(
            sqltext(
                f"INSERT INTO {TABLE} (contact_id, phone, contact_name, due_at, send_mode, "
                f"message_text, briefing, status, created_by_ia, chain_depth, created_at, "
                f"updated_at) VALUES (:contact_id, :phone, :contact_name, :due_at, "
                f"'{SEND_MODE_IA}', :message_text, :briefing, '{STATUS_SCHEDULED}', 1, "
                f":chain_depth, :created_at, :updated_at) RETURNING id"
            ),
            params,
        ).scalar()
    _notify(new_id, STATUS_SCHEDULED)
    item = get_item(new_id) or {}
    item["_replaced"] = bool(replaced)
    return item, None


def cancel_active_ia_items(phone: str, *, motivo: str = "") -> int:
    """Cancela os retornos pendentes DA IA com este contato. Devolve quantos."""
    with make_plugin_db() as conn:
        n = conn.execute(
            sqltext(
                f"UPDATE {TABLE} SET status = :cancelled, outcome_reason = :motivo, "
                f"updated_at = :now WHERE phone = :phone AND send_mode = :mode "
                f"AND created_by_ia = 1 AND status = :scheduled"
            ),
            {"cancelled": STATUS_CANCELLED, "motivo": (motivo or "")[:200], "now": _now(),
             "phone": phone, "mode": SEND_MODE_IA, "scheduled": STATUS_SCHEDULED},
        ).rowcount or 0
    if n:
        _notify(0, STATUS_CANCELLED)
    return int(n)


def _claim(item_id: int) -> bool:
    """Tira a row da fila (``agendado`` -> ``processando``). ``False`` = outro levou."""
    with make_plugin_db() as conn:
        n = conn.execute(
            sqltext(
                f"UPDATE {TABLE} SET status = :processing, claimed_at = :now, "
                f"updated_at = :now WHERE id = :id AND status = :scheduled"
            ),
            {"processing": STATUS_PROCESSING, "now": _now(), "id": int(item_id),
             "scheduled": STATUS_SCHEDULED},
        ).rowcount or 0
    return bool(n)


def _finish(item_id: int, status: str, outcome: str, reason: str = "", last_error=None) -> None:
    now = _now()
    with make_plugin_db() as conn:
        conn.execute(
            sqltext(
                f"UPDATE {TABLE} SET status = :status, outcome = :outcome, "
                f"outcome_reason = :reason, last_error = :err, updated_at = :now, "
                f"sent_at = COALESCE(sent_at, :sent) WHERE id = :id"
            ),
            {"status": status, "outcome": outcome, "reason": (reason or "")[:200],
             "err": last_error, "now": now, "sent": (now if status == STATUS_SENT else None),
             "id": int(item_id)},
        )
    _notify(item_id, status)


def recover_stale_processing(older_than: float) -> int:
    """Devolve ao histórico as rows presas em ``processando`` (restart no meio
    do turno). Não reenvia: um turno interrompido pode ter mandado parte das
    mensagens, e reenviar por cima é pior do que registrar a falha."""
    with make_plugin_db() as conn:
        n = conn.execute(
            sqltext(
                f"UPDATE {TABLE} SET status = :failed, outcome = :outcome, "
                f"last_error = 'turno interrompido (o servidor reiniciou durante o "
                f"disparo)', updated_at = :now WHERE status = :processing "
                f"AND COALESCE(claimed_at, 0) < :cutoff"
            ),
            {"failed": STATUS_FAILED, "outcome": OUTCOME_NO_REPLY, "now": _now(),
             "processing": STATUS_PROCESSING, "cutoff": float(older_than)},
        ).rowcount or 0
    return int(n)


def _build_fallback_note(*, reason: str, briefing: str, contact_name: str = "") -> str:
    """Texto da nota quando a IA não pôde ser acionada (autor vai no cabeçalho
    do card pelo painel — ``private_note`` já mostra "Mensagem privada", não
    precisa repetir no corpo)."""
    quem = (contact_name or "").strip() or "o cliente"
    explicacao = _MOTIVOS.get(reason, reason)
    return (
        f"{IA_FALLBACK_MARKER}: {explicacao}"
        f"\n\nO que a IA ia tratar com {quem}: {(briefing or '').strip() or '(sem instrução registrada)'}"
        f"\n\nSe ainda fizer sentido, retome você mesmo."
    )


async def _write_private_note(handler, phone: str, body: str) -> None:
    try:
        contact = await asyncio.to_thread(handler._get_contact, phone)
        saved = await asyncio.to_thread(contact.add_message, "private_note", body)
        broadcast("new_message", {
            "phone": phone,
            "message": {
                "role": "private_note", "content": body,
                "ts": (saved or {}).get("ts") or _now(), "status": None,
                "msg_id": (saved or {}).get("msg_id"),
            },
        })
    except Exception as e:  # noqa: BLE001 — nota é best-effort
        logger.warning("[AgendamentoRetorno] nota privada falhou (phone=%s): %s", phone, e)


async def _fallback_note(handler, row: dict, *, reason: str) -> None:
    body = _build_fallback_note(
        reason=reason, briefing=row.get("briefing") or "",
        contact_name=row.get("contact_name") or "")
    await _write_private_note(handler, row.get("phone") or "", body)
    _finish(int(row["id"]), STATUS_SENT, OUTCOME_NOTE, reason)


def _gowa_client():
    from db.repositories import config_repo
    from gowa.client import GOWAClient
    port = int(config_repo.get("gowa_port", 3000) or 3000)
    return GOWAClient(port=port)


async def _resolve_send_text(phone: str, part: str) -> tuple[str, list[str] | None]:
    send_text, mentions = part, None
    if "@g.us" in phone:
        try:
            from agent import group_mentions
            send_text, mentions = await asyncio.to_thread(
                group_mentions.resolve_outgoing, phone, part)
        except Exception:  # noqa: BLE001 — grupo sem resolução cai pro texto cru
            logger.debug("[AgendamentoRetorno] resolve_outgoing falhou", exc_info=True)
    return send_text, mentions


async def _emit_sent(phone: str, text_: str, msg_id: str | None, *, source: str, status: str) -> None:
    try:
        from plugins.events import emit_with_filter
        await emit_with_filter("message.sent", {
            "phone": phone, "text": text_, "msg_id": msg_id,
            "media_type": None, "media_path": None,
            "source": source, "status": status, "ts": _now(),
        })
    except Exception:  # noqa: BLE001
        logger.debug("[AgendamentoRetorno] emit message.sent falhou", exc_info=True)


# ── Disparo manual (send_mode='message') ──────────────────────────────────────

async def _dispatch_manual(row: dict) -> None:
    from plugins.events import apply_filter

    item_id = int(row["id"])
    phone = row.get("phone") or ""
    body = (row.get("message_text") or "").strip()

    part = await apply_filter(
        "filter.reply.part", body,
        {"phone": phone, "index": 0, "total": 1, "source": "agendamento_retorno"})
    if part is None:
        _finish(item_id, STATUS_FAILED, "", REASON_PLUGIN_BLOCKED,
                last_error="mensagem bloqueada por um plugin")
        return
    part = str(part).strip()
    if not part:
        _finish(item_id, STATUS_FAILED, "", "", last_error="mensagem vazia")
        return

    send_text, mentions = await _resolve_send_text(phone, part)

    handler = _handler()
    if handler is None:
        _finish(item_id, STATUS_FAILED, "", "", last_error="agent_handler indisponível")
        return

    from gowa.client import extract_msg_id

    mark_sent(phone, send_text)
    try:
        client = _gowa_client()
        send_result = await asyncio.to_thread(client.send_message, phone, send_text, mentions)
    except Exception as e:  # noqa: BLE001
        logger.warning("[AgendamentoRetorno] envio manual falhou (id=%s): %s", item_id, e)
        _finish(item_id, STATUS_FAILED, "", "", last_error=str(e)[:500])
        return

    msg_id = extract_msg_id(send_result)
    saved = await asyncio.to_thread(
        handler.save_operator_message, phone, part, status="operator", msg_id=msg_id)
    try:
        broadcast("new_message", {"phone": phone, "message": saved})
    except Exception:  # noqa: BLE001
        pass
    await _emit_sent(phone, part, msg_id, source="agendamento_retorno", status="operator")
    _finish(item_id, STATUS_SENT, OUTCOME_SENT)


# ── Disparo pela própria IA (send_mode='ia_turn') ─────────────────────────────

async def _dispatch_ia(row: dict) -> None:
    from plugins.events import apply_filter

    item_id = int(row["id"])
    if not _claim(item_id):
        logger.debug("[AgendamentoRetorno] item %s já foi levado por outro ciclo", item_id)
        return
    row = get_item(item_id) or row
    phone = row.get("phone") or ""
    briefing = (row.get("briefing") or "").strip()

    handler = _handler()
    if handler is None:
        _finish(item_id, STATUS_FAILED, OUTCOME_NO_REPLY, REASON_NO_REPLY,
                last_error="agent_handler indisponível")
        return

    # O cliente voltou a falar sozinho? O retorno perdeu a razão de existir —
    # cancela sem nota (a conversa já está viva).
    if cliente_respondeu(phone, since=row.get("created_at") or 0):
        _finish(item_id, STATUS_CANCELLED, OUTCOME_CLIENT_REPLIED)
        return

    from db.repositories import contact_repo
    contact = await asyncio.to_thread(contact_repo.get_by_phone, phone)
    if not contact or not contact.get("ai_enabled"):
        await _fallback_note(handler, row, reason=REASON_AI_OFF)
        return

    # A nota privada é o ÚNICO veículo da instrução até o modelo:
    # `aprocess_message` descarta o argumento `text` quando
    # `save_user_message=False`, e `get_context_messages` traduz
    # `private_note` para `role="user"` com o prefixo "[Nota privada do
    # operador]: ..." — é assim que a instrução chega ao LLM.
    await _write_private_note(handler, phone, f"{IA_BRIEFING_MARKER}\n\n{briefing}")

    token = _IN_TURN.set(True)
    try:
        result = await asyncio.wait_for(
            handler.aprocess_message(
                phone, briefing, save_user_message=False, save_response=False),
            timeout=TURN_TIMEOUT_SECONDS)
    except asyncio.TimeoutError:
        _finish(item_id, STATUS_FAILED, OUTCOME_NO_REPLY, REASON_NO_REPLY,
                last_error="turno da IA excedeu o tempo limite")
        return
    except Exception as e:  # noqa: BLE001
        logger.warning("[AgendamentoRetorno] turno da IA falhou (id=%s): %s", item_id, e)
        _finish(item_id, STATUS_FAILED, OUTCOME_NO_REPLY, REASON_NO_REPLY,
                last_error=str(e)[:500])
        return
    finally:
        _IN_TURN.reset(token)

    reply = (getattr(result, "reply", "") or "").strip()
    if not reply or reply.startswith("[WhatsBot]"):
        _finish(item_id, STATUS_FAILED, OUTCOME_NO_REPLY, REASON_NO_REPLY,
                last_error=(reply[:500] if reply else None))
        return

    # Reconfere DEPOIS do turno: algo pode ter desligado a IA enquanto ela
    # redigia (o turno pode levar dezenas de segundos).
    contact2 = await asyncio.to_thread(contact_repo.get_by_phone, phone)
    if not contact2 or not contact2.get("ai_enabled"):
        await _fallback_note(handler, row, reason=REASON_AI_OFF)
        return

    reply = await apply_filter("filter.reply.raw", reply, {"phone": phone})
    if reply is None:
        _finish(item_id, STATUS_FAILED, OUTCOME_NO_REPLY, REASON_PLUGIN_BLOCKED)
        return

    split = True
    try:
        from db.repositories import config_repo
        split = bool(config_repo.get("split_messages", True))
    except Exception:  # noqa: BLE001
        pass
    from server.helpers import parse_split_reply
    parts = parse_split_reply(reply) if split else [reply]
    parts = await apply_filter("filter.reply.parts", parts, {"phone": phone})
    if not parts:
        _finish(item_id, STATUS_FAILED, OUTCOME_NO_REPLY, REASON_PLUGIN_BLOCKED)
        return

    from gowa.client import extract_msg_id
    client = _gowa_client()

    sent_count = 0
    for index, raw in enumerate(parts):
        part = await apply_filter(
            "filter.reply.part", raw,
            {"phone": phone, "index": index, "total": len(parts),
             "source": "agendamento_retorno_ia"})
        if part is None or not str(part).strip():
            continue
        part = str(part).strip()

        send_text, mentions = await _resolve_send_text(phone, part)
        mark_sent(phone, send_text)
        try:
            send_result = await asyncio.to_thread(
                client.send_message, phone, send_text, mentions)
        except Exception as e:  # noqa: BLE001 — para no meio, o que já saiu fica salvo
            logger.warning(
                "[AgendamentoRetorno] envio do turno da IA falhou (id=%s): %s", item_id, e)
            break

        msg_id = extract_msg_id(send_result)
        await asyncio.to_thread(
            handler.save_assistant_message, phone, part, msg_id=msg_id, status="sent")
        try:
            contact_mem = await asyncio.to_thread(handler._get_contact, phone)
            await asyncio.to_thread(contact_mem.increment_unread_ai)
        except Exception:  # noqa: BLE001
            pass
        sent_count += 1
        try:
            broadcast("new_message", {"phone": phone, "message": {
                "role": "assistant", "content": part, "ts": _now(),
                "status": "sent", "msg_id": msg_id,
            }})
        except Exception:  # noqa: BLE001
            pass
        await _emit_sent(phone, part, msg_id, source="agendamento_retorno_ia", status="sent")

    if sent_count == 0:
        _finish(item_id, STATUS_FAILED, OUTCOME_NO_REPLY, REASON_NO_REPLY)
    else:
        _finish(item_id, STATUS_SENT, OUTCOME_SENT)


# ── Ciclo do verificador (chamado a cada minuto por events.py) ───────────────

async def run_due_cycle() -> dict:
    now = _now()
    tol = tolerance_seconds()
    _prune_recently_sent()
    try:
        await asyncio.to_thread(recover_stale_processing, now - (TURN_TIMEOUT_SECONDS * 3))
    except Exception:  # noqa: BLE001 — varredura nunca derruba o ciclo
        logger.debug("[AgendamentoRetorno] varredura de 'processando' falhou", exc_info=True)

    def _load_due():
        with make_plugin_db() as conn:
            rows = conn.execute(
                sqltext(
                    f"SELECT * FROM {TABLE} WHERE status = :st AND due_at <= :now "
                    f"ORDER BY due_at ASC"
                ),
                {"st": STATUS_SCHEDULED, "now": now},
            ).mappings().all()
        return [dict(r) for r in rows]

    due = await asyncio.to_thread(_load_due)

    sent = expired = failed = 0
    for row in due:
        overdue = now - float(row["due_at"])
        if overdue > tol:
            await asyncio.to_thread(_set_status, row["id"], STATUS_EXPIRED)
            _notify(row["id"], STATUS_EXPIRED)
            expired += 1
            continue
        try:
            if row.get("send_mode") == SEND_MODE_IA:
                await _dispatch_ia(row)
            else:
                await _dispatch_manual(row)
        except Exception as e:  # falha de um item nunca derruba o ciclo
            logger.warning("[AgendamentoRetorno] disparo falhou (id=%s): %s", row["id"], e)
            await asyncio.to_thread(_set_status, row["id"], STATUS_FAILED, last_error=str(e)[:500])
            _notify(row["id"], STATUS_FAILED)
            failed += 1
            continue
        final = (await asyncio.to_thread(get_item, row["id"])) or {}
        st = final.get("status")
        if st == STATUS_FAILED:
            failed += 1
        elif st != STATUS_CANCELLED:
            sent += 1

    return {"checked_at": now, "due": len(due), "sent": sent, "expired": expired, "failed": failed}
