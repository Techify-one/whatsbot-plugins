"""Evita duplicar no histórico as mensagens que ESTE plugin acabou de mandar.

O core usa ``state.recently_sent`` para reconhecer o eco de um envio próprio
quando ele volta pelo webhook (``is_from_me=True``) — sem isso, o GOWA ecoaria
a mensagem de volta e o core salvaria uma bolha "Manual" duplicada. Esse
dicionário não é exposto a plugins (``EventContext``/``FilterContext`` só
trazem handler/plugin_id/plugin_db), então o ``agendamento_retorno`` mantém a
própria cópia (``logic._recently_sent``, escrita nos dois pontos de disparo) e
usa ``filter.message.outgoing`` — o mesmo ponto que o core usa para reconhecer
eco — para descartar antes de virar uma bolha duplicada no painel.
"""

from __future__ import annotations

from . import logic


def drop_own_echo(ctx, value):
    if not isinstance(value, dict):
        return value
    phone = value.get("phone") or ""
    text_ = value.get("text") or ""
    if logic.consume_recent_echo(phone, text_):
        return None
    return value


FILTERS = {
    "filter.message.outgoing": drop_own_echo,
}
