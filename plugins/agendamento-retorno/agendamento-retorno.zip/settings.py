"""Settings declarativas (form auto-gerado no modal "Configurar" do card).

Persistem em ``config`` com prefixo ``plugin.agendamento_retorno.<field>``.
"""

from pydantic import BaseModel, Field


class Settings(BaseModel):
    tolerance_minutes: int = Field(
        default=60,
        ge=0,
        title="Janela de tolerância (minutos)",
        description=(
            "Agendamentos vencidos há MENOS deste tempo ainda são enviados quando o "
            "verificador voltar de um período parado; os mais antigos são marcados como "
            "Expirado (não disparam). 0 = nunca enviar atrasado."
        ),
    )
    retorno_ia_enabled: bool = Field(
        default=True,
        title="Permitir que a IA agende o próprio retorno",
        description=(
            "Libera as ferramentas de IA “agendar_retorno_ia” e "
            "“cancelar_retorno_ia”. Desmarcado, a ferramenta recusa com uma "
            "frase que o modelo entende e a conversa segue normal — nenhum agendamento "
            "novo é criado."
        ),
    )
    retorno_ia_min_lead_minutes: int = Field(
        default=5,
        ge=1,
        le=1440,
        title="Antecedência mínima do retorno da IA (minutos)",
        description="A IA não consegue agendar um retorno mais perto do que isto.",
    )
    retorno_ia_max_horizon_days: int = Field(
        default=30,
        ge=1,
        le=365,
        title="Horizonte máximo do retorno da IA (dias)",
    )
    retorno_ia_max_chain: int = Field(
        default=3,
        ge=1,
        le=10,
        title="Retornos seguidos sem resposta do cliente",
        description=(
            "Depois deste número de retornos da IA sem NENHUMA mensagem do cliente entre "
            "eles, a ferramenta recusa novos agendamentos. Uma resposta do cliente zera a "
            "contagem."
        ),
    )
