"""Verificador de retornos agendados — abre um loop próprio no boot do app.

Não existe "lifecycle"/tarefa supervisionada de plugin no whatsbot simples
(isso é exclusivo do whatsbot-pro): o único jeito de rodar algo periódico é
assinar ``app.startup``/``app.shutdown`` e gerenciar o próprio
``asyncio.Task`` — mesmo padrão do plugin ``monitor_conexao``.
"""

from __future__ import annotations

import asyncio
import logging

from . import logic

logger = logging.getLogger("plugin.agendamento_retorno")

CHECK_INTERVAL_SECONDS = 60.0

# Task de polling. Módulo-level para app.startup criar e app.shutdown cancelar.
_task: "asyncio.Task | None" = None


async def _checker_loop() -> None:
    logger.info("agendamento_retorno: verificador iniciado")
    try:
        while True:
            try:
                summary = await logic.run_due_cycle()
                if summary.get("sent") or summary.get("expired") or summary.get("failed"):
                    logger.info("[AgendamentoRetorno] ciclo: %s", summary)
            except Exception as e:  # noqa: BLE001 — um ciclo com erro não derruba o laço
                logger.warning("[AgendamentoRetorno] ciclo falhou: %s", e)
            await asyncio.sleep(CHECK_INTERVAL_SECONDS)
    except asyncio.CancelledError:
        logger.info("agendamento_retorno: verificador cancelado")
        raise


async def _on_startup(ctx, payload) -> None:
    global _task
    logic.set_handler(ctx.handler)
    if _task and not _task.done():
        return
    _task = asyncio.create_task(_checker_loop())


async def _on_shutdown(ctx, payload) -> None:
    global _task
    if _task and not _task.done():
        _task.cancel()
        try:
            await _task
        except asyncio.CancelledError:
            pass
        except Exception:  # noqa: BLE001
            pass
    _task = None


EVENT_HANDLERS = {
    "app.startup": _on_startup,
    "app.shutdown": _on_shutdown,
}
