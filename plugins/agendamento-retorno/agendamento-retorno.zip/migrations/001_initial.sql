-- Agendamentos de retorno. Uma linha = uma mensagem programada para um contato.
-- Convenções do projeto: timestamps como epoch (DOUBLE PRECISION), sem FK
-- cross-table (contact_id/phone são snapshot solto), prefixo
-- plugin_agendamento_retorno_ obrigatório. INTEGER PRIMARY KEY AUTOINCREMENT
-- vira IDENTITY no Postgres (o migrator do core traduz isso sozinho).
CREATE TABLE IF NOT EXISTS plugin_agendamento_retorno_items (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_id     INTEGER NOT NULL,
    phone          TEXT    NOT NULL,
    contact_name   TEXT    NOT NULL DEFAULT '',
    due_at         DOUBLE PRECISION NOT NULL,          -- instante de disparo (epoch)
    send_mode      TEXT    NOT NULL DEFAULT 'message',  -- 'message' (manual) | 'ia_turn' (a própria IA)
    message_text   TEXT    NOT NULL DEFAULT '',         -- texto literal (manual) ou rótulo (ia_turn)
    briefing       TEXT    NOT NULL DEFAULT '',         -- instrução pra IA seguir (ia_turn)
    status         TEXT    NOT NULL DEFAULT 'agendado', -- agendado|processando|enviado|falhou|expirado|cancelado
    outcome        TEXT    NOT NULL DEFAULT '',
    outcome_reason TEXT    NOT NULL DEFAULT '',
    last_error     TEXT,
    created_by_ia  INTEGER NOT NULL DEFAULT 0,
    chain_depth    INTEGER NOT NULL DEFAULT 0,
    claimed_at     DOUBLE PRECISION,
    created_at     DOUBLE PRECISION NOT NULL,
    updated_at     DOUBLE PRECISION NOT NULL,
    sent_at        DOUBLE PRECISION
);

-- Consulta do verificador (status + vencimento).
CREATE INDEX IF NOT EXISTS plugin_agendamento_retorno_due
    ON plugin_agendamento_retorno_items(status, due_at);

-- Consulta "existe retorno ATIVO da IA para este telefone?" (regra de um por
-- contato) e cálculo da corrente (chain_depth).
CREATE INDEX IF NOT EXISTS plugin_agendamento_retorno_phone_active
    ON plugin_agendamento_retorno_items(phone, send_mode, status);
