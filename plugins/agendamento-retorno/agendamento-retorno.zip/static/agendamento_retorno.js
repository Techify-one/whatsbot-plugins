// Tela do plugin Agendamento de Retorno — Preact + HTM, sem build.
// Duas abas: "Agendar" (form manual, envia a mensagem real na hora marcada) e
// "Lista de Agendamentos" (todos os retornos — manuais e da IA — com status
// ao vivo via WebSocket /ws, evento "agendamento_retorno_changed").
import { h } from 'preact';
import { useEffect, useMemo, useState } from 'preact/hooks';
import htm from 'htm';

const html = htm.bind(h);

function authHeaders(extra = {}) {
  const token = localStorage.getItem('whatsbot_token') || '';
  return token ? { ...extra, Authorization: `Bearer ${token}` } : { ...extra };
}

async function apiFetch(url, init = {}) {
  const headers = authHeaders({ 'Content-Type': 'application/json', ...(init.headers || {}) });
  const res = await fetch(url, { ...init, headers });
  if (res.status === 401) {
    localStorage.removeItem('whatsbot_token');
    window.dispatchEvent(new Event('whatsbot:unauthorized'));
    throw new Error('Não autenticado.');
  }
  return res;
}

const fieldCls =
  'w-full wa-field border border-wa-border rounded px-3 py-2 text-[14px] focus:outline-none focus:border-wa-teal';

const STATUS_LABEL = {
  agendado: 'Agendado',
  processando: 'Processando…',
  enviado: 'Enviado',
  falhou: 'Falhou',
  expirado: 'Expirado',
  cancelado: 'Cancelado',
};

const STATUS_CLS = {
  agendado: 'bg-wa-teal/10 text-wa-teal',
  processando: 'bg-wa-teal/10 text-wa-teal',
  enviado: 'bg-green-100 text-green-700',
  falhou: 'bg-red-500/10 text-red-600',
  expirado: 'bg-amber-100 text-amber-700',
  cancelado: 'bg-wa-hover text-wa-secondary',
};

function StatusBadge({ status }) {
  const cls = STATUS_CLS[status] || 'bg-wa-hover text-wa-secondary';
  return html`<span class=${`text-[11px] px-2 py-0.5 rounded shrink-0 ${cls}`}>${STATUS_LABEL[status] || status}</span>`;
}

function fmtDate(ts) {
  if (!ts) return '—';
  try {
    return new Date(ts * 1000).toLocaleString('pt-BR');
  } catch {
    return '—';
  }
}

// ── Aba Agendar ──────────────────────────────────────────────────────────

function AgendarTab({ apiBase, contacts, onCreated }) {
  const [phone, setPhone] = useState('');
  const [contactName, setContactName] = useState('');
  const [message, setMessage] = useState('');
  const [dueLocal, setDueLocal] = useState('');
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState(null); // { type: 'ok'|'err', text }
  const [showSuggest, setShowSuggest] = useState(false);

  const suggestions = useMemo(() => {
    const q = phone.trim().toLowerCase();
    if (!q || q.length < 2) return [];
    return contacts
      .filter((c) => !c.is_group)
      .filter((c) => (c.phone || '').includes(q) || (c.name || '').toLowerCase().includes(q))
      .slice(0, 8);
  }, [phone, contacts]);

  function pickContact(c) {
    setPhone(c.phone || '');
    setContactName(c.name || '');
    setShowSuggest(false);
  }

  async function submit(e) {
    e.preventDefault();
    setMsg(null);
    if (!phone.trim() || !message.trim() || !dueLocal) {
      setMsg({ type: 'err', text: 'Preencha telefone, mensagem e data/hora.' });
      return;
    }
    const dueAt = new Date(dueLocal).getTime() / 1000;
    if (!Number.isFinite(dueAt)) {
      setMsg({ type: 'err', text: 'Data/hora inválida.' });
      return;
    }
    setSaving(true);
    try {
      const r = await apiFetch(`${apiBase}/items`, {
        method: 'POST',
        body: JSON.stringify({
          phone: phone.trim(),
          contact_name: contactName.trim(),
          message: message.trim(),
          due_at: dueAt,
        }),
      });
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || 'Falha ao agendar.');
      setMsg({ type: 'ok', text: 'Retorno agendado.' });
      setPhone('');
      setContactName('');
      setMessage('');
      setDueLocal('');
      onCreated && onCreated(data.data);
    } catch (err) {
      setMsg({ type: 'err', text: String(err.message || err) });
    } finally {
      setSaving(false);
    }
  }

  return html`
    <form class="space-y-4 max-w-xl" onSubmit=${submit}>
      <div class="relative">
        <label class="block text-wa-text text-[13px] font-medium mb-1">Telefone do contato</label>
        <input
          class=${fieldCls}
          type="text"
          placeholder="Nome ou telefone (ex: 5511999999999)"
          value=${phone}
          onInput=${(e) => { setPhone(e.target.value); setShowSuggest(true); }}
          onFocus=${() => setShowSuggest(true)}
          onBlur=${() => setTimeout(() => setShowSuggest(false), 150)}
        />
        ${showSuggest && suggestions.length > 0 && html`
          <ul class="absolute z-10 mt-1 w-full bg-wa-panel border border-wa-border rounded shadow-lg max-h-56 overflow-y-auto">
            ${suggestions.map((c) => html`
              <li key=${c.phone}>
                <button
                  type="button"
                  class="w-full text-left px-3 py-2 text-[13px] hover:bg-wa-hover text-wa-text"
                  onClick=${() => pickContact(c)}
                >
                  <div class="font-medium">${c.name || c.phone}</div>
                  <div class="text-wa-secondary text-[12px]">${c.phone}</div>
                </button>
              </li>
            `)}
          </ul>
        `}
      </div>

      <div>
        <label class="block text-wa-text text-[13px] font-medium mb-1">Nome (opcional, só pro rótulo na lista)</label>
        <input class=${fieldCls} type="text" placeholder="Nome do contato"
          value=${contactName} onInput=${(e) => setContactName(e.target.value)} />
      </div>

      <div>
        <label class="block text-wa-text text-[13px] font-medium mb-1">Mensagem</label>
        <textarea class=${fieldCls} rows="4"
          placeholder="Texto que será enviado de verdade ao WhatsApp do contato, na hora marcada."
          value=${message} onInput=${(e) => setMessage(e.target.value)}></textarea>
      </div>

      <div>
        <label class="block text-wa-text text-[13px] font-medium mb-1">Data e hora</label>
        <input class=${fieldCls} type="datetime-local"
          value=${dueLocal} onInput=${(e) => setDueLocal(e.target.value)} />
      </div>

      ${msg && html`
        <div class=${'text-[13px] px-3 py-2 rounded ' + (msg.type === 'ok' ? 'bg-wa-teal/10 text-wa-teal' : 'bg-red-500/10 text-red-600')}>
          ${msg.text}
        </div>
      `}

      <button type="submit" disabled=${saving}
        class="bg-wa-teal text-white px-4 py-2 rounded text-[14px] font-medium disabled:opacity-50">
        ${saving ? 'Agendando…' : 'Agendar retorno'}
      </button>
    </form>
  `;
}

// ── Aba Lista ────────────────────────────────────────────────────────────

function ListaTab({ apiBase, items, loading, error, onCancel, onDelete }) {
  if (loading) return html`<div class="text-wa-secondary text-[14px]">Carregando…</div>`;
  if (error) return html`<div class="text-red-600 text-[14px]">Erro: ${error}</div>`;
  if (!items.length) return html`<div class="text-wa-secondary text-[14px]">Nenhum agendamento ainda.</div>`;

  return html`
    <ul class="divide-y divide-wa-border">
      ${items.map((it) => html`
        <li key=${it.id} class="py-3 flex items-start gap-3">
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-2 flex-wrap">
              <span class="text-[14px] font-medium text-wa-text">${it.contact_name || it.phone}</span>
              <${StatusBadge} status=${it.status} />
              <span class="text-[11px] px-2 py-0.5 rounded bg-wa-hover text-wa-secondary shrink-0">
                ${it.send_mode === 'ia_turn' ? 'IA' : 'Manual'}
              </span>
            </div>
            <div class="text-wa-secondary text-[12px] mt-0.5">${it.phone} · ${fmtDate(it.due_at)}</div>
            <div class="text-wa-text text-[13px] mt-1 whitespace-pre-wrap">
              ${it.send_mode === 'ia_turn' ? (it.briefing || '(sem instrução)') : (it.message_text || '')}
            </div>
            ${it.last_error && html`<div class="text-red-600 text-[12px] mt-1">Erro: ${it.last_error}</div>`}
          </div>
          <div class="flex flex-col gap-1 shrink-0">
            ${it.status === 'agendado' && html`
              <button class="text-[12px] text-wa-secondary hover:underline" onClick=${() => onCancel(it.id)}>cancelar</button>
            `}
            <button class="text-[12px] text-red-600 hover:underline" onClick=${() => onDelete(it.id)}>remover</button>
          </div>
        </li>
      `)}
    </ul>
  `;
}

// ── Tela ─────────────────────────────────────────────────────────────────

export default function AgendamentoRetornoScreen({ apiBase = '/api/plugins/agendamento_retorno' } = {}) {
  const [tab, setTab] = useState('agendar');
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [contacts, setContacts] = useState([]);
  const [wsOk, setWsOk] = useState(false);

  async function loadItems() {
    try {
      const r = await apiFetch(`${apiBase}/items`);
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || 'erro');
      setItems(data.data || []);
      setError(null);
    } catch (e) {
      setError(String(e.message || e));
    } finally {
      setLoading(false);
    }
  }

  async function loadContacts() {
    try {
      const r = await apiFetch('/api/contacts?archived=false');
      const data = await r.json();
      if (data.ok) setContacts(data.data || []);
    } catch {
      // autocomplete é conveniência — falha aqui não deve travar a tela
    }
  }

  async function cancelItem(id) {
    try {
      await apiFetch(`${apiBase}/items/${id}/cancel`, { method: 'POST' });
      loadItems();
    } catch (e) {
      setError(String(e.message || e));
    }
  }

  async function deleteItem(id) {
    try {
      await apiFetch(`${apiBase}/items/${id}`, { method: 'DELETE' });
      setItems((prev) => prev.filter((i) => i.id !== id));
    } catch (e) {
      setError(String(e.message || e));
    }
  }

  useEffect(() => {
    loadItems();
    loadContacts();
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${proto}//${location.host}/ws`);
    ws.onopen = () => setWsOk(true);
    ws.onclose = () => setWsOk(false);
    ws.onmessage = (raw) => {
      try {
        const ev = JSON.parse(raw.data);
        if (ev.event === 'agendamento_retorno_changed') {
          loadItems();
        }
      } catch {}
    };
    return () => ws.close();
  }, []);

  const tabCls = (id) =>
    `px-3 py-2 text-[14px] font-medium border-b-2 ${
      tab === id ? 'border-wa-teal text-wa-teal' : 'border-transparent text-wa-secondary hover:text-wa-text'
    }`;

  return html`
    <div class="p-6 max-w-3xl mx-auto">
      <div class="flex items-center gap-2 mb-1">
        <h1 class="text-2xl font-bold text-wa-text">Agendamento de Retorno</h1>
        <span class=${`text-xs px-2 py-0.5 rounded ${wsOk ? 'bg-green-100 text-green-700' : 'bg-wa-hover text-wa-secondary'}`}>
          ${wsOk ? 'ao vivo' : 'offline'}
        </span>
      </div>
      <p class="text-sm text-wa-secondary mb-4">
        Agende uma mensagem para ser enviada automaticamente na hora marcada. A própria IA também
        aprende a marcar o retorno dela quando o cliente pede para ser chamado depois.
      </p>

      <div class="flex border-b border-wa-border mb-4">
        <button class=${tabCls('agendar')} onClick=${() => setTab('agendar')}>Agendar</button>
        <button class=${tabCls('lista')} onClick=${() => setTab('lista')}>Lista de Agendamentos</button>
      </div>

      ${tab === 'agendar'
        ? html`<${AgendarTab} apiBase=${apiBase} contacts=${contacts} onCreated=${() => { loadItems(); setTab('lista'); }} />`
        : html`<${ListaTab} apiBase=${apiBase} items=${items} loading=${loading} error=${error} onCancel=${cancelItem} onDelete=${deleteItem} />`
      }
    </div>
  `;
}
