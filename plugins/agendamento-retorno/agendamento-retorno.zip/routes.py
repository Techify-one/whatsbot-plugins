"""REST do plugin Agendamento de Retorno (mountado em /api/plugins/agendamento_retorno).

Sem RBAC/auditoria — o whatsbot simples não tem esse sistema (é exclusivo do
whatsbot-pro). Shell fino sobre ``logic``, mesmo padrão do plugin ``lembretes``.
"""

from __future__ import annotations

from fastapi import APIRouter
from fastapi.responses import JSONResponse

from . import logic

router = APIRouter()


def _err(msg: str, status: int = 400):
    return JSONResponse({"ok": False, "error": msg}, status_code=status)


@router.get("/items")
async def list_items(status: str | None = None, phone: str | None = None):
    data = logic.list_items(status=status, phone=phone)
    return {"ok": True, "data": data}


@router.post("/items")
async def create_item(body: dict):
    item, err = logic.create_manual_item(
        phone=(body.get("phone") or "").strip(),
        message=(body.get("message") or "").strip(),
        due_at=body.get("due_at"),
        contact_name=(body.get("contact_name") or "").strip() or None,
    )
    if err:
        return _err(err)
    return {"ok": True, "data": item}


@router.post("/items/{item_id}/cancel")
async def cancel_item(item_id: int):
    item, err = logic.cancel_item(item_id)
    if err:
        return _err(err, status=404)
    return {"ok": True, "data": item}


@router.delete("/items/{item_id}")
async def delete_item(item_id: int):
    if not logic.delete_item(item_id):
        return _err("Agendamento não encontrado.", status=404)
    return {"ok": True}
