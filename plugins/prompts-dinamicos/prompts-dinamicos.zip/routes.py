"""REST endpoints do plugin Prompts Dinâmicos (mountados em /api/plugins/prompts_dinamicos)."""

import logging
import time
from typing import Any

from fastapi import APIRouter, HTTPException
from sqlalchemy import text

from plugins.context import broadcast, make_plugin_db

logger = logging.getLogger(__name__)
router = APIRouter()

VALID_MATCH_TYPES = ("contains", "exact", "starts_with")


def _ok(data: Any) -> dict:
    return {"ok": True, "data": data}


def _row_to_dict(row) -> dict:
    if not row:
        return {}
    d = dict(row)
    if "enabled" in d:
        d["enabled"] = bool(d["enabled"])
    return d


def _normalize_match_type(value: Any, default: str = "contains") -> str:
    if value is None:
        return default
    v = str(value).strip().lower()
    if v not in VALID_MATCH_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"match_type inválido (use {', '.join(VALID_MATCH_TYPES)})",
        )
    return v


def _normalize_enabled(value: Any, default: bool = True) -> int:
    if value is None:
        return 1 if default else 0
    if isinstance(value, bool):
        return 1 if value else 0
    if isinstance(value, (int, float)):
        return 1 if int(value) else 0
    s = str(value).strip().lower()
    if s in ("1", "true", "yes", "on"):
        return 1
    if s in ("0", "false", "no", "off"):
        return 0
    raise HTTPException(status_code=400, detail="enabled inválido")


@router.get("/keywords")
async def list_keywords() -> dict:
    with make_plugin_db() as conn:
        rows = conn.execute(
            text(
                "SELECT id, keyword, prompt, match_type, enabled, "
                "       created_at, updated_at "
                "FROM plugin_prompts_dinamicos_keywords "
                "ORDER BY updated_at DESC, id DESC"
            )
        ).mappings().all()
    return _ok([_row_to_dict(r) for r in rows])


@router.post("/keywords")
async def create_keyword(body: dict) -> dict:
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="body inválido")
    keyword = (body.get("keyword") or "").strip()
    prompt = (body.get("prompt") or "").strip()
    if not keyword:
        raise HTTPException(status_code=400, detail="palavra-chave obrigatória")
    if not prompt:
        raise HTTPException(status_code=400, detail="prompt obrigatório")
    match_type = _normalize_match_type(body.get("match_type"), default="contains")
    enabled = _normalize_enabled(body.get("enabled"), default=True)
    now = int(time.time())
    try:
        with make_plugin_db() as conn:
            rid = conn.execute(
                text(
                    "INSERT INTO plugin_prompts_dinamicos_keywords "
                    "(keyword, prompt, match_type, enabled, created_at, updated_at) "
                    "VALUES (:keyword, :prompt, :match_type, :enabled, :created_at, :updated_at) "
                    "RETURNING id"
                ),
                {
                    "keyword": keyword,
                    "prompt": prompt,
                    "match_type": match_type,
                    "enabled": enabled,
                    "created_at": now,
                    "updated_at": now,
                },
            ).scalar_one()
            row = conn.execute(
                text(
                    "SELECT id, keyword, prompt, match_type, enabled, "
                    "       created_at, updated_at "
                    "FROM plugin_prompts_dinamicos_keywords WHERE id = :id"
                ),
                {"id": rid},
            ).mappings().first()
    except HTTPException:
        raise
    except Exception as exc:
        msg = str(exc).lower()
        if "unique" in msg or "duplicate" in msg:
            raise HTTPException(status_code=409, detail="palavra-chave já existe")
        raise

    data = _row_to_dict(row)
    broadcast("plugin_prompts_dinamicos_keyword_changed", data)
    return _ok(data)


@router.put("/keywords/{rid}")
async def update_keyword(rid: int, body: dict) -> dict:
    """Atualização parcial: campos ausentes mantêm o valor atual.

    Aceita: ``keyword``, ``prompt``, ``match_type``, ``enabled``.
    """
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="body inválido")

    with make_plugin_db() as conn:
        current = conn.execute(
            text(
                "SELECT id, keyword, prompt, match_type, enabled "
                "FROM plugin_prompts_dinamicos_keywords WHERE id = :id"
            ),
            {"id": rid},
        ).mappings().first()
        if not current:
            raise HTTPException(status_code=404, detail="não encontrado")

        keyword = body.get("keyword", current["keyword"])
        if not isinstance(keyword, str):
            raise HTTPException(status_code=400, detail="keyword inválida")
        keyword = keyword.strip()
        if not keyword:
            raise HTTPException(status_code=400, detail="palavra-chave obrigatória")

        prompt = body.get("prompt", current["prompt"])
        if not isinstance(prompt, str):
            raise HTTPException(status_code=400, detail="prompt inválido")
        prompt = prompt.strip()
        if not prompt:
            raise HTTPException(status_code=400, detail="prompt obrigatório")

        match_type = (
            _normalize_match_type(body["match_type"], default=current["match_type"])
            if "match_type" in body
            else current["match_type"]
        )
        enabled = (
            _normalize_enabled(body["enabled"], default=bool(current["enabled"]))
            if "enabled" in body
            else int(current["enabled"])
        )
        now = int(time.time())

        try:
            conn.execute(
                text(
                    "UPDATE plugin_prompts_dinamicos_keywords "
                    "SET keyword = :keyword, prompt = :prompt, "
                    "    match_type = :match_type, enabled = :enabled, "
                    "    updated_at = :updated_at "
                    "WHERE id = :id"
                ),
                {
                    "keyword": keyword,
                    "prompt": prompt,
                    "match_type": match_type,
                    "enabled": enabled,
                    "updated_at": now,
                    "id": rid,
                },
            )
        except Exception as exc:
            msg = str(exc).lower()
            if "unique" in msg or "duplicate" in msg:
                raise HTTPException(status_code=409, detail="palavra-chave já existe")
            raise

        row = conn.execute(
            text(
                "SELECT id, keyword, prompt, match_type, enabled, "
                "       created_at, updated_at "
                "FROM plugin_prompts_dinamicos_keywords WHERE id = :id"
            ),
            {"id": rid},
        ).mappings().first()

    data = _row_to_dict(row)
    broadcast("plugin_prompts_dinamicos_keyword_changed", data)
    return _ok(data)


@router.delete("/keywords/{rid}")
async def delete_keyword(rid: int) -> dict:
    with make_plugin_db() as conn:
        existing = conn.execute(
            text(
                "SELECT id FROM plugin_prompts_dinamicos_keywords WHERE id = :id"
            ),
            {"id": rid},
        ).first()
        if not existing:
            raise HTTPException(status_code=404, detail="não encontrado")
        conn.execute(
            text(
                "DELETE FROM plugin_prompts_dinamicos_active WHERE keyword_id = :id"
            ),
            {"id": rid},
        )
        conn.execute(
            text(
                "DELETE FROM plugin_prompts_dinamicos_keywords WHERE id = :id"
            ),
            {"id": rid},
        )
    broadcast("plugin_prompts_dinamicos_keyword_deleted", {"id": rid})
    return _ok({"id": rid, "deleted": True})


@router.get("/active")
async def list_active() -> dict:
    """Lista contatos com prompt dinâmico ativo no momento."""
    with make_plugin_db() as conn:
        rows = conn.execute(
            text(
                "SELECT a.phone, a.keyword_id, a.activated_at, "
                "       k.keyword, k.prompt, k.enabled AS keyword_enabled, "
                "       c.name AS contact_name "
                "FROM plugin_prompts_dinamicos_active a "
                "JOIN plugin_prompts_dinamicos_keywords k ON k.id = a.keyword_id "
                "LEFT JOIN contacts c ON c.phone = a.phone "
                "ORDER BY a.activated_at DESC"
            )
        ).mappings().all()
    items = []
    for r in rows:
        d = dict(r)
        d["keyword_enabled"] = bool(d.get("keyword_enabled"))
        items.append(d)
    return _ok(items)


@router.delete("/active/{phone}")
async def reset_active(phone: str) -> dict:
    """Remove a ativação para um contato (volta ao prompt global)."""
    with make_plugin_db() as conn:
        conn.execute(
            text("DELETE FROM plugin_prompts_dinamicos_active WHERE phone = :phone"),
            {"phone": phone},
        )
    broadcast("plugin_prompts_dinamicos_active_cleared", {"phone": phone})
    return _ok({"phone": phone, "cleared": True})
