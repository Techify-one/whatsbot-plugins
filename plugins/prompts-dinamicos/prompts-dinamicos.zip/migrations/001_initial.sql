CREATE TABLE IF NOT EXISTS plugin_prompts_dinamicos_keywords (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword    TEXT    NOT NULL UNIQUE,
    prompt     TEXT    NOT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_prompts_dinamicos_keywords_updated
    ON plugin_prompts_dinamicos_keywords(updated_at DESC);

CREATE TABLE IF NOT EXISTS plugin_prompts_dinamicos_active (
    phone        TEXT PRIMARY KEY,
    keyword_id   INTEGER NOT NULL,
    activated_at REAL    NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_prompts_dinamicos_active_keyword
    ON plugin_prompts_dinamicos_active(keyword_id);
