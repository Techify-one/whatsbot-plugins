ALTER TABLE plugin_prompts_dinamicos_keywords
    ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1;

ALTER TABLE plugin_prompts_dinamicos_keywords
    ADD COLUMN match_type TEXT NOT NULL DEFAULT 'contains';
