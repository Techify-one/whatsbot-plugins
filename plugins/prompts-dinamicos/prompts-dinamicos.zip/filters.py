"""Filters do plugin Prompts Dinâmicos.

Comportamento:

* ``filter.message.before_save`` — detecta se o texto inbound contém alguma
  palavra-chave cadastrada (case-insensitive). Se sim, registra/atualiza a
  ativação para o phone do contato. Conversas em grupo são ignoradas.
* ``filter.system_prompt`` — quando há ativação para o phone, substitui
  COMPLETAMENTE o system prompt global pelo prompt da palavra-chave.
* ``filter.llm.messages`` — quando há ativação, mantém apenas o system
  prompt (já substituído) + mensagens com ``ts >= activated_at``. Isso
  descarta histórico anterior à ativação sem apagar nada do banco.
"""

import logging
import time
from typing import Any

from sqlalchemy import text

from plugins.context import broadcast, make_plugin_db
from db.engine import get_engine
from db.tables import contacts as contacts_table, messages as messages_table
from sqlalchemy import select

logger = logging.getLogger(__name__)


VALID_MATCH_TYPES = ("contains", "exact", "starts_with")


def _matches(text_lower: str, kw_lower: str, match_type: str) -> bool:
    if not kw_lower or not text_lower:
        return False
    if match_type == "exact":
        return text_lower.strip() == kw_lower
    if match_type == "starts_with":
        return text_lower.lstrip().startswith(kw_lower)
    return kw_lower in text_lower


def _find_matching_keyword(text_value: str) -> dict[str, Any] | None:
    """Carrega keywords ATIVAS e devolve a primeira que casa segundo seu ``match_type``.

    Ordem: keywords mais longas primeiro (mais específicas vencem). ``exact``
    e ``starts_with`` comparam contra o texto normalizado (lstrip/strip).
    """
    if not text_value:
        return None
    lowered = text_value.lower()
    with make_plugin_db() as conn:
        rows = conn.execute(
            text(
                "SELECT id, keyword, prompt, match_type, enabled "
                "FROM plugin_prompts_dinamicos_keywords "
                "WHERE enabled = 1 "
                "ORDER BY LENGTH(keyword) DESC, id ASC"
            )
        ).mappings().all()
    for row in rows:
        kw = (row.get("keyword") or "").strip().lower()
        match_type = (row.get("match_type") or "contains").lower()
        if match_type not in VALID_MATCH_TYPES:
            match_type = "contains"
        if _matches(lowered, kw, match_type):
            return dict(row)
    return None


def _activate(phone: str, keyword_id: int) -> float:
    now = time.time()
    with make_plugin_db() as conn:
        existing = conn.execute(
            text(
                "SELECT phone FROM plugin_prompts_dinamicos_active WHERE phone = :phone"
            ),
            {"phone": phone},
        ).first()
        if existing:
            conn.execute(
                text(
                    "UPDATE plugin_prompts_dinamicos_active "
                    "SET keyword_id = :kid, activated_at = :ts WHERE phone = :phone"
                ),
                {"kid": keyword_id, "ts": now, "phone": phone},
            )
        else:
            conn.execute(
                text(
                    "INSERT INTO plugin_prompts_dinamicos_active "
                    "(phone, keyword_id, activated_at) VALUES (:phone, :kid, :ts)"
                ),
                {"phone": phone, "kid": keyword_id, "ts": now},
            )
    return now


def _get_active(phone: str) -> dict[str, Any] | None:
    """Devolve a ativação atual do contato — ignora se a keyword foi desativada."""
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT a.phone, a.keyword_id, a.activated_at, "
                "       k.keyword, k.prompt, k.enabled "
                "FROM plugin_prompts_dinamicos_active a "
                "JOIN plugin_prompts_dinamicos_keywords k ON k.id = a.keyword_id "
                "WHERE a.phone = :phone AND k.enabled = 1"
            ),
            {"phone": phone},
        ).mappings().first()
    return dict(row) if row else None


def on_message_before_save(ctx, value: dict | None) -> dict | None:
    """Detecta keyword na mensagem inbound e ativa o prompt para o phone."""
    if not value or not isinstance(value, dict):
        return value
    if value.get("is_group"):
        return value
    if value.get("is_from_me"):
        return value
    body = (value.get("text") or "").strip()
    if not body:
        return value
    match = _find_matching_keyword(body)
    if not match:
        return value
    phone = value.get("phone") or ctx.extras.get("phone")
    if not phone:
        return value
    activated_at = _activate(phone, int(match["id"]))
    logger.info(
        "[prompts_dinamicos] keyword '%s' (id=%s) ativada para phone=%s",
        match["keyword"], match["id"], phone,
    )
    try:
        broadcast(
            "plugin_prompts_dinamicos_activated",
            {
                "phone": phone,
                "keyword_id": int(match["id"]),
                "keyword": match["keyword"],
                "activated_at": activated_at,
            },
        )
    except Exception:
        pass
    return value


def on_system_prompt(ctx, value: str | None) -> str | None:
    """Substitui o system prompt quando há ativação para o phone."""
    phone = ctx.extras.get("phone")
    if not phone:
        return value
    active = _get_active(phone)
    if not active:
        return value
    prompt = (active.get("prompt") or "").strip()
    if not prompt:
        return value
    return prompt


def on_llm_messages(ctx, value: list[dict] | None) -> list[dict] | None:
    """Filtra mensagens, mantendo apenas as posteriores à ativação."""
    if not value:
        return value
    phone = ctx.extras.get("phone")
    if not phone:
        return value
    active = _get_active(phone)
    if not active:
        return value
    activated_at = float(active.get("activated_at") or 0.0)
    if activated_at <= 0:
        return value

    # Busca contact_id do contato para filtrar mensagens por ts no DB.
    try:
        with get_engine().connect() as conn:
            row = conn.execute(
                select(contacts_table.c.id).where(contacts_table.c.phone == phone)
            ).first()
            if not row:
                return value
            contact_id = int(row[0])

            excluded = ("transcription", "tool_call", "system_notice")
            rows = conn.execute(
                select(messages_table)
                .where(
                    (messages_table.c.contact_id == contact_id)
                    & (~messages_table.c.role.in_(excluded))
                    & (
                        (messages_table.c.status.is_(None))
                        | (messages_table.c.status != "failed")
                    )
                    & (messages_table.c.ts >= activated_at)
                )
                .order_by(messages_table.c.ts.asc())
            ).mappings().all()
    except Exception as exc:
        logger.warning(
            "[prompts_dinamicos] falha ao re-ler mensagens do DB: %s — devolvendo value original",
            exc,
        )
        return value

    rebuilt: list[dict] = []
    if value and isinstance(value[0], dict) and value[0].get("role") == "system":
        rebuilt.append(value[0])

    for m in rows:
        role = m.get("role")
        if role == "private_note":
            rebuilt.append({
                "role": "user",
                "content": f"[Nota privada do operador]: {m.get('content') or ''}",
            })
            continue
        # Para simplificar, descartamos mídia binária — só texto/descrição já
        # transcrita. Caso a transcrição não tenha acontecido ainda, o texto
        # original (caption etc) vai.
        content = m.get("content") or ""
        if role in ("user", "assistant"):
            rebuilt.append({"role": role, "content": content})

    return rebuilt


FILTERS = {
    "filter.message.before_save": (on_message_before_save, 50),
    "filter.system_prompt": on_system_prompt,
    "filter.llm.messages": on_llm_messages,
}
