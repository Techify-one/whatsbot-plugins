// Tela do plugin Prompts Dinâmicos — Preact + HTM, sem build.
// CRUD de palavras-chave + prompt, com toggle de enabled e seleção de match_type.
// Atualização em tempo real via /ws.
import { h } from 'preact';
import { useEffect, useMemo, useState } from 'preact/hooks';
import htm from 'htm';

const html = htm.bind(h);

const MATCH_LABELS = {
  contains: 'Contém',
  exact: 'Exata',
  starts_with: 'Começa com',
};

const MATCH_DESCRIPTIONS = {
  contains: 'Dispara se a palavra-chave aparecer em qualquer parte da mensagem.',
  exact: 'Dispara apenas se a mensagem (trim) for igual à palavra-chave.',
  starts_with: 'Dispara se a mensagem começar pela palavra-chave.',
};

function authHeaders(extra = {}) {
  const token = localStorage.getItem('whatsbot_token') || '';
  return token ? { ...extra, Authorization: `Bearer ${token}` } : { ...extra };
}

async function apiFetch(url, init = {}) {
  const headers = authHeaders({
    ...(init.body ? { 'Content-Type': 'application/json' } : {}),
    ...(init.headers || {}),
  });
  const res = await fetch(url, { ...init, headers });
  if (res.status === 401) {
    localStorage.removeItem('whatsbot_token');
    window.dispatchEvent(new Event('whatsbot:unauthorized'));
    throw new Error('Não autenticado.');
  }
  return res;
}

function formatTs(ts) {
  if (!ts) return '';
  const ms = ts > 1e12 ? ts : ts * 1000;
  return new Date(ms).toLocaleString();
}

function KeywordForm({ initial, onSubmit, onCancel, busy }) {
  const [keyword, setKeyword] = useState(initial?.keyword || '');
  const [prompt, setPrompt] = useState(initial?.prompt || '');
  const [matchType, setMatchType] = useState(initial?.match_type || 'contains');
  const [enabled, setEnabled] = useState(
    initial && typeof initial.enabled === 'boolean' ? initial.enabled : true
  );

  function submit(e) {
    e.preventDefault();
    const k = keyword.trim();
    const p = prompt.trim();
    if (!k || !p) return;
    onSubmit({ keyword: k, prompt: p, match_type: matchType, enabled });
  }

  return html`
    <form onSubmit=${submit} class="border rounded p-4 bg-white space-y-3 mb-6">
      <div>
        <label class="block text-sm font-medium mb-1">Palavra-chave</label>
        <input
          type="text"
          class="w-full border rounded px-3 py-2 text-sm"
          placeholder="ex: vendas"
          value=${keyword}
          onInput=${(e) => setKeyword(e.currentTarget.value)}
          required
        />
      </div>
      <div>
        <label class="block text-sm font-medium mb-1">Tipo de match</label>
        <select
          class="w-full border rounded px-3 py-2 text-sm bg-white"
          value=${matchType}
          onChange=${(e) => setMatchType(e.currentTarget.value)}
        >
          <option value="contains">Contém — palavra em qualquer parte</option>
          <option value="exact">Exata — mensagem inteira é igual</option>
          <option value="starts_with">Começa com — mensagem inicia pela palavra</option>
        </select>
        <p class="text-xs text-gray-500 mt-1">${MATCH_DESCRIPTIONS[matchType]} Case-insensitive em todos os modos.</p>
      </div>
      <div>
        <label class="block text-sm font-medium mb-1">Prompt</label>
        <textarea
          class="w-full border rounded px-3 py-2 text-sm font-mono"
          rows="10"
          placeholder="Escreva o system prompt completo que o agente deve usar quando essa palavra-chave for detectada..."
          value=${prompt}
          onInput=${(e) => setPrompt(e.currentTarget.value)}
          required
        ></textarea>
      </div>
      <div>
        <label class="inline-flex items-center gap-2 text-sm cursor-pointer select-none">
          <input
            type="checkbox"
            class="rounded"
            checked=${enabled}
            onChange=${(e) => setEnabled(e.currentTarget.checked)}
          />
          <span>Ativo (palavras-chave desativadas ficam guardadas mas não disparam)</span>
        </label>
      </div>
      <div class="flex gap-2 justify-end">
        ${onCancel && html`
          <button
            type="button"
            class="px-3 py-1.5 text-sm border rounded hover:bg-gray-50"
            onClick=${onCancel}
            disabled=${busy}
          >Cancelar</button>
        `}
        <button
          type="submit"
          class="px-3 py-1.5 text-sm rounded bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50"
          disabled=${busy}
        >${initial ? 'Salvar alterações' : 'Adicionar prompt'}</button>
      </div>
    </form>
  `;
}

export default function PromptsDinamicosScreen({ apiBase = '/api/plugins/prompts_dinamicos' } = {}) {
  const [items, setItems] = useState([]);
  const [active, setActive] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [wsOk, setWsOk] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState('');

  async function load() {
    try {
      const [kr, ar] = await Promise.all([
        apiFetch(`${apiBase}/keywords`),
        apiFetch(`${apiBase}/active`),
      ]);
      const kd = await kr.json();
      const ad = await ar.json();
      if (!kd.ok) throw new Error(kd.error || 'erro ao carregar palavras-chave');
      if (!ad.ok) throw new Error(ad.error || 'erro ao carregar ativações');
      setItems(kd.data || []);
      setActive(ad.data || []);
      setError(null);
    } catch (e) {
      setError(String(e.message || e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${proto}//${location.host}/ws`);
    ws.onopen = () => setWsOk(true);
    ws.onclose = () => setWsOk(false);
    ws.onmessage = (msg) => {
      try {
        const ev = JSON.parse(msg.data);
        if (!ev || !ev.event) return;
        if (
          ev.event === 'plugin_prompts_dinamicos_keyword_changed' ||
          ev.event === 'plugin_prompts_dinamicos_keyword_deleted' ||
          ev.event === 'plugin_prompts_dinamicos_activated' ||
          ev.event === 'plugin_prompts_dinamicos_active_cleared'
        ) {
          load();
        }
      } catch {}
    };
    return () => ws.close();
  }, []);

  async function save(payload) {
    setBusy(true);
    try {
      const url = editing ? `${apiBase}/keywords/${editing.id}` : `${apiBase}/keywords`;
      const method = editing ? 'PUT' : 'POST';
      const res = await apiFetch(url, {
        method,
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.detail || data.error || `HTTP ${res.status}`);
      }
      setShowForm(false);
      setEditing(null);
      await load();
    } catch (e) {
      alert('Erro ao salvar: ' + String(e.message || e));
    } finally {
      setBusy(false);
    }
  }

  async function toggle(item) {
    try {
      const res = await apiFetch(`${apiBase}/keywords/${item.id}`, {
        method: 'PUT',
        body: JSON.stringify({ enabled: !item.enabled }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.detail || data.error || `HTTP ${res.status}`);
      }
      await load();
    } catch (e) {
      alert('Erro: ' + String(e.message || e));
    }
  }

  async function remove(item) {
    if (!confirm(`Remover a palavra-chave "${item.keyword}"?`)) return;
    try {
      const res = await apiFetch(`${apiBase}/keywords/${item.id}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.detail || data.error || `HTTP ${res.status}`);
      }
      await load();
    } catch (e) {
      alert('Erro ao remover: ' + String(e.message || e));
    }
  }

  async function clearActive(item) {
    if (!confirm(`Desativar prompt para ${item.contact_name || item.phone}?`)) return;
    try {
      const res = await apiFetch(`${apiBase}/active/${encodeURIComponent(item.phone)}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.detail || data.error || `HTTP ${res.status}`);
      }
      await load();
    } catch (e) {
      alert('Erro ao desativar: ' + String(e.message || e));
    }
  }

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return items;
    return items.filter(
      (i) =>
        (i.keyword || '').toLowerCase().includes(q) ||
        (i.prompt || '').toLowerCase().includes(q)
    );
  }, [items, search]);

  return html`
    <div class="p-6 max-w-5xl mx-auto">
      <div class="flex items-center gap-2 mb-1">
        <h1 class="text-2xl font-bold">Prompts Dinâmicos</h1>
        <span class=${`text-xs px-2 py-0.5 rounded ${wsOk ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
          ${wsOk ? 'ao vivo' : 'offline'}
        </span>
      </div>
      <p class="text-sm text-gray-500 mb-4">
        Cadastre palavras-chave que, quando enviadas pelo contato em uma conversa
        individual, substituem o system prompt do agente. Palavras-chave desativadas
        ficam guardadas mas não disparam.
      </p>

      ${error && html`<div class="text-red-600 mb-3">Erro: ${error}</div>`}

      <div class="flex items-center justify-between gap-3 mb-3">
        <input
          type="search"
          class="border rounded px-3 py-1.5 text-sm w-64"
          placeholder="Buscar palavra-chave ou prompt..."
          value=${search}
          onInput=${(e) => setSearch(e.currentTarget.value)}
        />
        ${!showForm && !editing && html`
          <button
            class="px-3 py-1.5 text-sm rounded bg-blue-600 text-white hover:bg-blue-700"
            onClick=${() => { setEditing(null); setShowForm(true); }}
          >+ Novo prompt</button>
        `}
      </div>

      ${(showForm || editing) && html`
        <${KeywordForm}
          initial=${editing}
          busy=${busy}
          onSubmit=${save}
          onCancel=${() => { setShowForm(false); setEditing(null); }}
        />
      `}

      ${loading
        ? html`<div>Carregando…</div>`
        : filtered.length === 0
          ? html`<div class="text-gray-500 border rounded p-6 text-center bg-white">
              ${items.length === 0
                ? 'Nenhuma palavra-chave cadastrada ainda.'
                : 'Nenhuma palavra-chave bate com a busca.'}
            </div>`
          : html`
            <div class="border rounded overflow-hidden bg-white">
              <table class="w-full text-sm">
                <thead class="bg-gray-50 text-gray-600 text-xs uppercase">
                  <tr>
                    <th class="text-left px-3 py-2 w-20">Ativo</th>
                    <th class="text-left px-3 py-2 w-44">Palavra-chave</th>
                    <th class="text-left px-3 py-2 w-28">Match</th>
                    <th class="text-left px-3 py-2">Prompt</th>
                    <th class="text-left px-3 py-2 w-36">Atualizado</th>
                    <th class="text-right px-3 py-2 w-32">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  ${filtered.map((it) => html`
                    <tr key=${it.id} class=${`border-t align-top ${it.enabled ? '' : 'bg-gray-50 text-gray-400'}`}>
                      <td class="px-3 py-2">
                        <button
                          class=${`text-xs px-2 py-0.5 rounded font-medium ${it.enabled ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-gray-200 text-gray-600 hover:bg-gray-300'}`}
                          onClick=${() => toggle(it)}
                          title=${it.enabled ? 'Clique para desativar' : 'Clique para ativar'}
                        >${it.enabled ? 'ativo' : 'inativo'}</button>
                      </td>
                      <td class="px-3 py-2 font-medium">${it.keyword}</td>
                      <td class="px-3 py-2">
                        <span class="text-xs px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                          ${MATCH_LABELS[it.match_type] || it.match_type}
                        </span>
                      </td>
                      <td class="px-3 py-2">
                        <div class="text-xs whitespace-pre-wrap line-clamp-3 max-w-2xl">
                          ${it.prompt}
                        </div>
                      </td>
                      <td class="px-3 py-2 text-xs">${formatTs(it.updated_at)}</td>
                      <td class="px-3 py-2 text-right whitespace-nowrap">
                        <button
                          class="text-xs text-blue-600 hover:underline mr-3"
                          onClick=${() => { setEditing(it); setShowForm(false); }}
                        >editar</button>
                        <button
                          class="text-xs text-red-600 hover:underline"
                          onClick=${() => remove(it)}
                        >remover</button>
                      </td>
                    </tr>
                  `)}
                </tbody>
              </table>
            </div>
          `
      }

      <h2 class="text-lg font-semibold mt-8 mb-2">Contatos com prompt ativo</h2>
      <p class="text-xs text-gray-500 mb-2">
        Contatos para os quais o agente está usando um prompt dinâmico em vez do prompt global.
      </p>
      ${active.length === 0
        ? html`<div class="text-gray-500 border rounded p-4 text-center bg-white text-sm">
            Nenhum contato com prompt dinâmico ativo no momento.
          </div>`
        : html`
          <div class="border rounded overflow-hidden bg-white">
            <table class="w-full text-sm">
              <thead class="bg-gray-50 text-gray-600 text-xs uppercase">
                <tr>
                  <th class="text-left px-3 py-2">Contato</th>
                  <th class="text-left px-3 py-2 w-48">Palavra-chave</th>
                  <th class="text-left px-3 py-2 w-44">Ativado em</th>
                  <th class="text-right px-3 py-2 w-32">Ações</th>
                </tr>
              </thead>
              <tbody>
                ${active.map((it) => html`
                  <tr key=${it.phone} class="border-t">
                    <td class="px-3 py-2">${it.contact_name || it.phone}</td>
                    <td class="px-3 py-2">
                      ${it.keyword}
                      ${it.keyword_enabled === false && html`
                        <span class="text-xs ml-2 px-2 py-0.5 rounded bg-yellow-100 text-yellow-700">
                          keyword desativada
                        </span>
                      `}
                    </td>
                    <td class="px-3 py-2 text-xs text-gray-500">${formatTs(it.activated_at)}</td>
                    <td class="px-3 py-2 text-right">
                      <button
                        class="text-xs text-red-600 hover:underline"
                        onClick=${() => clearActive(it)}
                      >desativar</button>
                    </td>
                  </tr>
                `)}
              </tbody>
            </table>
          </div>
        `
      }
    </div>
  `;
}
