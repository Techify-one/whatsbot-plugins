"""Plugin Google Agenda — conector genérico de Google Calendar (Service Account)."""
