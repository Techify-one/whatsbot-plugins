"""Tools de LLM do plugin Google Agenda.

Permitem que a IA agende, consulte disponibilidade, liste e cancele eventos na
ÚNICA agenda vinculada (o plugin trava em uma só). O ``calendar_key`` é
resolvido automaticamente — a IA não precisa saber o ID da agenda.

Datas/horas: a IA passa o horário local (ex: ``2026-06-20T14:00:00``); o fuso
configurado nas opções do plugin é aplicado. Para criar/cancelar, o LLM
normalmente lista primeiro (``agenda_listar_eventos``) para descobrir o
``evento_id``.

Registradas via ``CORE_TOOLS`` + ``entry.tools: tools`` no manifest — chegam
junto com o plugin ao importar; ficam ativas quando o plugin é ativado.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from . import api
from .service import GoogleCalendarError

logger = logging.getLogger(__name__)


# ── Helpers ──────────────────────────────────────────────────────────────────


def _tz() -> str:
    return api._tz()


def _linked_calendar_key() -> str | None:
    """calendar_key da única agenda vinculada, ou None se não houver."""
    cals = api.list_calendars()
    return cals[0]["calendar_key"] if cals else None


def _guard() -> str | None:
    """Retorna uma mensagem de erro se a integração não estiver pronta."""
    if not api.is_available():
        return (
            "A integração com o Google Agenda não está disponível. Verifique se "
            "a conta de serviço foi configurada e o plugin está ativo nas "
            "configurações do plugin Google Agenda."
        )
    if _linked_calendar_key() is None:
        return (
            "Nenhuma agenda do Google está vinculada ainda. Vincule uma agenda "
            "na tela de configuração do plugin Google Agenda antes de agendar."
        )
    return None


def _parse_iso(value: str) -> datetime:
    """Parse flexível de ISO 8601 (aceita 'Z' e ausência de segundos)."""
    return datetime.fromisoformat(value.strip().replace("Z", "+00:00"))


def _to_local_naive(value: str) -> str:
    """Normaliza para wall-clock local sem offset (o api adiciona o timeZone)."""
    dt = _parse_iso(value)
    if dt.tzinfo is not None:
        dt = dt.replace(tzinfo=None)
    return dt.isoformat()


def _to_rfc3339(value: str) -> str:
    """RFC3339 com timezone — exigido por freeBusy/events.list do Google."""
    dt = _parse_iso(value)
    if dt.tzinfo is None:
        try:
            from zoneinfo import ZoneInfo

            dt = dt.replace(tzinfo=ZoneInfo(_tz()))
        except Exception:  # tzdata ausente (ex: EXE Windows) — assume UTC
            dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


def _fmt_dt(value: str) -> str:
    """Formata um datetime ISO para exibição (dd/mm HH:MM) no fuso local.

    Respostas do Google (freeBusy/events.list) vêm em UTC/com offset; converte
    para o fuso configurado antes de exibir, senão a hora mostrada fica errada.
    """
    try:
        dt = _parse_iso(value)
    except (ValueError, TypeError):
        return value
    if dt.tzinfo is not None:
        try:
            from zoneinfo import ZoneInfo

            dt = dt.astimezone(ZoneInfo(_tz()))
        except Exception:  # tzdata ausente — exibe como veio
            pass
    return dt.strftime("%d/%m/%Y %H:%M")


def _requester(ctx) -> str:
    contact = getattr(ctx, "contact", None)
    if contact is None:
        return ""
    info = getattr(contact, "info", {}) or {}
    name = info.get("name") or getattr(contact, "group_name", "") or ""
    phone = getattr(contact, "phone", "") or ""
    if name and phone:
        return f"{name} ({phone})"
    return name or phone


# ── Tool: criar evento ────────────────────────────────────────────────────────

CRIAR_EVENTO_TOOL = {
    "type": "function",
    "display_label": "Agenda — criar evento",
    "function": {
        "name": "agenda_criar_evento",
        "description": (
            "Cria um compromisso/agendamento na agenda do Google. Use quando o "
            "usuário pedir para marcar, agendar ou reservar um horário. Informe "
            "o horário em formato ISO 8601 no fuso local (ex: 2026-06-20T14:00:00). "
            "Se o fim não for dado, use a duração em minutos (padrão 60)."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "titulo": {
                    "type": "string",
                    "description": "Título curto do compromisso (ex: 'Consulta com João').",
                },
                "inicio": {
                    "type": "string",
                    "description": "Início em ISO 8601, horário local. Ex: 2026-06-20T14:00:00",
                },
                "fim": {
                    "type": "string",
                    "description": "Fim em ISO 8601 (opcional). Se ausente, usa duracao_min.",
                },
                "duracao_min": {
                    "type": "integer",
                    "description": "Duração em minutos quando 'fim' não é informado. Padrão 60.",
                },
                "descricao": {
                    "type": "string",
                    "description": "Detalhes adicionais do compromisso (opcional).",
                },
            },
            "required": ["titulo", "inicio"],
        },
    },
}


def execute_criar_evento(ctx, args: dict) -> str | None:
    err = _guard()
    if err:
        return err
    args = args or {}
    titulo = (args.get("titulo") or "").strip()
    inicio_raw = (args.get("inicio") or "").strip()
    if not titulo or not inicio_raw:
        return "Para agendar preciso ao menos do título e do horário de início."

    try:
        start_iso = _to_local_naive(inicio_raw)
        fim_raw = (args.get("fim") or "").strip()
        if fim_raw:
            end_iso = _to_local_naive(fim_raw)
        else:
            dur = int(args.get("duracao_min") or 60)
            end_iso = (_parse_iso(start_iso) + timedelta(minutes=dur)).isoformat()
    except (ValueError, TypeError):
        return "Não entendi o horário. Use ISO 8601, ex: 2026-06-20T14:00:00."

    descricao = (args.get("descricao") or "").strip()
    requester = _requester(ctx)
    if requester:
        descricao = (descricao + f"\n\nAgendado via WhatsApp por {requester}.").strip()

    key = _linked_calendar_key()
    try:
        result = api.create_event(
            key,
            summary=titulo,
            start_iso=start_iso,
            end_iso=end_iso,
            description=descricao,
            source_plugin="google_agenda",
            source_ref=getattr(getattr(ctx, "contact", None), "phone", "") or "tool",
        )
    except GoogleCalendarError as e:
        logger.warning("[google_agenda] criar evento falhou: %s", e)
        return f"Não consegui criar o evento no Google: {e}"

    return (
        f"Compromisso criado: '{titulo}' em {_fmt_dt(start_iso)}–{_fmt_dt(end_iso)}. "
        f"ID do evento: {result.get('google_event_id', '?')}."
    )


# ── Tool: verificar disponibilidade ───────────────────────────────────────────

DISPONIBILIDADE_TOOL = {
    "type": "function",
    "display_label": "Agenda — verificar disponibilidade",
    "function": {
        "name": "agenda_verificar_disponibilidade",
        "description": (
            "Verifica se um intervalo de tempo está livre ou ocupado na agenda. "
            "Use antes de confirmar um horário ao usuário. Horários em ISO 8601 "
            "no fuso local."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "inicio": {"type": "string", "description": "Início do intervalo (ISO 8601)."},
                "fim": {"type": "string", "description": "Fim do intervalo (ISO 8601)."},
            },
            "required": ["inicio", "fim"],
        },
    },
}


def execute_verificar_disponibilidade(ctx, args: dict) -> str | None:
    err = _guard()
    if err:
        return err
    args = args or {}
    try:
        tmin = _to_rfc3339(args.get("inicio") or "")
        tmax = _to_rfc3339(args.get("fim") or "")
    except (ValueError, TypeError):
        return "Não entendi o intervalo. Use ISO 8601, ex: 2026-06-20T14:00:00."

    key = _linked_calendar_key()
    try:
        busy_map = api.freebusy([key], tmin, tmax)
    except GoogleCalendarError as e:
        return f"Não consegui consultar a disponibilidade: {e}"

    busy = busy_map.get(key, [])
    if not busy:
        return f"O intervalo {_fmt_dt(tmin)}–{_fmt_dt(tmax)} está livre."
    blocos = "; ".join(f"{_fmt_dt(s)}–{_fmt_dt(e)}" for s, e in busy)
    return f"Já há compromisso(s) nesse intervalo: {blocos}."


# ── Tool: listar eventos ──────────────────────────────────────────────────────

LISTAR_EVENTOS_TOOL = {
    "type": "function",
    "display_label": "Agenda — listar eventos",
    "function": {
        "name": "agenda_listar_eventos",
        "description": (
            "Lista os compromissos da agenda num período. Use para saber o que "
            "está marcado ou para obter o ID de um evento antes de cancelar. "
            "Horários em ISO 8601 no fuso local."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "inicio": {"type": "string", "description": "Início do período (ISO 8601)."},
                "fim": {"type": "string", "description": "Fim do período (ISO 8601)."},
            },
            "required": ["inicio", "fim"],
        },
    },
}


def execute_listar_eventos(ctx, args: dict) -> str | None:
    err = _guard()
    if err:
        return err
    args = args or {}
    try:
        tmin = _to_rfc3339(args.get("inicio") or "")
        tmax = _to_rfc3339(args.get("fim") or "")
    except (ValueError, TypeError):
        return "Não entendi o período. Use ISO 8601, ex: 2026-06-20T00:00:00."

    key = _linked_calendar_key()
    try:
        items = api.list_events(key, tmin, tmax)
    except GoogleCalendarError as e:
        return f"Não consegui listar os eventos: {e}"

    if not items:
        return f"Nenhum compromisso entre {_fmt_dt(tmin)} e {_fmt_dt(tmax)}."

    linhas = []
    for ev in items[:25]:
        start = (ev.get("start") or {}).get("dateTime") or (ev.get("start") or {}).get("date") or "?"
        titulo = ev.get("summary") or "(sem título)"
        linhas.append(f"- {_fmt_dt(start)} · {titulo} · ID: {ev.get('id', '?')}")
    extra = "" if len(items) <= 25 else f"\n(+{len(items) - 25} evento(s) não exibidos)"
    return "Compromissos:\n" + "\n".join(linhas) + extra


# ── Tool: cancelar evento ─────────────────────────────────────────────────────

CANCELAR_EVENTO_TOOL = {
    "type": "function",
    "display_label": "Agenda — cancelar evento",
    "function": {
        "name": "agenda_cancelar_evento",
        "description": (
            "Cancela/apaga um compromisso da agenda pelo ID do evento. Obtenha o "
            "ID antes com agenda_listar_eventos. Use só quando o usuário pedir "
            "explicitamente para cancelar/desmarcar."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "evento_id": {
                    "type": "string",
                    "description": "ID do evento no Google (campo 'ID' retornado por agenda_listar_eventos).",
                },
            },
            "required": ["evento_id"],
        },
    },
}


def execute_cancelar_evento(ctx, args: dict) -> str | None:
    err = _guard()
    if err:
        return err
    evento_id = ((args or {}).get("evento_id") or "").strip()
    if not evento_id:
        return "Preciso do ID do evento para cancelar. Liste os eventos primeiro."

    key = _linked_calendar_key()
    try:
        api.delete_event(key, evento_id)
    except GoogleCalendarError as e:
        return f"Não consegui cancelar o evento: {e}"
    return f"Compromisso cancelado (ID {evento_id})."


CORE_TOOLS = [
    (CRIAR_EVENTO_TOOL, execute_criar_evento),
    (DISPONIBILIDADE_TOOL, execute_verificar_disponibilidade),
    (LISTAR_EVENTOS_TOOL, execute_listar_eventos),
    (CANCELAR_EVENTO_TOOL, execute_cancelar_evento),
]
