"""Sync reverso — polling incremental do Google (events.list + syncToken).

Detecta mudanças feitas **fora** do sistema (alguém apagou/moveu um evento
direto no Google) e emite ``google_agenda.event.changed`` no bus de eventos para
os consumidores reagirem.

Mecânica (por calendário):
  - 1ª passada: ``events.list`` completo (paginado), guarda ``nextSyncToken``.
  - Passadas seguintes: ``events.list?syncToken=...`` (incremental). Em
    ``410 Gone`` o token expirou → descarta e refaz a passada completa.
  - Para cada item retornado, compara com o espelho ``plugin_google_agenda_events``
    (por ``google_event_id``) e decide ``deleted`` / ``updated``.

Em localhost o polling é o mecanismo (sem URL pública). Push em tempo real
(``events.watch``) fica para depois (precisa de domínio público).
"""

from __future__ import annotations

import logging
import time
from datetime import datetime

from sqlalchemy import text

from plugins.context import broadcast, make_plugin_db
from plugins.events import emit_with_filter_sync

from .api import _svc
from .service import GoogleCalendarError

logger = logging.getLogger(__name__)

CHANGED_EVENT = "google_agenda.event.changed"


def _event_times(item: dict) -> tuple[str, str]:
    start = item.get("start", {}) or {}
    end = item.get("end", {}) or {}
    s = start.get("dateTime") or start.get("date") or ""
    e = end.get("dateTime") or end.get("date") or ""
    return s, e


def _parse_iso(value: str):
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def _same_instant(a: str, b: str) -> bool:
    """Compara dois timestamps ISO pelo INSTANTE, não pelo texto.

    O Google normaliza o offset para o fuso do calendário (ex: gravamos
    ``...+00:00`` e ele devolve ``...-03:00``) — mesmo instante, texto diferente.
    Comparar string daria falso ``movido``. Para eventos de dia inteiro
    (``date`` sem hora) cai na comparação textual.
    """
    if a == b:
        return True
    da, db = _parse_iso(a), _parse_iso(b)
    if da is not None and db is not None:
        return da == db
    return False


def _emit_change(
    calendar_key: str,
    mirror_row: dict,
    change: str,
    old: dict | None,
    new: dict | None,
) -> None:
    payload = {
        "calendar_key": calendar_key,
        "google_event_id": mirror_row["google_event_id"],
        "change": change,
        "source_plugin": mirror_row.get("source_plugin") or None,
        "source_ref": mirror_row.get("source_ref") or None,
        "old": old,
        "new": new,
    }
    logger.info(
        "[google_agenda] mudança externa: %s evento=%s key=%s",
        change, payload["google_event_id"], calendar_key,
    )
    emit_with_filter_sync(CHANGED_EVENT, payload)
    broadcast("google_agenda_event_changed", payload)


def _list_page(gcal_id: str, sync_token: str | None, page_token: str | None) -> dict:
    """Uma página do events.list. Com syncToken só passa pageToken (filtros são
    lembrados pelo token)."""
    if sync_token:
        params: dict = {"syncToken": sync_token, "maxResults": 250}
    else:
        # 1ª passada (full sync): a partir de agora — só nos interessam eventos
        # futuros que o sistema possa ter espelhado.
        params = {
            "showDeleted": "true",
            "singleEvents": "true",
            "maxResults": 250,
            "timeMin": _now_iso(),
        }
    if page_token:
        params["pageToken"] = page_token
    return _svc().list_events(gcal_id, params)


def _now_iso() -> str:
    # RFC3339 em UTC (Z). Aqui é runtime normal (não script de workflow).
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _poll_calendar(cal: dict) -> int:
    """Faz o sync incremental de UM calendário. Retorna nº de mudanças emitidas."""
    cal_row_id = cal["id"]
    calendar_key = cal["calendar_key"]
    gcal_id = cal["google_calendar_id"]
    sync_token = cal.get("sync_token")

    # Carrega o espelho do calendário (por google_event_id).
    with make_plugin_db() as conn:
        mirror_rows = conn.execute(
            text(
                "SELECT google_event_id, source_plugin, source_ref, summary, "
                " start_iso, end_iso, status, etag "
                "FROM plugin_google_agenda_events WHERE calendar_id = :cid"
            ),
            {"cid": cal_row_id},
        ).mappings().all()
    mirror = {r["google_event_id"]: dict(r) for r in mirror_rows}

    items: list[dict] = []
    next_sync_token: str | None = None
    page_token: str | None = None

    while True:
        try:
            resp = _list_page(gcal_id, sync_token, page_token)
        except GoogleCalendarError as e:
            if e.status_code == 410 and sync_token:
                # Token expirou → resync completo.
                logger.info("[google_agenda] syncToken expirou (410) key=%s — resync", calendar_key)
                sync_token = None
                page_token = None
                items = []
                _save_sync_token(cal_row_id, None)
                continue
            raise
        items.extend(resp.get("items", []))
        page_token = resp.get("nextPageToken")
        if page_token:
            continue
        next_sync_token = resp.get("nextSyncToken")
        break

    emitted = 0
    now = time.time()
    for item in items:
        gid = item.get("id")
        if not gid:
            continue
        row = mirror.get(gid)
        if not row:
            continue  # evento não é nosso (não espelhado) — ignora
        status = item.get("status")
        if status == "cancelled":
            if row["status"] != "deleted":
                _mark_deleted(cal_row_id, gid, now)
                _emit_change(
                    calendar_key, row, "deleted",
                    old={"start_iso": row["start_iso"], "end_iso": row["end_iso"]},
                    new=None,
                )
                emitted += 1
            continue
        new_start, new_end = _event_times(item)
        if not (_same_instant(new_start, row["start_iso"]) and _same_instant(new_end, row["end_iso"])):
            _update_mirror_times(cal_row_id, gid, new_start, new_end, item.get("etag", ""), now)
            _emit_change(
                calendar_key, row, "updated",
                old={"start_iso": row["start_iso"], "end_iso": row["end_iso"]},
                new={"start_iso": new_start, "end_iso": new_end},
            )
            emitted += 1
        elif item.get("etag") and item["etag"] != row["etag"]:
            _update_mirror_etag(cal_row_id, gid, item["etag"], now)

    if next_sync_token and next_sync_token != cal.get("sync_token"):
        _save_sync_token(cal_row_id, next_sync_token)

    return emitted


def _save_sync_token(cal_row_id: int, token: str | None) -> None:
    with make_plugin_db() as conn:
        conn.execute(
            text("UPDATE plugin_google_agenda_calendars SET sync_token = :t WHERE id = :id"),
            {"t": token, "id": cal_row_id},
        )


def _mark_deleted(cal_row_id: int, gid: str, ts: float) -> None:
    with make_plugin_db() as conn:
        conn.execute(
            text(
                "UPDATE plugin_google_agenda_events SET status = 'deleted', updated_at = :ts "
                "WHERE calendar_id = :cid AND google_event_id = :gid"
            ),
            {"ts": ts, "cid": cal_row_id, "gid": gid},
        )


def _update_mirror_times(
    cal_row_id: int, gid: str, start: str, end: str, etag: str, ts: float
) -> None:
    with make_plugin_db() as conn:
        conn.execute(
            text(
                "UPDATE plugin_google_agenda_events "
                "SET start_iso = :st, end_iso = :en, etag = :etag, status = 'active', "
                " updated_at = :ts "
                "WHERE calendar_id = :cid AND google_event_id = :gid"
            ),
            {"st": start, "en": end, "etag": etag, "ts": ts, "cid": cal_row_id, "gid": gid},
        )


def _update_mirror_etag(cal_row_id: int, gid: str, etag: str, ts: float) -> None:
    with make_plugin_db() as conn:
        conn.execute(
            text(
                "UPDATE plugin_google_agenda_events SET etag = :etag, updated_at = :ts "
                "WHERE calendar_id = :cid AND google_event_id = :gid"
            ),
            {"etag": etag, "ts": ts, "cid": cal_row_id, "gid": gid},
        )


def poll_all() -> int:
    """Faz o poll de todos os calendários ativos. Síncrono — rodar em thread.

    Retorna o total de mudanças emitidas. Erros por calendário são isolados
    (logam e seguem) para um calendário quebrado não travar os outros.
    """
    with make_plugin_db() as conn:
        cals = conn.execute(
            text(
                "SELECT id, calendar_key, google_calendar_id, sync_token "
                "FROM plugin_google_agenda_calendars WHERE ativo = 1"
            )
        ).mappings().all()

    total = 0
    for cal in cals:
        try:
            total += _poll_calendar(dict(cal))
        except Exception:
            logger.exception("[google_agenda] poll falhou para key=%s", cal["calendar_key"])
    return total
