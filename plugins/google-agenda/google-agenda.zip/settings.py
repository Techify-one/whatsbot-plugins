"""Settings declarativas do plugin Google Agenda (Pydantic Valves).

Persistidas em ``config`` com prefixo ``plugin.google_agenda.``.

O JSON do Service Account NÃO fica aqui — é colado/subido pela tela de
configuração do plugin e persistido em ``service_account_json`` via endpoint
dedicado (``POST /api/plugins/google_agenda/credentials``). Estas settings são
apenas as opções de comportamento.
"""

from pydantic import BaseModel, Field


class Settings(BaseModel):
    share_email: str = Field(
        default="",
        title="E-mail para compartilhar (leitura)",
        description=(
            "E-mail Google opcional. Toda agenda criada pelo sistema é "
            "compartilhada automaticamente com este e-mail como leitor "
            "(ver todos os detalhes). Deixe vazio para não compartilhar."
        ),
    )
    timezone: str = Field(
        default="America/Sao_Paulo",
        title="Fuso horário",
        description=(
            "Fuso aplicado às agendas criadas e aos eventos espelhados. "
            "Formato IANA, ex: America/Sao_Paulo."
        ),
    )
    sync_intervalo_seg: int = Field(
        default=120,
        ge=30,
        le=3600,
        title="Intervalo do sync reverso (segundos)",
        description=(
            "De quanto em quanto tempo o plugin consulta o Google em busca "
            "de eventos apagados/movidos fora do sistema. Menor = detecta "
            "mais rápido, porém mais chamadas à API."
        ),
    )
    enabled: bool = Field(
        default=True,
        title="Integração ativa",
        description=(
            "Liga/desliga a integração sem desinstalar o plugin. Desligado, "
            "is_available() retorna False e os consumidores degradam "
            "graciosamente."
        ),
    )
