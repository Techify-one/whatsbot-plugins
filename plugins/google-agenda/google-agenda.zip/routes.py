"""REST endpoints do plugin Google Agenda (montados em /api/plugins/google_agenda).

O plugin vincula UMA agenda só. As rotas travam em no máximo um calendário ativo:
você pode CRIAR uma agenda nova (dona = Service Account, compartilhada com o
usuário) ou CONECTAR uma agenda já existente — basta o usuário compartilhar a
agenda dele com o e-mail da Service Account (sem precisar caçar o ID).

* ``GET  /health`` — autentica e lista os calendários acessíveis (smoke test).
* ``GET  /service-account-info`` — e-mail da Service Account (p/ compartilhar).
* ``GET  /calendars`` — lista o calendário conectado.
* ``POST /calendars/create`` — cria a agenda e compartilha (limite: 1 ativa).
* ``POST /calendars/link-existing`` — conecta a agenda principal do usuário
  pelo e-mail dele (precisa estar compartilhada com a Service Account).
* ``POST /calendars/register`` — avançado: registra por ID de calendário cru.
* ``POST /calendars/{id}/test`` — testa acesso (freebusy de hoje).
* ``POST /calendars/{id}/share`` — compartilha avulso.
* ``DELETE /calendars/{id}`` — desativa o vínculo (``?google=true`` apaga no Google).
* Endpoints ``/test/*`` — exercícios manuais de evento/freebusy/poll.
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text

from db.repositories import config_repo

from plugins.context import make_plugin_db

from .service import CONFIG_PREFIX, GoogleCalendarError

logger = logging.getLogger(__name__)

router = APIRouter()


def _ok(data) -> dict:
    return {"ok": True, "data": data}


def _calendar_key_by_id(cal_id: int) -> str:
    with make_plugin_db() as conn:
        row = conn.execute(
            text(
                "SELECT calendar_key FROM plugin_google_agenda_calendars "
                "WHERE id = :id AND ativo = 1"
            ),
            {"id": cal_id},
        ).first()
    if not row:
        raise HTTPException(status_code=404, detail="Calendário não encontrado")
    return str(row[0])


def _ensure_no_active_calendar() -> None:
    """O plugin trava em UMA agenda. Levanta 400 se já houver uma ativa."""
    from . import api

    if api.active_calendar_count() >= 1:
        raise HTTPException(
            status_code=400,
            detail="Já existe uma agenda vinculada. Remova-a antes de vincular outra.",
        )


# ── Health / smoke test ─────────────────────────────────────────────────────


@router.get("/health")
async def health() -> dict:
    from .api import _svc

    try:
        detail = await asyncio.to_thread(lambda: _svc().smoke_test())
        return {"ok": True, "detail": detail}
    except GoogleCalendarError as e:
        return {"ok": False, "detail": str(e)}
    except Exception as e:  # google-auth ausente, etc.
        logger.exception("[google_agenda] health falhou")
        return {"ok": False, "detail": f"{type(e).__name__}: {e}"}


@router.get("/service-account-info")
async def service_account_info() -> dict:
    """E-mail da Service Account — é o que o usuário adiciona ao compartilhamento."""
    from . import api

    email = await asyncio.to_thread(api.service_account_email)
    return _ok({"email": email, "configured": bool(email)})


# ── Credenciais (Service Account JSON) ──────────────────────────────────────


def _read_credentials_meta() -> dict:
    """Resumo seguro do JSON salvo — nunca expõe a private_key."""
    raw = (config_repo.get(CONFIG_PREFIX + "service_account_json") or "").strip()
    if not raw:
        return {"configured": False, "client_email": "", "project_id": ""}
    try:
        info = json.loads(raw)
    except json.JSONDecodeError:
        return {"configured": True, "valid": False, "client_email": "", "project_id": ""}
    return {
        "configured": True,
        "valid": info.get("type") == "service_account",
        "client_email": str(info.get("client_email") or ""),
        "project_id": str(info.get("project_id") or ""),
    }


@router.get("/credentials")
async def get_credentials() -> dict:
    """Estado do Service Account salvo (sem expor a chave privada)."""
    return _ok(await asyncio.to_thread(_read_credentials_meta))


class CredentialsBody(BaseModel):
    content: str = Field(min_length=1, description="Conteúdo bruto do .json do Service Account")


@router.post("/credentials")
async def set_credentials(body: CredentialsBody) -> dict:
    """Valida e salva o JSON do Service Account (colado ou subido) no banco.

    O frontend manda o texto cru do arquivo — paste e upload usam a mesma rota
    (o upload é lido client-side e enviado como ``content``).
    """
    raw = body.content.strip()
    try:
        info = json.loads(raw)
    except json.JSONDecodeError as e:
        raise HTTPException(status_code=400, detail=f"JSON inválido: {e}")
    if not isinstance(info, dict) or info.get("type") != "service_account":
        raise HTTPException(
            status_code=400,
            detail='O arquivo não é de uma Service Account (esperado "type": "service_account").',
        )
    if not info.get("client_email") or not info.get("private_key"):
        raise HTTPException(
            status_code=400,
            detail="JSON incompleto: faltam client_email/private_key.",
        )

    def _persist() -> None:
        config_repo.set(CONFIG_PREFIX + "service_account_json", raw)

    await asyncio.to_thread(_persist)

    # descarta credenciais em cache para a próxima chamada recarregar
    from . import api

    await asyncio.to_thread(api.reset_service)
    return _ok(
        {
            "configured": True,
            "client_email": str(info.get("client_email") or ""),
            "project_id": str(info.get("project_id") or ""),
        }
    )


@router.delete("/credentials")
async def delete_credentials() -> dict:
    """Remove o Service Account salvo."""

    def _clear() -> None:
        config_repo.set(CONFIG_PREFIX + "service_account_json", "")

    await asyncio.to_thread(_clear)
    from . import api

    await asyncio.to_thread(api.reset_service)
    return _ok({"configured": False})


# ── Calendários ─────────────────────────────────────────────────────────────


@router.get("/calendars")
async def list_calendars() -> dict:
    from . import api

    data = await asyncio.to_thread(api.list_calendars)
    return _ok(data)


class CreateCalendarBody(BaseModel):
    display_name: str = Field(min_length=1)
    owner_email: str = ""
    calendar_key: str = ""


@router.post("/calendars/create")
async def create_calendar(body: CreateCalendarBody) -> dict:
    from . import api
    from .service import _config

    await asyncio.to_thread(_ensure_no_active_calendar)

    if not await asyncio.to_thread(api.is_available):
        raise HTTPException(status_code=400, detail="Integração indisponível (Service Account não configurado ou plugin desligado).")

    share = (_config("share_email") or "").strip()
    readers = [share] if share else []
    try:
        result = await asyncio.to_thread(
            lambda: api.create_calendar(
                body.display_name,
                body.owner_email.strip(),
                reader_emails=readers,
                calendar_key=body.calendar_key.strip(),
            )
        )
    except GoogleCalendarError as e:
        raise HTTPException(status_code=502, detail=str(e))
    return _ok(result)


class LinkExistingBody(BaseModel):
    owner_email: str = Field(min_length=3)
    display_name: str = ""


@router.post("/calendars/link-existing")
async def link_existing(body: LinkExistingBody) -> dict:
    """Conecta a agenda PRINCIPAL do usuário usando o e-mail dele como ID.

    O usuário precisa ter compartilhado a agenda dele com a Service Account.
    Antes de registrar, validamos o acesso via freeBusy e damos um erro claro
    caso o compartilhamento ainda não tenha sido feito.
    """
    from . import api

    await asyncio.to_thread(_ensure_no_active_calendar)

    if not await asyncio.to_thread(api.is_available):
        raise HTTPException(status_code=400, detail="Integração indisponível (Service Account não configurado ou plugin desligado).")

    email = body.owner_email.strip()
    name = body.display_name.strip() or email

    now = datetime.now(timezone.utc)
    tmin = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    tmax = (now + timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        resp = await asyncio.to_thread(lambda: api._svc().freebusy([email], tmin, tmax))
    except GoogleCalendarError as e:
        raise HTTPException(status_code=502, detail=f"Falha ao validar acesso: {e}")

    cal = (resp.get("calendars") or {}).get(email, {})
    if cal.get("errors"):
        reason = (cal["errors"][0] or {}).get("reason", "desconhecido")
        raise HTTPException(
            status_code=400,
            detail=(
                f"A conta de serviço ainda não tem acesso à agenda de {email} "
                f"(motivo: {reason}). Compartilhe a agenda com o e-mail da conta "
                "de serviço e tente novamente."
            ),
        )

    result = await asyncio.to_thread(lambda: api.register_calendar(email, name, email))
    return _ok(result)


class RegisterCalendarBody(BaseModel):
    google_calendar_id: str = Field(min_length=1)
    display_name: str = ""
    owner_email: str = ""
    calendar_key: str = ""


@router.post("/calendars/register")
async def register_calendar(body: RegisterCalendarBody) -> dict:
    from . import api

    await asyncio.to_thread(_ensure_no_active_calendar)

    result = await asyncio.to_thread(
        lambda: api.register_calendar(
            body.google_calendar_id.strip(),
            body.display_name.strip(),
            body.owner_email.strip(),
            body.calendar_key.strip(),
        )
    )
    return _ok(result)


@router.post("/calendars/{cal_id}/test")
async def test_calendar(cal_id: int) -> dict:
    from . import api

    key = await asyncio.to_thread(_calendar_key_by_id, cal_id)
    now = datetime.now(timezone.utc)
    tmin = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    tmax = (now + timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        busy = await asyncio.to_thread(lambda: api.freebusy([key], tmin, tmax))
        return {"ok": True, "detail": {"calendar_key": key, "busy": busy.get(key, [])}}
    except GoogleCalendarError as e:
        return {"ok": False, "detail": str(e)}


class ShareBody(BaseModel):
    email: str = Field(min_length=3)
    role: str = "reader"


@router.post("/calendars/{cal_id}/share")
async def share_calendar(cal_id: int, body: ShareBody) -> dict:
    from . import api

    key = await asyncio.to_thread(_calendar_key_by_id, cal_id)
    try:
        await asyncio.to_thread(lambda: api.share_calendar(key, body.email.strip(), body.role))
    except GoogleCalendarError as e:
        raise HTTPException(status_code=502, detail=str(e))
    return _ok({"shared": body.email, "role": body.role})


@router.delete("/calendars/{cal_id}")
async def delete_calendar(cal_id: int, google: bool = Query(default=False)) -> dict:
    from . import api

    key = await asyncio.to_thread(_calendar_key_by_id, cal_id)
    try:
        await asyncio.to_thread(lambda: api.delete_calendar(key, delete_in_google=google))
    except GoogleCalendarError as e:
        raise HTTPException(status_code=502, detail=str(e))
    return _ok({"deleted": key, "google": google})


# ── Endpoints de teste manual ───────────────────────────────────────────────


class TestEventBody(BaseModel):
    calendar_key: str
    summary: str = "Teste WhatsBot"
    start_iso: str
    end_iso: str
    description: str = ""


@router.post("/test/event")
async def test_create_event(body: TestEventBody) -> dict:
    from . import api

    try:
        result = await asyncio.to_thread(
            lambda: api.create_event(
                body.calendar_key,
                summary=body.summary,
                start_iso=body.start_iso,
                end_iso=body.end_iso,
                description=body.description,
                source_plugin="google_agenda_test",
                source_ref="manual",
            )
        )
    except GoogleCalendarError as e:
        raise HTTPException(status_code=502, detail=str(e))
    return _ok(result)


@router.delete("/test/event")
async def test_delete_event(
    calendar_key: str = Query(...), google_event_id: str = Query(...)
) -> dict:
    from . import api

    try:
        await asyncio.to_thread(lambda: api.delete_event(calendar_key, google_event_id))
    except GoogleCalendarError as e:
        raise HTTPException(status_code=502, detail=str(e))
    return _ok({"deleted": google_event_id})


class FreeBusyBody(BaseModel):
    calendar_keys: list[str]
    time_min_iso: str
    time_max_iso: str


@router.post("/test/freebusy")
async def test_freebusy(body: FreeBusyBody) -> dict:
    from . import api

    try:
        result = await asyncio.to_thread(
            lambda: api.freebusy(body.calendar_keys, body.time_min_iso, body.time_max_iso)
        )
    except GoogleCalendarError as e:
        raise HTTPException(status_code=502, detail=str(e))
    # tuplas viram listas no JSON
    return _ok({k: [list(t) for t in v] for k, v in result.items()})


@router.post("/test/poll")
async def test_poll() -> dict:
    from . import sync

    emitted = await asyncio.to_thread(sync.poll_all)
    return _ok({"emitted": emitted})
