"""Google Calendar via Service Account — auth (google-auth) + REST (httpx).

Decisão: usamos só ``google-auth`` (assina o JWT local e troca por access
token) e ``httpx`` para todas as chamadas REST. NÃO dependemos de ``requests``
nem de ``google-api-python-client`` — mais leve no PyInstaller.

Para evitar puxar ``requests`` (que é o transport default do
``google.auth.transport.requests``), plugamos um transport próprio em cima do
httpx (``_HttpxRequest``) que satisfaz a interface ``google.auth.transport``.

Resolução do Service Account: fonte única — o JSON colado/subido na tela de
configuração do plugin, persistido em ``plugin.google_agenda.service_account_json``.
"""

from __future__ import annotations

import json
import logging
import threading
from typing import Any
from urllib.parse import quote

import httpx
from google.auth.transport import Request as _AuthRequest
from google.auth.transport import Response as _AuthResponse

from db.repositories import config_repo

logger = logging.getLogger(__name__)

CALENDAR_API_BASE = "https://www.googleapis.com/calendar/v3"
SCOPES = ["https://www.googleapis.com/auth/calendar"]
CONFIG_PREFIX = "plugin.google_agenda."


def _config(key: str, default: Any = None) -> Any:
    return config_repo.get(CONFIG_PREFIX + key, default)


class GoogleCalendarError(RuntimeError):
    """Erro de auth/HTTP do Google. ``status_code`` ajuda a tratar 410 Gone."""

    def __init__(self, message: str, status_code: int | None = None, payload: Any = None):
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload


# ── Transport httpx para o google-auth (evita dependência de requests) ──────


class _HttpxAuthResponse(_AuthResponse):
    def __init__(self, resp: httpx.Response):
        self._resp = resp

    @property
    def status(self) -> int:
        return self._resp.status_code

    @property
    def headers(self):
        return self._resp.headers

    @property
    def data(self) -> bytes:
        return self._resp.content


class _HttpxAuthRequest(_AuthRequest):
    """Adapter chamável usado pelo ``creds.refresh`` para bater no token endpoint."""

    def __call__(self, url, method="GET", body=None, headers=None, timeout=None, **kwargs):
        resp = httpx.request(
            method, url, content=body, headers=headers, timeout=timeout or 60.0
        )
        return _HttpxAuthResponse(resp)


# ── Carga do Service Account ────────────────────────────────────────────────


def load_service_account_info() -> dict:
    """Lê o JSON do Service Account salvo no banco. Levanta em falha.

    Fonte única: ``plugin.google_agenda.service_account_json`` — preenchido
    colando ou subindo o arquivo .json na tela de configuração do plugin.
    """
    content = (_config("service_account_json") or "").strip()
    if not content:
        raise GoogleCalendarError(
            "Service Account não configurado. Cole ou suba o arquivo .json na "
            "tela de configuração do plugin Google Agenda."
        )
    try:
        info = json.loads(content)
    except json.JSONDecodeError as e:
        raise GoogleCalendarError(f"JSON do Service Account inválido: {e}") from e
    if not isinstance(info, dict) or info.get("type") != "service_account":
        raise GoogleCalendarError(
            "O JSON salvo não parece ser de uma Service Account "
            '(esperado "type": "service_account").'
        )
    return info


# ── Service ─────────────────────────────────────────────────────────────────


class GoogleCalendarService:
    """Cliente REST do Google Calendar autenticado via Service Account.

    Mantém as credenciais em cache; ``creds.refresh`` renova o token quando
    expira. ``reset()`` força recarregar (usado quando as Settings mudam).
    """

    def __init__(self) -> None:
        self._creds = None
        self._lock = threading.Lock()

    # -- auth -----------------------------------------------------------------

    def reset(self) -> None:
        with self._lock:
            self._creds = None

    def _credentials(self):
        from google.oauth2 import service_account

        with self._lock:
            if self._creds is None:
                info = load_service_account_info()
                self._creds = service_account.Credentials.from_service_account_info(
                    info, scopes=SCOPES
                )
            return self._creds

    def _access_token(self) -> str:
        creds = self._credentials()
        with self._lock:
            if not creds.valid:
                creds.refresh(_HttpxAuthRequest())
            return creds.token

    # -- HTTP -----------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict | None = None,
        json_body: dict | None = None,
    ) -> Any:
        token = self._access_token()
        url = CALENDAR_API_BASE + path
        headers = {"Authorization": f"Bearer {token}"}
        try:
            resp = httpx.request(
                method, url, params=params, json=json_body, headers=headers, timeout=30.0
            )
        except httpx.HTTPError as e:
            raise GoogleCalendarError(f"falha de rede ao chamar o Google: {e}") from e

        if resp.status_code == 204:
            return None
        if resp.status_code >= 400:
            detail = self._error_detail(resp)
            raise GoogleCalendarError(
                f"Google API {resp.status_code}: {detail}",
                status_code=resp.status_code,
                payload=detail,
            )
        if not resp.content:
            return None
        return resp.json()

    @staticmethod
    def _error_detail(resp: httpx.Response) -> str:
        try:
            data = resp.json()
            err = data.get("error", {})
            if isinstance(err, dict):
                return err.get("message", resp.text)
            return str(err)
        except Exception:
            return resp.text

    @staticmethod
    def _cid(calendar_id: str) -> str:
        # IDs de calendário contêm @ e precisam ser url-encoded no path.
        return quote(calendar_id, safe="")

    # -- Calendários ----------------------------------------------------------

    def list_calendar_list(self) -> list[dict]:
        data = self._request("GET", "/users/me/calendarList")
        return (data or {}).get("items", [])

    def create_calendar(self, summary: str, timezone: str) -> dict:
        return self._request(
            "POST", "/calendars", json_body={"summary": summary, "timeZone": timezone}
        )

    def delete_calendar(self, calendar_id: str) -> None:
        self._request("DELETE", f"/calendars/{self._cid(calendar_id)}")

    def insert_acl(self, calendar_id: str, email: str, role: str) -> dict:
        body = {"role": role, "scope": {"type": "user", "value": email}}
        return self._request(
            "POST", f"/calendars/{self._cid(calendar_id)}/acl", json_body=body
        )

    # -- Eventos --------------------------------------------------------------

    def insert_event(self, calendar_id: str, body: dict) -> dict:
        return self._request(
            "POST", f"/calendars/{self._cid(calendar_id)}/events", json_body=body
        )

    def patch_event(self, calendar_id: str, event_id: str, body: dict) -> dict:
        return self._request(
            "PATCH",
            f"/calendars/{self._cid(calendar_id)}/events/{quote(event_id, safe='')}",
            json_body=body,
        )

    def get_event(self, calendar_id: str, event_id: str) -> dict | None:
        return self._request(
            "GET",
            f"/calendars/{self._cid(calendar_id)}/events/{quote(event_id, safe='')}",
        )

    def delete_event(self, calendar_id: str, event_id: str) -> None:
        self._request(
            "DELETE",
            f"/calendars/{self._cid(calendar_id)}/events/{quote(event_id, safe='')}",
        )

    def list_events(self, calendar_id: str, params: dict) -> dict:
        """Retorna a resposta crua (com ``items``/``nextSyncToken``/``nextPageToken``)."""
        return self._request(
            "GET", f"/calendars/{self._cid(calendar_id)}/events", params=params
        ) or {}

    def freebusy(self, calendar_ids: list[str], time_min: str, time_max: str) -> dict:
        body = {
            "timeMin": time_min,
            "timeMax": time_max,
            "items": [{"id": cid} for cid in calendar_ids],
        }
        return self._request("POST", "/freeBusy", json_body=body) or {}

    # -- Smoke test -----------------------------------------------------------

    def smoke_test(self) -> dict:
        """Autentica e lista os calendários acessíveis pela Service Account."""
        items = self.list_calendar_list()
        cals = [
            {
                "id": it.get("id"),
                "summary": it.get("summary"),
                "accessRole": it.get("accessRole"),
                "primary": it.get("primary", False),
            }
            for it in items
        ]
        return {"calendars": cals, "count": len(cals)}
