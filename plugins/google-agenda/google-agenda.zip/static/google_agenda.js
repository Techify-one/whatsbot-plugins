// Tela do plugin Google Agenda — Preact + HTM, sem build.
// Vincula UMA agenda do Google Calendar (via Service Account):
//  - criar uma agenda nova (dona = Service Account, compartilhada com o usuário); ou
//  - conectar uma agenda existente: o usuário compartilha a agenda dele com o
//    e-mail da Service Account e informa o próprio e-mail aqui.
// Mostra o status do health (auth) e mudanças externas em tempo real via WebSocket.
import { h } from 'preact';
import { useEffect, useState } from 'preact/hooks';
import htm from 'htm';

const html = htm.bind(h);

function authHeaders(extra = {}) {
  const token = localStorage.getItem('whatsbot_token') || '';
  return token ? { ...extra, Authorization: `Bearer ${token}` } : { ...extra };
}

async function apiFetch(url, init = {}) {
  const headers = authHeaders(init.headers || {});
  const res = await fetch(url, { ...init, headers });
  if (res.status === 401) {
    localStorage.removeItem('whatsbot_token');
    window.dispatchEvent(new Event('whatsbot:unauthorized'));
    throw new Error('Não autenticado.');
  }
  return res;
}

function shareMailto(saEmail, ownerEmail) {
  const subject = encodeURIComponent('Compartilhar sua Google Agenda');
  const body = encodeURIComponent(
    'Olá!\n\n' +
    'Para integrarmos sua agenda do Google, compartilhe-a com esta conta de serviço:\n\n' +
    saEmail + '\n\n' +
    'Passo a passo:\n' +
    '1. Abra o Google Agenda (calendar.google.com) no computador.\n' +
    '2. Passe o mouse sobre a sua agenda (menu lateral) e clique nos três pontinhos > "Configurações e compartilhamento".\n' +
    '3. Em "Compartilhar com pessoas específicas", clique em "Adicionar pessoas".\n' +
    '4. Cole o e-mail acima e escolha a permissão "Fazer alterações nos eventos".\n' +
    '5. Clique em "Enviar".\n\n' +
    'Depois é só confirmar. Obrigado!'
  );
  return `mailto:${ownerEmail || ''}?subject=${subject}&body=${body}`;
}

export default function GoogleAgendaScreen({ apiBase = '/api/plugins/google_agenda' } = {}) {
  const [calendars, setCalendars] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [health, setHealth] = useState(null);
  const [saEmail, setSaEmail] = useState('');
  const [mode, setMode] = useState('create'); // 'create' | 'link'
  // criar
  const [nome, setNome] = useState('');
  const [ownerCreate, setOwnerCreate] = useState('');
  // conectar existente
  const [ownerLink, setOwnerLink] = useState('');
  const [nomeLink, setNomeLink] = useState('');
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState(null);
  const [copied, setCopied] = useState(false);
  const [wsOk, setWsOk] = useState(false);
  // credenciais (Service Account JSON)
  const [credConfigured, setCredConfigured] = useState(false);
  const [credEmail, setCredEmail] = useState('');
  const [credProject, setCredProject] = useState('');
  const [credText, setCredText] = useState('');
  const [credBusy, setCredBusy] = useState(false);
  // opções (settings declarativas)
  const [opts, setOpts] = useState(null);
  const [optsBusy, setOptsBusy] = useState(false);

  const linked = calendars.length > 0 ? calendars[0] : null;

  async function loadCalendars() {
    try {
      const r = await apiFetch(`${apiBase}/calendars`);
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || 'erro');
      setCalendars(data.data || []);
      setError(null);
    } catch (e) {
      setError(String(e.message || e));
    } finally {
      setLoading(false);
    }
  }

  async function loadHealth() {
    try {
      const r = await apiFetch(`${apiBase}/health`);
      setHealth(await r.json());
    } catch (e) {
      setHealth({ ok: false, detail: String(e.message || e) });
    }
  }

  async function loadSaInfo() {
    try {
      const r = await apiFetch(`${apiBase}/service-account-info`);
      const data = await r.json();
      if (data.ok) setSaEmail(data.data.email || '');
    } catch { /* ignore */ }
  }

  async function loadCredentials() {
    try {
      const r = await apiFetch(`${apiBase}/credentials`);
      const data = await r.json();
      if (data.ok) {
        setCredConfigured(!!data.data.configured);
        setCredEmail(data.data.client_email || '');
        setCredProject(data.data.project_id || '');
      }
    } catch { /* ignore */ }
  }

  async function salvarCredenciais() {
    const content = credText.trim();
    if (!content) return;
    setCredBusy(true);
    setFeedback(null);
    try {
      const r = await apiFetch(`${apiBase}/credentials`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content }),
      });
      const data = await r.json();
      if (!r.ok || data.ok === false) throw new Error(data.detail || data.error || `HTTP ${r.status}`);
      setCredText('');
      setFeedback({ ok: true, msg: `Credenciais salvas (${data.data.client_email}).` });
      // recarrega tudo que depende das credenciais
      await Promise.all([loadCredentials(), loadHealth(), loadSaInfo(), loadCalendars()]);
    } catch (e) {
      setFeedback({ ok: false, msg: String(e.message || e) });
    } finally {
      setCredBusy(false);
    }
  }

  function onPickFile(e) {
    const file = e.target.files && e.target.files[0];
    e.target.value = ''; // permite re-selecionar o mesmo arquivo
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setCredText(String(reader.result || ''));
    reader.onerror = () => setFeedback({ ok: false, msg: 'Falha ao ler o arquivo.' });
    reader.readAsText(file);
  }

  async function removerCredenciais() {
    if (!confirm('Remover as credenciais da conta de serviço? A integração ficará indisponível até configurar de novo.')) return;
    setCredBusy(true);
    setFeedback(null);
    try {
      const r = await apiFetch(`${apiBase}/credentials`, { method: 'DELETE' });
      const data = await r.json();
      if (!r.ok || data.ok === false) throw new Error(data.detail || data.error || `HTTP ${r.status}`);
      setFeedback({ ok: true, msg: 'Credenciais removidas.' });
      await Promise.all([loadCredentials(), loadHealth(), loadSaInfo(), loadCalendars()]);
    } catch (e) {
      setFeedback({ ok: false, msg: String(e.message || e) });
    } finally {
      setCredBusy(false);
    }
  }

  async function loadSettings() {
    try {
      const r = await fetch(`/api/plugins/google_agenda/settings`, { headers: authHeaders() });
      const data = await r.json();
      if (data.ok) setOpts(data.data.values || {});
    } catch { /* ignore */ }
  }

  async function salvarOpcoes() {
    if (!opts) return;
    setOptsBusy(true);
    setFeedback(null);
    try {
      const r = await fetch(`/api/plugins/google_agenda/settings`, {
        method: 'PUT',
        headers: authHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(opts),
      });
      const data = await r.json();
      if (!r.ok || data.ok === false) throw new Error(data.error || `HTTP ${r.status}`);
      setFeedback({ ok: true, msg: 'Opções salvas.' });
      await Promise.all([loadHealth(), loadCalendars()]);
    } catch (e) {
      setFeedback({ ok: false, msg: String(e.message || e) });
    } finally {
      setOptsBusy(false);
    }
  }

  function setOpt(key, value) {
    setOpts((prev) => ({ ...(prev || {}), [key]: value }));
  }

  async function copySa() {
    try {
      await navigator.clipboard.writeText(saEmail);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch { /* ignore */ }
  }

  async function criarAgenda(e) {
    e.preventDefault();
    if (!nome.trim()) return;
    setBusy(true);
    setFeedback(null);
    try {
      const r = await apiFetch(`${apiBase}/calendars/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ display_name: nome.trim(), owner_email: ownerCreate.trim() }),
      });
      const data = await r.json();
      if (!r.ok || data.ok === false) throw new Error(data.detail || data.error || `HTTP ${r.status}`);
      setFeedback({ ok: true, msg: `Agenda criada: ${data.data.calendar_key}` });
      setNome(''); setOwnerCreate('');
      loadCalendars();
    } catch (e) {
      setFeedback({ ok: false, msg: String(e.message || e) });
    } finally {
      setBusy(false);
    }
  }

  async function conectarExistente(e) {
    e.preventDefault();
    if (!ownerLink.trim()) return;
    setBusy(true);
    setFeedback(null);
    try {
      const r = await apiFetch(`${apiBase}/calendars/link-existing`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ owner_email: ownerLink.trim(), display_name: nomeLink.trim() }),
      });
      const data = await r.json();
      if (!r.ok || data.ok === false) throw new Error(data.detail || data.error || `HTTP ${r.status}`);
      setFeedback({ ok: true, msg: `Agenda conectada: ${data.data.calendar_key}` });
      setOwnerLink(''); setNomeLink('');
      loadCalendars();
    } catch (e) {
      setFeedback({ ok: false, msg: String(e.message || e) });
    } finally {
      setBusy(false);
    }
  }

  async function testar(id) {
    setFeedback(null);
    try {
      const r = await apiFetch(`${apiBase}/calendars/${id}/test`, { method: 'POST' });
      const data = await r.json();
      setFeedback(
        data.ok
          ? { ok: true, msg: `Acesso OK (${(data.detail.busy || []).length} bloqueio(s) hoje)` }
          : { ok: false, msg: data.detail || 'falha no teste' }
      );
    } catch (e) {
      setFeedback({ ok: false, msg: String(e.message || e) });
    }
  }

  async function remover(id, google) {
    if (!confirm(google
      ? 'Apagar a agenda NO GOOGLE e remover o vínculo? Esta ação é destrutiva.'
      : 'Remover o vínculo desta agenda? (a agenda continua no Google)')) return;
    try {
      const r = await apiFetch(`${apiBase}/calendars/${id}?google=${google ? 'true' : 'false'}`, {
        method: 'DELETE',
      });
      const data = await r.json();
      if (!r.ok || data.ok === false) throw new Error(data.detail || `HTTP ${r.status}`);
      loadCalendars();
    } catch (e) {
      setFeedback({ ok: false, msg: String(e.message || e) });
    }
  }

  useEffect(() => {
    loadCredentials();
    loadSettings();
    loadCalendars();
    loadHealth();
    loadSaInfo();
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${proto}//${location.host}/ws`);
    ws.onopen = () => setWsOk(true);
    ws.onclose = () => setWsOk(false);
    ws.onmessage = (msg) => {
      try {
        const ev = JSON.parse(msg.data);
        if (ev.event === 'google_agenda_event_changed' && ev.data) {
          setFeedback({
            ok: true,
            msg: `Mudança no Google: evento ${ev.data.change} (${ev.data.calendar_key})`,
          });
        }
      } catch {}
    };
    return () => ws.close();
  }, []);

  return html`
    <div class="p-6 max-w-3xl mx-auto">
      <div class="flex items-center gap-2 mb-1">
        <h1 class="text-2xl font-bold">Google Agenda</h1>
        <span class=${`text-xs px-2 py-0.5 rounded ${wsOk ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
          ${wsOk ? 'ao vivo' : 'offline'}
        </span>
      </div>
      <p class="text-sm text-wa-secondary mb-4">
        Vincule uma agenda do Google Calendar. Primeiro configure a conta de
        serviço (cole ou suba o arquivo .json), depois crie uma agenda nova ou
        conecte uma já existente compartilhando-a com a conta de serviço.
      </p>

      <div class="border border-wa-border rounded p-4 mb-4 bg-wa-panel">
        <div class="flex items-center justify-between mb-1">
          <h2 class="font-semibold">Conta de serviço (Google)</h2>
          <span class=${`text-xs px-2 py-0.5 rounded ${credConfigured ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
            ${credConfigured ? 'configurada' : 'não configurada'}
          </span>
        </div>
        ${credConfigured
          ? html`
            <p class="text-xs text-wa-secondary mb-2">
              Credenciais salvas no banco${credEmail ? html` · <code class="break-all">${credEmail}</code>` : null}${credProject ? html` · projeto ${credProject}` : null}.
              Para substituir, cole ou suba outro arquivo .json abaixo.
            </p>`
          : html`
            <p class="text-xs text-wa-secondary mb-2">
              Cole o conteúdo do arquivo .json da conta de serviço ou suba o
              arquivo. Ele é validado e guardado no banco de dados (a chave
              privada nunca é exibida de volta).
            </p>`}
        <textarea
          class="wa-field w-full font-mono text-xs rounded px-3 py-2 mb-2"
          rows="6"
          placeholder='{ "type": "service_account", "project_id": "...", "client_email": "...", "private_key": "..." }'
          value=${credText}
          onInput=${(e) => setCredText(e.target.value)}></textarea>
        <div class="flex flex-wrap items-center gap-2">
          <button type="button" disabled=${credBusy || !credText.trim()}
            class="bg-wa-teal text-white rounded px-4 py-2 text-sm disabled:opacity-50"
            onClick=${salvarCredenciais}>
            ${credBusy ? 'Salvando…' : 'Salvar credenciais'}
          </button>
          <label class="text-sm text-wa-teal hover:underline cursor-pointer">
            Subir arquivo .json
            <input type="file" accept=".json,application/json" class="hidden" onChange=${onPickFile} />
          </label>
          ${credConfigured ? html`
            <button type="button" disabled=${credBusy}
              class="text-sm text-red-600 hover:underline ml-auto"
              onClick=${removerCredenciais}>remover credenciais</button>` : null}
        </div>
      </div>

      ${opts && html`
        <div class="border border-wa-border rounded p-4 mb-4 bg-wa-panel">
          <h2 class="font-semibold mb-3">Opções</h2>
          <div class="flex flex-col gap-3">
            <label class="flex items-center gap-2 text-sm">
              <input type="checkbox" checked=${!!opts.enabled}
                onChange=${(e) => setOpt('enabled', e.target.checked)} />
              Integração ativa
            </label>
            <label class="flex flex-col gap-1 text-sm">
              <span class="text-wa-secondary text-xs">Fuso horário (IANA)</span>
              <input class="wa-field rounded px-3 py-2" placeholder="America/Sao_Paulo"
                value=${opts.timezone || ''} onInput=${(e) => setOpt('timezone', e.target.value)} />
            </label>
            <label class="flex flex-col gap-1 text-sm">
              <span class="text-wa-secondary text-xs">E-mail para compartilhar agendas criadas (opcional, leitura)</span>
              <input class="wa-field rounded px-3 py-2" placeholder="fulano@gmail.com"
                value=${opts.share_email || ''} onInput=${(e) => setOpt('share_email', e.target.value)} />
            </label>
            <label class="flex flex-col gap-1 text-sm">
              <span class="text-wa-secondary text-xs">Intervalo do sync reverso (segundos, 30–3600)</span>
              <input type="number" min="30" max="3600" class="wa-field rounded px-3 py-2 w-40"
                value=${opts.sync_intervalo_seg ?? 120}
                onInput=${(e) => setOpt('sync_intervalo_seg', parseInt(e.target.value || '120', 10))} />
            </label>
            <button type="button" disabled=${optsBusy}
              class="bg-wa-teal text-white rounded px-4 py-2 text-sm disabled:opacity-50 self-start"
              onClick=${salvarOpcoes}>${optsBusy ? 'Salvando…' : 'Salvar opções'}</button>
          </div>
        </div>`}

      ${feedback && html`
        <div class=${`mb-3 text-sm ${feedback.ok ? 'text-green-700' : 'text-red-600'}`}>
          ${feedback.msg}
        </div>`}
      ${error && html`<div class="text-red-600 mb-3">Erro: ${error}</div>`}

      ${!credConfigured
        ? html`<div class="text-sm text-wa-secondary">Configure a conta de serviço acima para vincular uma agenda.</div>`
        : html`

      ${health && html`
        <div class=${`mb-4 text-sm rounded p-3 ${health.ok ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
          <b>Conexão Google:</b> ${health.ok ? 'OK' : 'falhou'}
          ${health.ok && health.detail
            ? html` — ${health.detail.count} calendário(s) acessível(is)`
            : health.detail ? html` — ${typeof health.detail === 'string' ? health.detail : JSON.stringify(health.detail)}` : null}
        </div>`}

      ${saEmail && html`
        <div class="mb-4 text-sm rounded p-3 bg-blue-50 text-blue-900">
          <div class="font-semibold mb-1">E-mail da conta de serviço</div>
          <p class="text-xs mb-2">
            Para conectar uma agenda existente, o usuário precisa compartilhar a
            agenda dele com este e-mail (permissão "Fazer alterações nos eventos"):
          </p>
          <div class="flex flex-wrap items-center gap-2">
            <code class="bg-white border rounded px-2 py-1 break-all">${saEmail}</code>
            <button class="text-xs text-blue-700 hover:underline" onClick=${copySa}>${copied ? 'copiado!' : 'copiar'}</button>
            <a class="text-xs text-blue-700 hover:underline" href=${shareMailto(saEmail, ownerLink.trim())} target="_blank" rel="noopener">enviar instruções por e-mail</a>
          </div>
        </div>`}

      ${loading
        ? html`<div>Carregando…</div>`
        : linked
          ? html`
            <div class="border rounded p-4 bg-gray-50">
              <div class="flex items-start gap-3">
                <div class="flex-1">
                  <div class="text-xs uppercase tracking-wide text-gray-400 mb-1">Agenda vinculada</div>
                  <div class="text-sm font-medium">${linked.display_name || linked.calendar_key}</div>
                  <div class="text-xs text-gray-500 mt-0.5">
                    key: <code>${linked.calendar_key}</code>
                    ${linked.owner_email ? html` · ${linked.owner_email}` : null}
                    ${linked.criado_pelo_sistema ? html` · <span class="text-blue-600">criada pelo sistema</span>` : html` · existente`}
                  </div>
                  <div class="text-[11px] text-gray-400 mt-0.5 break-all">${linked.google_calendar_id}</div>
                </div>
                <div class="flex flex-col gap-1 items-end">
                  <button class="text-xs text-blue-600 hover:underline" onClick=${() => testar(linked.id)}>testar acesso</button>
                  <button class="text-xs text-red-600 hover:underline" onClick=${() => remover(linked.id, false)}>remover vínculo</button>
                  ${linked.criado_pelo_sistema ? html`<button class="text-xs text-red-400 hover:underline" onClick=${() => remover(linked.id, true)}>apagar no Google</button>` : null}
                </div>
              </div>
            </div>`
          : html`
            <div class="flex gap-2 mb-4">
              <button onClick=${() => setMode('create')}
                class=${`px-3 py-1.5 rounded text-sm ${mode === 'create' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`}>
                Criar agenda nova
              </button>
              <button onClick=${() => setMode('link')}
                class=${`px-3 py-1.5 rounded text-sm ${mode === 'link' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`}>
                Conectar agenda existente
              </button>
            </div>

            ${mode === 'create'
              ? html`
                <form onSubmit=${criarAgenda} class="border rounded p-4 bg-gray-50">
                  <h2 class="font-semibold mb-1">Criar agenda nova</h2>
                  <p class="text-xs text-gray-500 mb-3">
                    A conta de serviço cria a agenda e (opcional) compartilha com o
                    e-mail informado como editor.
                  </p>
                  <div class="flex flex-col gap-2">
                    <input class="border rounded px-3 py-2" placeholder="Nome da agenda (ex: Agenda Comercial)"
                      value=${nome} onInput=${(e) => setNome(e.target.value)} />
                    <input class="border rounded px-3 py-2" placeholder="E-mail Google do dono (opcional)"
                      value=${ownerCreate} onInput=${(e) => setOwnerCreate(e.target.value)} />
                    <button type="submit" disabled=${busy}
                      class="bg-blue-600 text-white rounded px-4 py-2 disabled:opacity-50 self-start">
                      ${busy ? 'Criando…' : 'Criar agenda'}
                    </button>
                  </div>
                </form>`
              : html`
                <form onSubmit=${conectarExistente} class="border rounded p-4 bg-gray-50">
                  <h2 class="font-semibold mb-1">Conectar agenda existente</h2>
                  <p class="text-xs text-gray-500 mb-3">
                    Primeiro o usuário compartilha a agenda dele com o e-mail da
                    conta de serviço (acima). Depois informe o e-mail Google dele —
                    usamos a agenda principal dessa conta. Sem precisar caçar o ID.
                  </p>
                  <div class="flex flex-col gap-2">
                    <input class="border rounded px-3 py-2" placeholder="E-mail Google do usuário (ex: fulano@gmail.com)"
                      value=${ownerLink} onInput=${(e) => setOwnerLink(e.target.value)} />
                    <input class="border rounded px-3 py-2" placeholder="Nome para exibir (opcional)"
                      value=${nomeLink} onInput=${(e) => setNomeLink(e.target.value)} />
                    <button type="submit" disabled=${busy}
                      class="bg-blue-600 text-white rounded px-4 py-2 disabled:opacity-50 self-start">
                      ${busy ? 'Conectando…' : 'Conectar agenda'}
                    </button>
                  </div>
                </form>`
            }
          `
      }
      `}
    </div>
  `;
}
