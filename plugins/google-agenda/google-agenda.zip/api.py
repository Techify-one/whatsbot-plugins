"""API in-process do plugin google_agenda — consumida pelo plugin e por terceiros.

Outros plugins podem importar isto de forma **lazy** dentro das funções:

    from whatsbot_plugins.google_agenda import api
    if api.is_available():
        info = api.create_event(calendar_key=..., ...)

Todas as funções resolvem ``calendar_key`` → ``google_calendar_id`` pela tabela
``plugin_google_agenda_calendars`` e mantêm o espelho ``plugin_google_agenda_events``
em dia para a reconciliação do sync reverso.

Este plugin é pensado para vincular UMA agenda — mas a camada de dados continua
multi-calendar (o limite de "uma só" é aplicado na camada de rotas/UI).
"""

from __future__ import annotations

import logging
import re
import time
import unicodedata

from sqlalchemy import text

from plugins.context import make_plugin_db

from .service import GoogleCalendarError, GoogleCalendarService, _config

logger = logging.getLogger(__name__)

_service: GoogleCalendarService | None = None


def _svc() -> GoogleCalendarService:
    global _service
    if _service is None:
        _service = GoogleCalendarService()
    return _service


def reset_service() -> None:
    """Recria o service (chamado quando as Settings mudam)."""
    global _service
    if _service is not None:
        _service.reset()
    _service = None


def _tz() -> str:
    return _config("timezone", "America/Sao_Paulo")


# ── Disponibilidade ─────────────────────────────────────────────────────────


def is_available() -> bool:
    """True se a integração está ligada e a Service Account é carregável."""
    if not _config("enabled", True):
        return False
    try:
        _svc()._credentials()  # local: só monta as credenciais, sem rede
        return True
    except Exception:
        logger.debug("[google_agenda] is_available=False", exc_info=True)
        return False


def service_account_email() -> str:
    """E-mail (client_email) da Service Account configurada, ou '' se indisponível.

    É este e-mail que o usuário deve adicionar ao compartilhamento da agenda dele
    no Google Calendar para permitir o acesso (sem precisar caçar o ID da agenda).
    """
    try:
        from .service import load_service_account_info

        info = load_service_account_info()
        return str(info.get("client_email") or "")
    except Exception:
        logger.debug("[google_agenda] service_account_email indisponível", exc_info=True)
        return ""


# ── Resolução de calendar_key ───────────────────────────────────────────────


def _resolve(conn, calendar_key: str) -> tuple[int, str]:
    row = conn.execute(
        text(
            "SELECT id, google_calendar_id FROM plugin_google_agenda_calendars "
            "WHERE calendar_key = :k AND ativo = 1"
        ),
        {"k": calendar_key},
    ).first()
    if not row:
        raise GoogleCalendarError(f"calendar_key desconhecido ou inativo: {calendar_key}")
    return int(row[0]), str(row[1])


# ── Eventos ─────────────────────────────────────────────────────────────────


def create_event(
    calendar_key: str,
    *,
    summary: str,
    start_iso: str,
    end_iso: str,
    description: str = "",
    source_plugin: str = "",
    source_ref: str = "",
    timezone: str | None = None,
) -> dict:
    tz = timezone or _tz()
    body = {
        "summary": summary,
        "description": description,
        "start": {"dateTime": start_iso, "timeZone": tz},
        "end": {"dateTime": end_iso, "timeZone": tz},
    }
    with make_plugin_db() as conn:
        cal_row_id, gcal_id = _resolve(conn, calendar_key)
        ev = _svc().insert_event(gcal_id, body)
        gid = ev.get("id", "")
        etag = ev.get("etag", "")
        # Espelha o que o Google REALMENTE gravou (normaliza o offset p/ o fuso
        # do calendário) — senão o 1º poll veria diferença textual e emitiria
        # um "movido" falso.
        g_start = (ev.get("start") or {}).get("dateTime") or (ev.get("start") or {}).get("date") or start_iso
        g_end = (ev.get("end") or {}).get("dateTime") or (ev.get("end") or {}).get("date") or end_iso
        conn.execute(
            text(
                "INSERT INTO plugin_google_agenda_events "
                "(calendar_id, google_event_id, source_plugin, source_ref, summary, "
                " start_iso, end_iso, status, etag, updated_at) "
                "VALUES (:cid, :gid, :sp, :sr, :sum, :st, :en, 'active', :etag, :ts)"
            ),
            {
                "cid": cal_row_id,
                "gid": gid,
                "sp": source_plugin,
                "sr": source_ref,
                "sum": summary,
                "st": g_start,
                "en": g_end,
                "etag": etag,
                "ts": time.time(),
            },
        )
    return {
        "google_event_id": gid,
        "etag": etag,
        "html_link": ev.get("htmlLink", ""),
    }


def update_event(calendar_key: str, google_event_id: str, **fields) -> dict:
    """Atualiza campos do evento. Aceita ``summary``, ``description``,
    ``start_iso``, ``end_iso`` (+ ``timezone``)."""
    tz = fields.get("timezone") or _tz()
    body: dict = {}
    if "summary" in fields:
        body["summary"] = fields["summary"]
    if "description" in fields:
        body["description"] = fields["description"]
    if fields.get("start_iso"):
        body["start"] = {"dateTime": fields["start_iso"], "timeZone": tz}
    if fields.get("end_iso"):
        body["end"] = {"dateTime": fields["end_iso"], "timeZone": tz}

    with make_plugin_db() as conn:
        cal_row_id, gcal_id = _resolve(conn, calendar_key)
        ev = _svc().patch_event(gcal_id, google_event_id, body)
        sets = ["etag = :etag", "updated_at = :ts", "status = 'active'"]
        params = {
            "etag": ev.get("etag", ""),
            "ts": time.time(),
            "gid": google_event_id,
            "cid": cal_row_id,
        }
        if "summary" in fields:
            sets.append("summary = :sum")
            params["sum"] = fields["summary"]
        if fields.get("start_iso"):
            sets.append("start_iso = :st")
            params["st"] = (ev.get("start") or {}).get("dateTime") or fields["start_iso"]
        if fields.get("end_iso"):
            sets.append("end_iso = :en")
            params["en"] = (ev.get("end") or {}).get("dateTime") or fields["end_iso"]
        conn.execute(
            text(
                "UPDATE plugin_google_agenda_events SET " + ", ".join(sets)
                + " WHERE calendar_id = :cid AND google_event_id = :gid"
            ),
            params,
        )
    return {"google_event_id": google_event_id, "etag": ev.get("etag", "")}


def delete_event(calendar_key: str, google_event_id: str) -> bool:
    with make_plugin_db() as conn:
        cal_row_id, gcal_id = _resolve(conn, calendar_key)
        try:
            _svc().delete_event(gcal_id, google_event_id)
        except GoogleCalendarError as e:
            # 404/410 = já não existe no Google; tratamos como sucesso idempotente.
            if e.status_code not in (404, 410):
                raise
        conn.execute(
            text(
                "UPDATE plugin_google_agenda_events SET status = 'deleted', updated_at = :ts "
                "WHERE calendar_id = :cid AND google_event_id = :gid"
            ),
            {"ts": time.time(), "cid": cal_row_id, "gid": google_event_id},
        )
    return True


def get_event(calendar_key: str, google_event_id: str) -> dict | None:
    with make_plugin_db() as conn:
        _, gcal_id = _resolve(conn, calendar_key)
    try:
        return _svc().get_event(gcal_id, google_event_id)
    except GoogleCalendarError as e:
        if e.status_code in (404, 410):
            return None
        raise


def list_events(calendar_key: str, time_min_iso: str, time_max_iso: str) -> list[dict]:
    with make_plugin_db() as conn:
        _, gcal_id = _resolve(conn, calendar_key)
    params = {
        "timeMin": time_min_iso,
        "timeMax": time_max_iso,
        "singleEvents": "true",
        "orderBy": "startTime",
        "maxResults": 2500,
    }
    return _svc().list_events(gcal_id, params).get("items", [])


def freebusy(
    calendar_keys: list[str], time_min_iso: str, time_max_iso: str
) -> dict[str, list[tuple[str, str]]]:
    """Intervalos ocupados por calendar_key. Aceita vários numa só chamada."""
    if not calendar_keys:
        return {}
    key_to_gid: dict[str, str] = {}
    with make_plugin_db() as conn:
        for key in dict.fromkeys(calendar_keys):  # dedup preservando ordem
            row = conn.execute(
                text(
                    "SELECT google_calendar_id FROM plugin_google_agenda_calendars "
                    "WHERE calendar_key = :k AND ativo = 1"
                ),
                {"k": key},
            ).first()
            if row:
                key_to_gid[key] = str(row[0])

    if not key_to_gid:
        return {key: [] for key in calendar_keys}

    gid_to_key = {gid: key for key, gid in key_to_gid.items()}
    resp = _svc().freebusy(list(key_to_gid.values()), time_min_iso, time_max_iso)
    calendars = resp.get("calendars", {})

    out: dict[str, list[tuple[str, str]]] = {key: [] for key in calendar_keys}
    for gid, info in calendars.items():
        key = gid_to_key.get(gid)
        if key is None:
            continue
        out[key] = [
            (b.get("start", ""), b.get("end", "")) for b in info.get("busy", [])
        ]
    return out


# ── Gestão da agenda ────────────────────────────────────────────────────────


def _slugify(value: str) -> str:
    norm = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    norm = re.sub(r"[^a-z0-9]+", "_", norm.lower()).strip("_")
    return norm or "agenda"


def _gen_calendar_key(conn, display_name: str) -> str:
    base = _slugify(display_name)
    candidate = base
    n = 1
    while conn.execute(
        text("SELECT 1 FROM plugin_google_agenda_calendars WHERE calendar_key = :k"),
        {"k": candidate},
    ).first():
        n += 1
        candidate = f"{base}_{n}"
    return candidate


def create_calendar(
    display_name: str,
    owner_email: str,
    *,
    reader_emails: list[str] = (),
    calendar_key: str = "",
) -> dict:
    """Cria a agenda (dona = Service Account) e compartilha via ACL.

    owner_email vira writer (editar); cada reader_email vira reader (ver).
    """
    tz = _tz()
    gcal = _svc().create_calendar(display_name, tz)
    gcal_id = gcal["id"]

    if owner_email:
        try:
            _svc().insert_acl(gcal_id, owner_email, "writer")
        except GoogleCalendarError:
            logger.warning("[google_agenda] falha ao compartilhar com %s", owner_email, exc_info=True)
    for em in reader_emails:
        if em:
            try:
                _svc().insert_acl(gcal_id, em, "reader")
            except GoogleCalendarError:
                logger.warning("[google_agenda] falha ao compartilhar (leitor) %s", em, exc_info=True)

    with make_plugin_db() as conn:
        if not calendar_key:
            calendar_key = _gen_calendar_key(conn, display_name)
        conn.execute(
            text(
                "INSERT INTO plugin_google_agenda_calendars "
                "(calendar_key, google_calendar_id, display_name, owner_email, "
                " sync_token, criado_pelo_sistema, ativo, created_at) "
                "VALUES (:k, :gid, :dn, :oe, NULL, 1, 1, :ts)"
            ),
            {
                "k": calendar_key,
                "gid": gcal_id,
                "dn": display_name,
                "oe": owner_email or "",
                "ts": time.time(),
            },
        )
    return {"calendar_key": calendar_key, "google_calendar_id": gcal_id}


def register_calendar(
    google_calendar_id: str,
    display_name: str,
    owner_email: str = "",
    calendar_key: str = "",
) -> dict:
    """Registra uma agenda já existente (não criada pelo sistema).

    Para a agenda principal de um usuário, ``google_calendar_id`` é o próprio
    e-mail dele — basta que ele compartilhe a agenda com a Service Account.
    """
    with make_plugin_db() as conn:
        if not calendar_key:
            calendar_key = _gen_calendar_key(conn, display_name or google_calendar_id)
        conn.execute(
            text(
                "INSERT INTO plugin_google_agenda_calendars "
                "(calendar_key, google_calendar_id, display_name, owner_email, "
                " sync_token, criado_pelo_sistema, ativo, created_at) "
                "VALUES (:k, :gid, :dn, :oe, NULL, 0, 1, :ts)"
            ),
            {
                "k": calendar_key,
                "gid": google_calendar_id,
                "dn": display_name,
                "oe": owner_email,
                "ts": time.time(),
            },
        )
    return {"calendar_key": calendar_key, "google_calendar_id": google_calendar_id}


def share_calendar(calendar_key: str, email: str, role: str = "reader") -> bool:
    with make_plugin_db() as conn:
        _, gcal_id = _resolve(conn, calendar_key)
    _svc().insert_acl(gcal_id, email, role)
    return True


def delete_calendar(calendar_key: str, *, delete_in_google: bool = False) -> bool:
    """Desativa o vínculo. Com ``delete_in_google`` apaga a agenda no Google
    (DESTRUTIVO — só para agendas criadas pelo sistema)."""
    with make_plugin_db() as conn:
        cal_row_id, gcal_id = _resolve(conn, calendar_key)
        if delete_in_google:
            try:
                _svc().delete_calendar(gcal_id)
            except GoogleCalendarError as e:
                if e.status_code not in (404, 410):
                    raise
        conn.execute(
            text("UPDATE plugin_google_agenda_calendars SET ativo = 0 WHERE id = :id"),
            {"id": cal_row_id},
        )
    return True


def active_calendar_count() -> int:
    """Quantas agendas ativas existem (o plugin trava em no máximo 1)."""
    with make_plugin_db() as conn:
        row = conn.execute(
            text("SELECT COUNT(*) FROM plugin_google_agenda_calendars WHERE ativo = 1")
        ).first()
    return int(row[0]) if row else 0


def list_calendars() -> list[dict]:
    with make_plugin_db() as conn:
        rows = conn.execute(
            text(
                "SELECT id, calendar_key, google_calendar_id, display_name, owner_email, "
                " criado_pelo_sistema, ativo, sync_token, created_at "
                "FROM plugin_google_agenda_calendars WHERE ativo = 1 "
                "ORDER BY LOWER(display_name)"
            )
        ).mappings().all()
    return [dict(r) for r in rows]
