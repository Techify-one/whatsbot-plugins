"""Background task do plugin Google Agenda + reset de credenciais.

* **`google-agenda-sync-loop`** — a cada ``sync_intervalo_seg`` segundos
  roda ``sync.poll_all()`` num thread, detectando eventos apagados/movidos
  direto no Google e emitindo ``google_agenda.event.changed``.

* **`plugin.settings.changed`** — quando as Settings deste plugin mudam
  (novo JSON de Service Account, novo fuso), descarta as credenciais em cache
  para que a próxima chamada recarregue.
"""

from __future__ import annotations

import asyncio
import logging

logger = logging.getLogger(__name__)

_task_sync: asyncio.Task | None = None

# Fallback caso as Settings ainda não tenham sido salvas.
_DEFAULT_INTERVAL = 120


def _sync_interval_seg() -> int:
    from .service import _config

    try:
        return max(30, int(_config("sync_intervalo_seg", _DEFAULT_INTERVAL)))
    except (TypeError, ValueError):
        return _DEFAULT_INTERVAL


async def _sync_loop() -> None:
    from . import sync
    from .api import is_available

    logger.info("[google_agenda] sync reverso iniciado (intervalo=%ss)", _sync_interval_seg())
    while True:
        try:
            await asyncio.sleep(_sync_interval_seg())
            if not is_available():
                continue
            emitted = await asyncio.to_thread(sync.poll_all)
            if emitted:
                logger.info("[google_agenda] sync: %s mudança(s) emitida(s)", emitted)
        except asyncio.CancelledError:
            logger.info("[google_agenda] sync reverso encerrado")
            raise
        except Exception as exc:
            logger.exception("[google_agenda] sync reverso erro: %s", exc)


async def on_startup(ctx, payload) -> None:
    global _task_sync
    if _task_sync is None or _task_sync.done():
        _task_sync = asyncio.create_task(_sync_loop(), name="google-agenda-sync-loop")


async def on_shutdown(ctx, payload) -> None:
    global _task_sync
    if _task_sync is not None:
        _task_sync.cancel()
    _task_sync = None


async def on_settings_changed(ctx, payload) -> None:
    pid = (payload or {}).get("plugin_id")
    if pid in (None, "google_agenda"):
        from .api import reset_service

        reset_service()
        logger.info("[google_agenda] credenciais resetadas após mudança de settings")


EVENT_HANDLERS = {
    "app.startup": on_startup,
    "app.shutdown": on_shutdown,
    "plugin.settings.changed": on_settings_changed,
}
