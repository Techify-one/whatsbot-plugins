-- Plugin google_agenda: calendario vinculado e espelho de eventos.
-- Tabelas com prefixo obrigatorio plugin_google_agenda_.
--
-- ATENCAO: o splitter de migration respeita aspas simples mas NAO respeita
-- comentarios. Evite ponto-e-virgula, apostrofo e dois-pontos dentro de -- ...

CREATE TABLE IF NOT EXISTS plugin_google_agenda_calendars (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    calendar_key         TEXT    NOT NULL UNIQUE,
    google_calendar_id   TEXT    NOT NULL,
    display_name         TEXT    NOT NULL DEFAULT '',
    owner_email          TEXT    NOT NULL DEFAULT '',
    sync_token           TEXT,
    criado_pelo_sistema  INTEGER NOT NULL DEFAULT 0,
    ativo                INTEGER NOT NULL DEFAULT 1,
    created_at           REAL    NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_google_agenda_calendars_ativo_idx
    ON plugin_google_agenda_calendars (ativo);

CREATE TABLE IF NOT EXISTS plugin_google_agenda_events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    calendar_id     INTEGER NOT NULL REFERENCES plugin_google_agenda_calendars(id),
    google_event_id TEXT    NOT NULL,
    source_plugin   TEXT    NOT NULL DEFAULT '',
    source_ref      TEXT    NOT NULL DEFAULT '',
    summary         TEXT    NOT NULL DEFAULT '',
    start_iso       TEXT    NOT NULL DEFAULT '',
    end_iso         TEXT    NOT NULL DEFAULT '',
    status          TEXT    NOT NULL DEFAULT 'active',
    etag            TEXT    NOT NULL DEFAULT '',
    updated_at      REAL    NOT NULL
);

CREATE INDEX IF NOT EXISTS plugin_google_agenda_events_cal_idx
    ON plugin_google_agenda_events (calendar_id);

CREATE INDEX IF NOT EXISTS plugin_google_agenda_events_gid_idx
    ON plugin_google_agenda_events (google_event_id);
